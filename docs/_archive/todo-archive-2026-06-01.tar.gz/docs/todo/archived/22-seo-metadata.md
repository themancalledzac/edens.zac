# SEO & Social Metadata — `generateMetadata`

> **Status**: ✅ Done (2026-03-15, updated 2026-03-16) -- on branch `0111-todos-part-01`
> **Archival**: Ready to move to `refactor/archived/` after merge. Remaining: JSON-LD structured data (low priority).
> **Priority**: Critical
> **Effort**: ~2-3 hours
> **Origin**: Codebase review 2026-03-15

---

## Problem

Zero `generateMetadata` exports exist in the entire `app/` directory. Every page shows the generic root title "Edens Zac" with no per-page description, no Open Graph tags, and no social preview images.

For a photography portfolio shared on social media, missing `og:image` means links on Twitter/Slack/Instagram show **no preview image**.

---

## Current State

- `app/layout.tsx` defines a title template `'%s | Edens Zac'` — but no page populates `%s`
- No `og:title`, `og:description`, or `og:image` on any collection page
- No structured data (JSON-LD) for photography content
- No per-page `description` meta tags
- `app/[slug]/page.tsx` has no `generateMetadata` export
- `app/collectionType/[collectionType]/page.tsx` has no `generateMetadata` export

---

## Fix

### Dynamic Collection Pages (`app/[slug]/page.tsx`)

```tsx
import type { Metadata } from 'next';

export async function generateMetadata({ params }: CollectionPageProps): Promise<Metadata> {
  const { slug } = await params;
  const collection = await getCollectionBySlug(slug, 0, 1);

  if (!collection) {
    return { title: 'Not Found' };
  }

  return {
    title: collection.title,
    description: collection.description ?? `${collection.title} — photography by Zac Eden`,
    openGraph: {
      title: collection.title,
      description: collection.description ?? undefined,
      images: collection.coverImage?.imageUrl
        ? [{ url: collection.coverImage.imageUrl, width: 1200, height: 630 }]
        : [],
      type: 'website',
    },
    twitter: {
      card: 'summary_large_image',
      title: collection.title,
      images: collection.coverImage?.imageUrl ? [collection.coverImage.imageUrl] : [],
    },
  };
}
```

### Collection Type Pages (`app/collectionType/[collectionType]/page.tsx`)

Similar pattern but with collection type as the title (e.g., "Portfolio | Edens Zac").

### Home Page (`app/page.tsx`)

Static metadata export with default description and a representative OG image.

### Also Add: `generateStaticParams`

For known collection slugs, pre-render at build time:

```tsx
export async function generateStaticParams() {
  const collections = await getAllCollections();
  return collections.map((c) => ({ slug: c.slug }));
}
```

This dramatically improves TTFB for collection pages.

---

## Files

- `app/[slug]/page.tsx` — add `generateMetadata` + `generateStaticParams`
- `app/collectionType/[collectionType]/page.tsx` — add `generateMetadata`
- `app/page.tsx` — add static metadata export
- `app/lib/api/collections.ts` — `getCollectionBySlug` already returns cover image data

---

## Completed

- ✅ **`app/[slug]/page.tsx`** — `generateMetadata` with title, description, OG tags, twitter card, cover image
- ✅ **`app/[slug]/page.tsx`** — `generateStaticParams` for pre-rendering known collection slugs
- ✅ **`app/collectionType/[collectionType]/page.tsx`** — `generateMetadata` with formatted type title
- ✅ **`app/page.tsx`** — static `metadata` export with portfolio description and OG tags

### Remaining

- [ ] **JSON-LD structured data** for photography content (not implemented — lower priority)
- [ ] **OG image dimensions** — cover images may need cropping/resizing to `1200x630` for optimal social previews

## Impact

- Per-page titles in browser tabs and search results
- Social media preview cards with cover images
- Static pre-rendering of known collections (ISR)
- Better SEO indexing for individual collection pages
