# 14 — Mobile Spacing Tuning

> **Todoist ID**: `6XjghMJ8QxwrjQqG`
> **Category**: Quick Win
> **Estimated effort**: ~30-45 min

## Problem

Mobile spacing was partially tuned during the Phase 3 refactor (2026-03-13) — `--space-mobile-border` was dropped from `12px` to `4px` and `.hbox`/`.vbox` gap was halved to `0.4rem`. However several things still warrant a careful look:

1. **Compound spacing on mobile**: Each image row has a `4px` top border (`--space-mobile-border`) AND `.row` adds `margin-bottom: 0.4rem` (6.4px) below it. Between two rows that is `4px` + `6.4px` = ~10.4px. Whether that feels right on device needs a real-phone check.
2. **Hardcoded header border override**: `ContentComponent.module.scss` line 57 overrides `.blockContainer` to `border-width: 2px 0 0` for the header row. This is a magic number that should reference `--space-mobile-border` or be a named token.
3. **`blockContainer` also gets `--space-mobile-border`**: The text metadata block on mobile gets the same 4px top border as images. On a standalone metadata row this can feel disconnected from the image above it.
4. **`mobilePadding: 0`** — content is full-bleed on mobile. This is intentional, but combined with a white `border-color` the image separator relies entirely on the white border being visible against the background. If the page background changes this breaks silently.

## Key Files

- `/Users/themancalledzac/Code/edens.zac/app/styles/globals.css` — defines `--space-mobile-border: 4px` (line 47) and breakpoint variables
- `/Users/themancalledzac/Code/edens.zac/app/components/Content/Content.module.scss` — `.image` applies `border-width: var(--space-mobile-border) 0 0 0` (line 4), cleared at `>=768px`
- `/Users/themancalledzac/Code/edens.zac/app/components/Content/ContentComponent.module.scss` — `.blockContainer` applies same border (line 49); header row overrides to `2px 0 0` (line 58); `.row` has `margin-bottom: 0.4rem` mobile / `var(--default-padding)` desktop (line 19-26)
- `/Users/themancalledzac/Code/edens.zac/app/components/Content/BoxRenderer.module.scss` — `.hbox` and `.vbox` both use `gap: 0.4rem` mobile / `0.8rem` desktop
- `/Users/themancalledzac/Code/edens.zac/app/constants/index.ts` — `mobileGridGap: 6.4` (0.4rem), `mobilePadding: 0` (full-bleed), `mobileSlotWidth: 2`
- `/Users/themancalledzac/Code/edens.zac/app/hooks/useViewport.ts` — `isMobile` fires at `< 768px` (BREAKPOINTS.mobile)

## Current Values

```css
/* globals.css */
--space-mobile-border: 4px;           /* top border between images on mobile */
--page-padding-mobile: var(--space-4); /* 1rem = 16px — used by header and .main */
--default-padding: 0.8rem;             /* 12.8px — used by .row margin-bottom on desktop */

/* ContentComponent.module.scss */
.row {
  margin-bottom: 0.4rem;              /* 6.4px — inter-row gap on mobile */
  /* desktop: margin-bottom: var(--default-padding) = 12.8px */
}

.blockContainer {
  border-width: var(--space-mobile-border) 0 0 0;  /* 4px top border */
}

[data-pattern='header'] .blockContainer {
  border-width: 2px 0 0;             /* hardcoded, not a token */
}

/* BoxRenderer.module.scss */
.hbox, .vbox {
  gap: 0.4rem;                        /* 6.4px — between items inside a row */
  /* desktop: gap: 0.8rem = 12.8px */
}
```

```ts
// constants/index.ts
mobileGridGap: 6.4,   // 0.4rem — gap used in layout size calculations
mobilePadding: 0,     // full-bleed, no side padding
```

## Proposed Changes

### 1. Tune `--space-mobile-border` (if 4px still feels too much on device)

```css
/* globals.css */
--space-mobile-border: 2px;   /* try 2px if 4px still feels chunky */
```

Also add a companion token so the header override is no longer a magic number:

```css
--space-mobile-border-header: 2px;  /* lighter separator for text blocks */
```

Then in `ContentComponent.module.scss`:

```scss
:global([data-pattern='header']) .blockContainer {
  border-width: var(--space-mobile-border-header) 0 0;
}
```

### 2. Evaluate `.row` margin-bottom on mobile

Current `0.4rem` (6.4px) row margin stacks on top of the 4px border from the next row = ~10px total. Options:

- **Keep as-is** if 10px looks intentional on device
- **Set to 0** and rely solely on `--space-mobile-border` for row separation (cleaner, one mechanism)
- **Reduce to `0.2rem`** (3.2px) for tighter feel

```scss
/* ContentComponent.module.scss */
.row {
  margin-bottom: 0;  /* rely only on --space-mobile-border for separation */
}
```

### 3. Decide whether `blockContainer` should get the same border as images

If text metadata blocks feel visually disconnected at 4px, either:
- Match images: keep `var(--space-mobile-border)`
- Reduce: use `var(--space-mobile-border-header)` (if token added above)
- Remove entirely: let row margin handle the gap

## Testing

- Chrome DevTools → iPhone 14 Pro (393px width) or Pixel 7 (412px)
- Content width on mobile at 393px = `393 - 0 = 393px` (full-bleed, `mobilePadding: 0`)
- Check with a collection that has: cover image, text metadata block, mix of H5*, H3*, V3*, V1* images
- Scroll through the whole feed — count visible "seams" between rows and assess if spacing feels intentional vs accidental
- Verify the white border is visible on the white page background (it relies on shadow/contrast from the image below)
- Cross-check on a real iPhone if available — DevTools emulation does not replicate the exact rendering of `border-color: white` on a white background

## Related Context

- Archived doc: `todo/refactor/archived/08-mobile.md` — full history of mobile spacing decisions (Issues 1-6)
- Issue 3 in the archived doc is the direct predecessor to this task: border was `12px`, reduced to `4px` on 2026-03-13
- Issue 6 fixed `.hbox` gap and AR-floor to prevent row cramming on mobile
- `LAYOUT.mobilePadding = 0` is intentional: images run edge-to-edge on mobile. The white border is the only separator.
- Do NOT change `.hbox`/`.vbox` `flex-direction` — horizontal pairs on mobile are intentional UX (see Issue 2, Issue 6 in archived doc)
