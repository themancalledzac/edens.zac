# Suspense Boundaries & Streaming SSR

> **Status**: ✅ Partially Done (2026-03-15, updated 2026-03-16) — root loading.tsx created; Suspense wrappers deferred
> **Priority**: High
> **Effort**: ~2-3 hours
> **Origin**: Codebase review 2026-03-15

---

## Completed

- ✅ **`app/loading.tsx`** — created with `LoadingSpinner`. Single root-level file covers all routes via layout inheritance.

Segment-level `loading.tsx` files were initially created but removed -- identical content to root, unnecessary duplication. Only worth adding per-segment files if a route needs a different loading UI (e.g., skeleton layout).

> **Note (2026-03-16)**: This work is on branch `0111-todos-part-01`, not yet merged to `main`. The `app/loading.tsx` file does not exist on `main`.

---

## Remaining

- [ ] **Suspense wrappers in page.tsx files** — wrapping `<CollectionPageWrapper>` in `<Suspense>` for component-level streaming. The root `loading.tsx` provides route-level streaming which may be sufficient.
- [ ] **Remove `force-dynamic`** from `app/page.tsx` once backend `blocks_per_page` bug is fixed — restores ISR caching for home page

---

## Files Created

- `app/loading.tsx`

---

## Impact

- Shell (header, layout chrome) renders immediately
- Spinner shows while data loads
- Perceived performance improvement even if total load time is the same
