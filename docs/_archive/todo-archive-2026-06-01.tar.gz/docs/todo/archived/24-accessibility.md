# Accessibility Fixes

> **Status**: ✅ Mostly Done (2026-03-15, updated 2026-03-16) -- P4 (FullScreenModal nav buttons) deferred. Changes on branch `0111-todos-part-01`.
> **Priority**: Critical
> **Effort**: ~3-4 hours
> **Origin**: Codebase review 2026-03-15

---

## Completed

- ✅ **P1**: Menu items changed from `<h2>` to `<button>` with `type="button"` (About, Contact, Blogs, Create, Update)
- ✅ **P2**: Hamburger SVG wrapped in `<button aria-label="Toggle menu">`
- ✅ **P3**: Social icons wrapped in `<button>` with `aria-label="Visit Instagram"` / `"Visit GitHub"`
- ✅ **P5**: `window.location.href` replaced with `router.push()` for all internal navigation
- ✅ Close button (`CircleX`) wrapped in `<button aria-label="Close menu">`

---

## Remaining

- [ ] **P4**: FullScreenModal prev/next buttons — no visible `<button>` elements for image navigation. Keyboard arrow and swipe work, but keyboard-only / screen-reader users have no discoverable navigation. Needs new UI elements (left/right overlay buttons).

---

## ⚠️ SCSS Review Needed

The `<h2>` → `<button>` and icon `<button>` wrappers added new classes: `.menuButton` (SiteHeader), `.socialButton` (MenuDropdown), `.dropdownCloseIcon` (MenuDropdown). Basic styles were added to the SCSS modules but **visual QA is needed** to verify buttons don't introduce unwanted borders, padding, or background.

---

## Files Changed

- `app/components/SiteHeader/SiteHeader.tsx` — hamburger button wrapper
- `app/components/SiteHeader/SiteHeader.module.scss` — `.menuButton` class
- `app/components/MenuDropdown/MenuDropdown.tsx` — buttons, aria-labels, router.push
- `app/components/MenuDropdown/MenuDropdown.module.scss` — `.socialButton`, `.dropdownCloseIcon` classes
