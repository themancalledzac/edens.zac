# Investigation: Batch getMetadata on Image Select (Item 27)

**Question**: When selecting images on the admin manage/create page, does it fetch metadata one at a time? Should it batch-fetch?

## Findings

No per-image metadata fetch occurs at image select time. Here is how the data flows:

1. **Page load**: `ManageClient.tsx` calls `useCollectionData(slug, ...)` which fetches the full `CollectionUpdateResponseDTO` from the backend. This single response contains:
   - The collection with all its content blocks (including full `ContentImageModel` objects with their metadata already populated)
   - All available metadata for dropdowns: tags, people, locations, cameras, lenses, filmTypes, filmFormats, collections

2. **Image selection**: `handleMultiSelectToggle` simply appends/removes IDs from `selectedImageIds` state. No API call is made.

3. **Opening the metadata editor**: `handleBulkEdit` filters `collection.content` by `selectedImageIds` to get the image objects — these are already in memory from the initial load. `openEditor(firstImage)` opens the modal with the already-fetched image data. No fetch.

4. **The `getMetadata()` call at line 125**: This fetches the full system-wide metadata list for collection dropdown population (`allCollections` state). It fires once on mount, not per image select.

## Conclusion

**No batching is needed.** The design is already optimal:
- Full image metadata (including all relationships) is loaded once per collection page load
- Image selection is pure in-memory filtering
- The modal receives already-complete `ContentImageModel` objects

The only scenario where per-image fetching would become a concern is if the backend started returning partial image objects (without metadata fields populated) in collection responses — but the current `CollectionUpdateResponseDTO` returns full `ContentImageModel` objects.

## What "batch getMetadata" might have been referring to

The todo item may have been anticipating a future pattern where images are fetched lazily (e.g., thumbnail-only on load, then full metadata on demand). This does not exist in the current implementation. If the collection content API is ever changed to return lightweight stubs, a batch fetch on select would be needed at that point.
