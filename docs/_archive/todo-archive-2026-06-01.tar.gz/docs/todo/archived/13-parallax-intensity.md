# 13 — Parallax Intensity Tuning

> **Todoist ID**: `6XjghQ38pvmx3XHp`
> **Category**: Quick Win
> **Estimated effort**: ~30 min

## Problem

The current parallax offset range (`OFFSET_MIN: -50`, `OFFSET_MAX: 100`) produces a 150px total travel range. The asymmetry is intentional — images start shifted upward and travel downward as the user scrolls — but the range may feel too subtle at typical scroll speeds, especially on tall viewport images. Increasing `OFFSET_MIN`/`OFFSET_MAX` will make the parallax motion more pronounced and dramatic without requiring any structural changes to the hook or components.

The SCSS bakes in a matching constraint: `parallaxImage` is rendered at `height: 130%` with `top: -25%`. This overflow budget is what prevents the parallax transform from revealing whitespace at the image edges. Any change to `OFFSET_MIN`/`OFFSET_MAX` must stay within the budget afforded by the 30% overflow (15% above, 15% below the container).

## Key Files

- `/Users/themancalledzac/Code/edens.zac/app/constants/parallax.ts` — single source of truth for all parallax constants including `OFFSET_MIN`, `OFFSET_MAX`, `VIEWPORT_HEIGHT_OFFSET`, and `UPDATE_THRESHOLD`
- `/Users/themancalledzac/Code/edens.zac/app/hooks/useParallax.ts` — consumes `OFFSET_MIN`/`OFFSET_MAX` to calculate `newOffset = OFFSET_MIN + (scrollProgress * offsetRange)`, applies as `translate3d(0, newOffset, 0)` on the `.parallax-bg` element
- `/Users/themancalledzac/Code/edens.zac/app/components/Content/ParallaxImageRenderer.module.scss` — sets `height: 130%` and `top: -25%` on `.parallaxImage`, which defines the overflow budget
- `/Users/themancalledzac/Code/edens.zac/app/components/Content/CollectionContentRenderer.tsx` — the only consumer of `useParallax`; attaches `parallaxRef` to the wrapper div and adds `className="parallax-bg"` to the `<Image>` element when `enableParallax` is true

## Current Implementation

`app/constants/parallax.ts` lines 25–26:

```ts
// Parallax offset range (in pixels)
OFFSET_MIN: -50,
OFFSET_MAX: 100,
```

Total travel: 150px. The image shifts from -50px (entering viewport from bottom) to +100px (exiting viewport at top).

`app/hooks/useParallax.ts` lines 88–89 — offset calculation:

```ts
const offsetRange = PARALLAX_CONSTANTS.OFFSET_MAX - PARALLAX_CONSTANTS.OFFSET_MIN;
const newOffset = PARALLAX_CONSTANTS.OFFSET_MIN + (scrollProgress * offsetRange);
```

`app/components/Content/ParallaxImageRenderer.module.scss` lines 9–10 — overflow budget:

```scss
height: 130%; /* PARALLAX_CONSTANTS.IMAGE_HEIGHT_PERCENTAGE */
top: -25%;    /* PARALLAX_CONSTANTS.IMAGE_TOP_OFFSET */
```

At a 300px container height the image is 390px tall, starting at -75px. That gives ~75px of upward headroom and ~15px of downward headroom before the image edge becomes visible at the current values. The downward budget is the binding constraint — `OFFSET_MAX` must not push the bottom of the image above the container bottom.

## Proposed Changes

Edit `app/constants/parallax.ts` only:

```ts
// Parallax offset range (in pixels)
OFFSET_MIN: -75,  // was -50
OFFSET_MAX: 75,   // was 100
```

This makes the offset symmetric (±75px, 150px total travel — same range) while centering the motion. Alternatively, to increase drama:

```ts
OFFSET_MIN: -80,
OFFSET_MAX: 120,
```

Total travel: 200px. More motion but requires verifying the overflow budget holds on the smallest parallax containers in use (check mobile header row where container height is set by `headerRowHeightRatio: 0.45`).

Before committing, verify the math for the smallest expected container:

- Minimum container height on mobile: estimate ~200px
- Image height at 130%: 260px, `top: -25%` = -50px, so image spans -50px to +210px
- At `OFFSET_MAX: 120`, image bottom = 260px - 50px + 120px = 330px — exceeds container (200px), which is fine since the image is taller than the container and overflow is hidden

The safe rule of thumb: `OFFSET_MAX < (imageHeight - containerHeight) / 2` where `imageHeight = containerHeight * 1.3`.

## Testing

1. Run the dev server and open the home page or any collection page that shows parallax cards.
2. Scroll slowly through several parallax images and observe whether the motion feels more pronounced.
3. Check edge cases — cards at the very top and bottom of the page should not show whitespace at image edges at any scroll position.
4. Resize to mobile viewport and repeat the scroll check.
5. No automated tests cover visual parallax behavior; this is a manual visual verification.
