# Dead Dependencies Cleanup

> **Status**: ✅ Done (2026-03-15, updated 2026-03-16) -- on branch `0111-todos-part-01`
> **Archival**: Ready to move to `refactor/archived/` after merge.
> **Priority**: High
> **Effort**: ~1-2 hours
> **Origin**: Codebase review 2026-03-15

---

## Completed

### Removed (873 packages total)

| Package | Size Impact |
|---------|------------|
| `@mui/material` + `@mui/icons-material` | ~300KB gzipped |
| `@emotion/react` + `@emotion/styled` | ~30KB gzipped |
| `@react-spring/parallax` | ~150KB unparsed |
| `nprogress` | ~5KB |
| `lodash` | ~70KB |
| `aws-amplify` | Very large |
| `react-zoom-pan-pinch` | ~30KB |

All verified to have zero imports in `app/` directory. No `pages/` directory exists.

### Moved to devDependencies

| Package | From | To |
|---------|------|----|
| `stylelint` | `dependencies` | `devDependencies` |
| `stylelint-config-standard-scss` | `dependencies` | `devDependencies` |
| `stylelint-prettier` | `dependencies` | `devDependencies` |
| `@next/eslint-plugin-next` | `dependencies` | `devDependencies` |

### Also

- ✅ **Deleted `InstagramIcon.jsx`** — replaced with typed `InstagramIcon.tsx`

---

## Files Changed

- `package.json` — removed 9 unused packages, moved 4 to devDependencies
- `package-lock.json` — regenerated (873 packages removed)
- `app/components/Icons/InstagramIcon.jsx` — deleted
- `app/components/Icons/InstagramIcon.tsx` — created (typed replacement)
