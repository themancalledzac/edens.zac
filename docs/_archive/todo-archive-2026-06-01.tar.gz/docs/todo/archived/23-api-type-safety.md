# API Type Safety — `null as unknown as T` and Error Handling

> **Status**: ✅ Done (2026-03-15, updated 2026-03-16) -- on branch `0111-todos-part-01`
> **Archival**: Ready to move to `refactor/archived/` after merge.
> **Priority**: Critical
> **Effort**: ~2-3 hours
> **Origin**: Codebase review 2026-03-15

---

## Completed

- ✅ **Fixed `null as unknown as T`** — all 3 instances in `core.ts` now return `T | null`; all 10 wrapper functions updated
- ✅ **Renamed `handleApiError` → `throwApiError`** in `core.ts` (private, always-throws contract now explicit)
- ✅ **Removed `safeJson`** — `getAllCollections`, `getCollectionBySlug`, `getCollectionsByType` migrated to `fetchReadApi`
- ✅ **Removed `getCollectionBySlugAdmin`** — duplicate of `getCollectionBySlug`
- ✅ **Removed re-export** from `manageUtils.ts` — 3 consumer files updated to import from `apiUtils` directly
- ✅ **Null guard fixes** across 10+ downstream call sites (hooks, admin pages, components)
- ✅ All 808 tests pass; `tsc --noEmit` clean

### ⚠️ Potential Issues

- **All admin API functions now return `T | null`** — call sites that previously assumed non-null have been updated, but any new call sites must handle `null`. This is by design (honest types) but is a behavior change.
- **`validateClientGalleryAccess`** was kept as raw `fetch` (POST, not a good fit for `fetchReadApi`) — has its own inline error handling.

---

## Original Problem (resolved)

### 1. `null as unknown as T` Silent Null Returns

`core.ts` returned `null as unknown as T` on 204 responses — lying to the type system.

### 2. Two `handleApiError` Functions With Conflicting Contracts

Same name, different behavior. The `core.ts` version (always throws) was renamed to `throwApiError`.

### 3. `safeJson` Bypassed Standardized `fetchReadApi`

Local helper duplicated error handling. Removed and migrated to `fetchReadApi`.

---

## Files Changed

- `app/lib/api/core.ts` — return types, rename, null returns
- `app/lib/api/collections.ts` — removed `safeJson`, `getCollectionBySlugAdmin`; migrated to `fetchReadApi`
- `app/lib/api/content.ts` — return types updated
- `app/(admin)/collection/manage/[[...slug]]/manageUtils.ts` — removed re-export, null guards
- `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx` — import path + null guards
- `app/(admin)/collection/manage/[[...slug]]/useCoverImageSelection.ts` — import + null guard
- `app/(admin)/collection/manage/[[...slug]]/useContentReordering.ts` — import + null guard
- `app/(admin)/all-collections/page.tsx` — null guard
- `app/(admin)/all-images/page.tsx` — null guard
- `app/hooks/useCollectionData.tsx` — null guard
- `app/components/ImageMetadata/ImageMetadataModal.tsx` — null guard
- `app/types/Content.ts` — function return types
