# Image Optimization — Remove Global `unoptimized: true`

> **Status**: ✅ Done (2026-03-15, updated 2026-03-16) -- on branch `0111-todos-part-01`
> **Archival**: Ready to move to `refactor/archived/` after merge. Only remaining concern is Amplify deploy verification.
> **Priority**: Critical
> **Effort**: ~2-3 hours
> **Origin**: Codebase review 2026-03-15

---

## Completed

All steps implemented in single session:

- ✅ **Removed `unoptimized: true`** from `next.config.js` — Next.js image optimization now active
- ✅ **Wildcard `remotePatterns`** — changed from env-var-based hostname to `*.cloudfront.net`
- ✅ **`formats` config active** — `['image/avif', 'image/webp']` now functional
- ✅ **Removed `unoptimized` from `About.tsx`** — static asset now optimized
- ✅ **Kept `unoptimized` on `FullScreenModal.tsx`** — intentional for full-res viewing
- ✅ **Added `sizes` prop** to `CollectionContentRenderer.tsx` — `sizes={(max-width: 768px) 100vw, ${Math.round(width)}px}`
- ✅ **Removed `'use client'` from `About.tsx`** — now a Server Component

### ⚠️ Potential Issues

- **Image optimization requires a running image optimization service** — Vercel provides this automatically; AWS Amplify may need `sharp` installed or a custom loader. Verify images still render after deployment.
- **CloudFront wildcard** `*.cloudfront.net` is broad — if the CloudFront domain is known, consider tightening to the exact hostname.

---

## Fix

### Step 1: Configure `remotePatterns` for CloudFront

```js
// next.config.js
images: {
  // REMOVE: unoptimized: true,
  formats: ['image/avif', 'image/webp'],
  remotePatterns: [
    {
      protocol: 'https',
      hostname: '*.cloudfront.net', // adjust to actual CloudFront domain
    },
  ],
},
```

### Step 2: Keep Per-Component `unoptimized` Where Needed

- `FullScreenModal.tsx` — keep `unoptimized` for full-resolution viewing
- Remove `unoptimized` from `About.tsx` (static asset benefits from optimization)

### Step 3: Add `sizes` Prop to Grid Images

`CollectionContentRenderer.tsx` renders images with fixed `width`/`height` but no `sizes` attribute. Without it, Next.js generates a generic `srcSet`. Since `contentWidth` is available via `useViewport`, compute accurate `sizes` values:

```tsx
sizes={`(max-width: 768px) 100vw, ${Math.round(width)}px`}
```

### Step 4: Verify Build

Run `npm run build` and check that images are properly optimized. Test on mobile to confirm smaller payloads.

---

## Files

- `next.config.js:16-28` — remove global `unoptimized`, keep `formats` and add `remotePatterns`
- `app/components/FullScreenModal/FullScreenModal.tsx:73` — keep per-component `unoptimized`
- `app/components/About/About.tsx:36` — remove `unoptimized`
- `app/components/Content/CollectionContentRenderer.tsx:280-299` — add `sizes` prop

---

## Related

- [023-lcp-and-lighthouse.md](023-lcp-and-lighthouse.md) — LCP priority prop threading
- [09-gif-placeholder.md](09-gif-placeholder.md) — GIF poster frame
