# Tags System

> **Status**: Open
> **Priority**: Medium
> **Todoist IDs**: `6Xjgjqqm8WRMHcRG`, `6g8xcmCwg3WFpRgH`
> **Effort**: ~3-4 hours

---

## Current State

### Image Tags — Working
- `ContentImageModel.tags?: ContentTagModel[]` — stored as `{ id, name }[]`
- `ImageMetadataModal` has full tag UI via `UnifiedMetadataSelector`
- `ContentImageUpdateRequest.tags?: TagUpdate` — proper add/remove/new pattern

### Collection Tags — Broken
- `CollectionModel.tags?: string[]` — plain strings, not `{ id, name }[]`
- `CollectionUpdateRequest.tags?: TagUpdate` — uses proper update DTO (inconsistent with model)
- **No tag selector UI** exists on the manage/create form
- `GeneralMetadataDTO.tags` has `{ id, name }[]` from the backend

---

## What's Needed

1. Fix `CollectionModel.tags` from `string[]` to `ContentTagModel[]` (match backend)
2. Add `tags` to `updateData` state in `ManageClient`
3. Wire up `UnifiedMetadataSelector` for collection tags in the form
4. Pass `currentState.tags` as `availableTags`

### Related: "Top bar tags/people/locations clickable"
The site header shows tags/people/locations but they're not clickable/filterable. This needs:
- Route for `/tag/[tagName]` or similar
- Backend endpoint: `getAllByTag` (collections + images)
- UI for tag filter pages

---

## Files

- `app/types/Collection.ts:171` — `tags?: string[]` (the problem)
- `app/types/ImageMetadata.ts:19` — `ContentTagModel = IdNameModel`
- `app/components/ImageMetadata/ImageMetadataModal.tsx:737-768` — existing tag UI to reuse
- `app/components/ImageMetadata/UnifiedMetadataSelector.tsx` — reusable selector
- `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx` — needs tag field in form
