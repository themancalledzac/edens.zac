# 32 — Frontend Critical Review: Sprint Completed (2026-04-18)

> **Sprint:** 2026-04-18 — two sessions (Quick Wins + P1 Polish)
> **Branch:** `0123-critical-review` — 21 commits above `main`
> **Total items addressed:** 21 of ~315 findings

---

## What Was Done

### Quick Wins (10 commits)

All 12 quick-win items from the original table were completed except item 4 (CloudFront preconnect — skipped, low effort but architectural decision needed).

| # | Fix | Commit | Notes |
|---|---|---|---|
| 1 | `revalidateTag` fix | 7b03ca6 | Changed to `'max'` profile — see concerns below |
| 2 | `h2`→`span` in SiteHeader + MenuDropdown nav items | f44ac5c | Fixes heading hierarchy site-wide |
| 3 | `useSearchParams()` replacing `window.location.search` | e7c0f89 | Fixes hydration mismatch in SearchPage |
| 4 | `<link rel="preconnect">` for CloudFront | ❌ Skipped | —  |
| 5 | `Inter({ display: 'swap' })` | a8458b6 | Eliminates FOIT |
| 6 | `themeColor: '#ffffff'` | a8458b6 | Matches light background |
| 7 | `next/dynamic` for FullScreenModal | d131f10 | Removes 258 lines from initial bundle; named-export pattern used |
| 8 | Extract `sortByDate` to `app/utils/` | fa94b6b | Deletes character-for-character duplicate |
| 9 | `aria-hidden="true"` on decorative Lucide icons | dbbd7c1 | SiteHeader, MenuDropdown, FullScreenModal |
| 10 | `role="status" aria-label="Loading"` on LoadingSpinner | 88f4732 | Announces loading state to AT |
| 11 | `revalidate = 3600` on `metadata/page.tsx` | 8503fb8 | Stops dynamic render per visitor |
| 12 | Merge PersonPage + TagPage → `TaxonomyPage` | de912b2 | ~140 lines deleted; `entityName` prop unifies both |

### P1 Polish (11 commits)

| Item | Commit | Files |
|---|---|---|
| `revalidate = 3600` on tag / people / location slug pages | f537487 | app/tag/[slug]/page.tsx, app/people/[slug]/page.tsx, app/location/[slug]/page.tsx |
| `aria-pressed` on ContentFilter chips | 31ab370 | ContentFilter.tsx — rating, people, tags, cameras, locations |
| `aria-pressed` on LocationFilterBar chips | f840da8 | LocationFilterBar.tsx — date sort, highly rated, film/digital, tags, people |
| FullScreenModal: `aria-label="Image viewer"` on dialog | 70646c2 | FullScreenModal.tsx |
| FullScreenModal: remove `unoptimized` prop from Image | 70646c2 | FullScreenModal.tsx |
| Remove `import type React from 'react'` (wrong style) | 70646c2 | FullScreenModal.tsx, useFullScreenImage.tsx |
| Convert `React.*` namespace usages to named imports | 70646c2 | useFullScreenImage.tsx — `RefObject`, `MouseEvent`, `Dispatch`, `SetStateAction` |
| Escape key closes MenuDropdown | 76439a1 | MenuDropdown.tsx — useEffect with keydown listener, always cleans up |
| `BREAKPOINTS.mobile` replaces magic `768` | 76439a1 + 32fde83 | MenuDropdown.tsx, ContactForm.tsx |
| `scrollbar-gutter: stable` on `.scroll-locked` | 1d17878 | app/styles/globals.css |
| `color-scheme: light` on `:root` | 1d17878 | app/styles/globals.css |
| `logger.error` replaces bare `console.error` | 6b0a241 + d9dffc4 | Component.tsx, BoxRenderer.tsx, LocationPageClient.tsx, CollectionContentRenderer.tsx |
| `useMemo` returning a function → `useCallback` | ed04a76 | CollectionContentRenderer.tsx — `hasClickHandler` boolean introduced for cursor/class logic |
| Remaining `console.error` in CollectionContentRenderer | d9dffc4 | NaN detection guard now uses `logger.error` |

---

## Implementation Concerns

### 1. `revalidateTag` second argument (`'max'`)

**Commit:** 7b03ca6
**Original review said:** Remove the second arg — it's silently ignored.
**Reality:** Next.js 16 TypeScript types require the second `profile: string | CacheLifeConfig` argument. Removing it causes a type error. The original assertion was incorrect.
**What we did:** Changed `'default'` to `'max'`. Since the app uses no `use cache` directives anywhere, the profile argument is functionally irrelevant for traditional fetch-based ISR caching. The type is satisfied; behavior is unchanged.
**Future:** If the app ever adopts `use cache`, revisit which profile is appropriate.

### 2. `scrollbar-gutter: stable` is a no-op

**Commit:** 1d17878
**Concern:** `scrollbar-gutter` only applies to scrolling boxes (`overflow: auto | scroll`). `.scroll-locked` uses `overflow: hidden` + `position: fixed`, so the property has no effect per the CSS spec. Additionally, the site already hides scrollbars entirely via `scrollbar-width: none` on `html`, so layout shift from scrollbar appearance/disappearance was never occurring. The CSS is harmless dead code.
**Future:** If scroll-lock layout shift becomes an issue, the correct fix is either `overflow-y: scroll` on `html` always (no shift), or saving/restoring `window.scrollY` in JS.

### 3. `CollectionContentRenderer` — GIF onClick in reorder mode

**Commit:** ed04a76
**Concern:** `handleClick` is attached unconditionally to the GIF branch `onClick` even when `isReorderMode=true`. The `ReorderOverlay` renders on top so the user cannot trigger it, and `handleClick` early-returns on the `isReorderMode` guard anyway. Pre-existing pattern — the `useCallback` refactor did not introduce this.

### 4. `useMemo` → `useCallback` required `hasClickHandler` extraction

**Commit:** ed04a76
**What happened:** The original `useMemo` returned `undefined` or a function, and callers used truthiness (`!!handleClick`, `handleClick ? 'pointer' : 'default'`) to control cursor styles and CSS classes. Converting to `useCallback` (always a function) broke those checks. A separate `hasClickHandler` boolean was introduced that mirrors all guard conditions. The dependency array is complete; no stale-closure risk.

---

## Still Pending — P0 Blockers

These were NOT addressed in this sprint. All remain open.

| # | Item | File(s) | Severity |
|---|---|---|---|
| 4 | **No focus trap in any modal** — Tab escapes to background | FullScreenModal, ImageMetadataModal, TextBlockCreateModal, MenuDropdown | WCAG 2.1 SC 2.1.2 |
| 5 | **`<div onClick>` / `<h2 onClick>` as interactive** — zero keyboard access | CollectionContentRenderer:265,489; ManageClient:858,1119 | WCAG 2.1.1 |
| 7 | **`outline: none` without `:focus-visible` replacement** | 11 files — ContactForm, ContentFilter (×2), ImageMetadataModal, TextBlockCreateModal, fullscreen-image.module.scss (×2), MetadataPage | WCAG 2.4.7 |
| 8 | **`height: 100vh` / no `env(safe-area-inset-*)`** | app/styles/fullscreen-image.module.scss:7,8,79,107 | iPhone notch/Dynamic Island clipping |
| 9 | **`padding-left/right` between flex siblings** (gap rule violation) | Content.module.scss:19,25,31,32; ContentComponent.module.scss:215,223,231,232 | Double-counted 1.2rem spacing |
| 10 | **Two parallel CSS token systems** — `--border-color`, `--text-primary`, etc. not declared globally | ContentFilter.module.scss, LocationFilterBar.module.scss, SearchPage.module.scss, MetadataPage.module.scss | All hex fallbacks active |
| 11 | **`force-dynamic` on home page** — `app/page.tsx:25` | app/page.tsx | Every visitor pays a round-trip |
| 12 | **`BoxRenderer` no `React.memo`** — O(n) re-renders | app/components/Content/BoxRenderer.tsx:42 | 200-image gallery perf |
| 3 | **Unsafe API casts** — `unknown` → `CollectionModel[]` with no validation | app/lib/api/collections.ts:55,63 | Silent undefined on backend rename |

---

## Still Pending — P1 Items

### Accessibility

- `<label>` not linked to control via `htmlFor`/`id` — ImageMetadataModal (all fields), TextBlockCreateModal, ManageClient (dozens)
- No `aria-live` on toasts/status/result counts — ClientGalleryDownload, ImageDownloadOverlay, SearchResults, ManageClient toolbar, ContentFilter "Updating…", ClientGalleryGate error
- No skip link to `<main>` — keyboard users tab through logo + hamburger on every page
- `window.confirm()` for destructive actions — ImageMetadataModal `handleCancel`, `handleDelete`
- No `prefers-reduced-motion` support — LoadingSpinner keyframe, CSS parallax, FullScreenModal `slideUp`, 7× `transition: all` in ImageMetadataModal
- Nav buttons in FullScreenModal disappear at boundary instead of being disabled — SR user can't discover edge
- Error messages not focused on submit failure — ClientGalleryGate, ImageMetadataModal
- `CollectionListSelector.tsx:53` still has `import type React from 'react'` (same wrong pattern as the ones fixed)

### Performance

- No `<link rel="preconnect">` for CloudFront in `app/layout.tsx` — 100-300ms LCP penalty
- Proxy adds server→server hop — `app/lib/api/core.ts:23` routes server-component fetches through `/api/proxy/` instead of hitting backend directly
- `estimateRowAR` called inside `buildRows` inner loop — `app/utils/rowCombination.ts:737,748`. Closed-form estimate eliminates nested `compose` calls
- `computeHeightCoeffs` called 2× per node — `app/utils/rowStructureAlgorithm.ts:107,124`. Memoize by node identity
- Double layout pass on mount — `app/hooks/useViewport.ts` initial height `0` → `targetAR` fallback `1.5` → second computation

### Design system

- `transition: all` anti-pattern — 7+ instances in ImageMetadataModal, ContentFilter, CollectionListSelector, TextBlockCreateModal, ManageClient
- Magic font sizes outside token scale — ContentFilter alone uses 9 values outside `--text-xs…--text-3xl`
- Bare `color: black` / `color: white` in SCSS — SiteHeader.module.scss:49, MenuDropdown.module.scss:154,187, ImageMetadataModal.module.scss:289
- Breakpoints declared three times — SCSS `$bp-*` vars, CSS custom props, JS `BREAKPOINTS` constant
- Border-radius inconsistency — ContentFilter chip `border-radius: 100px` (pill) vs LocationFilterBar chip `border-radius: 3px` (square)
- Inter font disconnected from `--font-sans` token — body font stack ends with stray `, serif`
- Undeclared token `--color-overlay-light-80` — referenced in ImageMetadataModal.module.scss:737; scale jumps 70→90

### Code quality

- `ManageClient.tsx` 1000+ lines — still a god component
- `SearchPage` ships 24 mock images in production — gate behind `NODE_ENV === 'development'` or remove
- Slug→entity resolution triplicated across tag / person / location route files — extract `resolveEntityFromSlug`
- Three filter components with duplicated chip UI — no `<FilterChip>` primitive yet
- `exactOptionalPropertyTypes: false` in `tsconfig.json` — weakens strict mode
- `useEffect` dep suppression — `app/hooks/useFullScreenImage.tsx:97-123` suppresses `react-hooks/exhaustive-deps` while closing over `currentImage` and `setLoadedImageIds`

---

## Still Pending — P2 Polish (unchanged from original)

- Placeholders don't end with `…`
- Ellipsis written as `...` not `…`, straight quotes instead of curly
- Non-breaking spaces missing from units (`10 MB`, `⌘ K`)
- Magic pixel values in padding (`5px`, `47px`, `60px`, `20px`) outside `--space-*` scale
- Redundant scrollbar hiding applied at 4 CSS levels in globals.css
- Stale unused CSS custom props (`--content-min-width`, `--content-max-width`)
- Empty states are bare `<p>`s with no CTA / icon / suggestion
- 404 page has no search / sitemap link beyond "Return home"
- Error messages don't include fix or next step
- `generateStaticParams` not clearly tied to ISR (slug pages may not prerender)
- Tailwind color names (`--color-gray-300`, `#d1d5db`) leak into custom token system
- `dateBadge` / `cardTypeBadge` declared in globals.css AND re-declared in ContentComponent.module.scss
- Stepper buttons use `←`/`→` as visible labels (SR reads "leftwards arrow")
- `title` attributes used where `aria-label` required (ManageClient date clear)
- Magic `calc(100vh - 15rem)` in ContactForm — breaks if header height changes

---

## Still Pending — Strategic Initiatives (unchanged)

1. **Unify CSS token system** — pick `--color-*`, `--text-*`, `--space-*`, `--radius-*`; rename `--border-color`, `--text-primary`, `--bg-primary`, `--hover-bg`, `--accent-color` everywhere; hex fallbacks disappear; enables dark mode
2. **Modal accessibility primitive** — `<Modal>` wrapping `<dialog>` with focus-trap, `aria-labelledby`, Escape, `inert` on background, `prefers-reduced-motion` guard; replaces FullScreenModal, ImageMetadataModal, TextBlockCreateModal, MenuDropdown
3. **`<FilterChip>` primitive** — `<FilterChip active disabled label count onClick>`; unify ContentFilter, LocationFilterBar, CollectionFilterBar; long-term: merge `GalleryFilterState` + `CollectionFilterState`
4. **Replace `padding-left/right` with `gap`** — Content.module.scss + ContentComponent.module.scss; visual gap from double-counted 1.2rem → correct 0.8rem
5. **Safe-area + `dvh`** — fullscreen-image.module.scss; `100dvh`/`100svh` + `env(safe-area-inset-*)` on wrapper
6. **API boundary runtime validation** — Zod schemas at `app/lib/api/collections.ts`; `as CollectionModel[]` → `schema.parse(data)`
7. **Backend ISR unblock** — resolve `blocks_per_page` `@todo` in `app/page.tsx:25`; restore `revalidate = 3600` on home page
8. **Memoize `BoxRenderer`** — `React.memo(BoxRenderer)` + `useMemo`-stable `childProps`; O(n) → O(1) re-renders
9. **`prefers-reduced-motion` global rule** — add to globals.css; per-component opt-outs where motion is semantically meaningful
10. **BoxTree algorithm cleanup** — memoize `computeHeightCoeffs`; replace `estimateRowAR` with closed-form; profile before/after with 400-image collection
11. **Split `ManageClient.tsx`** — `ManageCollection`, `ManageImages`, `ManageMetadata`, `ManageCoverImage`, `ManageReorder`
