# Branch Review Fixes — `0107-row-refactor-pt-4`

> **Created**: 2026-03-14
> **Source**: Full branch review (5 parallel agents: algorithms, components, SCSS, tests, error handling)
> **Branch stats**: 93 files | +18.5k / -24.3k lines | 24 commits

---

## Critical (fix before merge)

### C1. Double click handler fires twice per click
- **File**: `app/components/Content/CollectionContentRenderer.tsx:334,339`
- **Bug**: Outer `div` gets `onClick` via `wrapperProps` spread AND inner `.imageWrapper` div also attaches `onClick={handleClick}`. Every click fires handler twice (bubbling). In ManageClient this opens editor twice or fires two navigations.
- **Fix**: Remove `onClick` from one of the two elements — keep it on the inner `.imageWrapper` only.

### C2. Layout error catch returns empty array — blank page, zero feedback
- **File**: `app/components/Content/Component.tsx:103-106`
- **Bug**: `catch (error) { console.error(...); return []; }` around the entire layout pipeline. Any error in `buildRows`/`compose`/`optimizeRows` silently produces a blank content area with no user message.
- **Fix**: Let it throw to a React error boundary with a visible fallback, or render an error state component. Replace `console.error` with structured logging.

### C3. BoxRenderer silently returns null for missing sizes — images vanish
- **File**: `app/components/Content/BoxRenderer.tsx:62-63`
- **Bug**: If content ID isn't in the `sizes` map (type mismatch, calculation bug), the image disappears with no log or placeholder.
- **Fix**: Add `console.error` with content ID context, render a visible placeholder `div`.

### C4. setTimeout in useCoverImageSelection has no cleanup — memory leak
- **File**: `app/(admin)/collection/manage/[[...slug]]/useCoverImageSelection.ts:61-63`
- **Bug**: 500ms timeout never stored/cleared. If user navigates away, `setJustClickedImageId` fires on unmounted component.
- **Fix**: Track timer with `useRef`, clear on unmount via `useEffect` cleanup. Same pattern already used correctly in `useFullScreenImage`.

### C5. slotWidth multiplication in calculateBoxTreeAspectRatio is dead code
- **File**: `app/utils/rowStructureAlgorithm.ts:26-43`
- **Bug**: `slotWidth` multiplied into both width AND height cancels out: `(w*s)/(h*s) = w/h`. The `getSlotWidth` call is wasted and the comment "Apply slot width scaling" is misleading.
- **Fix**: Remove the `getSlotWidth` call and dead multiplication. Just return `width / height` with a zero-height guard.

---

## High (should fix before merge)

### H1. Silent catch swallows rollback failure in reorder
- **File**: `app/(admin)/collection/manage/[[...slug]]/useContentReordering.ts:116-117`
- **Bug**: If API save fails AND recovery re-fetch also fails, empty `catch {}` leaves UI showing incorrect optimistic data with no indication.
- **Fix**: Set a secondary error message: `"Additionally, failed to refresh data — please reload the page."` Or call `handleCancelReorder()` to reset to pre-reorder state.

### H2. onExitMultiSelect inline arrow recreates every render — stale closure
- **File**: `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx:204-207`
- **Bug**: Inline function invalidates `useContentReordering`'s `useCallback` dependency array every render.
- **Fix**: Wrap in `useCallback(() => { setIsMultiSelectMode(false); setSelectedImageIds([]); }, [])`.

### H3. Race condition in handleMetadataSaveSuccess
- **File**: `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx:445-454`
- **Bug**: Two sequential `setCurrentState` calls — first sets `fullResponse`, then merges metadata from stale `currentState` captured at callback start, overwriting the fresh response.
- **Fix**: Merge in a single `setCurrentState` call, or use functional updater form `setCurrentState(prev => ...)` for the second call.

### H4. compose() has unbounded recursion — stack overflow risk
- **File**: `app/utils/rowCombination.ts:377-405`
- **Bug**: No depth guard on recursive composition. `MAX_ROW_IMAGES=8` provides some protection, but `compose` itself has no safeguard.
- **Fix**: Add `depth` parameter (default 0), max 10, fallback to `hChain(images)`.

### H5. Native `<img>` instead of next/image — violates CLAUDE.md
- **File**: `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx:996`
- **Bug**: `<img src={displayedCoverImage.imageUrl}>` bypasses Next.js image optimization.
- **Fix**: Use `<Image>` from `next/image` with appropriate width/height.

### H6. useViewport stores debounce timer in useState — extra renders
- **File**: `app/hooks/useViewport.ts:20`
- **Bug**: Every resize event causes 2 renders (one for timer state, one for dimensions). Standard pattern is `useRef` for mutable timer IDs.
- **Fix**: Replace `const [debounceTimer, setDebounceTimer] = useState(...)` with `const debounceTimerRef = useRef(...)`.

---

## Medium (address before or shortly after merge)

### M1. LOW_RATED_THRESHOLD defined inside hot while loop
- **File**: `app/utils/rowCombination.ts:611`
- **Fix**: Move `const LOW_RATED_THRESHOLD = 2` to module scope alongside `MIN_FILL_RATIO`, `MAX_FILL_RATIO`, etc.

### M2. _slotWidth parameter accepted but ignored in getEffectiveRating
- **File**: `app/utils/contentRatingUtils.ts:72`
- **Bug**: Callers pass `rowWidth` expecting it to affect the result, but the parameter is prefixed `_` and unused.
- **Fix**: Remove the parameter entirely, or document the deprecation clearly. Update callers.

### M3. NaN fallback debug scaffolding should not ship to production
- **File**: `app/utils/contentRendererUtils.ts:94-152`
- **Bug**: 45 lines of `console.error` + NaN fallback handling. Spams server logs in production.
- **Fix**: Convert to structured logger (dev-only), or remove if data pipeline is now reliable.

### M4. General hook imports from admin route directory — wrong layer
- **File**: `app/hooks/useCollectionData.tsx:5`
- **Bug**: `import { handleApiError } from '@/app/(admin)/collection/manage/[[...slug]]/manageUtils'` — hooks should not depend on page-specific utilities.
- **Fix**: Extract `handleApiError` to `app/lib/api/` or `app/utils/` and import from there.

### M5. CollectionListSelector row missing keyboard accessibility
- **File**: `app/components/CollectionListSelector/CollectionListSelector.tsx:96-101`
- **Bug**: Clickable `<div>` has no `tabIndex`, `role`, or `onKeyDown` handler.
- **Fix**: Add `tabIndex={0}`, `role="button"`, `onKeyDown` for Enter/Space. Or use a `<button>` element.

### M6. ReorderOverlay — contentId prop declared but never used
- **File**: `app/components/Content/ReorderOverlay.tsx:6`
- **Fix**: Remove `contentId` from both the interface and the call site in `CollectionContentRenderer`.

### M7. Header row guard in optimizeBoundaries is dead code
- **File**: `app/utils/rowOptimizer.ts:58`
- **Bug**: `label === 'header'` check — header rows never enter `optimizeBoundaries` since they're prepended after `buildRows`.
- **Fix**: Remove the dead guard.

### M8. getTemplateKey and parseTemplateKey duplicate identical loops
- **File**: `app/utils/rowCombination.ts:196,549`
- **Bug**: `lookupComposition` calls both in sequence, iterating the images array twice.
- **Fix**: Combine into one function or have one call the other.

### M9. 404 detection via string matching is fragile
- **Files**: `app/(admin)/all-collections/page.tsx`, `app/(admin)/all-images/page.tsx`
- **Bug**: `errorMessage.includes('404')` — breaks if message format changes.
- **Fix**: Use structured error objects with status codes from the API layer.

### M10. collectionStorage has 6 empty catch blocks
- **File**: `app/lib/storage/collectionStorage.ts`
- **Bug**: Cache failures are completely silent — impossible to diagnose storage issues.
- **Fix**: Add `console.warn` to all cache catch blocks.

### M11. replayMoves silently skips invalid moves
- **File**: `app/(admin)/collection/manage/[[...slug]]/manageUtils.ts:~460-470`
- **Bug**: `if (fromIndex === -1) continue` with no log — reorder produces wrong results without feedback.
- **Fix**: Add `console.warn` when a move references a non-existent imageId.

### M12. handleDeleteSuccess and handleAddNewChild silent early returns
- **File**: `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx`
- **Bug**: Guard clauses return silently with no user feedback when preconditions fail.
- **Fix**: Set error state or disable the triggering UI when state is unavailable.

---

## Test Coverage Gaps

### T1. CRITICAL — calculateBoxTreeAspectRatio and calculateSizesFromBoxTree have zero dedicated tests
- **File needed**: `tests/utils/rowStructureAlgorithm.test.ts`
- **Cover**: Leaf AR calculation, horizontal/vertical composition AR math, gap subtraction in sizes, zero-height edge case, scaleFactor vertical height scaling.
- **Note**: These functions are the bridge between composition trees and pixel dimensions. A bug here silently produces wrong image sizes everywhere.

### T2. CRITICAL — processContentForDisplay (public API) never directly tested
- **File**: `tests/utils/contentLayout.test.ts`
- **Cover**: Full pipeline (content in, sized rows out), mobile vs desktop, `targetAR` option, empty input, mixed content types.

### T3. HIGH — No tests for buildRows with rowWidth=2 (mobile path)
- **File**: `tests/utils/rowCombination.test.ts`
- **Cover**: Mobile AR-floor bypass (`arFloor = rowWidth <= 2 ? 0 : ...`), mobile row formation.

### T4. HIGH — buildNestedQuad fallback to hChain not directly tested
- **File**: `tests/utils/rowCombination.test.ts`
- **Cover**: `buildNestedQuad` with < 3 verticals falling back to `hChain`.

### T5. MEDIUM — optimizeBoundaries header-row skip not tested
- **File**: `tests/utils/rowOptimizer.test.ts`
- **Note**: If M7 removes this dead code, this gap is resolved.

### T6. MEDIUM — No tests with mixed content types through buildRows
- **Cover**: Text blocks, GIFs, and collection cards flowing through the layout pipeline.

### T7. IMPROVEMENT — Extract shared test fixtures
- **Current**: `createImageContent`, `createHorizontalImage`, `createVerticalImage` copy-pasted across 5+ test files.
- **Fix**: Create `tests/fixtures/contentFixtures.ts` and import from there.

---

## 2026 Best Practice Suggestions

### BP1. Error boundaries over catch-and-return-empty
React 19's error boundaries are mature. Let layout errors propagate to a boundary with a visible fallback UI rather than catching and returning `[]`.

### BP2. useRef over useState for non-render values
Timers, previous values, and mutable IDs should use `useRef` — emphasized in React 19 docs. Applies to `useViewport` (H6) and `useCoverImageSelection` (C4).

### BP3. Structured error logging
Replace all `console.error` calls with a logging utility that integrates with error tracking (Sentry, etc.). Current codebase has 5+ `console.error` calls that will be invisible in production.

### BP4. Property-based tests for layout pipeline
The optimizer tests already use invariant checks (no items lost, score never worsens). Extend this pattern to `compose()` and `buildRows` — fuzz with random content arrays and assert structural properties.

### BP5. Use Map<number, ...> over Map<string, ...> for sizes
Avoids `String(id)` conversion throughout `BoxRenderer` and `calculateSizesFromBoxTree`.

---

## Checklist

- [x] C1 — Double click handler (removed duplicate onClick from Image props; .imageWrapper handles clicks)
- [x] C2 — Layout error boundary (returns { rows: [], layoutError: message })
- [x] C3 — BoxRenderer missing-size placeholder (console.error + .missingImage div)
- [x] C4 — useCoverImageSelection timeout cleanup (flashTimerRef + useEffect cleanup)
- [x] C5 — Dead slotWidth multiplication (removed; just width/height)
- [x] H1 — Reorder rollback error handling (sets secondary error + handleCancelReorder)
- [x] H2 — onExitMultiSelect useCallback (wrapped in useCallback with [] deps)
- [x] H3 — handleMetadataSaveSuccess race condition (single setCurrentState with functional updater)
- [x] H4 — compose() depth guard (MAX_COMPOSE_DEPTH = 10)
- [x] H5 — Native img → next/image (uses Image from next/image)
- [x] H6 — useViewport useRef for timer (debounceTimerRef)
- [x] M1 — LOW_RATED_THRESHOLD at module scope (line 63)
- [x] M2 — _slotWidth parameter removed from getEffectiveRating
- [x] M3 — NaN fallback guarded by process.env.NODE_ENV === 'development'
- [x] M4 — handleApiError extracted to app/utils/apiUtils.ts
- [x] M5 — CollectionListSelector has role="button", tabIndex={0}, onKeyDown
- [x] M6 — contentId prop removed from ReorderOverlay
- [x] M7 — Dead header row guard removed from optimizeBoundaries
- [x] M8 — getTemplateKey/parseTemplateKey combined (single iteration)
- [x] M9 — 404 detection uses ApiError.status (structured)
- [x] M10 — collectionStorage catch blocks have console.warn
- [x] M11 — replayMoves logs console.warn for invalid moves
- [x] M12 — handleDeleteSuccess/handleAddNewChild have console.warn + setError
- [x] T1–T7 — Test coverage gaps (804 tests, 16 suites)
- [ ] BP1–BP5 — Best practice improvements (deferred)
