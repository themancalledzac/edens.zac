# Display Modes, Reorder UX, and Content Toolbar

> Design spec for three display modes, the reorder interaction model, and content toolbar behavior.


---

## Completed ✅

- **Display mode type**: `DisplayMode` updated to include `FIXED`, dropdown labels renamed (Default/Chronological/Fixed)
- **`reorderLonelyVerticals`**: Skipped for FIXED/CHRONOLOGICAL modes
- **Reorder utility functions**: Added to `manageUtils.ts` — `replayMoves`, `applyArrowMove`, `applyPickAndPlace`, `cancelImageMoves`, `buildReorderChangesFromFinalOrder`
- **ManageClient state**: `dragState` replaced with `reorderState`, all reorder handlers wired up
- **ReorderOverlay component**: Created with SCSS
- **Drag-and-drop removal**: Drag props replaced with reorder props through entire tree (ContentBlockWithFullScreen → Component → BoxRenderer → CollectionContentRenderer), drag handlers removed from `contentComponentHandlers.ts`
- **`overflow-x: clip`**: Fixed on `body` in `globals.css` (was `overflow-x: hidden`, which breaks `position: sticky`)
- **Content Toolbar Redesign** (2026-03-13): `.contentHeader`/`.contentHeading`/`.bulkEditControls` removed. Replaced with sticky `.contentToolbar` — item count, Select Multiple, Reorder, status text. All three toolbar modes (default / reorder / multi-select) implemented via `renderToolbarActions()`.
- **Reorder utility tests** (2026-03-13): 35 tests added across `replayMoves`, `applyArrowMove`, `applyPickAndPlace`, `cancelImageMoves`, `buildReorderChangesFromFinalOrder`.
- **Full test suite** (2026-03-13): 753 tests, 15 suites — all green.

---

## Reference: Design Decisions (resolved)

| Question | Answer |
|---|---|
| Insert vs swap on pick-and-place? | Insert — placing A at B's position shifts everything from B onward forward 1 index |
| Arrow tap consolidation? | One move entry per tap (not consolidated) |
| Cancel with overlapping moves? | History replay — remove cancelled image's moves, replay the rest from original |
| "Default" naming? | "Default" label for the `ORDERED` enum value |
| Backend enum? | Three-value enum (`ORDERED \| CHRONOLOGICAL \| FIXED`), `FIXED` added when backend supports it |
| Mobile reorder? | Desktop only for now |

---

## Reference: Display Modes

| Mode | Sort Source | Window Reorder? | User Can Rearrange? |
|---|---|---|---|
| **Default** (ORDERED) | `orderIndex` | Yes | Yes |
| **Chronological** | `createdAt` | No | No |
| **Fixed** | `orderIndex` | No | Yes |

---

## Reference: Reorder State Model

```typescript
interface ReorderMove {
  imageId: number;
  toIndex: number; // target index in the array at time of move
}

interface ReorderState {
  originalOrder: number[]; // image IDs in starting order
  moves: ReorderMove[];    // ordered move history
  pickedUpImageId: number | null;
}
```

- **Current display order** = `replay(originalOrder, moves)`
- **Cancel image X** = remove moves where `imageId === X`, replay the rest
- **Save** = send final order to API (single batch call), exit reorder mode

## Reference: Image Controls in Reorder Mode

```
┌──────────────────────────┐
│ [⇄]                  [✕] │  ⇄ = pick up (top-left)
│                          │  ✕ = cancel this image's move (top-right)
│ [←]   image here     [→] │  ←/→ = shift ±1 position
│                          │
└──────────────────────────┘
```
