# 2. ManageClient Component - ✅ DONE (2026-03-13)

> **Status**: Complete — all 3 hooks extracted
> **File**: `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx`
> **Lines**: 1,172 (was 1,362 before extraction)

---

## Overview

ManageClient is a "god component" handling collection management with too many responsibilities.

---

## State Variables (11 useState calls)

| Line | Variable | Type | Purpose |
|------|----------|------|---------|
| 64 | `saving` | boolean | Tracks collection update in progress |
| 67 | `currentState` | CollectionUpdateResponseDTO | **Single source of truth** |
| 79 | `operationLoading` | boolean | Loading for create/upload/text block |
| 82 | `error` | string \| null | Component-level error messages |
| 88 | `isSelectingCoverImage` | boolean | Cover image selection mode |
| 89 | `isMultiSelectMode` | boolean | Bulk editing mode |
| 90 | `justClickedImageId` | number \| null | Image highlight flash state |
| 91 | `selectedImageIds` | number[] | Selected images for edit/bulk |
| 92 | `isTextBlockModalOpen` | boolean | Text block modal visibility |
| 93-99 | `dragState` | { draggedId, dragOverId } | Drag-and-drop state |
| 101-104 | `createData` | CollectionCreateRequest | CREATE mode form state |
| 133-156 | `updateData` | CollectionUpdateRequest | UPDATE mode form state |

---

## Extraction Opportunities

### Extracted ✅

| Hook | File | Lines |
|------|------|-------|
| `useContentReordering()` | `useContentReordering.ts` | ~170 |
| `useCoverImageSelection()` | `useCoverImageSelection.ts` | ~70 |
| `useImageClickHandler()` | `useImageClickHandler.ts` | ~75 |

### COULD Extract (Medium Impact)

| Hook | Lines Saved | Concern |
|------|-------------|---------|
| `useCollectionForm()` | ~70 | Tight coupling to multiple state variables |
| Form sections as components | ~150 | Would require significant prop passing |

### Should NOT Extract

- Modal rendering (simple conditionals)
- Content display section (already delegated to ContentBlockWithFullScreen)

---

## Props to ContentBlockWithFullScreen (17 props)

```typescript
<ContentBlockWithFullScreen
  content={processedContent}
  priorityBlockIndex={0}                              // Always 0
  enableFullScreenView={false}
  isSelectingCoverImage={isSelectingCoverImage}
  currentCoverImageId={collection.coverImage?.id}
  onImageClick={handleImageClick}
  justClickedImageId={justClickedImageId}
  selectedImageIds={isMultiSelectMode ? selectedImageIds : []}
  currentCollectionId={collection.id}                 // DUPLICATES collectionData.id
  collectionSlug={collection.slug}
  collectionData={collection}
  enableDragAndDrop={collection.displayMode === 'ORDERED'}
  draggedImageId={dragState.draggedId}
  dragOverImageId={dragState.dragOverId}
  onDragStart={handleDragStart}
  onDragOver={handleDragOver}
  onDrop={handleDrop}
  onDragEnd={handleDragEnd}
/>
```

**Issues**:
1. `currentCollectionId` duplicates `collectionData.id`
2. `priorityBlockIndex={0}` is hardcoded
3. 4 drag handlers passed individually instead of grouped

---

## API Patterns

**Pattern A: Via `refreshCollectionAfterOperation()` utility**:
```typescript
const response = await refreshCollectionAfterOperation(
  collection.slug,
  () => createTextContent(collection.slug, textBlock),
  collectionStorage
);
setCurrentState(prev => ({ ...prev!, collection: response.collection }));
```

**Pattern B: Manual pattern**:
```typescript
await updateCollection(collection.id, finalUpdates);
const response = await getCollectionUpdateMetadata(collection.slug);
collectionStorage.update(collection.slug, response.collection);
setCurrentState(prev => ({ ...prev!, collection: response.collection }));
```

**Recommendation**: Higher-order function for common parts:
```typescript
async function withCollectionRefresh<T>(
  operation: () => Promise<T>,
  onSuccess?: (response: CollectionUpdateResponseDTO) => void
): Promise<T>;
```

---

## Implementation Plan

### Step 1: Extract `useContentReordering()` (~100 lines)

```typescript
function useContentReordering(collection, onReorder) {
  const [dragState, setDragState] = useState({ draggedId: null, dragOverId: null });

  const handleDragStart = (id) => { ... };
  const handleDragOver = (id) => { ... };
  const handleDrop = async () => { ... };
  const handleDragEnd = () => { ... };

  return {
    dragState,
    handlers: { handleDragStart, handleDragOver, handleDrop, handleDragEnd }
  };
}
```

### Step 2: Extract `useCoverImageSelection()` (~45 lines)

```typescript
function useCoverImageSelection(collection, onUpdate) {
  const [isSelecting, setIsSelecting] = useState(false);

  const startSelection = () => setIsSelecting(true);
  const cancelSelection = () => setIsSelecting(false);
  const selectCover = async (imageId) => { ... };

  return { isSelecting, startSelection, cancelSelection, selectCover };
}
```

### Step 3: Extract `useImageClickHandler()` (~40 lines)

Handle the 4 click modes:
1. Cover image selection mode
2. Multi-select mode
3. Single image edit mode
4. Normal click (no action)
