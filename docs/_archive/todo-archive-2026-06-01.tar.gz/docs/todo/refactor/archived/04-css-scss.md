# 4. CSS/SCSS Analysis - ✅ Variables Added

> **Status**: Missing CSS variables added, hardcoded values cleanup pending
> **Impact**: 160+ hardcoded color values to replace

---

## Hardcoded Values Count

| Category | Count | Examples |
|----------|-------|----------|
| Hex colors (#xxx) | 20 | `#333` (6x), `#666` (3x), `#888` (3x) |
| RGBA white variants | 90+ | `rgba(255,255,255,0.9)` (14x) |
| RGBA black variants | 15 | `rgba(0,0,0,0.95)` (1x) |
| Error red variants | 8 | `rgb(220 38 38)` |
| Blue accent variants | 9 | `rgba(59,130,246,0.1-1)` |
| Hardcoded `4px` radius | 20 | Should use `var(--radius-1)` |
| Hardcoded `8px` radius | 2 | Should use `var(--radius-2)` |

---

## CSS Variables Added to globals.css ✅

```css
--color-bg-dark: ...
--color-primary-dark: ...
--color-secondary-dark: ...
--color-success: #22c55e;
--color-success-dark: #16a34a;
```

---

## Button Implementations (28 unique classes)

**Files with most duplication**:
- `ManageClient.module.scss`: 9 button classes
- `ImageMetadataModal.module.scss`: 11 button classes
- `TextBlockCreateModal.module.scss`: 3 button classes

**Common pattern that should be shared**:
```scss
padding: 0.75rem 1.5rem;
border-radius: var(--radius-1);
cursor: pointer;
font-weight: 500;
transition: background-color 0.2s;
```

---

## Intentional vs Accidental Differences

**Intentional** (keep separate):
- Modal background opacities (0.95 vs 0.85) - creates hierarchy
- Blue input focus opacity scale (0.1 → 0.3 → 0.5)
- Error red opacity scale (0.2, 0.3, 0.4)

**Accidental** (should consolidate):
- 14 instances of `rgba(255,255,255,0.9)` → `--color-text-primary`
- 14 instances of `rgba(255,255,255,0.2)` → `--color-border-soft`
- All gray hex colors (#333, #666, #888) → semantic variables

---

## Completed (2026-03-13)

- [x] Replace hardcoded color values — white overlay scale (05–90), danger-on-dark, blue accent, shadow-sm added to globals.css; replaced across ImageMetadataModal, TextBlockCreateModal, fullscreen-image, ManageClient
- [x] `border-radius: 4px` → `var(--radius-1)` and `8px` → `var(--radius-2)` throughout modals
- [ ] Create shared button module (deferred)

## Intentional values preserved (not replaced)

- White overlay intermediate steps: `0.03`, `0.08`, `0.12`, `0.15`, `0.25`, `0.85`
- Error red opacity scale: `0.3`, `0.4`, `0.5` (hover/active progressions over `--color-danger-subtle`)
- Modal bg opacities: `rgba(0,0,0,0.95)` vs `rgba(0,0,0,0.85)` (hierarchy)
- CollectionListSelector green checkbox colors (material green, intentionally different from `--color-success`)
