# Refactor Overview

> **Updated**: 2026-03-14
> **Branch**: `0107-row-refactor-pt-4`

---

## Active Work Streams


| #   | Area                           | Status      | Doc                                                                                            |
| --- | ------------------------------ | ----------- | ---------------------------------------------------------------------------------------------- |
| 1   | CSS/SCSS — Hardcoded Values    | COMPLETE    | [04-css-scss.md](04-css-scss.md)                                                               |
| 2   | Display Modes & Toolbar        | COMPLETE    | [10-row-layout-08-display-modes-and-reorder.md](10-row-layout-08-display-modes-and-reorder.md) |
| 3   | Image Reorder (click-to-place) | COMPLETE    | [image-reorder.md](image-reorder.md)                                                           |
| 4   | Branch Review Fixes            | IN PROGRESS | [11-branch-review-fixes.md](11-branch-review-fixes.md)                                         |


---

## Row Layout System

**Phase 1 through Phase 3c — COMPLETE** ✅

- Phase 1 (2026-02-22): Template map replacing `PATTERN_TABLE`. ~560 lines removed.
- Phase 2 (2026-02-23): Row optimizer — boundary +/-1, within-row reorder. `rowOptimizer.ts` ~126 lines.
- Phase 3a (2026-02-24): Standalone promotion + mobile unification (`rowWidth=2`). Net -336 lines.
- Phase 3b (2026-02-26): `buildAtomic` AR-target scoring. `targetAR` threaded through full pipeline.
- Phase 3c (2026-03-13): `compose()` recursive dispatcher + AR-aware row fill. `AR_FLOOR_MULTIPLIER=0.7`, `MAX_ROW_IMAGES=8`, partition at n>=5. Tests and staging in progress.

**753 tests passing across 15 suites.**

**Docs**: [10-row-layout-main.md](10-row-layout-main.md)

---

## Mobile Layout Fixes

6 issues identified — all resolved except Issue 5 (deferred experiment):

1. ~~**chunkSize not adapted for mobile**~~ — resolved by Phase 3a unification
2. ~~**BoxRenderer flex direction**~~ — `.hbox` stacks vertically on mobile
3. ~~**Header row splitting**~~ — cover + text are separate rows on mobile
4. ~~**Inter-image spacing**~~ — reduced `--space-mobile-border` and gap
5. **Text overlay experiment** (deferred)
6. ~~**AR-aware fill overflow**~~ — `arFloor = 0` on mobile prevents 3-4+ items per row

**Details**: [08-mobile.md](08-mobile.md)

---

## CSS/SCSS — Hardcoded Values

160+ hardcoded color values → CSS custom properties. 28 button classes → shared module.

**Details**: [04-css-scss.md](04-css-scss.md)

---

## Completed (archived)

- **Image Reorder** (2026-03-14): Green outline for moved images added (`ReorderOverlay` `.moved` class). All items complete.
- **Display Modes & Toolbar** (2026-03-14): Content toolbar, reorder utilities + tests (753 tests). All work complete.
- **ManageClient Hook Extractions** (2026-03-13): `useContentReordering`, `useCoverImageSelection`, `useImageClickHandler` extracted. 1,362 → 1,172 lines (-190 net).
- **Mobile Layout Fixes** (2026-03-13): Issues 1-4, 6 resolved. Issue 5 (text overlay) deferred.
- **Row Layout Phase 3c** (2026-03-13): `compose()` recursive dispatcher, AR-aware row fill, partition candidates
- **Row Layout Phase 3b** (2026-02-26): `buildAtomic` AR-target scoring, `targetAR` pipeline
- **Row Layout Phase 3a** (2026-02-24): Standalone promotion + mobile unification
- **Row Layout Phase 2** (2026-02-23): Row optimizer — boundary + within-row reorder
- **Row Layout Phase 1** (2026-02-22): Template map refactor
- **BoxTree Migration** (2026-02-06): Recursive rendering, legacy cleanup
- **Bloat Reduction Phase A** (2026-02-23): .gitignore, stale doc deletion, archive cleanup (~26k lines)

