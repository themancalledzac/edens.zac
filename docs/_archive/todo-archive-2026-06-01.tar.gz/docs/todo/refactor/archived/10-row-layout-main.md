# Row Layout System

> Architecture reference for the row layout pipeline.

## Status

- **Phase 1: Template Map** — COMPLETE ✅ (2026-02-22)
- **Phase 2: Row Optimizer** — COMPLETE ✅ (2026-02-23)
- **Phase 3a: Cleanup/Unification** — COMPLETE ✅ (2026-02-24)
- **Phase 3b: buildAtomic + AR-Target Scoring** — COMPLETE ✅ (2026-02-26)
- **Phase 3c: AR-Aware Row Fill + Recursive Composition** — COMPLETE ✅ (2026-03-13)

## Current Architecture

### Pipeline

```
Desktop: content → buildRows(content, 5, targetAR) → optimizeRows → BoxTree → calculateSizes → BoxRenderer
Mobile:  content → buildRows(content, 2, targetAR) → optimizeRows → BoxTree → calculateSizes → BoxRenderer
targetAR = clamp(contentWidth / viewportHeight, 1.5, 3.0)
AR floor = targetAR * 0.7 (triggers pulling more images into row)
MAX_ROW_IMAGES = 8
```

### Core Functions (all in `rowCombination.ts`)

| Function | Role |
|----------|------|
| `compose(images, targetAR, rowWidth)` | Recursive dispatcher: n=1 single, n=2 best of hPair/vStack, n=3-4 buildAtomic, n>=5 partition candidates + single-dominant |
| `buildAtomic(images, targetAR, rowWidth)` | Dominant-extraction + candidate scoring for 3-4 images |
| `estimateRowAR(images, targetAR, rowWidth)` | Quick AR estimate via compose + calculateBoxTreeAspectRatio |
| `lookupComposition(images, targetAR, rowWidth)` | Template map lookup → AtomicComponent + metadata |
| `buildRows(items, rowWidth, targetAR)` | Greedy fill with AR-aware extension (pulls more images if row AR < floor) |
| `acToBoxTree()` | Converts AtomicComponent → BoxTree for rendering |

### Key Types

- `ImageType` — thin view over `AnyContentModel` with pre-computed `ar`, `effectiveRating`, `componentValue`
- `AtomicComponent` — recursive composition tree (`single` | `pair` with direction)
- `TEMPLATE_MAP` — 20 entries keyed by `"hCount-vCount"` (12 use `compose`, 4 use specialized builders, 4 use simple helpers)

### Optimizer (`rowOptimizer.ts`, ~126 lines)

- `rowScore()` — fill-quality metric (1.0 = perfect fill)
- `optimizeBoundaries()` — single forward pass, moves items +/-1 between adjacent rows
- `reorderWithinRows()` — for 2-item rows, puts higher-rated image on left
- `optimizeRows()` — public API, wired into `contentLayout.ts`

### Row Building (`buildRows`)

1. Greedy sequential fill until `isRowComplete()` (standalone skip integrated)
2. AR check: if row AR < `targetAR * 0.7`, keep pulling images (up to MAX_ROW_IMAGES=8)
3. Template map lookup → `compose` scores candidates against `targetAR`
4. Partition strategies for n>=5: balanced splits with rating-sort and AR-sort

### Design Decisions (Phase 3c)

| Decision | Value | Rationale |
|----------|-------|-----------|
| AR_FLOOR_MULTIPLIER | 0.7 | Prevents all-vertical rows from exceeding viewport height |
| MAX_ROW_IMAGES | 8 | Practical cap on images per row |
| Partition threshold | n>=5 | Below 5, single-dominant is sufficient |
| vStack wins ties | Yes | Prefer vertical stacking when AR scores are equal |

## Key Source Files

| File | Role |
|---|---|
| `app/utils/rowCombination.ts` | Template map, row building, compose, buildAtomic, AtomicComponent/BoxTree generation |
| `app/utils/rowOptimizer.ts` | Boundary optimizer and within-row reorder (~126 lines) |
| `app/utils/rowStructureAlgorithm.ts` | BoxTree size calculator (~120 lines) |
| `app/utils/contentRatingUtils.ts` | Rating system, getEffectiveRating, getComponentValue |
| `app/utils/contentLayout.ts` | Layout orchestrator, processContentForDisplay |
| `app/hooks/useViewport.ts` | Viewport dimensions including viewportHeight for targetAR |
| `app/components/Content/Component.tsx` | Computes targetAR, passes through pipeline |
| `app/components/Content/BoxRenderer.tsx` | Recursive renderer |
| `app/utils/contentTypeGuards.ts` | Type guards, getAspectRatio |

## Related Docs

| Doc | Contents |
|---|---|
| [08-display-modes-and-reorder](./10-row-layout-08-display-modes-and-reorder.md) | Three display modes, reorder UX, sticky toolbar |
| [08-mobile](./08-mobile.md) | Mobile layout fixes (5 issues) |
