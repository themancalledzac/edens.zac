# 08 — Mobile Layout Fixes

## Status: DONE (Issues 1–6), DEFERRED (Issue 5), REVISED (Issue 6 CSS approach)

## Summary

After the Phase 2/3 refactor (BoxTree migration, pattern registry removal), the mobile layout had several issues. Issues 1 and 4 were resolved during Phase 3a (mobile unification). Issues 2 and 3 were fixed on 2026-03-13. Issue 5 (text overlay experiment) is deferred. Issue 6 (AR-aware fill overflow) was discovered and fixed on 2026-03-13.

---

## Issues

### Issue 1: `chunkSize` not adapted for mobile

**Symptom**: "The 2-wide doesn't work" — images are grouped incorrectly on mobile.

**Root Cause**: `processContentForDisplay()` receives `chunkSize=4` (LAYOUT.defaultChunkSize) regardless of viewport. On mobile, it should use `mobileSlotWidth=2`.

**Code Path** (what happens today):
1. `CollectionPageWrapper` sets `chunkSize = collection.rowsWide ?? LAYOUT.defaultChunkSize` (4)
2. `Component.tsx:90` calls `processContentForDisplay(content, contentWidth, chunkSize, { isMobile })`
3. Mobile branch in `contentLayout.ts:434-443`:
   ```ts
   const chunks = chunkContent(content, chunkSize);  // chunkSize=4, should be 2 on mobile
   ```
4. `chunkContent` calls `getSlotWidth(item, 4, ...)` — produces desktop-sized slots
5. Result: items are grouped as if 4 slots available, but mobile should only have 2

**Fix Options**:
- **Option A** (simplest): In `processContentForDisplay()`, when `isMobile`, override `chunkSize` to `LAYOUT.mobileSlotWidth` (2).
- **Option B**: Have `Component.tsx` compute `effectiveChunkSize = isMobile ? LAYOUT.mobileSlotWidth : chunkSize` before passing it down.

**Preferred**: Option A — keeps the override internal to the layout engine.

---

### Issue 2: `BoxRenderer` flex direction on mobile

**Original concern**: Multi-image rows rendering side-by-side on narrow screens with chunkSize=4.

**Resolution**: Fixed via Issue 1 (chunkSize=2 on mobile), which limits mobile rows to 1–2 items. The `.hbox` CSS remains `flex-direction: row` on all viewports — this is intentional.

**Final behavior**:
- Single items (high-rated, CV=2): fill row solo, full width
- Paired items (low-rated, CV=1 each): render side-by-side horizontally, each ~50% width with AR-proportional split
- `.hbox` does NOT stack vertically on mobile — horizontal pairs are the desired UX for low-rated image pairs

**Status**: RESOLVED — no CSS direction change needed.

---

### Issue 3: Too much space between images on mobile

**Symptom**: "Too much space between images"

**Root Cause**: Multiple spacing sources compound on mobile:
1. `.image` class has `border-width: var(--space-mobile-border) 0 0 0` → `12px` white top border on every image
2. BoxRenderer `.hbox`/`.vbox` have `gap: 0.8rem` (12.8px) always
3. `.row` has `margin-bottom: 0` on mobile, `margin-bottom: 0.8rem` on desktop

Combined, adjacent images get ~12px (border) + ~12.8px (gap) = ~25px spacing on mobile.

**Fix Options**:
- Reduce `--space-mobile-border` (e.g., from 12px to 4px or 0)
- Reduce BoxRenderer gap on mobile (e.g., `gap: 0.25rem` below 768px)
- Or consolidate: use only one spacing mechanism on mobile (just the border OR just the gap, not both)

**Recommended**:
- Set `--space-mobile-border` to a smaller value (e.g., `4px` or `2px`)
- Add a mobile media query to `.hbox`/`.vbox` reducing gap to `0.25rem`
- This gives a clean, tight look on mobile with ~4–6px between images

---

### Issue 4: Header Row — Cover Image + Text Block forced side-by-side on mobile

**Symptom**: "Top Cover Image and Text Block need to be on their own rows"

**Root Cause**: `createHeaderRow()` in `contentLayout.ts` creates a single row with a horizontal BoxTree combining the cover image and text block. BoxRenderer renders this as `.hbox` (side by side). On mobile, they should be on separate rows.

**Code Path**:
1. `createHeaderRow()` at line 846 builds `[coverImage, metadataBlock]` as a single `RowWithPatternAndSizes`
2. BoxTree is `createSimpleHorizontalBoxTree([coverImage, metadataBlock])` → horizontal combined
3. BoxRenderer renders `.hbox` → side by side on all viewports

**Fix Options**:
- **Option A**: Make `createHeaderRow()` mobile-aware — when called with `isMobile`, return TWO rows (one for cover, one for text) instead of one combined row.
- **Option B**: Use CSS to make `.hbox` stack vertically on mobile (Issue 2 fix) — this would naturally cause the header items to stack. But we'd lose the ability to do the overlay experiment (Issue 5).
- **Option C**: Create separate header row logic for mobile in `processContentForDisplay()` — if `isMobile`, create the cover and text as separate rows instead of calling `createHeaderRow()`.

**Preferred**: Option C — keeps `createHeaderRow()` clean and allows mobile-specific treatment of the header.

---

### Issue 5 (Experiment): Text Block overlayed on Cover Image (mobile)

**Symptom**: User wants to try overlaying the metadata text block on top of the cover image on mobile.

**Concept**: Instead of stacking cover and text as separate rows, the text block would be absolutely positioned over the cover image with a semi-transparent background.

**Implementation Approach**:
1. On mobile, `processContentForDisplay()` creates a SINGLE header row with just the cover image
2. The metadata text block is rendered as an overlay inside the cover image's container
3. This requires:
   - A new mobile-specific header rendering mode in BoxRenderer or CollectionContentRenderer
   - CSS for the overlay positioning (absolute, bottom-aligned, semi-transparent bg)
   - The text block data needs to be passed alongside the cover image somehow

**Alternative approach**:
- Create a dedicated `MobileHeaderRow` component that receives both the cover image and metadata
- Renders the cover full-width with the metadata overlayed at the bottom
- This keeps the overlay logic self-contained rather than threading it through BoxTree

**Decision**: Try the simple approach first (separate rows, Issue 4), then experiment with overlay as a follow-up.

---

### Issue 6: AR-aware fill packs too many items per row on mobile

**Symptom**: Homepage collection cards appear tiny (3 cards crammed into one row at ~155px wide). Collection pages show 4-image rows with images as small as 41px wide. Pattern shows `0h-3v` or `2h-2v` when each item should be standalone or at most a pair.

**Root Cause**: The AR-aware fill override in `buildRows()` (Phase 3c feature) interacts badly with mobile layout. On mobile:
1. `targetAR = max(1.5, viewportWidth/viewportHeight) ≈ 1.5` (portrait phone)
2. `arFloor = targetAR × 0.7 = 1.05`
3. A single vertical collection card (AR ~0.8) fills the row by slot count (CV=2, fill=1.0)
4. But its row AR (0.8) < arFloor (1.05), so `slotCountComplete = true`
5. The algorithm keeps pulling more items to raise the combined AR
6. Result: 3+ items crammed into one row with nested hbox/vbox, all at tiny widths

This is fundamentally wrong for mobile: every full-width image is displayed solo, so row AR naturally equals the image's AR. Vertical images will always have AR < 1.05. The AR optimization was designed for desktop multi-image rows.

**Fix**: Disable AR-floor on mobile by setting `arFloor = 0` when `rowWidth ≤ 2`:
```typescript
const arFloor = rowWidth <= 2 ? 0 : targetAR * AR_FLOOR_MULTIPLIER;
```
This ensures once slot count fills the row, it closes immediately. No AR override.

**CSS approach (revised 2026-03-13)**: `.hbox` is always `flex-direction: row` on both mobile and desktop. Low-rated image pairs display side-by-side horizontally on mobile, each taking AR-proportional pixel widths computed by `calculateSizesFromBoxTree` from the actual `componentWidth`.

The earlier attempt to stack pairs vertically (`flex-direction: column` + `width: 100% !important`) was reverted because the intended mobile UX is horizontal side-by-side pairs for low-rated images — the same layout the algorithm deliberately produces.

**Final state of `BoxRenderer.module.scss`**:
```scss
.hbox {
  display: flex;
  flex-direction: row;
  gap: 0.4rem;

  @media (width >= 768px) {
    gap: 0.8rem;
  }
}
```

**Files changed**:
- `app/utils/rowCombination.ts` — line 651: `arFloor = rowWidth <= 2 ? 0 : ...`
- `app/components/Content/BoxRenderer.module.scss` — `.hbox` always `flex-direction: row`; smaller gap on mobile

**Fixed**: 2026-03-13

---

## Execution Plan

### Step 1: Fix chunkSize for mobile (Issue 1)
**File**: `app/utils/contentLayout.ts`
- In `processContentForDisplay()`, when `isMobile`, override chunkSize to `LAYOUT.mobileSlotWidth`
- This immediately fixes slot grouping on mobile

### Step 2: Fix BoxRenderer flex direction on mobile (Issue 2)
**File**: `app/components/Content/BoxRenderer.module.scss`
- Add mobile media query to `.hbox` so it stacks vertically below 768px

### Step 3: Reduce inter-image spacing on mobile (Issue 3)
**Files**: `app/styles/globals.css`, `app/components/Content/BoxRenderer.module.scss`
- Reduce `--space-mobile-border` from 12px to ~4px
- Reduce BoxRenderer gap on mobile

### Step 4: Split header row on mobile (Issue 4)
**File**: `app/utils/contentLayout.ts`
- In `processContentForDisplay()`, when `isMobile` and `collectionData` is provided, create two rows: one for cover image (full width), one for text block (full width)
- Skip calling `createHeaderRow()` on mobile

### Step 5 (Experiment): Text overlay on cover image (Issue 5)
**Files**: `app/utils/contentLayout.ts`, `app/components/Content/BoxRenderer.tsx` or new component, SCSS
- After Step 4 works, try overlaying the text block on the cover image
- Create a `MobileHeaderRow` component or handle in BoxRenderer
- Add overlay CSS

---

## Key Files

| File | Role |
|------|------|
| `app/utils/contentLayout.ts` | Layout orchestrator — mobile branch at line 434 |
| `app/utils/contentTypeGuards.ts` | `getSlotWidth()` — slot calculation per item |
| `app/utils/contentRatingUtils.ts` | `getComponentValue()` — mobile binary logic at line 177 |
| `app/components/Content/Component.tsx` | Main render component — passes isMobile, chunkSize |
| `app/components/Content/BoxRenderer.tsx` | Recursive renderer — uses `.hbox`/`.vbox` |
| `app/components/Content/BoxRenderer.module.scss` | `.hbox`/`.vbox` always flex-row/column |
| `app/components/Content/ContentComponent.module.scss` | `.row` — switches to column on mobile |
| `app/constants/index.ts` | `mobileSlotWidth=2`, `defaultChunkSize=4`, `mobilePadding=40` |
| `app/styles/globals.css` | `--space-mobile-border: 12px` |
| `app/hooks/useViewport.ts` | Detects `isMobile` at `< 768px` |

---

## Testing Notes

- Use Chrome DevTools mobile emulation (iPhone 14 Pro, 393px width or similar)
- Content width on mobile = `viewportWidth - 40px` (LAYOUT.mobilePadding)
- So at 393px viewport → contentWidth = 353px
- Test with collections that have: cover image, metadata (date/location/description), mixed content (H5★, H3★, V3★, V1★)
- Verify: single images take full width, low-rated pairs are side-by-side horizontally (~50% each), no excessive gaps
