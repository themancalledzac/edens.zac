# Image Reorder Feature

> **Status**: COMPLETE (2026-03-14)

## Overview
Replace the current click-and-drag reorder system with a click-to-select, click-to-place workflow. This provides a more intentional and mobile-friendly reorder experience.

## UI Changes

### Button: "Reorder" (labeled, next to "Select Multiple")
- Toggles reorder mode on/off
- Hidden when `displayMode === 'CHRONOLOGICAL'` (auto-ordered by date)
- Implemented in `ManageClient.tsx` `renderToolbarActions()`

### Button: "Save Order" (conditional)
- Appears only after at least one image has been moved (`moves.length > 0`)
- Fires a single batch API call to persist all changes
- Disappears after successful save or on cancel

## Reorder Workflow

1. User clicks "Reorder" to enter reorder mode (`handleEnterReorderMode`)
2. User clicks the pick-up button (⇄) on an image — image gets blue outline (picked up)
3. User clicks any other image — source is inserted at that position (`handlePlace`)
4. All other images shift accordingly
5. Repeat for additional moves; arrow buttons (←/→) also available per image
6. User clicks "Save Order" to persist via single batch API call (`handleSaveReorder`)

## Visual Feedback

### Picked-up image
- Blue outline + tinted background (`ReorderOverlay.module.scss` `.pickedUp`)

### Moved images
- Green outline (`ReorderOverlay.module.scss` `.moved`) applied when `hasMoved && !isPickedUp`
- `hasMoved` = image appears as `imageId` in the `moves` array (explicit pick-and-place or arrow move)
- Does NOT apply to images that only shifted passively

## Implementation

| File | Role |
|---|---|
| `useContentReordering.ts` | All reorder state and handlers |
| `manageUtils.ts` | `replayMoves`, `applyPickAndPlace`, `applyArrowMove`, `cancelImageMoves`, `ReorderMove` type |
| `BoxRenderer.tsx` | Computes `hasMoved`, `isPickedUp`, `isFirstInOrder`, `isLastInOrder` per image |
| `CollectionContentRenderer.tsx` | Renders `ReorderOverlay` when `isReorderMode` |
| `ReorderOverlay.tsx` + `.module.scss` | Overlay UI with pick/place/arrow/cancel buttons; blue + green outline states |

## TODO
- [x] Add "Reorder Images" button next to "Select Multiple"
- [x] Implement click-to-select, click-to-place reorder logic
- [x] Track manually moved images for green outline styling
- [x] Add "Save Reorder" button (visible only after a move)
- [x] Wire up batch update API call
- [x] Remove/disable old drag-and-drop reorder logic in reorder mode
- [x] Add cancel/reset flow
