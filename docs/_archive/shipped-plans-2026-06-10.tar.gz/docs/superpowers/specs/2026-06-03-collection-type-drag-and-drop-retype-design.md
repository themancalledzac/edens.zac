# Collection-Type Drag-and-Drop Retype — Design Spec

**Date:** 2026-06-03
**Branch:** `0165-collections-parent-column` (continue here per user; no new branch)
**Status:** Approved (Approach A), implementing to completion.

## Problem

On the admin collection **Manage Page**, the right-hand `CollectionListSelector`
renders all collections as an accordion grouped by `CollectionType`
(HOME / PARENT / CLIENT_GALLERY / ART_GALLERY / PORTFOLIO / BLOG / MISC). Today,
clicking a collection's name navigates to that collection's manage page. There is
no fast way to change another collection's *type* without navigating to it and
using the "Collection Type" dropdown + "Update Metadata" save.

## Goal

Let the admin **drag a collection row and drop it onto a different type's section
header** to immediately reassign that collection's type. The change is sent to the
backend right away and the row visually moves to the target section optimistically.
On any non-success response the move is reverted and an error is shown. No page
refetch or reload.

## Locked Decisions

1. **On-drop = instant, revert on error.** Fire the PUT immediately; move the row
   optimistically; on non-success, snap it back and show an error banner. No
   confirm dialog, no undo toast.
2. **Valid drop targets = the 5 assignable types only**: PORTFOLIO, ART_GALLERY,
   BLOG, CLIENT_GALLERY, PARENT (the same set the create/update form offers).
   HOME and MISC headers are inert (no drop handlers, no highlight).
3. **The current ("you are here") row stays inert** — not draggable. Retype the
   current collection via the existing "Collection Type" dropdown.
4. **Header-only drop targets.** Drop onto a type's accordion header (always
   visible, even when collapsed). No body/inter-row drop zones.

### Defaults

- **Desktop-only.** Native HTML5 DnD has no touch support; the manage page is an
  admin/desktop tool.
- **HOME rows are not draggable** (HOME is a pinned singleton; reassigning it via
  drag is dangerous, and the form dropdown doesn't even offer HOME as a target).
- **MISC rows *are* draggable as sources** (lets you clean unknown-typed
  collections into a real type), even though MISC is not a valid drop *target*.
- **Accessibility:** native DnD is not keyboard-accessible. The existing Type
  dropdown remains the keyboard path for the current collection. Documented as a
  known limitation for this admin power-feature.

## Architecture (Approach A — controlled selector, state owned by ManageClient)

The selector stays presentational/controlled. ManageClient owns the source of
truth (`allCollections` state, loaded once from `getMetadata()`), so the optimistic
move is a local state update that re-buckets the row through the existing
`groupsByType` memo — no refetch, no reload.

### Data flow

1. In accordion mode, each row is `draggable` **except** the current row and HOME
   rows. `onDragStart` stashes the dragged `CollectionListModel` in a ref (source
   of truth for the drop) and sets `draggedId` state (for dimming).
2. Only the 5 assignable type-headers get `onDragOver` (preventDefault → allow
   drop), `onDragEnter`/`onDragLeave` (highlight), and `onDrop`. HOME/MISC headers
   get none.
3. On drop, the selector validates: dragged exists **and** target type ≠ dragged
   collection's current type. If valid → `onChangeType(collection, targetType)`.
   Otherwise no-op. `onDragEnd` clears drag state.
4. ManageClient's `useCollectionRetype` hook handles `onChangeType`:
   - capture `previousType = collection.type`
   - optimistic: `setAllCollections(prev => prev.map(c => c.id === id ? { ...c, type: targetType } : c))`
   - `await updateCollection(id, { id, type: targetType })`
   - on `null` or thrown error → revert to `previousType` + `setError(...)`
   - The PUT response describes the *dragged* collection (not the manage-page
     collection), so it is intentionally ignored beyond success/failure — it must
     **not** be written into `currentState`.

### New shared constant

Add to `app/types/Collection.ts` next to `COLLECTION_TYPE_ORDER`:

```ts
/** Collection types an admin can assign (drag-and-drop drop targets + form selects). */
export const ASSIGNABLE_COLLECTION_TYPES: CollectionType[] = [
  CollectionType.PORTFOLIO,
  CollectionType.ART_GALLERY,
  CollectionType.BLOG,
  CollectionType.CLIENT_GALLERY,
  CollectionType.PARENT,
];
```

Used by the selector for target validation. (The two `<select>`s in ManageClient
hardcode this same set; DRYing them is out of scope but the constant makes it
trivial later.)

## Component changes

### `CollectionListSelector.tsx`

- New optional prop: `onChangeType?: (collection: CollectionListModel, targetType: CollectionType) => void`.
- `dragEnabled = accordionMode && !!onChangeType` (single-column mode and the
  ImageMetadataModal usage — which don't pass `onChangeType` — are unaffected).
- Refs/state: `draggedRef` (CollectionListModel | null), `draggedId` (number | null,
  dim), `dragOverType` (CollectionType | null, header highlight).
- Row (accordion branch): `draggable={dragEnabled && !isCurrent && !isHome}`,
  `onDragStart`/`onDragEnd`, `.draggable` + `.dragging` classes.
- Type header (assignable only): `onDragOver`/`onDragEnter`/`onDragLeave`/`onDrop`,
  `.typeHeaderRow--dropTarget` highlight when `dragOverType === t`.
- Drop guard: `dragged && dragged.type !== t` before calling `onChangeType`.

### `CollectionListSelector.module.scss`

- `.draggable { cursor: grab; } .draggable:active { cursor: grabbing; }`
- `.dragging { opacity: 0.4; }`
- `.typeHeaderRow--dropTarget { background: var(--sel-elev-hover); outline: 2px dashed var(--sel-accent-child); outline-offset: -2px; }`

### `useCollectionRetype.ts` (new, colocated with the other manage hooks)

`useCollectionRetype({ setAllCollections, setError }) => { handleChangeType }`.
Optimistic update + `updateCollection` PUT + revert-on-failure, as above.

### `ManageClient.tsx`

- `const { handleChangeType } = useCollectionRetype({ setAllCollections, setError });`
- Pass `onChangeType={handleChangeType}` to `<CollectionListSelector>`.

## Testing

- **`useCollectionRetype`** (`tests/(admin)/collection/manage/[[...slug]]/useCollectionRetype.test.tsx`):
  optimistic apply; revert on `null`; revert on throw; same-type no-op (no PUT).
  Mock `@/app/lib/api/collections`.
- **Selector drag behavior** (extend `tests/components/CollectionListSelector.test.tsx`):
  drag a row + drop on an assignable header fires `onChangeType(collection, type)`;
  same-type drop fires nothing; HOME/MISC headers are not drop targets; current row
  and HOME rows are not draggable (`draggable` attr false). Source-of-truth for the
  drop is the ref, so `fireEvent.dragStart` then `fireEvent.drop` is enough.

## Out of scope

- Touch/mobile drag, keyboard-accessible retype for non-current collections.
- DRYing the two form `<select>`s onto `ASSIGNABLE_COLLECTION_TYPES`.
- Animations/transitions on the re-bucket.

## Files

| File | Change |
| --- | --- |
| `app/types/Collection.ts` | add `ASSIGNABLE_COLLECTION_TYPES` |
| `app/components/CollectionListSelector/CollectionListSelector.tsx` | draggable rows, header drop zones, `onChangeType` |
| `app/components/CollectionListSelector/CollectionListSelector.module.scss` | drag/drop styles |
| `app/(admin)/collection/manage/[[...slug]]/useCollectionRetype.ts` | new optimistic-retype hook |
| `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx` | wire hook + pass `onChangeType` |
| `tests/components/CollectionListSelector.test.tsx` | extend with drag tests |
| `tests/(admin)/collection/manage/[[...slug]]/useCollectionRetype.test.tsx` | new hook tests |
