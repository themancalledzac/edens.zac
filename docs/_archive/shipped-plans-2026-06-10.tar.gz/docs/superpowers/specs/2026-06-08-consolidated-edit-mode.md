# Consolidated Light Edit-Mode (Collection Page) — Design Spec

> **Status:** **Approved (full pivot greenlit 2026-06-08).** Ready for `writing-plans`.
> **Branch:** `0179-mobile-first-admin-dark`. **Date:** 2026-06-08.
> **Supersedes:** the Phase-3 bespoke dark `/manage` page (kept components are reused; the page UI is deleted). Also supersedes this doc's earlier §3.5 4-tab split.
> **Defers:** dark mode → a separate future feature (flip the `[data-surface="dark"]` scope on later); the `Dropdown` / `CollectionListSelector` UX polish → its own follow-up branch.

---

## 0. TL;DR

Editing happens **in place on the real collection page**, which stays **visually identical and light** when not editing. Manage is a **mode of the same `/[slug]` route** (a `?manage=1` searchParam), so entering it adds logic without remounting the page — no full refresh. We thread an `editMode` flag through the **existing** `CollectionPageClient` (not a new wrapper), lift the manage logic into a `useCollectionEdit` hook, and mount **one reusable bottom `EditBar`** that follows context — collection-edit, image-edit, and the transient modes (select/reorder/add). The separate `/collection/manage/[slug]` page is **deleted**; its bottom-bar / Edit-sheet / image-editor pieces are lifted onto the collection page. Tapping title/description/location edits them in place; tapping an image opens the image-edit modal whose bar **is** the same EditBar in image context. Minimal change, maximum reuse, dark deferred.

This fixes three reported issues: the yellow/red buttons bleeding through behind the image-edit modal, the "full refresh" on entering manage, and the dark background hiding date/location (see §3).

## 1. Goals / non-goals

**Goals:** one mental model (edit-in-place); the public (non-edit) collection view stays **pixel-identical**; **entering manage is a same-route mode change with no full refresh / no remount**; reuse Phase 1/2 + the tabbed image editor + text-block editor (they render light by default); **one** `EditBar` component shared across collection-edit, image-edit, and the transient modes; inline on-page editing of title/description/location; remove the bespoke manage page.

**Non-goals (now):** dark mode (separate future feature — the token foundation + surface-aware primitives stay dormant/light); the `Dropdown` / `CollectionListSelector` UX polish (separate follow-up); per-user auth (009); any change to the public view's look/logic/layout.

## 2. Hard rule (regression guard)

The `/[slug]` public view must render **byte-for-byte as it does today**. Edit affordances mount **only** when `editMode` is true. Because `editMode` is threaded through the *same* `CollectionPageClient`, `editMode=false` is literally today's code path. Every step is **visually verified** (mobile + desktop) before commit. (This spec exists because a rushed rendering change broke the public page; that won't recur.)

## 3. The bugs being fixed (context for the architecture)

### 3.1 Yellow/red bar bleeding through the image modal
On the current dark manage page, clicking an image opens the image `MetadataModal`, **but the collection bottom bar stays mounted and renders on top of it**, with the modal's own action row (Delete/Remove/Cancel/Save) peeking out below.

**Root cause (verified):** `ManageClient`'s `.bottomBar` uses `z-index: var(--z-modal-controls, 1002)`; the image modal's `<Modal>` backdrop is `var(--z-modal, 1000)`. The manage bar (1002) sits above the modal (1000) and never changes mode when the modal opens. The faint **yellow/red** cells the user sees are the `MetadataActionRow` (Delete = danger/red, Remove = warning/yellow) behind the manage "Select·Reorder·Add·Edit" bar.

**Fix:** there is **one** bar that follows context. When an image opens, the bar **is** the image-edit bar; the collection/browse bar is not mounted behind it. Z-index is corrected so no bar floats above an open modal.

### 3.2 "Full refresh" when entering manage from the menu
`MenuDropdown.tsx:69` (`handleNavigation.update`) already uses `router.push(\`/collection/manage/${collectionSlug}\`)` — so it is **not** a hard browser reload. The perceived "full refresh" is the **route swap**: `/collection/manage/[[...slug]]` is a separate route segment (under `(admin)`) with its own server component, so the soft nav unmounts the public `/[slug]` tree, mounts the admin tree, re-fetches the collection, and re-runs the BoxTree layout — a visible flash. In App Router, two distinct route segments cannot share a mounted client instance, so a separate manage route can never be seamless.

**Fix:** manage becomes a **mode of the same route** via a searchParam — see §4.1. The user was explicit: *"just adding logic, not new page."*

### 3.3 Dark background hides date/location on entry
On entry the page is currently the dark manage surface, so the (dark-on-dark) date and location metadata are invisible. This is the same root issue as the whole pivot: the manage view must **be** the (light) collection page, not a dark duplicate. Fixed by **not applying** the `[data-surface="dark"]` scope here (§4.1).

## 4. Architecture

### 4.1 One component, same-route mode (searchParam-driven `editMode`)
**Manage is a mode of the `/[slug]` route, not a separate route.** This is the only way (in App Router) to enter manage without remounting the page — the same `CollectionPageClient` instance stays mounted and just gains edit affordances.

- Add **`editMode?: boolean`** (default `false`) to the existing `app/components/ContentCollection/CollectionPageClient.tsx`. `editMode=false` is the current render — **unchanged**. `editMode=true` mounts the `EditBar`, the Edit sheet, the image modal, the admin click-routing, and renders hidden content (`filterVisible=false`).
- Lift `ManageClient`'s edit logic into a **`useCollectionEdit`** hook that composes the existing hooks (`useImageClickHandler`, `useContentReordering`, `useCoverImageSelection`, `useCollectionRetype`, `useMetadataEditor`) + the collection update form (`buildUpdatePayload`, dirty/save) + the mode state machine (`deriveManageMode`). `CollectionPageClient` calls this hook only when `editMode`.
- **Entry / exit (no full refresh):**
  - `app/[slug]/page.tsx` (server) reads the `manage` searchParam. When `?manage=1` **and** `requireAdmin` passes, it fetches with `filterVisible=false` and renders `CollectionPageClient editMode={true}`; otherwise it fetches/gates exactly as today and renders `editMode={false}` (public, **pixel-identical**). Non-admins hitting `?manage=1` just get the public view (param ignored).
  - The "Update" menu item → `router.push(\`/${collectionSlug}?manage=1\`)` (soft, same route segment). The `EditBar` **✕** → `router.push(\`/${collectionSlug}\`)`.
  - A searchParam change is a **soft navigation**: the `/[slug]` server component re-runs (re-fetching with hidden content) but `CollectionPageClient` is **not** remounted (stable position) — it receives `editMode=true` + the fuller content as new props. No unmount, no white flash, no re-layout from scratch: "same page + logic." The param-less public path stays cacheable.
- **Delete** the separate per-collection `app/(admin)/collection/manage/[[...slug]]/` page UI (`ManageClient`). Its hooks move to live beside the shared logic (`useCollectionEdit` + colocated hooks); its presentation (`renderBottomBar`, the Edit sheet, the grid wiring) is replaced by `EditBar` + `CollectionPageClient`'s edit branch. Update the two other admin-context navigations that target the old route — `getCollectionNavigationPath` (`contentComponentHandlers.ts:80`) and `useImageClickHandler.ts:51` — to push `\`/${slug}?manage=1\``. The no-slug `/collection/manage` hub/create entry (`handleNavigation.create`) is **out of scope** and stays as-is.
- **Stop applying** the `(admin)` `[data-surface="dark"]` scope to this edit experience — it renders **light** (this is why date/location are currently invisible, §3.3). The token foundation + surface-aware primitives stay (dark = flip the scope on later).

### 4.2 The one reusable `EditBar`
A single fixed bottom bar of **uniform-height cells** (≥44px, emphasis by color/weight only — never size). Two render shapes driven by context:
- **Mode shape** (browse / select / reorder / add): a single row of action cells.
- **Edit shape** (collection-edit / image-edit): a **tab row** above an **action row**.

| Context | Cells |
|---|---|
| **browse** | Select · Reorder · Add · Edit · **✕** (exit edit → public) |
| **select** | All · Edit(n) · *(Set as cover when 1)* · Remove · Cancel |
| **reorder** | Done · Cancel |
| **add** | Text · Upload · Cancel |
| **collection edit** | tabs `Info · Tags · Structure` + actions `Save · Close` |
| **image edit** | tabs `Info · Camera · Tags · Collections` + actions `Delete/Remove · Cancel · Save` |

- The `MetadataModal`'s inline `.bottomTabRow` + `MetadataActionRow` are **replaced** by `EditBar` (image context). The collection edit sheet uses the **same** `EditBar` (collection context). `Reorder` stays disabled for `CHRONOLOGICAL`; `Add` stays hidden for parent collections — preserving today's gating.
- **Consistent height, not consistent count.** The earlier "always 5 cells" target is relaxed: same component, uniform height, but tab count varies by context (collection 3 tabs, image 4). This is the honest one-component reuse the request calls for.
- **✕ exits** the edit/manage state → back to the public collection view. Closing the image modal returns to the collection edit view.

### 4.3 Inline editing (in scope this round)
In `editMode`, on the collection page itself:
- **Title** → tap to edit in place (text `Input`).
- **Description** → tap to edit in place (`Textarea`).
- **Location** → tap to pick/change (location selector).

Inline edits **commit on blur / Enter** (Escape cancels), write to the **shared** `useCollectionEdit` update buffer, and persist via the existing `updateCollection` path. The Info tab edits the **same** fields against the same buffer, so the two never conflict. Non-edit mode shows them as normal read-only text (unchanged). These render in the collection's metadata TEXT block (`CollectionContentRenderer` TEXT branch); the inline-edit affordance mounts only when `editMode`.

### 4.4 Image edit
In `editMode`, tapping an image opens the **image-edit `MetadataModal`** (renders **light** — no dark scope applied) instead of the fullscreen viewer. Its bar is the **same** `EditBar` in image context (its tabs + Save/Delete/Remove/Cancel). Closing returns to the collection edit view. This is the bug fix from §3 made structural: one bar, one context at a time.

### 4.5 The "Edit" sheet — refined tab content (supersedes the old §3.5)

| Tab | Fields |
|---|---|
| **Info** | Title · Date · Description · Location · **Visibility** · *(client-gallery / parent only:* **Gallery password · Recipients/send***)* |
| **Tags** | Tags · People |
| **Structure** | **Collection Type** · Display mode · Row density · **Collections** (parent / child / sibling via `CollectionListSelector`) · *(home collection only:* child-rating*)* |

- The **Access tab is removed**; its password + recipients fields move into **Info** as a conditional "Client gallery access" group (shown only for `CLIENT_GALLERY` / parent types, matching today's gating). **Visibility** moves from Structure to **Info**. **Type** stays in **Structure**.
- Title / Description / Location are *also* inline-editable on the page (§4.3); the sheet is the explicit/alternate path and holds everything else.
- People keep their separate save (`setCollectionPeople`); gallery access keeps its atomic `saveGalleryAccess` (with parent→children propagation); ratings persist immediately. These existing save paths are reused unchanged — only their tab placement changes.

**Cover image — no read-only display in any tab.** Editing is in-place on the real page, so the cover is already visible. Cover *setting* stays contextual: non-parents via Select-mode "Set as cover"; parents via the child-image picker (shown only while setting, never as a persistent thumbnail).

## 5. Reuse map (what happens to Phase 3)

| Phase 3 piece | Fate |
|---|---|
| Phase 1 fetch fix + `requireAdmin` seam | **Keep** |
| Phase 2 tokens + **surface-aware primitives** | **Keep** — render light by default; dark = flip the scope later |
| Tabbed image editor (`MetadataModal` + `sections/` + `hooks/`) | **Keep** — opens from the collection page in edit mode (light); its inline tab row + `MetadataActionRow` are replaced by `EditBar`; non-destructive bulk Remove + parent cover logic reused |
| Text-block editor (primitives) | **Keep** — opens from Add → Text |
| `ManageClient` 5 hooks + `buildUpdatePayload` + mode machine | **Lift** into `useCollectionEdit` (+ colocated hooks) |
| `ManageClient` `renderBottomBar` + Edit sheet presentation | **Replace** with `EditBar` + `CollectionPageClient` edit branch |
| Bespoke dark `ManageClient` page UI | **Delete** |
| `(admin)` `[data-surface="dark"]` application on the edit experience | **Stop applying** (kept as the future dark-mode switch) |

## 6. Incremental build order (one commit per step, each verified)

1. **Extract the `EditBar` primitive** (uniform cells; mode shape + edit shape); adopt it inside `MetadataModal` (image context) in place of its inline tab row + `MetadataActionRow`. Isolated, low risk.
2. **Ship the bar bug fix** structurally on the current manage page: one context-driven bar — when the image modal is open, the collection bar is not mounted; z-index corrected. (Removes the yellow/red bleed-through.)
3. **Restructure the collection tabs** (Access→Info merge, Visibility→Info, Type stays Structure, Access tab removed); adopt `EditBar` for the collection-edit context.
4. **Extract `useCollectionEdit`** from `ManageClient` (compose the 5 hooks + update form + mode machine).
5. **Thread `editMode` into `CollectionPageClient`**; mount `EditBar` / Edit sheet / image modal / admin click-routing; wire `filterVisible=false`.
6. **Wire the same-route entry** (§4.1): `/[slug]` reads `?manage=1` + `requireAdmin` → `editMode=true` (light, hidden content shown); MenuDropdown "Update" + the two nav helpers (`getCollectionNavigationPath`, `useImageClickHandler`) push `?manage=1`; the ✕ pushes back. Verify **no remount/flash** on enter and exit, and that date/location are visible (light).
7. **Add inline editing** of title/description/location on the page (§4.3).
8. **Delete the old manage route** (`app/(admin)/collection/manage/[[...slug]]/` page UI + `ManageClient`); stop applying the dark scope to the edit experience; relocate any still-referenced hooks/utils.
9. **Verify public pixel-identical** (mobile + desktop); cleanup any orphaned styles/dead code.

Each step runs `tsc --noEmit` + `jest` + `eslint --fix` + `stylelint --fix` (SCSS) + `prettier --write`, plus a visual pass in the preview before commit.

## 7. Out of scope (explicit)
- **Dark mode** for the edit experience — deferred; the scope flip is the future feature.
- **`Dropdown` / `CollectionListSelector` UX+visual polish** — deferred to its own branch (specifics undecided: affordance / multi-select density / add-new flow / touch targets).
- **Per-user auth (009)** — the route is the admin entry for now.
- **Bulk-GIF edit** — unchanged (mixed selections still split before the modal, as today).

## 8. Coverage vs the request

| Request | Section |
|---|---|
| Yellow/red buttons behind the image modal removed | §3.1, §4.4, §6 (step 2) |
| Clicking an image → bar becomes the content/image-edit bar (not the collection bar) | §4.2, §4.4 |
| Image edit screen mimics the collection edit screen (shared component) | §4.2 |
| Move any non-duplicated logic into the new components | §4.1, §5 |
| `info` tab shows access items; Access tab removed | §4.5 |
| Visibility in the `info` tab | §4.5 |
| Cover not shown as an image in Structure | §4.5 |
| Structure = Type · Display/Density · Collections | §4.5 |
| Same bar component, different items by collection vs content | §4.2 |
| **No full refresh entering manage — same page, just add logic** | §3.2, §4.1, §6 (step 6) |
| **Date/location visible on entry (render light, not a dark duplicate)** | §3.3, §4.1 |
| **EditBar far-right ✕ exits manage/edit** | §4.2, §4.1 |
| No separate manage page; reuse the collection page; no redirect | §4.1 |
| Public view stays pixel-identical, light, minimal change | §2, §4.1 |
| Incremental commits; live in the new model asap | §6 |
| Inline edit title/description/location | §4.3 |
| Dark mode = separate later feature | §0, §5, §7 |

---

_Local artifact (gitignored). Next: `writing-plans` for the incremental, visually-verified build._
