# Collections Manage Page — Parent Column + Type-Grouped Accordion Rows

**Status:** Design approved 2026-06-02; awaiting implementation plan.
**Owner:** themancalledzac
**Branch:** `0163-collections-parent-column` (off `0161-test-quality-cleanup` after `git merge origin/main`).
**Spans:** `edens-zac` (frontend) + `edens-zac-backend` (Spring Boot).

---

## 1. Problem

The `CollectionListSelector` on `/collection/manage/{slug}` admin pages currently shows a two-column Sibling | Child grid against a flat list of every collection in the database. Two gaps:

1. **No Parent column.** Admin can declare a candidate as a Child or Sibling of the current collection, but cannot declare it as a Parent. The relationship is structurally identical to the inverse of Child (X→Y child ⇒ Y is a parent of X), so the data already exists — it just isn't surfaced.
2. **Flat unsorted list scales poorly.** As collection count grows, scanning a flat list to find a specific candidate becomes slow. The user wants type-grouped accordion rows so they can collapse uninteresting types and focus on one type at a time.

The secondary asks (string renames, intra-group sort by type) are minor cleanups bundled into the same change.

---

## 2. Goals

- Add a third toggle column **Parent** alongside Sibling and Child, with the same checkbox visual contract (saved / pending-add / pending-remove / remove-intent hover).
- Group rows by `CollectionType` under collapsible section headers; one type expanded at a time (accordion).
- Default state: all sections collapsed.
- Within an expanded type: `BLOG` rows sort by `collectionDate` descending (newest first, null-last); all other types sort alphabetically by `name`.
- Rename UI labels "Catalog Name" → "Collection Name" and (where surviving) "Catalog Type" → "Collection Type".
- Prevent direct 2-cycles in the parent/child relationship (cannot mark Y as both Child and Parent of X simultaneously).
- Ship as a single bundled MR spanning BE + FE.

## 3. Non-Goals

- No new join table or schema migration for the parent relationship — derived from the existing `collection_content` + `content_collection` tables.
- No new REST endpoints — the existing atomic `updateCollection` PUT carries the new `parents` field.
- No changes to the image-metadata-editor's invocation of `CollectionListSelector` (it still renders in single-column mode; new props are optional).
- No changes to public-facing collection pages.
- No deeper cycle detection (3+ hops). Direct 2-cycle blocking only. Documented limitation.
- No removal of the `CollectionType.PARENT` enum value — it remains a distinct collection type and gets its own accordion section.
- No accordion behavior for the image-metadata-editor's instance of `CollectionListSelector` (it lacks the type-column grouping use case).

---

## 4. Architecture Decision

**Chosen: Option A — derive parents from existing data; add a `parents: CollectionUpdate` field to the existing update DTO.**

### Why not Option B (new `collection_parent` join table)

The parent relationship is already fully encoded in `collection_content` + `content_collection`. A new table would be a denormalized duplicate with dual-source-of-truth drift risk — the same shape of bug that produced the past `cc.visible` defaulting issue (CollectionService.handleCollectionToCollectionUpdates, 2026-05-06). The migration is pure overhead.

### Why not Option C (FE calls existing add-child endpoint per change)

Breaks the atomic save contract that siblings established. The existing PUT bundles children + siblings + locations into one transaction. Splitting parent writes into N separate POSTs would be inconsistent UX, partial-save-prone, and harder to test.

### How A works

The existing `CollectionService.handleCollectionToCollectionUpdates(parent, update)` signature already takes a "parent collection" and a `CollectionUpdate {prev, newValue, remove}`. For the new parent direction: when X (the collection being edited) declares Y as its parent, this is semantically identical to "Y adds X as a child." So the implementation is one method that iterates `parents.newValue` and `parents.remove`, swaps args, and calls the existing handler — for each parentId P, call `handleCollectionToCollectionUpdates(P, {newValue: [X]})` or `{remove: [X.id]}`. Pure inversion, no new write logic.

For reads, one new repo query traverses the same JOIN in reverse direction to find "all collections that already have X as a child."

---

## 5. Backend Changes (edens-zac-backend)

### 5.1 DTO additions

**`CollectionUpdateRequest.java`** — add one field:
```java
private CollectionUpdate parents;
```
Mirrors the existing `collections` (children) and `siblings` fields. Reuses the existing `CollectionUpdate {prev, newValue, remove}` shape — no new inner type.

**`CollectionModel.java`** (admin response DTO) — add one field:
```java
private List<ChildCollection> parents;
```
Reuses the same `ChildCollection` record used by `collections` and `siblings`. Populated by the service layer on GET via the new repo query (5.3).

**`CollectionListModel.java`** — add one field:
```java
private LocalDate collectionDate;  // or String if existing fields use ISO strings
```
Needed by the FE so the BLOG group can sort by date. Match the existing field type used on `CollectionEntity.collectionDate`. **TODO during implementation: confirm whether `CollectionListModel` already exposes `collectionDate`; if so, this addition is a no-op.**

### 5.2 Cycle-guard validation

Inside the new service method (5.4), reject before writing if either condition holds:

1. **Self-parent**: any `parents.newValue.collectionId == currentCollection.id`.
2. **Direct 2-cycle**: any `parents.newValue.collectionId == P` where P is already a child of currentCollection (i.e. the `(P, X)` parent→child link already exists in `collection_content` + `content_collection`).

Both throw a `CycleDetectedException` (or reuse the existing validation-exception type) with a message that names the offending collection ID. The controller returns 400 Bad Request.

### 5.3 New repository query

Add to whichever repository owns `collection_content` queries (likely `CollectionRepository.java` or `CollectionContentRepository.java`):

```java
@Query("""
    SELECT c FROM CollectionEntity c
    JOIN CollectionContentEntity cc ON cc.collectionId = c.id
    JOIN ContentCollectionEntity cct ON cct.id = cc.contentId
    WHERE cct.referencedCollectionId = :childCollectionId
      AND cc.visible = true
""")
List<CollectionEntity> findParentCollectionsOf(@Param("childCollectionId") Long childCollectionId);
```

Two notes:
- `cc.visible = true` is included (matches the precedent established by the 2026-05-06 visible-flag bug fix — soft-deleted memberships must not leak as live parents).
- **`c.visibility` is NOT filtered.** Admin manage page must see all parents regardless of LISTED / UNLISTED / HIDDEN so they can manage the relationship. This is consistent with how the existing child list is rendered in admin views.

### 5.4 New service method

In `CollectionService.java`:

```java
public void handleParentCollectionUpdates(
    CollectionEntity currentCollection,
    CollectionUpdate parentUpdate
) {
    if (parentUpdate == null) return;

    validateNoCycles(currentCollection, parentUpdate);  // see 5.2

    if (parentUpdate.newValue() != null) {
        for (ChildCollection toAdd : parentUpdate.newValue()) {
            CollectionEntity parent = collectionRepository.findById(toAdd.collectionId())
                .orElseThrow(() -> new ResourceNotFoundException(
                    "Parent collection not found: " + toAdd.collectionId()));
            // Inverse write: add currentCollection as a child of parent
            handleCollectionToCollectionUpdates(parent, CollectionUpdate.builder()
                .newValue(List.of(toChildCollection(currentCollection)))
                .build());
        }
    }

    if (parentUpdate.remove() != null) {
        for (Long parentId : parentUpdate.remove()) {
            CollectionEntity parent = collectionRepository.findById(parentId)
                .orElseThrow(() -> new ResourceNotFoundException(
                    "Parent collection not found: " + parentId));
            handleCollectionToCollectionUpdates(parent, CollectionUpdate.builder()
                .remove(List.of(currentCollection.getId()))
                .build());
        }
    }
}
```

`toChildCollection(currentCollection)` constructs a `ChildCollection {collectionId, name}` from the current entity. The existing `handleCollectionToCollectionUpdates` already populates `visible=true` by default (since the 2026-05-06 fix).

Called inside the existing `updateCollection` transaction after children + siblings handlers, before the final save. Inherits transactional semantics — partial failure rolls back the entire request.

### 5.5 Service `getCollection` change

Wherever `CollectionService` builds the admin `CollectionModel` response (whichever method populates `siblings`), add a parallel call:
```java
model.setParents(
    collectionRepository.findParentCollectionsOf(collection.getId()).stream()
        .map(parent -> toChildCollection(parent))
        .toList()
);
```

### 5.6 Controller

No new endpoints. The existing admin `updateCollection` controller method already deserializes `CollectionUpdateRequest` and calls `CollectionService.updateCollection(slug, request)`. The new `parents` field rides through automatically; the service is the only place that needs the new branch.

### 5.7 Test additions

**`CollectionRepositoryTest`** (or equivalent integration test):
- `findParentCollectionsOf_returnsParents_whenChildHasParents` — seed parent P with child C; query by C.id returns [P].
- `findParentCollectionsOf_excludesSoftDeleted_whenMembershipNotVisible` — seed P→C with `cc.visible=false`; query returns [].
- `findParentCollectionsOf_returnsEmpty_whenCollectionHasNoParents` — query by an orphan collection.

**`CollectionServiceTest`**:
- `handleParentCollectionUpdates_addsParent_invertingArgs` — verify the inverse write reaches `handleCollectionToCollectionUpdates` with swapped args.
- `handleParentCollectionUpdates_removesParent` — symmetric removal.
- `handleParentCollectionUpdates_rejectsSelfParent` — throws on `newValue` containing currentCollection.id.
- `handleParentCollectionUpdates_rejects2Cycle` — seed X→Y child; attempt to add Y as parent of X throws.
- `handleParentCollectionUpdates_noOp_whenUpdateIsNull` — graceful null handling.

**Integration test** (`CollectionControllerTest` or equivalent):
- PUT `/admin/collections/{slug}` with `parents: { newValue: [{collectionId: P}] }` results in P having current collection as a child; round-trip GET shows `parents: [{collectionId: P}]`.

**Existing `handleCollectionToCollectionUpdates` tests**: no changes — the underlying mechanism is unchanged.

---

## 6. Frontend Changes (edens-zac)

### 6.1 Types — `app/types/Collection.ts`

Two additions:

```ts
export interface CollectionListModel {
  id: number;
  name: string;
  slug?: string;
  type?: string;
  collectionDate?: string | null;  // NEW: ISO date, for BLOG group sort
}

export interface CollectionUpdateRequest {
  // ... existing fields
  parents?: CollectionUpdate;  // NEW: parallel to siblings + collections
}
```

`CollectionModel` (admin response type) also gains:
```ts
parents: ChildCollection[];  // NEW: server populates from findParentCollectionsOf
```

### 6.2 `CollectionListSelector.tsx`

#### 6.2.1 New optional props (no breaking change)

```ts
interface CollectionListSelectorProps {
  // ... existing props
  // Optional third ("Parent") toggle column. Engages 3-column "parentMode" when
  // all four are supplied, mirroring the existing siblingMode contract.
  parentSavedIds?: Set<number>;
  parentPendingAddIds?: Set<number>;
  parentPendingRemoveIds?: Set<number>;
  onToggleParent?: (collection: CollectionListModel) => void;
}
```

Engagement: `const parentMode = !!onToggleParent && !!parentSavedIds && !!parentPendingAddIds && !!parentPendingRemoveIds`. Same implicit-engagement pattern as `siblingMode`. Existing single-column callers (image-metadata editor) and the manage-page sibling-mode caller continue to work unchanged.

Independent hover state: `const [hoveredParentId, setHoveredParentId] = useState<number | null>(null)`.

#### 6.2.2 Accordion grouping

New module-scope constant:
```ts
const COLLECTION_TYPE_ORDER: CollectionType[] = [
  CollectionType.HOME,
  CollectionType.PARENT,
  CollectionType.CLIENT_GALLERY,
  CollectionType.ART_GALLERY,
  CollectionType.PORTFOLIO,
  CollectionType.BLOG,
  CollectionType.MISC,
];
```

> **Open: MISC placement.** The user spec listed 6 types in order; `CollectionType.MISC` (the 7th) was not addressed. Default placement: at the end after BLOG. Confirm with user before implementation; alternative is to hide MISC entirely from this list (unsafe — could lose visibility into MISC collections).

New accordion state:
```ts
const [expandedType, setExpandedType] = useState<CollectionType | null>(null);
```

Default: `null` (all collapsed).

#### 6.2.3 Accordion render order

`HOME` is special — there is canonically a single HOME collection (it is the site's landing page), so it behaves as an always-visible row rather than a collapsible section. It is rendered as an ordinary collection row pinned to the top of the list, with full Sibling | Child | Parent toggle interaction. No type-header chip, no collapse affordance. If multiple HOME rows exist in the data (edge case), all are rendered at top in alphabetical order — still no collapse.

For all other types in `COLLECTION_TYPE_ORDER` (`PARENT`, `CLIENT_GALLERY`, `ART_GALLERY`, `PORTFOLIO`, `BLOG`, `MISC`), the accordion rules apply.

When `expandedType === T` (T ≠ HOME):
1. Render HOME row(s) at the top (always visible, no header).
2. Render type header row for T (clickable, shows row count, chevron-down).
3. Render T's collection rows (sorted per 6.2.4), each row using the `expandedRow` CSS class for the lighter background.
4. Render all other non-HOME type headers (in `COLLECTION_TYPE_ORDER` minus HOME and T), collapsed (chevron-right). No rows beneath these.

When `expandedType === null` (default):
1. Render HOME row(s) at the top (always visible, no header).
2. Render the 6 non-HOME type headers in `COLLECTION_TYPE_ORDER`, all collapsed.

Clicking a collapsed non-HOME header sets `expandedType` to that type. Clicking the currently-expanded header sets `expandedType` back to `null`. One-open-at-a-time is enforced by the single-value state. HOME rows are never affected by `expandedType` changes.

Accordion mode only engages when the component is rendered in `siblingMode || parentMode` context — single-column callers (image-metadata editor) keep the existing flat-list layout.

#### 6.2.4 Intra-group sort

```ts
function sortGroup(rows: CollectionListModel[], type: CollectionType): CollectionListModel[] {
  if (type === CollectionType.BLOG) {
    // Newest first; null/undefined dates sort to end
    return [...rows].sort((a, b) => {
      if (!a.collectionDate && !b.collectionDate) return a.name.localeCompare(b.name);
      if (!a.collectionDate) return 1;
      if (!b.collectionDate) return -1;
      return b.collectionDate.localeCompare(a.collectionDate);
    });
  }
  // All other types: alphabetical by name (current behavior)
  return [...rows].sort((a, b) => a.name.localeCompare(b.name));
}
```

#### 6.2.5 Mutual-exclusion: disable opposite checkbox

For each row, compute:

```ts
const isCheckedAsChild =
  savedCollectionIds.has(c.id) || pendingAddIds.has(c.id);
const isCheckedAsParent =
  (parentSavedIds?.has(c.id) ?? false) || (parentPendingAddIds?.has(c.id) ?? false);

const parentDisabled = isCheckedAsChild;
const childDisabled = isCheckedAsParent;
```

(`pendingAdd` minus `pendingRemove` would be more precise — exclude rows that are pending-removal. Implement carefully: a saved row that is `pendingRemove` is effectively NOT currently a parent/child, so the opposite checkbox should NOT be disabled.)

The `renderCheckbox` helper grows a `disabled?: boolean` and `disabledReason?: string` argument. Disabled state visual: muted color, `cursor: not-allowed`, `aria-disabled="true"`. Tooltip via `title="A collection cannot be both a parent and a child of the same collection."`.

The Sibling column is NOT subject to this disable — siblings are mutual and can coexist with either child or parent relationships.

#### 6.2.6 Header row in 3-column mode

```tsx
{(siblingMode || parentMode) && (
  <div className={styles.columnHeaderRow}>
    <span className={styles.columnHeaderName}>Collection Name</span>
    {/* Catalog Type column REMOVED — type is the accordion section header */}
    <span className={styles.columnHeaderToggle}>Sibling</span>
    <span className={styles.columnHeaderToggle}>Child</span>
    {parentMode && <span className={styles.columnHeaderToggle}>Parent</span>}
  </div>
)}
```

The "Catalog Type" span on line 149 of the existing implementation is **deleted** (the type column has no place in accordion layout). The "Catalog Name" → "Collection Name" rename is here.

The `<span className={styles.type}>` inside each row is **also removed** in accordion mode for the same reason.

#### 6.2.7 String-rename grep coverage

Initial grep (verified during design): "Catalog Name" and "Catalog Type" appear only at `CollectionListSelector.tsx:148-149`. Implementation must additionally grep:
- `tests/components/CollectionListSelector.test.tsx` (if it exists) — `getByText('Catalog Name')` etc.
- `tests/` subdirectories generally.
- Any Storybook stories or fixtures.

### 6.3 SCSS — `CollectionListSelector.module.scss`

Additions:
```scss
:root {
  --collection-row-expanded-bg: /* defined in theme; ~2-4% lighter than --row-bg */;
}

.expandedRow {
  background-color: var(--collection-row-expanded-bg);
}

.typeHeaderRow {
  // Clickable accordion header — visually distinct from collection rows.
  // Contains: chevron icon, type label (e.g. "Client Gallery"), row count badge.
  cursor: pointer;
  // ... existing header styling adapted
}

.typeHeaderRow--expanded {
  // Active state for the currently-open type header.
}
```

The exact `--collection-row-expanded-bg` value is determined during implementation by reading the existing `--row-bg` variable in the theme module and bumping lightness by 2-4%. Use a project-consistent naming convention; if `--row-bg` doesn't exist, fall back to a hardcoded subtle delta.

### 6.4 `manageUtils.ts`

Zero changes to `toggleRelation`. `buildUpdatePayload` gains one block parallel to the existing `siblings` block:

```ts
if (formData.parents !== undefined) {
  payload.parents = formData.parents;
}
```

### 6.5 `ManageClient.tsx`

#### 6.5.1 New derived state

Mirror the existing `originalCollectionIds` (children) and `originalSiblingIds` patterns:
```ts
const originalParentIds = useMemo(() => {
  return new Set<number>((collection?.parents ?? []).map(p => p.collectionId));
}, [collection?.parents]);

const pendingParentAddIds = useMemo(() => {
  const ids = new Set<number>();
  for (const parent of updateData.parents?.newValue ?? []) {
    ids.add(parent.collectionId);
  }
  return ids;
}, [updateData.parents?.newValue]);

const pendingParentRemoveIds = useMemo(() => {
  return new Set<number>(updateData.parents?.remove ?? []);
}, [updateData.parents?.remove]);
```

#### 6.5.2 New toggle handler

```ts
const handleParentToggle = useCallback(
  (toggledCollection: CollectionListModel) => {
    setUpdateData(prev => {
      const newParents = toggleRelation(
        prev.parents,
        toggledCollection,
        originalParentIds,
        (c) => ({ collectionId: c.id, name: c.name })  // sibling-shape entry
      );
      return { ...prev, parents: newParents };
    });
  },
  [originalParentIds]
);
```

`buildEntry` shape `{collectionId, name}` matches siblings — no `visible` / `orderIndex` needed (being a parent is unordered).

#### 6.5.3 Pass props to `CollectionListSelector`

```tsx
<CollectionListSelector
  allCollections={allCollections}
  savedCollectionIds={originalCollectionIds}
  pendingAddIds={pendingAddIds}
  pendingRemoveIds={pendingRemoveIds}
  onToggle={handleCollectionToggle}
  siblingSavedIds={originalSiblingIds}
  siblingPendingAddIds={pendingSiblingAddIds}
  siblingPendingRemoveIds={pendingSiblingRemoveIds}
  onToggleSibling={handleSiblingToggle}
  parentSavedIds={originalParentIds}                  // NEW
  parentPendingAddIds={pendingParentAddIds}           // NEW
  parentPendingRemoveIds={pendingParentRemoveIds}     // NEW
  onToggleParent={handleParentToggle}                 // NEW
  // ... rest unchanged
/>
```

### 6.6 Test additions

**`CollectionListSelector.test.tsx`** (extend; create if missing):
- `renders 3-column header when parentMode props supplied` — expects "Collection Name", "Sibling", "Child", "Parent" headers.
- `does NOT render "Catalog Name" or "Catalog Type" anywhere`.
- `renders HOME row(s) always visible at top, no header` — when HOME data is present.
- `renders 6 non-HOME type-header rows in COLLECTION_TYPE_ORDER, all collapsed by default` — assert 6 headers, no non-HOME collection rows.
- `clicking a non-HOME type header expands it and shows rows beneath` — sibling+child+parent toggles still functional.
- `clicking another type header closes the previously-expanded one` (accordion semantics); HOME row remains visible throughout.
- `BLOG group sorts by collectionDate descending; null dates sort to end`.
- `non-BLOG groups sort alphabetically by name`.
- `Parent checkbox is disabled when row is checked as Child` — assert `aria-disabled="true"` and click handler not fired.
- `Child checkbox is disabled when row is checked as Parent` — symmetric.
- `Sibling checkbox is NOT affected by Parent/Child state`.
- `Parent checkbox fires onToggleParent with correct collection`.
- `expanded rows have the expandedRow class applied`.

**`manageUtils.test.ts`** — `toggleRelation` tests already cover the helper. Add one test for `buildUpdatePayload` to confirm `parents` is included in the payload when `formData.parents !== undefined`.

**`ManageClient.test.tsx`** (if exists): no new test required — handler is a thin wrapper. If integration test coverage exists, add a smoke test that toggling Parent updates `updateData.parents`.

### 6.7 No changes to

- Image-metadata-editor's `CollectionListSelector` invocation — does not pass parent props; still renders in single-column mode.
- `pinnedCollectionId` behavior — not used in this codepath.
- The Sibling implementation — purely additive.
- Public-facing collection pages or any rendering outside the admin manage page.

---

## 7. Data Flow

User clicks Parent checkbox for row Y on collection X's manage page:

1. `CollectionListSelector` invokes `onToggleParent(Y)`.
2. `ManageClient.handleParentToggle(Y)` calls `toggleRelation(prev.parents, Y, originalParentIds, buildEntry)`.
3. React state updates `updateData.parents`; `CollectionListSelector` re-renders with Y in `pendingAddIds` (or `pendingRemoveIds`).
4. User clicks Save.
5. `buildUpdatePayload` diffs `parents` (and children, siblings, locations) into the request body.
6. PUT `/admin/collections/{slug}` carries `parents: {newValue: [{collectionId: Y, name: ...}]}`.
7. `CollectionController.updateCollection` → `CollectionService.updateCollection`.
8. Service runs in this order inside one `@Transactional`:
   - `handleCollectionToCollectionUpdates(currentCollection, request.collections)` — children
   - `handleSiblingUpdates(currentCollection, request.siblings)` — siblings
   - `handleParentCollectionUpdates(currentCollection, request.parents)` — NEW. Iterates `newValue` and for each Y, calls `handleCollectionToCollectionUpdates(Y, {newValue: [currentCollection-as-ChildCollection]})`. Writes the inverse direction into the same `collection_content` join table.
   - Cycle validation runs first; throws → rolls back whole transaction.
   - Save.
9. Service rebuilds response `CollectionModel`, including `parents = findParentCollectionsOf(currentCollection.id)`.
10. FE receives response, mutates SWR cache, resets `originalParentIds`. Pending sets clear. Row Y now renders as `saved` (green) in the Parent column.

---

## 8. Edge Cases & Limitations

| Case | Behavior | Enforcement |
|---|---|---|
| Self-parent (mark X as parent of X) | Blocked | FE: `excludeCollectionId` already filters X from candidate list. BE: explicit reject. |
| Direct 2-cycle (X has Y as child AND user marks Y as parent of X) | Blocked | FE: opposite-column checkbox is `aria-disabled` with tooltip. BE: explicit reject, returns 400. |
| Deeper N-cycles (3+ hops, e.g. A→B→C→A) | Accepted limitation | Documented in code comment; admin tool, low risk. |
| Parent with `visibility = HIDDEN` | Shown to admin | New repo query does NOT filter by `c.visibility`. Public pages still gate appropriately. |
| Soft-deleted parent membership (`cc.visible = false`) | NOT shown | New repo query filters `cc.visible = true`. Matches established precedent. |
| BLOG row with null `collectionDate` | Sorts to end of BLOG group, alphabetical within nulls | Comparator handles null-last explicitly. |
| `HOME` collection type | Always-visible at top; no accordion header, no collapse | Special-cased in render; HOME rows are not affected by `expandedType`. |
| Multiple HOME rows (data anomaly) | All rendered at top, alphabetical | Same special-case path. Operationally there should be exactly one. |
| Zero HOME rows | Nothing rendered at top; first accordion section becomes visually first | Falls out of the existing logic; no special handling needed. |
| `MISC` collection type | Slotted at end of `COLLECTION_TYPE_ORDER` | Confirmed 2026-06-02. |
| Image-metadata-editor calling `CollectionListSelector` | Unchanged — renders flat single-column list | New props are optional; accordion only engages in `siblingMode || parentMode`. |

---

## 9. Build Sequence

Single bundled MR on branch `0163-collections-parent-column`, off `0161-test-quality-cleanup` after merging latest `main`.

Internal commit order (one commit per group; squash optional):

1. **Backend:**
   1. DTO additions (`CollectionUpdateRequest.parents`, `CollectionModel.parents`, `CollectionListModel.collectionDate`).
   2. Repository query `findParentCollectionsOf`.
   3. Service method `handleParentCollectionUpdates` + cycle validation.
   4. Wire into `updateCollection` + populate `parents` on read path.
   5. Tests (repo + service + integration).
   6. Verify `./mvnw verify` BUILD SUCCESS, Spotless + Checkstyle clean.
2. **Frontend types** (`app/types/Collection.ts` — `parents` + `collectionDate`).
3. **Frontend utility** (`manageUtils.ts` — `buildUpdatePayload` includes `parents`).
4. **Frontend component** (`CollectionListSelector.tsx` — accordion + Parent column + mutual-exclusion + rename; SCSS variable + classes).
5. **Frontend wiring** (`ManageClient.tsx` — state + handler + props).
6. **Frontend tests** (`CollectionListSelector.test.tsx`; `manageUtils.test.ts`).
7. Run Prettier + ESLint + Stylelint + `tsc --noEmit` + full jest suite.
8. Manual smoke via preview server on `/collection/manage/hidden-lake`.

---

## 10. Spec → Plan Coverage Checklist

| Plan task | Spec section |
|---|---|
| BE: Add `parents` field to `CollectionUpdateRequest` | 5.1 |
| BE: Add `parents` field to admin `CollectionModel` response | 5.1 |
| BE: Add `collectionDate` to `CollectionListModel` | 5.1 |
| BE: Implement `findParentCollectionsOf` repo query | 5.3 |
| BE: Implement `handleParentCollectionUpdates` service method | 5.4 |
| BE: Cycle-guard validation (self-parent, 2-cycle) | 5.2 |
| BE: Populate `parents` on read path | 5.5 |
| BE: Tests (repo + service + integration) | 5.7 |
| FE: Add `parents` + `collectionDate` to types | 6.1 |
| FE: `buildUpdatePayload` diffs `parents` | 6.4 |
| FE: `CollectionListSelector` Parent column (props, hover state) | 6.2.1 |
| FE: `COLLECTION_TYPE_ORDER` constant + accordion state | 6.2.2, 6.2.3 |
| FE: Intra-group sort (BLOG by date, others alphabetical) | 6.2.4 |
| FE: Mutual-exclusion disabled checkbox + tooltip | 6.2.5 |
| FE: Header row + string rename ("Catalog Name" → "Collection Name") | 6.2.6, 6.2.7 |
| FE: SCSS — `--collection-row-expanded-bg`, `typeHeaderRow`, `expandedRow` classes | 6.3 |
| FE: `ManageClient` state + handler + prop wiring | 6.5 |
| FE: Component + util tests | 6.6 |

Spec sections not mapped to plan tasks: none. Plan-task buckets without a spec section: none.

---

## 11. Open Questions Before Implementation

1. **Mutual-exclusion FE precision** — when a row is `pendingRemove` (saved-but-marked-for-removal), the opposite checkbox should NOT be disabled. Verify the disabled-computation handles this correctly during implementation; add a test for it.
2. **`collectionDate` on `CollectionListModel`** — confirm whether already exposed by the list endpoint or needs adding to the DTO.
3. **Accordion smoke test** — quick interactive verification on `/collection/manage/hidden-lake` before merge. The preview server runs on port 3001 (user holds 3000).

Resolved:
- `MISC` placement at end of `COLLECTION_TYPE_ORDER` (2026-06-02).
- Accordion default = fully collapsed, except HOME which is always visible at top (2026-06-02).
- Mutual-exclusion UX = disabled checkbox + tooltip (2026-06-02).
- `findParentCollectionsOf` visibility filter = none, admin sees all parents regardless of `c.visibility` (2026-06-02).

---

## 12. References

- Sibling-collections precedent: FE PR #148 + BE PR #96 (branch `0144-sibling-collections`). Shipped `toggleRelation` helper + two-column UI.
- Two-visibility-layer rule: `collection.visibility` vs `collection_content.visible` — both must be gated together in the right places (memory: 2026-05-07).
- Past bug: `handleCollectionToCollectionUpdates` defaulted `cc.visible` to false; fixed to true on 2026-05-06 (CollectionService.java:806).
- User preferences: bundled MRs, full autonomous-executable plans, strong test coverage.
