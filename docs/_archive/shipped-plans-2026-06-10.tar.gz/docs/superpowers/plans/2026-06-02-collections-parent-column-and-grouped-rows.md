# Collections Manage Page — Parent Column + Type-Grouped Accordion Rows — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: superpowers:subagent-driven-development. Steps use `- [ ]` syntax.

**Spec:** [docs/superpowers/specs/2026-06-02-collections-parent-column-and-grouped-rows-design.md](../specs/2026-06-02-collections-parent-column-and-grouped-rows-design.md)

**Goal:** Add a Parent toggle column to the admin Collections selector, group rows under collapsible CollectionType accordion sections (HOME always-visible at top), and rename "Catalog" → "Collection" labels — no new schema, no new endpoint.

**Architecture:** Derive parents from the inverse of the existing `collection_content` → `content_collection` join (Option A). New `parents: CollectionUpdate` field on `CollectionRequests.Update`. Service inverts args to delegate to existing `handleCollectionToCollectionUpdates`. New repo query `findAllParentCollectionsByChildId` populates `parents` on admin read path.

**Tech stack:** Spring Boot + JdbcTemplate (BE at `/Users/themancalledzac/Code/edens.zac.backend`); Next.js App Router + TypeScript + SCSS modules + Jest (FE at `/Users/themancalledzac/Code/edens.zac`).

---

## Conventions

- **Commit trailer:** every commit ends with `Co-Authored-By: Claude Opus 4.7 <noreply@anthropic.com>` — use HEREDOC. Omitted from each task's commit example for brevity.
- **FE tooling:** `npm` not on PATH; use `/opt/homebrew/bin/node node_modules/.bin/<tool>` for prettier, eslint, tsc, jest, stylelint, next.
- **BE tooling:** `./mvnw verify` from BE repo root for full build; `./mvnw -q test -Dtest=<ClassName>` for single test class.
- **Expected output:** every "Run …" step expects clean / PASS unless noted. TDD test-fail steps state the expected failure mode explicitly.

## File Structure

**BE** (`/Users/themancalledzac/Code/edens.zac.backend`):
- `model/CollectionRequests.java` — add `parents` to `Update` record.
- `model/CollectionModel.java` — add `parents: List<Records.CollectionList>`.
- `model/Records.java` — add `collectionDate` to `CollectionList`.
- `dao/CollectionRepository.java` — add `findAllParentCollectionsByChildId`.
- `services/CollectionService.java` — add `handleParentCollectionUpdates` + cycle guard; wire into `updateContent`; populate `parents` on admin read path.
- Tests: `dao/CollectionRepositoryTest.java`, `services/CollectionServiceTest.java`, `controller/admin/CollectionAdminControllerTest.java`.

**FE** (`/Users/themancalledzac/Code/edens.zac`):
- `app/types/Collection.ts` — add `collectionDate`; add `parents` to `CollectionUpdateRequest` + `CollectionModel`.
- `app/components/CollectionListSelector/CollectionListSelector.tsx` — Parent column + accordion + mutual-exclusion + rename.
- `app/components/CollectionListSelector/CollectionListSelector.module.scss` — `--collection-row-expanded-bg`, `.expandedRow`, `.typeHeaderRow*`, `.checkbox--disabled`.
- `app/(admin)/collection/manage/[[...slug]]/manageUtils.ts` — `parents` branch in `buildUpdatePayload`.
- `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx` — parent state + handler + props.
- Tests: `tests/components/CollectionListSelector.test.tsx`, `tests/(admin)/collection/manage/[[...slug]]/manageUtils.test.ts`.

---

## Phase 0 — Setup

### Task 0.1: Sync main + create branches

- [ ] **Step 1 (user, external — SSH auth):**
  ```bash
  cd /Users/themancalledzac/Code/edens.zac && git fetch origin main && git merge origin/main --no-edit
  ```
- [ ] **Step 2 (FE branch):**
  ```bash
  cd /Users/themancalledzac/Code/edens.zac && git checkout -b 0163-collections-parent-column
  ```
- [ ] **Step 3 (BE branch off latest main):**
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && git fetch origin main && git checkout -b 0163-collections-parent-column-be origin/main
  ```

---

## Phase 1 — Backend

> **Test-pattern context.** BE tests are **Mockito mocks + standalone MockMvc**, NO live DB.
> - `CollectionRepositoryTest`: mocks `NamedParameterJdbcTemplate.query(...)`, verifies SQL/params via `sqlCaptor` + `paramsCaptor`. Build entities with `CollectionEntity.builder()...build()`.
> - `CollectionServiceTest`: `@ExtendWith(MockitoExtension.class)`, `@Mock` every dep, stub `findById`/`save`/etc., verify mutation calls.
> - `CollectionAdminControllerTest`: standalone MockMvc + `@Mock CollectionService`.
>
> Read the corresponding existing test file before adding new tests — copy the nested-class organization and common-stub pattern.

### Task 1.1: DTO field additions

**Files:** `model/CollectionRequests.java`, `model/CollectionModel.java`, `model/Records.java`.

- [ ] **Step 1: `CollectionRequests.Update` — append `parents` component**

After the `siblings` component (currently last; line ~90), add trailing comma and:
```java
      /**
       * Parent collection updates. Derived from the inverse of the {@code collections} (children)
       * relationship — each {@code newValue} entry adds the current collection as a child of that
       * parent; each {@code remove} ID removes the current from that parent's children. Reuses
       * {@link CollectionUpdate}; only {@code collectionId} is read.
       */
      CollectionUpdate parents) {}
```

- [ ] **Step 2: `CollectionModel` — add `parents` field after `siblings` (line 81)**

```java
  /** Parents on the admin manage payload. Includes HIDDEN parents — admin sees every relationship. */
  private List<Records.CollectionList> parents;
```

- [ ] **Step 3: `Records.CollectionList` — add `collectionDate`**

Replace the record on line 69:
```java
  public record CollectionList(
      Long id, String name, String slug, CollectionType type, LocalDate collectionDate) {

    public CollectionList(Long id, String name, String slug, CollectionType type) {
      this(id, name, slug, type, null);
    }
  }
```

Ensure `import java.time.LocalDate;` at the top.

- [ ] **Step 4: Compile + commit**
  ```bash
  ./mvnw -q compile
  git add src/main/java/edens/zac/portfolio/backend/model
  git commit -m "feat(collection): add parents to Update DTO + CollectionModel; collectionDate on CollectionList"
  ```

---

### Task 1.2: TDD `findAllParentCollectionsByChildId`

**Files:** `dao/CollectionRepository.java`, `dao/CollectionRepositoryTest.java`.

- [ ] **Step 1: Failing tests** — append to `CollectionRepositoryTest.java`:
  ```java
  @Nested
  class FindAllParentCollectionsByChildId {
    @Test
    void buildsInverseJoinSql_andPassesChildIdParam() {
      CollectionEntity stub = CollectionEntity.builder().id(99L).title("Parent A").build();
      when(namedParameterJdbcTemplate.query(
              anyString(), any(MapSqlParameterSource.class),
              org.mockito.ArgumentMatchers.<RowMapper<CollectionEntity>>any()))
          .thenReturn(List.of(stub));

      List<CollectionEntity> parents = collectionRepository.findAllParentCollectionsByChildId(42L);

      verify(namedParameterJdbcTemplate).query(
          sqlCaptor.capture(), paramsCaptor.capture(),
          org.mockito.ArgumentMatchers.<RowMapper<CollectionEntity>>any());

      String sql = sqlCaptor.getValue();
      assertThat(sql).contains("JOIN collection_content cc ON cc.collection_id = c.id");
      assertThat(sql).contains("JOIN content_collection cct ON cct.id = cc.content_id");
      assertThat(sql).contains("WHERE cct.referenced_collection_id = :childId");
      assertThat(sql).contains("AND cc.visible = true");
      assertThat(sql).doesNotContain("c.visibility =");   // admin view — no parent-visibility gate
      assertThat(paramsCaptor.getValue().getValue("childId")).isEqualTo(42L);
      assertThat(parents).hasSize(1).first().extracting(CollectionEntity::getId).isEqualTo(99L);
    }

    @Test
    void returnsEmpty_whenJdbcReturnsEmpty() {
      when(namedParameterJdbcTemplate.query(
              anyString(), any(MapSqlParameterSource.class),
              org.mockito.ArgumentMatchers.<RowMapper<CollectionEntity>>any()))
          .thenReturn(List.of());
      assertThat(collectionRepository.findAllParentCollectionsByChildId(42L)).isEmpty();
    }
  }
  ```
  Run `./mvnw -q test -Dtest=CollectionRepositoryTest` → expect compile error (method undefined).

- [ ] **Step 2: Implement** — append in `CollectionRepository.java` after `findAllReferencedCollectionsByParentId`:
  ```java
  /**
   * Inverse of {@link #findAllReferencedCollectionsByParentId}. Walks child -&gt; content_collection
   * -&gt; collection_content -&gt; parent. Excludes soft-deleted memberships (cc.visible = false) but
   * does NOT filter by c.visibility — admin views see every parent.
   */
  @Transactional(readOnly = true)
  public List<CollectionEntity> findAllParentCollectionsByChildId(Long childId) {
    String sql = """
        SELECT c.id, c.type, c.title, c.slug, c.description, c.collection_date,
               c.visibility, c.display_mode, c.cover_image_id, c.content_per_page, c.total_content,
               c.rows_wide, c.gallery_password, c.recipient_emails, c.rating, c.created_at, c.updated_at
        FROM collection c
        JOIN collection_content cc ON cc.collection_id = c.id
        JOIN content_collection cct ON cct.id = cc.content_id
        WHERE cct.referenced_collection_id = :childId
          AND cc.visible = true
        ORDER BY c.title ASC
        """;
    MapSqlParameterSource params = createParameterSource().addValue("childId", childId);
    return query(sql, COLLECTION_ROW_MAPPER, params);
  }
  ```

- [ ] **Step 3: PASS + commit**
  ```bash
  ./mvnw -q test -Dtest=CollectionRepositoryTest
  git add src/main/java/edens/zac/portfolio/backend/dao/CollectionRepository.java \
          src/test/java/edens/zac/portfolio/backend/dao/CollectionRepositoryTest.java
  git commit -m "feat(collection-repo): add findAllParentCollectionsByChildId inverse query"
  ```

---

### Task 1.3: TDD `handleParentCollectionUpdates` — add path + cycle guard

**Files:** `services/CollectionService.java`, `services/CollectionServiceTest.java`.

- [ ] **Step 1: Failing add-path test** — append a new `@Nested class HandleParentCollectionUpdates` to `CollectionServiceTest.java`:
  ```java
  @Nested
  class HandleParentCollectionUpdates {
    private CollectionEntity current;
    private CollectionEntity targetParent;

    @BeforeEach
    void setUpEntities() {
      current = CollectionEntity.builder().id(7L).title("Current").slug("current").build();
      targetParent = CollectionEntity.builder().id(42L).title("Target Parent").build();
    }

    private CollectionRequests.Update updateWithParents(CollectionRequests.CollectionUpdate parents) {
      // Canonical record constructor — all 18 components, null where not exercised. The exact arity
      // matches CollectionRequests.Update; copy from the existing test in this file if it changes.
      return new CollectionRequests.Update(
          current.getId(), null, null, null, null, null, null, null, null,
          null, null, null, null, null, null, null, null, parents);
    }

    @Test
    void addsCurrentAsChildOfEachNewValueParent() {
      when(collectionRepository.findById(current.getId())).thenReturn(Optional.of(current));
      when(collectionRepository.findById(42L)).thenReturn(Optional.of(targetParent));
      when(collectionRepository.findAllReferencedCollectionsByParentId(7L)).thenReturn(List.of());
      when(collectionRepository.save(any(CollectionEntity.class))).thenAnswer(i -> i.getArgument(0));
      when(collectionRepository.findContentByCollectionIdOrderByOrderIndex(42L)).thenReturn(List.of());

      collectionService.updateContent(current.getId(), updateWithParents(
          new CollectionRequests.CollectionUpdate(
              null,
              List.of(new Records.ChildCollection(42L, null, null, null, null, null)),
              null)));

      // The inverse write reaches the parent-side join-table mutation.
      verify(collectionRepository, org.mockito.Mockito.atLeastOnce())
          .insertCollectionContent(eq(42L), anyLong(), anyInt(), anyBoolean());
    }
  }
  ```
  **Adapt at runtime:** the exact mutation-method names (`insertCollectionContent`, `deleteCollectionContentById`) are not yet verified — grep the body of `handleCollectionToCollectionUpdates` to find what it actually calls, and use those names. Also confirm the entity-lookup method used by `updateContent` (`findById` vs `findEntityById` vs `findEntityBySlug`).

  Run → expect compile error (`handleParentCollectionUpdates` not yet defined).

- [ ] **Step 2: Implement** — append after `handleSiblingUpdates` in `CollectionService.java`:
  ```java
  /**
   * Apply parent-collection updates by inverting args and delegating to
   * {@link #handleCollectionToCollectionUpdates}. Cycle validation (self-parent + direct 2-cycle)
   * runs first; throws {@link IllegalArgumentException} → 400 Bad Request.
   */
  private void handleParentCollectionUpdates(
      CollectionEntity currentCollection, CollectionRequests.CollectionUpdate parents) {
    if (parents == null) return;
    validateNoParentCycles(currentCollection, parents);

    if (parents.newValue() != null) {
      for (Records.ChildCollection entry : parents.newValue()) {
        Long parentId = entry.collectionId();
        if (parentId == null || parentId.equals(currentCollection.getId())) continue;
        CollectionEntity parent = collectionRepository.findById(parentId)
            .orElseThrow(() -> new ResourceNotFoundException(
                "Parent collection not found with ID: " + parentId));
        Records.ChildCollection currentAsChild = new Records.ChildCollection(
            currentCollection.getId(), currentCollection.getTitle(),
            currentCollection.getSlug(), null, null, null);
        handleCollectionToCollectionUpdates(parent,
            new CollectionRequests.CollectionUpdate(null, List.of(currentAsChild), null));
      }
    }
    // Remove branch implemented in Task 1.4
    log.info("Applied parent collection updates for collection {}", currentCollection.getId());
  }

  private void validateNoParentCycles(
      CollectionEntity current, CollectionRequests.CollectionUpdate parents) {
    if (parents == null || parents.newValue() == null) return;
    Set<Long> existingChildIds =
        collectionRepository.findAllReferencedCollectionsByParentId(current.getId()).stream()
            .map(CollectionEntity::getId).collect(Collectors.toSet());
    for (Records.ChildCollection entry : parents.newValue()) {
      Long parentId = entry.collectionId();
      if (parentId == null) continue;
      if (parentId.equals(current.getId())) {
        throw new IllegalArgumentException(
            "A collection cannot be its own parent (id=" + parentId + ")");
      }
      if (existingChildIds.contains(parentId)) {
        throw new IllegalArgumentException(
            "Cycle detected: collection " + parentId + " is already a child of "
                + current.getId() + " and cannot also be a parent");
      }
    }
  }
  ```
  Add imports: `import java.util.Set; import java.util.stream.Collectors;`.

- [ ] **Step 3: Wire into `updateContent`** — after the `handleSiblingUpdates(...)` call (line ~497):
  ```java
  handleParentCollectionUpdates(entity, updateDTO.parents());
  ```

- [ ] **Step 4: PASS + commit**
  ```bash
  ./mvnw -q test -Dtest=CollectionServiceTest#HandleParentCollectionUpdates
  git add src/main/java/edens/zac/portfolio/backend/services/CollectionService.java \
          src/test/java/edens/zac/portfolio/backend/services/CollectionServiceTest.java
  git commit -m "feat(collection-service): handleParentCollectionUpdates add path + cycle validation"
  ```

---

### Task 1.4: TDD remove path

**Files:** same as Task 1.3.

- [ ] **Step 1: Failing remove-path test** — append to `HandleParentCollectionUpdates`:
  ```java
  @Test
  void removesCurrentFromEachRemoveIdParentChildren() {
    CollectionEntity existingParent = CollectionEntity.builder().id(55L).title("Existing").build();
    when(collectionRepository.findById(current.getId())).thenReturn(Optional.of(current));
    when(collectionRepository.findById(55L)).thenReturn(Optional.of(existingParent));
    when(collectionRepository.findAllReferencedCollectionsByParentId(7L)).thenReturn(List.of());

    ContentCollectionEntity contentColl =
        ContentCollectionEntity.builder().id(900L).referencedCollection(current).build();
    CollectionContentEntity joinRow = CollectionContentEntity.builder()
        .id(800L).collectionId(55L).contentId(900L).visible(true).build();
    when(collectionRepository.findContentByCollectionIdOrderByOrderIndex(55L)).thenReturn(List.of(joinRow));
    when(contentRepository.findCollectionContentById(900L)).thenReturn(Optional.of(contentColl));

    collectionService.updateContent(current.getId(), updateWithParents(
        new CollectionRequests.CollectionUpdate(null, null, List.of(55L))));

    verify(collectionRepository, org.mockito.Mockito.atLeastOnce()).deleteCollectionContentById(800L);
  }
  ```
  Same adapt-at-runtime: confirm the actual delete-method name.

- [ ] **Step 2: Implement** — replace the `// Remove branch implemented in Task 1.4` comment with:
  ```java
  if (parents.remove() != null) {
    for (Long parentId : parents.remove()) {
      if (parentId == null || parentId.equals(currentCollection.getId())) continue;
      CollectionEntity parent = collectionRepository.findById(parentId)
          .orElseThrow(() -> new ResourceNotFoundException(
              "Parent collection not found with ID: " + parentId));
      handleCollectionToCollectionUpdates(parent,
          new CollectionRequests.CollectionUpdate(null, null, List.of(currentCollection.getId())));
    }
  }
  ```

- [ ] **Step 3: PASS + commit**
  ```bash
  ./mvnw -q test -Dtest=CollectionServiceTest#HandleParentCollectionUpdates
  git commit -am "feat(collection-service): handleParentCollectionUpdates remove path"
  ```

---

### Task 1.5: Cycle-rejection tests

**Files:** `services/CollectionServiceTest.java`.

- [ ] **Step 1: Add to `HandleParentCollectionUpdates`** — these PASS immediately (validation already exists from Task 1.3):
  ```java
  @Test
  void rejectsSelfParent() {
    when(collectionRepository.findById(current.getId())).thenReturn(Optional.of(current));
    when(collectionRepository.findAllReferencedCollectionsByParentId(7L)).thenReturn(List.of());
    CollectionRequests.CollectionUpdate parents = new CollectionRequests.CollectionUpdate(
        null,
        List.of(new Records.ChildCollection(current.getId(), null, null, null, null, null)),
        null);
    assertThatThrownBy(() -> collectionService.updateContent(current.getId(), updateWithParents(parents)))
        .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("its own parent");
  }

  @Test
  void rejects2Cycle_whenNewValueIdIsAlreadyAChild() {
    CollectionEntity existingChild = CollectionEntity.builder().id(99L).title("Existing Child").build();
    when(collectionRepository.findById(current.getId())).thenReturn(Optional.of(current));
    when(collectionRepository.findAllReferencedCollectionsByParentId(7L))
        .thenReturn(List.of(existingChild));
    CollectionRequests.CollectionUpdate parents = new CollectionRequests.CollectionUpdate(
        null,
        List.of(new Records.ChildCollection(99L, null, null, null, null, null)),
        null);
    assertThatThrownBy(() -> collectionService.updateContent(current.getId(), updateWithParents(parents)))
        .isInstanceOf(IllegalArgumentException.class).hasMessageContaining("Cycle detected");
  }
  ```

- [ ] **Step 2: PASS + commit**
  ```bash
  ./mvnw -q test -Dtest=CollectionServiceTest#HandleParentCollectionUpdates
  git commit -am "test(collection-service): cover self-parent + 2-cycle rejection"
  ```

---

### Task 1.6: Populate `parents` on admin read path + include `collectionDate` in `CollectionList` projections

**Files:** `services/CollectionService.java`, possibly `util/CollectionProcessingUtil.java`.

- [ ] **Step 1: Find every `setSiblings(` site on the admin path**
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend
  grep -rn "setSiblings\|new Records.CollectionList(" src/main/java
  ```

- [ ] **Step 2: At each admin-path `setSiblings(...)` site, add a parallel `setParents(...)` block**
  ```java
  model.setParents(
      collectionRepository.findAllParentCollectionsByChildId(entity.getId()).stream()
          .map(p -> new Records.CollectionList(
              p.getId(), p.getTitle(), p.getSlug(), p.getType(), p.getCollectionDate()))
          .toList());
  ```
  Do NOT add `setParents` to public read paths — admin only.

- [ ] **Step 3: Update any other `new Records.CollectionList(id, name, slug, type)` 4-arg construction**

  Admin endpoints: pass `entity.getCollectionDate()` (real value, 5-arg constructor). Public list endpoints: leave 4-arg form (backwards-compat constructor sets `collectionDate=null`).

- [ ] **Step 4: Failing test** — add inside the existing `@Nested` block in `CollectionServiceTest.java` that tests `getUpdateCollectionData`:
  ```java
  @Test
  void getUpdateCollectionData_populatesParentsFromInverseJoin() {
    CollectionEntity child = CollectionEntity.builder().id(7L).slug("child").title("Child").build();
    CollectionEntity parent = CollectionEntity.builder()
        .id(42L).title("Parent").slug("parent").type(CollectionType.PARENT).build();
    when(collectionRepository.findEntityBySlug("child")).thenReturn(child);
    when(collectionRepository.findAllParentCollectionsByChildId(7L)).thenReturn(List.of(parent));
    // Copy the rest of the dependency stubs from the existing getUpdateCollectionData test in this block.

    CollectionRequests.UpdateResponse response = collectionService.getUpdateCollectionData("child");

    assertThat(response.collection().getParents())
        .extracting(Records.CollectionList::id).containsExactly(42L);
  }
  ```

- [ ] **Step 5: PASS + commit**
  ```bash
  ./mvnw -q test
  git add -A src/main/java/edens/zac/portfolio/backend/ src/test/java/edens/zac/portfolio/backend/
  git commit -m "feat(collection-service): populate parents on admin read path; collectionDate in CollectionList"
  ```

---

### Task 1.7: Controller binding test

**Files:** `controller/admin/CollectionAdminControllerTest.java`.

- [ ] **Step 1: Add test**
  ```java
  @Test
  void updateCollection_forwardsParentsFieldToService() throws Exception {
    CollectionRequests.UpdateResponse stubResponse = new CollectionRequests.UpdateResponse(
        CollectionModel.builder().id(7L).slug("child").build(), /* metadata */ null);
    when(collectionService.updateContentWithMetadata(eq(7L), any(CollectionRequests.Update.class)))
        .thenReturn(stubResponse);

    String body = """
        { "id": 7, "parents": { "newValue": [{"collectionId": 42}] } }
        """;

    mockMvc.perform(put("/api/admin/collection/7")
            .contentType(MediaType.APPLICATION_JSON).content(body))
        .andExpect(status().isOk());

    ArgumentCaptor<CollectionRequests.Update> cap =
        ArgumentCaptor.forClass(CollectionRequests.Update.class);
    verify(collectionService).updateContentWithMetadata(eq(7L), cap.capture());
    assertThat(cap.getValue().parents()).isNotNull();
    assertThat(cap.getValue().parents().newValue())
        .extracting(Records.ChildCollection::collectionId).containsExactly(42L);
  }
  ```
  **Adapt:** confirm URL (`/api/admin/collection/{id}`) and service method (`updateContent` vs `updateContentWithMetadata`) against the actual controller mapping.

- [ ] **Step 2: PASS + commit**
  ```bash
  ./mvnw -q test -Dtest=CollectionAdminControllerTest
  git commit -am "test(collection-admin): controller forwards parents field to service"
  ```

---

### Task 1.8: Full verify + push

- [ ] `./mvnw -q verify` → BUILD SUCCESS (Spotless + Checkstyle clean).
- [ ] If Spotless complains: `./mvnw -q spotless:apply && git commit -am "style: spotless:apply"`.
- [ ] `git push -u origin 0163-collections-parent-column-be`.

---

## Phase 2 — FE Types + Util

### Task 2.1: Extend types in `app/types/Collection.ts`

- [ ] **Step 1: `CollectionListModel` — add `collectionDate`**
  ```ts
  export interface CollectionListModel {
    id: number;
    name: string;
    slug?: string;
    type?: string;
    /** ISO date — used to sort BLOG group rows on the manage page. */
    collectionDate?: string | null;
  }
  ```

- [ ] **Step 2: `CollectionUpdateRequest` — add `parents?: CollectionUpdate`** next to `siblings`.

- [ ] **Step 3: `CollectionModel` (admin response) — add `parents?: CollectionListModel[]`** next to `siblings`.

- [ ] **Step 4: tsc clean + commit**
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
  git commit -am "feat(types): add collectionDate + parents to Collection types"
  ```

---

### Task 2.2: TDD `buildUpdatePayload` parents diff

**Files:** `tests/(admin)/collection/manage/[[...slug]]/manageUtils.test.ts`, `app/(admin)/collection/manage/[[...slug]]/manageUtils.ts`.

- [ ] **Step 1: Failing tests** — append inside the `buildUpdatePayload` describe block:
  ```ts
  it('includes parents when formData.parents is defined', () => {
    const original = { id: 7, type: 'PORTFOLIO' } as unknown as CollectionModel;
    const formData = {
      id: 7, parents: { newValue: [{ collectionId: 42, name: 'New Parent' }] },
    } as CollectionUpdateRequest;
    expect(buildUpdatePayload(formData, original).parents)
        .toEqual({ newValue: [{ collectionId: 42, name: 'New Parent' }] });
  });

  it('omits parents when formData.parents is undefined', () => {
    const original = { id: 7, type: 'PORTFOLIO' } as unknown as CollectionModel;
    expect(buildUpdatePayload({ id: 7 } as CollectionUpdateRequest, original).parents).toBeUndefined();
  });
  ```

- [ ] **Step 2: Implement** — in `manageUtils.ts` immediately after the existing `siblings` block (~line 148):
  ```ts
  if (formData.parents !== undefined) {
    payload.parents = formData.parents;
  }
  ```

- [ ] **Step 3: PASS + commit**
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/jest tests/\(admin\)/collection/manage/\[\[...slug\]\]/manageUtils.test.ts -t parents
  git commit -am "feat(manage-utils): include parents in update payload diff"
  ```

---

## Phase 3 — Frontend: `CollectionListSelector` (accordion + Parent column)

### Task 3.1: TDD `COLLECTION_TYPE_ORDER` + `sortGroup` helper

**Files:** `app/components/CollectionListSelector/CollectionListSelector.tsx`, `tests/components/CollectionListSelector.test.tsx`.

- [ ] **Step 1: Failing tests** — append to test file:
  ```ts
  import { sortGroup, COLLECTION_TYPE_ORDER }
    from '@/app/components/CollectionListSelector/CollectionListSelector';

  describe('COLLECTION_TYPE_ORDER', () => {
    it('lists HOME first then PARENT, CLIENT_GALLERY, ART_GALLERY, PORTFOLIO, BLOG, MISC', () => {
      expect(COLLECTION_TYPE_ORDER).toEqual([
        'HOME', 'PARENT', 'CLIENT_GALLERY', 'ART_GALLERY', 'PORTFOLIO', 'BLOG', 'MISC',
      ]);
    });
  });

  describe('sortGroup', () => {
    it('sorts BLOG by collectionDate desc, null last', () => {
      const sorted = sortGroup([
        { id: 1, name: 'B', collectionDate: '2025-01-15' },
        { id: 2, name: 'C', collectionDate: null },
        { id: 3, name: 'A', collectionDate: '2025-06-01' },
      ], 'BLOG');
      expect(sorted.map(c => c.id)).toEqual([3, 1, 2]);
    });

    it('sorts non-BLOG alphabetically by name', () => {
      const sorted = sortGroup([
        { id: 1, name: 'Charlie' }, { id: 2, name: 'Alpha' }, { id: 3, name: 'Bravo' },
      ], 'PORTFOLIO');
      expect(sorted.map(c => c.id)).toEqual([2, 3, 1]);
    });

    it('falls back to name when both BLOG entries have null collectionDate', () => {
      const sorted = sortGroup([
        { id: 1, name: 'B', collectionDate: null },
        { id: 2, name: 'A', collectionDate: null },
      ], 'BLOG');
      expect(sorted.map(c => c.id)).toEqual([2, 1]);
    });
  });
  ```

- [ ] **Step 2: Implement** — near top of `CollectionListSelector.tsx` (after imports, before `CheckboxState`):
  ```ts
  import { CollectionType } from '@/app/types/Collection';

  export const COLLECTION_TYPE_ORDER: CollectionType[] = [
    CollectionType.HOME, CollectionType.PARENT, CollectionType.CLIENT_GALLERY,
    CollectionType.ART_GALLERY, CollectionType.PORTFOLIO, CollectionType.BLOG, CollectionType.MISC,
  ];

  export function sortGroup(
    rows: CollectionListModel[],
    type: CollectionType | string | undefined,
  ): CollectionListModel[] {
    if (type === CollectionType.BLOG) {
      return [...rows].sort((a, b) => {
        const da = a.collectionDate ?? null;
        const db = b.collectionDate ?? null;
        if (da == null && db == null) return a.name.localeCompare(b.name);
        if (da == null) return 1;
        if (db == null) return -1;
        return db.localeCompare(da);
      });
    }
    return [...rows].sort((a, b) => a.name.localeCompare(b.name));
  }
  ```

- [ ] **Step 3: PASS + commit**
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/jest tests/components/CollectionListSelector.test.tsx -t 'COLLECTION_TYPE_ORDER|sortGroup'
  git commit -am "feat(collection-selector): add COLLECTION_TYPE_ORDER + sortGroup helper"
  ```

---

### Task 3.2: Add Parent column props (types only, no rendering)

**Files:** `app/components/CollectionListSelector/CollectionListSelector.tsx`.

- [ ] **Step 1: Extend `CollectionListSelectorProps`** — after the existing sibling props (~line 33):
  ```ts
  // Optional third ("Parent") toggle column. Engages 3-column "parentMode" when all four are supplied.
  parentSavedIds?: Set<number>;
  parentPendingAddIds?: Set<number>;
  parentPendingRemoveIds?: Set<number>;
  onToggleParent?: (collection: CollectionListModel) => void;
  ```

- [ ] **Step 2: Destructure + derive** — in the component signature, after `onToggleSibling,`:
  ```ts
  parentSavedIds, parentPendingAddIds, parentPendingRemoveIds, onToggleParent,
  ```
  After the `siblingMode` derivation:
  ```ts
  const parentMode =
    !!onToggleParent && !!parentSavedIds && !!parentPendingAddIds && !!parentPendingRemoveIds;
  const [hoveredParentId, setHoveredParentId] = useState<number | null>(null);
  ```

- [ ] **Step 3: tsc + commit**
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
  git commit -am "feat(collection-selector): add Parent column props (no rendering yet)"
  ```

---

### Task 3.3: Accordion grouping + HOME-pinned render + SCSS

**Files:** `app/components/CollectionListSelector/CollectionListSelector.tsx`, `app/components/CollectionListSelector/CollectionListSelector.module.scss`.

- [ ] **Step 1: Accordion state + grouping memo** — after `hoveredParentId`:
  ```ts
  const [expandedType, setExpandedType] = useState<CollectionType | null>(null);
  const accordionMode = siblingMode || parentMode;
  const groupsByType = useMemo(() => {
    if (!accordionMode) return null;
    const map = new Map<string, CollectionListModel[]>();
    for (const t of COLLECTION_TYPE_ORDER) map.set(t, []);
    for (const c of orderedCollections) {
      const t = (c.type as string) ?? 'MISC';
      if (!map.has(t)) map.set(t, []);
      map.get(t)!.push(c);
    }
    for (const [t, rows] of map) map.set(t, sortGroup(rows, t));
    return map;
  }, [accordionMode, orderedCollections]);
  ```

- [ ] **Step 2: Add `humanizeType` + extract `renderRow` helper** — above the `return` statement. The body preserves the existing row markup from `CollectionListSelector.tsx:158-232`, with `styles.expandedRow` added to the wrapper className when `expanded` is true. The Parent toggle cell stays as a placeholder comment (added in Task 3.4):
  ```tsx
  const humanizeType = (t: string) =>
    t.split('_').map(w => w.charAt(0) + w.slice(1).toLowerCase()).join(' ');

  const renderRow = (collection: CollectionListModel, expanded: boolean) => {
    if (siblingMode || parentMode) {
      return (
        <div
          key={collection.id}
          className={`${styles.row} ${styles.rowSibling} ${expanded ? styles.expandedRow : ''}`}
          role="group" aria-label={collection.name}
        >
          {onNavigate ? (
            <button
              type="button"
              className={`${styles.name} ${styles.nameButton}`}
              onClick={() => onNavigate(collection)}
              aria-label={`Open ${collection.name}`}
            >{collection.name}</button>
          ) : (
            <span className={styles.name}>{collection.name}</span>
          )}
          <span className={styles.toggleCell}>
            {renderCheckbox(collection, siblingSavedIds!, siblingPendingAddIds!,
              siblingPendingRemoveIds!, onToggleSibling!,
              hoveredSiblingId, setHoveredSiblingId, `Toggle sibling ${collection.name}`)}
          </span>
          <span className={styles.toggleCell}>
            {renderCheckbox(collection, savedCollectionIds, pendingAddIds, pendingRemoveIds, onToggle,
              hoveredChildId, setHoveredChildId, `Toggle child ${collection.name}`)}
          </span>
          {/* Parent toggle cell — added in Task 3.4 */}
        </div>
      );
    }
    return (
      <div
        key={collection.id}
        className={`${styles.row} ${onNavigate ? styles.navigable : ''}`}
        role="button" tabIndex={0}
        onClick={() => handleRowClick(collection)}
        onKeyDown={e => {
          if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handleRowClick(collection); }
        }}
      >
        {renderCheckbox(collection, savedCollectionIds, pendingAddIds, pendingRemoveIds, onToggle,
          hoveredChildId, setHoveredChildId, `Toggle ${collection.name}`)}
        <span className={styles.type}>{collection.type || 'Portfolio'}</span>
        <span className={styles.name}>{collection.name}</span>
      </div>
    );
  };
  ```
  Note: the `<span className={styles.type}>` from the sibling/parent branch (was at line 179) is OMITTED — the accordion header carries the type now. Single-column branch keeps it.

- [ ] **Step 3: Replace `.map(...)` in `<div className={styles.list}>`** with the accordion-aware render:
  ```tsx
  <div className={styles.list}>
    {accordionMode && groupsByType ? (
      <>
        {(groupsByType.get(CollectionType.HOME) ?? []).map(c => renderRow(c, false))}
        {COLLECTION_TYPE_ORDER.filter(t => t !== CollectionType.HOME).map(t => {
          const rows = groupsByType.get(t) ?? [];
          const isExpanded = expandedType === t;
          return (
            <div key={t}>
              <button
                type="button"
                className={`${styles.typeHeaderRow} ${isExpanded ? styles['typeHeaderRow--expanded'] : ''}`}
                onClick={() => setExpandedType(isExpanded ? null : t)}
                aria-expanded={isExpanded}
              >
                <span className={styles.typeHeaderChevron}>{isExpanded ? '▾' : '▸'}</span>
                <span className={styles.typeHeaderLabel}>{humanizeType(t)}</span>
                <span className={styles.typeHeaderCount}>({rows.length})</span>
              </button>
              {isExpanded && rows.map(c => renderRow(c, true))}
            </div>
          );
        })}
      </>
    ) : (
      orderedCollections.map(c => renderRow(c, false))
    )}
    {(!accordionMode && orderedCollections.length === 0) && (
      <div className={styles.emptyState}>No collections available</div>
    )}
  </div>
  ```

- [ ] **Step 4: SCSS additions** — append to `CollectionListSelector.module.scss`:
  ```scss
  :root {
    --collection-row-expanded-bg: rgba(255, 255, 255, 0.03);
  }
  .typeHeaderRow {
    display: flex; align-items: center; gap: 0.5rem;
    width: 100%; padding: 0.5rem 0.75rem;
    background: transparent; border: none;
    border-top: 1px solid var(--border-subtle, rgba(255, 255, 255, 0.05));
    text-align: left; cursor: pointer; color: inherit; font: inherit;
    &:hover { background: rgba(255, 255, 255, 0.02); }
  }
  .typeHeaderRow--expanded { background: rgba(255, 255, 255, 0.04); }
  .typeHeaderChevron { width: 1rem; opacity: 0.6; }
  .typeHeaderLabel { flex: 1; font-weight: 600; }
  .typeHeaderCount { opacity: 0.5; font-size: 0.85em; }
  .expandedRow { background-color: var(--collection-row-expanded-bg); }
  ```
  Tune `--collection-row-expanded-bg` value visually during smoke test (Task 5.2).

- [ ] **Step 5: Stylelint + tsc + commit**
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/stylelint --fix app/components/CollectionListSelector/CollectionListSelector.module.scss
  /opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
  git commit -am "feat(collection-selector): accordion grouping, HOME pinned, expanded-row SCSS"
  ```

---

### Task 3.4: Render Parent toggle column + rename header labels

**Files:** `app/components/CollectionListSelector/CollectionListSelector.tsx`.

- [ ] **Step 1: Replace the header block** (was at line 146-153):
  ```tsx
  {(siblingMode || parentMode) && (
    <div className={styles.columnHeaderRow}>
      <span className={styles.columnHeaderName}>Collection Name</span>
      {/* "Catalog Type" column removed — type is the accordion section header */}
      <span className={styles.columnHeaderToggle}>Sibling</span>
      <span className={styles.columnHeaderToggle}>Child</span>
      {parentMode && <span className={styles.columnHeaderToggle}>Parent</span>}
    </div>
  )}
  ```
  This renames "Catalog Name" → "Collection Name" and deletes the "Catalog Type" column.

- [ ] **Step 2: Replace the `{/* Parent toggle cell — added in Task 3.4 */}` placeholder** in `renderRow`:
  ```tsx
  {parentMode && (
    <span className={styles.toggleCell}>
      {renderCheckbox(collection, parentSavedIds!, parentPendingAddIds!, parentPendingRemoveIds!,
        onToggleParent!, hoveredParentId, setHoveredParentId,
        `Toggle parent ${collection.name}`)}
    </span>
  )}
  ```
  (The `disabled` / `disabledReason` trailing args arrive in Task 3.5 with defaults, so this 8-arg call continues to compile.)

- [ ] **Step 3: tsc + commit**
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
  git commit -am "feat(collection-selector): Parent toggle column + Catalog → Collection rename"
  ```

---

### Task 3.5: Mutual-exclusion disabled checkbox + tooltip

**Files:** `app/components/CollectionListSelector/CollectionListSelector.tsx`, `app/components/CollectionListSelector/CollectionListSelector.module.scss`, `tests/components/CollectionListSelector.test.tsx`.

- [ ] **Step 1: Failing tests** — append:
  ```tsx
  it('disables Parent checkbox when row is currently checked as Child', () => {
    const onToggleParent = jest.fn();
    render(
      <CollectionListSelector
        allCollections={[{ id: 10, name: 'X', type: 'PORTFOLIO' }]}
        savedCollectionIds={new Set([10])}
        pendingAddIds={new Set()} pendingRemoveIds={new Set()}
        onToggle={jest.fn()}
        siblingSavedIds={new Set()} siblingPendingAddIds={new Set()} siblingPendingRemoveIds={new Set()}
        onToggleSibling={jest.fn()}
        parentSavedIds={new Set()} parentPendingAddIds={new Set()} parentPendingRemoveIds={new Set()}
        onToggleParent={onToggleParent}
      />
    );
    fireEvent.click(screen.getByText('Portfolio'));
    const btn = screen.getByLabelText('Toggle parent X');
    expect(btn).toHaveAttribute('aria-disabled', 'true');
    fireEvent.click(btn);
    expect(onToggleParent).not.toHaveBeenCalled();
  });

  it('disables Child checkbox when row is currently checked as Parent', () => {
    const onToggleChild = jest.fn();
    render(
      <CollectionListSelector
        allCollections={[{ id: 11, name: 'Y', type: 'PORTFOLIO' }]}
        savedCollectionIds={new Set()} pendingAddIds={new Set()} pendingRemoveIds={new Set()}
        onToggle={onToggleChild}
        siblingSavedIds={new Set()} siblingPendingAddIds={new Set()} siblingPendingRemoveIds={new Set()}
        onToggleSibling={jest.fn()}
        parentSavedIds={new Set([11])} parentPendingAddIds={new Set()} parentPendingRemoveIds={new Set()}
        onToggleParent={jest.fn()}
      />
    );
    fireEvent.click(screen.getByText('Portfolio'));
    expect(screen.getByLabelText('Toggle child Y')).toHaveAttribute('aria-disabled', 'true');
  });

  it('does NOT disable Parent when row is saved-but-pending-removal as Child', () => {
    render(
      <CollectionListSelector
        allCollections={[{ id: 12, name: 'Z', type: 'PORTFOLIO' }]}
        savedCollectionIds={new Set([12])} pendingAddIds={new Set()} pendingRemoveIds={new Set([12])}
        onToggle={jest.fn()}
        siblingSavedIds={new Set()} siblingPendingAddIds={new Set()} siblingPendingRemoveIds={new Set()}
        onToggleSibling={jest.fn()}
        parentSavedIds={new Set()} parentPendingAddIds={new Set()} parentPendingRemoveIds={new Set()}
        onToggleParent={jest.fn()}
      />
    );
    fireEvent.click(screen.getByText('Portfolio'));
    expect(screen.getByLabelText('Toggle parent Z')).not.toHaveAttribute('aria-disabled', 'true');
  });
  ```

- [ ] **Step 2: Extend `renderCheckbox`** to accept `disabled` (default `false`) and `disabledReason`:
  ```tsx
  const renderCheckbox = (
    collection: CollectionListModel,
    savedIds: Set<number>, pendingAdd: Set<number>, pendingRemove: Set<number>,
    onClick: (c: CollectionListModel) => void,
    hoveredId: number | null, setHoveredId: (id: number | null) => void,
    ariaLabel: string,
    disabled: boolean = false, disabledReason: string | undefined = undefined,
  ) => {
    const state = getCheckboxState(collection.id, savedIds, pendingAdd, pendingRemove);
    const isHovered = hoveredId === collection.id;
    const isSelected = state === 'saved' || state === 'pending-add';
    const showRemoveIntent = !disabled && isHovered && isSelected;
    return (
      <button
        type="button"
        className={`${styles.checkbox} ${styles[`checkbox--${state}`]} ${showRemoveIntent ? styles['checkbox--remove-intent'] : ''} ${disabled ? styles['checkbox--disabled'] : ''}`}
        onClick={e => { e.stopPropagation(); if (!disabled) onClick(collection); }}
        onMouseEnter={() => !disabled && setHoveredId(collection.id)}
        onMouseLeave={() => setHoveredId(null)}
        aria-label={ariaLabel}
        aria-disabled={disabled || undefined}
        title={disabled ? disabledReason : undefined}
      />
    );
  };
  ```

- [ ] **Step 3: Compute mutual-exclusion flags inside `renderRow`** — at top of the sibling/parent branch:
  ```tsx
  const isActivelyChild =
    (savedCollectionIds.has(collection.id) && !pendingRemoveIds.has(collection.id)) ||
    pendingAddIds.has(collection.id);
  const isActivelyParent = parentMode && (
    ((parentSavedIds?.has(collection.id) ?? false) && !(parentPendingRemoveIds?.has(collection.id) ?? false)) ||
    (parentPendingAddIds?.has(collection.id) ?? false)
  );
  const parentDisabled = parentMode && isActivelyChild;
  const childDisabled  = parentMode && isActivelyParent;
  const disabledReason = 'A collection cannot be both a parent and a child of the same collection.';
  ```
  Then pass the extra two args to the Child and Parent `renderCheckbox` calls (e.g. `..., childDisabled, childDisabled ? disabledReason : undefined,` and `..., parentDisabled, parentDisabled ? disabledReason : undefined,`).

- [ ] **Step 4: SCSS** — append:
  ```scss
  .checkbox--disabled { opacity: 0.35; cursor: not-allowed; pointer-events: auto; }
  ```

- [ ] **Step 5: PASS + commit**
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/jest tests/components/CollectionListSelector.test.tsx -t 'disables|does NOT disable'
  git commit -am "feat(collection-selector): mutual-exclusion disabled checkbox + tooltip"
  ```

---

### Task 3.6: Accordion behavior + HOME-pinned + sort tests

**Files:** `tests/components/CollectionListSelector.test.tsx`.

- [ ] **Step 1: Add tests** (implementation already lands in 3.3/3.4):
  ```tsx
  const allTypes: CollectionListModel[] = [
    { id: 1, name: 'Home', type: 'HOME' },
    { id: 2, name: 'P1', type: 'PORTFOLIO' }, { id: 3, name: 'P2', type: 'PORTFOLIO' },
    { id: 4, name: 'B1', type: 'BLOG', collectionDate: '2025-01-01' },
    { id: 5, name: 'B2', type: 'BLOG', collectionDate: '2025-06-01' },
    { id: 6, name: 'M', type: 'MISC' },
  ];

  function renderInThreeColumnMode(rows = allTypes) {
    return render(
      <CollectionListSelector
        allCollections={rows}
        savedCollectionIds={new Set()} pendingAddIds={new Set()} pendingRemoveIds={new Set()}
        onToggle={jest.fn()}
        siblingSavedIds={new Set()} siblingPendingAddIds={new Set()} siblingPendingRemoveIds={new Set()}
        onToggleSibling={jest.fn()}
        parentSavedIds={new Set()} parentPendingAddIds={new Set()} parentPendingRemoveIds={new Set()}
        onToggleParent={jest.fn()}
      />
    );
  }

  it('renders Collection Name header (not Catalog Name) in 3-column mode', () => {
    renderInThreeColumnMode();
    expect(screen.getByText('Collection Name')).toBeInTheDocument();
    expect(screen.queryByText('Catalog Name')).not.toBeInTheDocument();
    expect(screen.queryByText('Catalog Type')).not.toBeInTheDocument();
  });

  it('renders Parent column header', () => {
    renderInThreeColumnMode();
    expect(screen.getByText('Parent')).toBeInTheDocument();
  });

  it('renders HOME row always visible at top, no Home accordion header', () => {
    renderInThreeColumnMode();
    expect(screen.getByText('Home')).toBeInTheDocument();
    expect(screen.queryAllByRole('button', { name: /^Home$/ })).toHaveLength(0);
  });

  it('renders 6 collapsed non-HOME type headers by default; no rows beneath', () => {
    renderInThreeColumnMode();
    ['Parent', 'Client Gallery', 'Art Gallery', 'Portfolio', 'Blog', 'Misc'].forEach(l =>
      expect(screen.getByText(l)).toBeInTheDocument());
    expect(screen.queryByText('P1')).not.toBeInTheDocument();
    expect(screen.queryByText('B1')).not.toBeInTheDocument();
  });

  it('expand-collapse accordion: opening Blog closes Portfolio', () => {
    renderInThreeColumnMode();
    fireEvent.click(screen.getByText('Portfolio'));
    expect(screen.getByText('P1')).toBeInTheDocument();
    expect(screen.getByText('P2')).toBeInTheDocument();
    fireEvent.click(screen.getByText('Blog'));
    expect(screen.queryByText('P1')).not.toBeInTheDocument();
    expect(screen.getByText('B1')).toBeInTheDocument();
    expect(screen.getByText('B2')).toBeInTheDocument();
  });

  it('BLOG group renders rows in collectionDate desc order', () => {
    renderInThreeColumnMode();
    fireEvent.click(screen.getByText('Blog'));
    const rows = screen.getAllByText(/^B\d$/);
    expect(rows.map(r => r.textContent)).toEqual(['B2', 'B1']);
  });

  it('PORTFOLIO group renders rows alphabetically', () => {
    renderInThreeColumnMode([
      { id: 1, name: 'Charlie', type: 'PORTFOLIO' },
      { id: 2, name: 'Alpha', type: 'PORTFOLIO' },
      { id: 3, name: 'Bravo', type: 'PORTFOLIO' },
    ]);
    fireEvent.click(screen.getByText('Portfolio'));
    const names = screen.getAllByText(/Charlie|Alpha|Bravo/);
    expect(names.map(n => n.textContent)).toEqual(['Alpha', 'Bravo', 'Charlie']);
  });
  ```

- [ ] **Step 2: PASS + commit**
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/jest tests/components/CollectionListSelector.test.tsx
  git commit -am "test(collection-selector): accordion + HOME-pinned + sort coverage"
  ```

---

### Task 3.7: Catalog → Collection rename — sweep remaining references

- [ ] `grep -rn "Catalog Name\|Catalog Type" app tests --include="*.tsx" --include="*.ts" --include="*.scss"`
- [ ] Edit each match (likely test assertions using `getByText('Catalog Name')`) to use "Collection Name" / "Collection Type".
- [ ] Commit only if changes: `git commit -am "chore: complete Catalog → Collection rename sweep"`.

---

## Phase 4 — Frontend: `ManageClient.tsx` wiring

### Task 4.1: Parent state + handler + props

**Files:** `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx`.

- [ ] **Step 1: Derivations** — beside the existing sibling derivations:
  ```tsx
  const originalParentIds = useMemo(
    () => new Set<number>((collection?.parents ?? []).map(p => p.id)),
    [collection?.parents]
  );
  const pendingParentAddIds = useMemo(() => {
    const ids = new Set<number>();
    for (const p of updateData.parents?.newValue ?? []) ids.add(p.collectionId);
    return ids;
  }, [updateData.parents?.newValue]);
  const pendingParentRemoveIds = useMemo(
    () => new Set<number>(updateData.parents?.remove ?? []),
    [updateData.parents?.remove]
  );
  ```

- [ ] **Step 2: Handler** — near `handleSiblingToggle`:
  ```tsx
  const handleParentToggle = useCallback((toggled: CollectionListModel) => {
    setUpdateData(prev => ({
      ...prev,
      parents: toggleRelation(
        prev.parents, toggled, originalParentIds,
        c => ({ collectionId: c.id, name: c.name })
      ),
    }));
  }, [originalParentIds]);
  ```

- [ ] **Step 3: Props** — pass to `<CollectionListSelector …>`:
  ```tsx
  parentSavedIds={originalParentIds}
  parentPendingAddIds={pendingParentAddIds}
  parentPendingRemoveIds={pendingParentRemoveIds}
  onToggleParent={handleParentToggle}
  ```

- [ ] **Step 4: tsc + commit**
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
  git commit -am "feat(manage-client): wire parents state + handler into CollectionListSelector"
  ```

---

## Phase 5 — Verification

### Task 5.1: Lint / format / type-check / full jest

- [ ] Prettier + ESLint + Stylelint over touched files:
  ```bash
  cd /Users/themancalledzac/Code/edens.zac
  /opt/homebrew/bin/node node_modules/.bin/prettier --write \
    "app/components/CollectionListSelector/**" \
    "app/(admin)/collection/manage/[[...slug]]/**" \
    "app/types/Collection.ts" \
    "tests/components/CollectionListSelector.test.tsx" \
    "tests/(admin)/collection/manage/[[...slug]]/manageUtils.test.ts"
  /opt/homebrew/bin/node node_modules/.bin/eslint --fix \
    app/components/CollectionListSelector \
    "app/(admin)/collection/manage/[[...slug]]" \
    app/types/Collection.ts \
    tests/components/CollectionListSelector.test.tsx \
    "tests/(admin)/collection/manage/[[...slug]]/manageUtils.test.ts"
  /opt/homebrew/bin/node node_modules/.bin/stylelint --fix app/components/CollectionListSelector/CollectionListSelector.module.scss
  /opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
  /opt/homebrew/bin/node node_modules/.bin/jest
  ```
- [ ] Commit any formatting churn: `git commit -am "style: prettier/eslint/stylelint pass" || true`.

### Task 5.2: Smoke on local preview server

- [ ] `PORT=3001 /opt/homebrew/bin/node node_modules/.bin/next dev` (user holds 3000).
- [ ] Visit `http://localhost:3001/collection/manage/hidden-lake`.
- [ ] Verify: HOME pinned at top (no Home header); below it, six collapsed accordion headers in order Parent / Client Gallery / Art Gallery / Portfolio / Blog / Misc; clicking Blog shows newest-first; clicking Portfolio closes Blog and shows alphabetical; expanded rows have slightly lighter background; header reads "Collection Name | Sibling | Child | Parent" with no "Catalog" anywhere; Child↔Parent mutual-exclusion disables the opposite checkbox with tooltip; Save persists parent toggle and survives reload.
- [ ] Tune `--collection-row-expanded-bg` value if needed.
- [ ] Stop server (Ctrl-C).

### Task 5.3: Push + PRs

- [ ] FE push: `cd /Users/themancalledzac/Code/edens.zac && git push -u origin 0163-collections-parent-column`.
- [ ] BE push: `cd /Users/themancalledzac/Code/edens.zac.backend && git push -u origin 0163-collections-parent-column-be`.
- [ ] FE PR:
  ```bash
  gh pr create --title "feat(collection): Parent column + type-grouped accordion rows on manage page" \
    --body "$(cat <<'EOF'
  ## Summary
  - Third Parent toggle column derived from inverse of collection_content/content_collection. No new join table or endpoint.
  - Accordion grouping by CollectionType; HOME pinned always-visible at top.
  - BLOG sorted by collectionDate desc, others alphabetical. Catalog → Collection rename.
  - Direct 2-cycle prevention (FE disables opposite checkbox + tooltip; BE 400).

  ## Backend
  Separate PR on `0163-collections-parent-column-be`. Merge BE first.

  ## Spec
  `docs/superpowers/specs/2026-06-02-collections-parent-column-and-grouped-rows-design.md` (gitignored, local-only).

  ## Test plan
  - [ ] BE `./mvnw verify` BUILD SUCCESS
  - [ ] FE `tsc --noEmit` clean, full jest passes
  - [ ] Smoke `/collection/manage/hidden-lake`

  🤖 Generated with [Claude Code](https://claude.com/claude-code)
  EOF
  )"
  ```
- [ ] BE PR:
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend
  gh pr create --title "feat(collection): parents field on Update DTO + inverse-write service path" \
    --body "$(cat <<'EOF'
  ## Summary
  - New `parents: CollectionUpdate` on `CollectionRequests.Update`. Service inverts args and delegates to existing `handleCollectionToCollectionUpdates`.
  - New repo query `findAllParentCollectionsByChildId` populates admin read path. Excludes soft-deleted memberships; no visibility gate.
  - `collectionDate` added to `Records.CollectionList` for FE BLOG sort.
  - Cycle guards: self-parent + direct 2-cycle.

  ## Test plan
  - [ ] `./mvnw verify` BUILD SUCCESS

  🤖 Generated with [Claude Code](https://claude.com/claude-code)
  EOF
  )"
  ```

---

## Spec → Plan Coverage

| Spec § | Task |
|---|---|
| 5.1 DTO additions | 1.1 |
| 5.2 Cycle guards | 1.3 (impl), 1.5 (tests) |
| 5.3 Repo query | 1.2 |
| 5.4 Service method add / remove | 1.3, 1.4 |
| 5.5 Read-path population | 1.6 |
| 5.6 Controller (no change) | 1.7 binding test |
| 5.7 BE tests | 1.2–1.7 |
| 6.1 FE types | 2.1 |
| 6.2.1 Parent props | 3.2 |
| 6.2.2 TYPE_ORDER + accordion state | 3.1, 3.3 |
| 6.2.3 Accordion render (HOME pinned) | 3.3 |
| 6.2.4 Sort (BLOG by date, others alpha) | 3.1 helper, 3.6 tests |
| 6.2.5 Mutual-exclusion | 3.5 |
| 6.2.6 Header + rename | 3.4 |
| 6.2.7 Rename sweep | 3.7 |
| 6.3 SCSS | 3.3 + 3.5 |
| 6.4 buildUpdatePayload | 2.2 |
| 6.5 ManageClient | 4.1 |
| 6.6 FE tests | 3.5, 3.6 |
| 8 Edge cases (self-parent, 2-cycle, HIDDEN, soft-del, null date, MISC, HOME) | 1.2, 1.5, 3.1, 3.3, 3.6 |
| 9 Build sequence | Phases 0–5 |

No spec section is uncovered; no task lacks a spec reference.

## Dead-code notes

- `styles.columnHeaderType` SCSS class becomes unused after Task 3.4 — grep + delete if no other ref.
- `<span className={styles.type}>{collection.type || 'Portfolio'}</span>` removed from accordion-mode rows (kept in single-column branch).
