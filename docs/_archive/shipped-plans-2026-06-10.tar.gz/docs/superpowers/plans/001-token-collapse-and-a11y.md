# 001 · Color-Token Collapse & a11y Polish
_Chapter [001 · Design System Unification](../../001-design-review.md) · plan · branch `0152-token-collapse-a11y`_

> ✅ **SHIPPED — [PR #159](https://github.com/themancalledzac/edens.zac/pull/159) (merged 2026-06-03).** One semantic color taxonomy + `--scrim-{dark,light}-*` scales, `--duration-*`/`--ease-standard` motion tokens, one `--focus-ring`, banned bare `outline:none`, real per-page `h1`, `prefers-reduced-motion` guard; 12 dead tokens deleted post-ship. **Two carve-outs were intentionally deferred** and now live in [006 · Code Health](../../006-code-health.md): the `@custom-media` breakpoint bridge (Task 5 — postcss/Next 16 conflict) and the gap-rule + `rgb()`-slash sweeps (Tasks 6d/6e). The plan below is preserved as the implementation record.

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Collapse the three divergent color families + the ~15-token "shadow namespace" + the 9-step `--color-overlay-light-*` ramp + ~94 inline `rgb()` literals into **one** semantic color taxonomy; add `--duration-*`/`--ease-standard` motion tokens to replace ~43 magic-number transitions; bridge the existing `--breakpoint-*` tokens into a `@custom-media` layer so the 100 hardcoded `768px` queries become token-driven; and finish the a11y debt (one `--focus-ring`, banned bare `outline:none`, a real per-page `h1`, a `prefers-reduced-motion` guard on parallax, the gap-rule fix, and standardized `rgb()` slash syntax). This is the **last** phase of the design-system unification — it deletes the Task 0.1 alias block and assumes primitives have migrated.

**Architecture:** All changes are token-layer + mechanical-sweep + small targeted edits. The new semantic roles live in `app/styles/globals.css`'s `:root`/`html` block alongside the already-healthy `--space/--radius/--text/--z` scales. A `postcss.config.mjs` (re-declaring Next's default pipeline + `postcss-custom-media`) hosts `@custom-media` definitions sourced from the existing `--breakpoint-*` tokens. CSS-only changes are verified via `stylelint --fix` (clean) + browser computed-style spot-checks (they are **not** jest-unit-testable). The one behavioral change — emitting a real `h1` per collection/home — is a Server-Component edit covered by a React Testing Library test asserting `getByRole('heading')`.

**Tech Stack:** Next.js 16 App Router, React 19 (named imports), strict TypeScript (no `any`), SCSS Modules with bare `var(--token)` (no `@use` partial), PostCSS (`postcss-custom-media`), Jest + React Testing Library (tests mirror `app/` under `tests/`; with `next/jest`, `styles.foo === 'foo'`), Stylelint (`stylelint-config-standard-scss`, `.stylelintrc`).

> **Spec:** This plan implements [`../../001-design-review.md`](../../001-design-review.md) **§6b** (the unified color taxonomy), **§6c** (the migration sequence — step 5/6: migrate call sites then delete dead tokens last), **§5** 🟢-Low row (parallax reduced-motion, `outline:none`, gap-rule, breakpoint systems, 40+ magic transitions, `--color-danger` 4 values, `--color-primary` near-black-vs-blue), and **§1.3** (the shadow namespace). It is **Phase 4** of the master plan [`001-design-system-unification.md`](001-design-system-unification.md). Section references like *(review §6b)* point to the design review.
>
> **Status:** ✅ **Merged to `main` via [PR #159](https://github.com/themancalledzac/edens.zac/pull/159) (`0152-token-collapse-a11y`, 2026-06-03).** Tasks 1, 2, 3, 4, 6a, 6b, 6c **done**; Task 5 (`@custom-media` breakpoint bridge) **deferred** — `postcss-custom-media` is not installable in the current Next 16 + Turbopack setup without risking the build; the 93 literal `768px` queries stay in place. Tasks 6d (gap-rule) and 6e (rgb() syntax sweep) **deferred** — not in the shipping commit; either re-scope into a small follow-up or fold into the next code-health MR. The stylelint guard from Task 3 Step 7 (`csstools/value-no-unknown-custom-properties`) was **intentionally not added** per user preference ("don't gate, just don't add dead tokens"). See the **Shipped panel** below for the actual landed scope + post-ship cleanup.

---

## Shipped panel (2026-06-02, branch `0152-token-collapse-a11y`)

**Landed commits (in order):**

| Commit | Plan task | Notes |
|---|---|---|
| `e941075 feat(tokens): add unified semantic color taxonomy + scrim alpha scales` | Task 1 | Declared the surface/on-surface/accent roles + `--scrim-dark/light-{10..90}` |
| `ff1c6eb fix(tokens): split brand/accent collision (ReorderOverlay blue) + drop dead danger fallbacks` | Task 2 | ReorderOverlay outline + pickup button now resolve to real blue |
| `95b05e7 refactor(tokens): migrate legacy color families onto semantic roles + delete dead tokens` | Task 3 (− Step 7) | ~30 SCSS modules migrated; 27 legacy tokens deleted. Stylelint guard NOT added (user opted out — "shouldn't be adding variables that aren't used" is the rule, not a CI check) |
| `69b7037 refactor(tokens): add --duration-*/--ease-standard, tokenize the magic transitions` | Task 4 | 63 transition literals swept (estimate was 43) |
| `431c8f4 feat(a11y): focus-ring token, keyboard-visible focus, real h1, reduced-motion guard` | Tasks 6a/6b/6c | 4 inputs gained `:focus-visible` rings; CollectionPage emits a visually-hidden `<h1>` (RTL-tested); useParallax respects `prefers-reduced-motion` (SSR-safe, reactive to OS toggle) |
| `da5509e fix(lint): replace nested ternary in LocationPageClient filmFilter seed` | (review polish) | |

**Intentional color shifts** (visual verification — all upgrades, no fixes needed):
- `#333 → #111` (`--color-text-primary` → `--color-on-surface`): text darker, contrast ratio 12.6 → 18.9 on white.
- `#999 → #666` (`--color-text-muted` → `--color-on-surface-muted`): muted labels darker, contrast 2.85 → 5.74 (was failing WCAG AA, now passes).
- `#ccc`/`#dee2e6` → `#e5e5e5` (border families collapsed): decorative only, no WCAG impact.

**Deferred (still open):**
- **Task 5** — `@custom-media` breakpoint bridge. `postcss-custom-media` collides with Next 16's built-in PostCSS pipeline; the 93 literal `768px` queries remain. Re-evaluate after a future Next upgrade or when the cost of literal duplication outgrows the install risk.
- **Task 6d** — gap-rule fix on `ContentComponent.module.scss` (per-image directional padding → row `gap`). Fold into the next code-health MR; small and standalone.
- **Task 6e** — `rgb()` slash-syntax sweep via stylelint. Fold into the same code-health MR — mechanical, low-risk.

**Post-ship cleanup (also on this branch, 2026-06-02):**

Manual sweeps leave orphans. Verified with `grep "var(--<token>)"` after the migration finished — the following declarations had **0 references** and were deleted from `globals.css`:

| Token | Why it was dead |
|---|---|
| `--color-fg-muted` | Renamed to `--color-on-surface-muted` in Task 3; the old name was never re-pointed at any call site |
| `--color-surface` | Declared as the canonical "page canvas" role, but every consumer uses the older `--color-bg` (which already plays the same role); a duplicate role with no migration target |
| `--color-on-accent` | Declared for "text on an accent fill" but no primitive ever needed it — `--color-white` covers the only current call site (Button danger variant) |
| `--scrim-dark-10` through `--scrim-dark-90` (9 tokens) | The whole dark-scrim ramp was declared symmetrically with `--scrim-light-*` but never picked up a single call site. Reintroduce per-step on first real need. |

**Total post-ship deletion: 12 color tokens.** `globals.css` is now **240 lines** (was 246 on `main` pre-0152; the sweep is genuinely a small net shrink, not the noisy "0-net" headline number — the new semantic + motion + focus tokens absorbed most of the reclaimed space).

**Rule established (going forward):** don't add a token speculatively. If a primitive has no call site that needs the role today, defer the declaration until the first real need. The token layer is documentation of usage, not aspiration.

---

## PREREQUISITE — this is the LAST phase

This plan **must run after Phases 0–3** of the master plan, because:

- **Phase 0 (Task 0.1)** declared the non-breaking **alias block** (`--text-primary`, `--border-color`, `--color-accent`, `--surface-secondary`, etc.) that mapped the shadow namespace onto real tokens. **This plan deletes that block** (Task 3) — so it can only run once every usage has been migrated onto the semantic roles. (Note: verified against the live `globals.css`, the alias block from master-plan Task 0.1 is **not yet present** — if Phases 0–3 are skipped, Task 1 below still introduces the semantic roles, but Task 3's deletion step becomes a no-op for the alias block and only the legacy `--color-text-*`/`--color-bg-*` family is removed. Do **not** run Task 3's deletion until `grep` confirms zero remaining usages, per its guard step.)
- **Phases 1–2 (primitives)** moved ~30–38 button classes, 5 modal shells, 6 chips, 3 badges, and the form set onto canonical components in `app/components/ui/`. Those primitives already consume `--color-fg`/`--color-bg`/`--color-border`/`--color-danger`/`--color-accent`; this plan only **renames the underlying role tokens** and repoints the primitives' SCSS at them. Migrating the legacy family (Task 3) is safe only because the per-feature button/modal/chip CSS that referenced `--color-bg-light` etc. has already been deleted by Phases 1–2.
- **Phase 3** wired URL state + deep-linking; no token dependency, but its new components must also pass the stylelint guards this plan tightens.

**Pre-flight check (run before starting Task 1):**

```bash
cd /Users/themancalledzac/Code/edens.zac
# Confirm primitives exist (Phases 1–2 done) — expect a non-empty listing:
ls app/components/ui/Button/Button.tsx app/components/ui/Modal/Modal.tsx 2>/dev/null
# Snapshot the legacy-token usage counts we will drive to zero:
grep -rEn "color-text-(primary|secondary|muted)" app --include='*.scss' | wc -l   # baseline: 26
grep -rEn "color-bg-(light|medium|dark)" app --include='*.scss' | wc -l           # baseline: 15
grep -rn  "color-overlay-light-" app --include='*.scss' | wc -l                   # baseline: 85
```

If the primitives do **not** exist, stop and execute the master plan's Phases 1–2 first.

---

## File-structure map

**Modified:**

```
app/styles/globals.css                                  (Tasks 1, 2, 3, 4 — the token source of truth)
postcss.config.mjs                                      (Task 5 — NEW file: Next pipeline + postcss-custom-media)
app/styles/custom-media.css                             (Task 5 — NEW file: @custom-media definitions)
app/components/Content/ReorderOverlay.module.scss       (Task 2 — blue accent fix)
app/components/Content/ContentComponent.module.scss     (Tasks 3,4,5,6 — sweeps + gap-rule fix)
app/components/Content/CollectionContentRenderer.tsx    (Task 6 — title becomes h1, see note)
app/components/ContentCollection/CollectionPage.tsx     (Task 6 — emits the real per-page h1)
app/components/ContentCollection/ContentCollectionPage.module.scss (Task 6 — .srOnly + h1 visual style)
app/page.module.scss                                    (Task 5 — delete $bp/@mixin up())
app/styles/fullscreen-image.module.scss                 (Tasks 4,5,6 — durations, 768/600 queries, outline:none)
app/hooks/useParallax.ts                                (Task 6 — prefers-reduced-motion guard)
app/layout.tsx                                          (Task 1 — themeColor → token-derived literal)
.stylelintrc                                            (Tasks 3,6 — guard rules)
package.json                                            (Task 5 — postcss-custom-media devDependency)
~40 *.module.scss across app/                           (Tasks 3,4,5,6 — mechanical sweeps, exact greps below)
```

**Created:**

```
postcss.config.mjs
app/styles/custom-media.css
tests/components/ContentCollection/CollectionPage.test.tsx   (Task 6 — the h1 RTL test)
```

---

## Verified source facts (from reading the live files — every token/count below was confirmed)

- `globals.css` declares `--color-fg: var(--color-black)` (`#111`), `--color-bg: var(--color-white)` (`#fff`), `--color-fg-muted: #666`, `--color-border: #e5e5e5`.
- Legacy admin family: `--color-bg-light: #f8f9fa`, `--color-bg-medium: #e9ecef`, `--color-bg-dark: #dee2e6`, `--color-border-light: #ccc`, `--color-border-medium: #dee2e6`, `--color-border-dark: #adb5bd`, `--color-text-primary: #333`, `--color-text-secondary: #666`, `--color-text-muted: #999`.
- `--color-primary: #212226` (near-black), `--color-primary-dark: #1a1b1e`, `--color-success: #22c55e`, `--color-success-dark: #16a34a`, `--color-danger: #dc3545`.
- `--color-blue: rgb(59, 130, 246)`, `--color-blue-text: rgb(147, 197, 253)`.
- `--color-overlay-strong: rgb(0,0,0,0.7)` and `--color-overlay-soft: rgb(0,0,0,0.1)` are declared but have **0 usages** (verified). The `--color-overlay-light-{05,10,20,30,40,50,60,70,90}` ramp has **85 usages** (note: **80 is missing** from the ramp).
- `--color-danger` is referenced with **3 distinct inline fallbacks** across modules: `var(--color-danger, #c0392b)`, `var(--color-danger, #e53e3e)`, `var(--color-danger, #ef4444)` — plus the canonical `#dc3545` declaration = 4 red values total (review §5).
- `ReorderOverlay.module.scss:13,55` use `outline: 3px solid var(--color-primary, #3b82f6)` / `background: var(--color-primary, #3b82f6)` — author **intended blue** (the `#3b82f6` fallback + the adjacent `background: rgb(59,130,246,0.1)` on line 15 prove it), but `--color-primary` **is** declared (`#212226`), so the fallback never fires → the selection outline resolves **near-black**. Latent bug (review §5, master-plan register).
- Hardcoded breakpoint queries: **100** `768px`, **4** `1024px`, **0** `1280px`, **19** `600px` (the fullscreen landscape height gate) in `app/**/*.scss`.
- Bare `outline: none`: **9** occurrences across **6** files — `fullscreen-image.module.scss:162,185,386`, `TextBlockCreateModal.module.scss:135`, `MetadataPage.module.scss:143`, `ContactForm.module.scss:41,61`, `ClientGalleryGate.module.scss:59`, `ImageMetadataModal.module.scss:167`.
- Magic-number transitions: **43** `transition:` declarations with a literal duration across **15** files. Distinct durations: `0.15s` (40×), `0.2s` (33×), `0.3s` (1×), plus `1s`/`0.8s`/`0.125s`/`0.1s` (spinner/keyframe — leave alone).
- `rgb()` syntax: **68** legacy-comma `rgb(0,…)` + **26** slash `rgb(0 0 0 / x%)` = mixed; standardize.
- Collection/home title flow: `CollectionPage.tsx:52` sets `overlayText: col.title || col.slug || ''`; `CollectionContentRenderer.tsx:323,468` render it as `<div className={cbStyles.textOverlay}>` — **no `h1` anywhere** (review §5 🟡 Medium). `CollectionPage` is a **Server Component**; an existing `.srOnly` pattern lives in `RatingStars.module.scss:24`.
- No `postcss.config.*` exists; no `--duration-*`/`--ease-*` tokens exist; no `@custom-media` anywhere. `next.config.js` sets `sassOptions`. `jest.config.mjs` uses `next/jest` (so CSS-module class names equal their key: `styles.foo === 'foo'`).
- Gap-rule violation: `ContentComponent.module.scss` `.imageLeft/.imageRight/.imageMiddle` add directional `padding-{left,right}: 0.4rem` *between* row items at `@media (width >= 768px)` (review §5 🟢 — should be a row `gap`).
- `app/layout.tsx:38` sets `themeColor: '#ffffff'`.

---

## Task 1 — Define the unified semantic color taxonomy in globals.css

**Why:** Three color families + a 9-step overlay ramp + ~94 inline `rgb()` literals make the color layer un-themeable and impossible to reason about (review §1.3, §6b). One semantic role-set + one scrim alpha scale replaces them.

**Files:**
- Modify: `app/styles/globals.css` (the `html, :root` block, lines 8–135)
- Modify: `app/layout.tsx:38`

- [ ] **Step 1 — Add the semantic role tokens + scrim scales.** In `globals.css`, immediately **after** the existing `--color-fg: var(--color-black);` line (line 16) and **before** the `/* Badge and overlay colors */` comment (line 18), insert:

```css

  /* ── Unified semantic color taxonomy (review §6b). Roles, not raw colors.
     These are the canonical names; everything below migrates onto them and the
     legacy --color-text-*/--color-bg-*/overlay-light-* families are deleted. ── */
  --color-surface: var(--color-white); /* page + card canvas */
  --color-surface-raised: #f8f9fa; /* raised panels (was --color-bg-light) */
  --color-on-surface: var(--color-black); /* primary text on surface */
  --color-on-surface-muted: #666; /* secondary/muted text (was --color-fg-muted/-text-secondary) */
  --color-accent: rgb(59, 130, 246); /* interactive/selection blue (was the --color-blue collision target) */
  --color-on-accent: var(--color-white); /* text/icons on an accent fill */

  /* Scrim alpha ramps — one dark + one light scale, 10..90 in steps of 10.
     Replaces the 9-step --color-overlay-light-* ramp + ~94 inline rgb() literals. */
  --scrim-dark-10: rgb(0 0 0 / 10%);
  --scrim-dark-20: rgb(0 0 0 / 20%);
  --scrim-dark-30: rgb(0 0 0 / 30%);
  --scrim-dark-40: rgb(0 0 0 / 40%);
  --scrim-dark-50: rgb(0 0 0 / 50%);
  --scrim-dark-60: rgb(0 0 0 / 60%);
  --scrim-dark-70: rgb(0 0 0 / 70%);
  --scrim-dark-80: rgb(0 0 0 / 80%);
  --scrim-dark-90: rgb(0 0 0 / 90%);
  --scrim-light-10: rgb(255 255 255 / 10%);
  --scrim-light-20: rgb(255 255 255 / 20%);
  --scrim-light-30: rgb(255 255 255 / 30%);
  --scrim-light-40: rgb(255 255 255 / 40%);
  --scrim-light-50: rgb(255 255 255 / 50%);
  --scrim-light-60: rgb(255 255 255 / 60%);
  --scrim-light-70: rgb(255 255 255 / 70%);
  --scrim-light-80: rgb(255 255 255 / 80%);
  --scrim-light-90: rgb(255 255 255 / 90%);
```

`--color-border`, `--color-danger`, `--color-success` already exist as semantic roles and are kept as-is (Task 2 collapses the danger fallbacks; `--color-on-accent` reuses `--color-white`). `--color-on-surface` and `--color-on-surface-muted` are introduced here; the `--color-text-*` family they replace is **deleted in Task 3** after migration.

- [ ] **Step 2 — Repoint `themeColor` at the surface token's literal.** `themeColor` in a Next `Viewport` export cannot read a CSS var, so use the resolved hex. In `app/layout.tsx:38`:

```diff
-  themeColor: '#ffffff',
+  themeColor: '#ffffff', // = --color-surface (var(--color-white)); keep in sync if the surface color changes
```

(Value unchanged; the comment documents the binding. If a later theme decision changes `--color-surface`, update both.)

- [ ] **Step 3 — stylelint the file:**

```bash
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/styles/globals.css'
```
Expected output: no errors (exit 0); the new `rgb(… / …%)` slash declarations pass `color-function-notation: null`.

- [ ] **Step 4 — Verify the tokens resolve (browser, not jest — token declarations aren't unit-testable).** With the dev server on :3001, in DevTools console:

```js
getComputedStyle(document.documentElement).getPropertyValue('--color-surface').trim()   // expect "var(--color-white)" or computed "#fff"
getComputedStyle(document.documentElement).getPropertyValue('--scrim-dark-50').trim()    // expect "rgb(0 0 0 / 50%)" (or rgba(0,0,0,0.5))
getComputedStyle(document.documentElement).getPropertyValue('--color-accent').trim()     // expect "rgb(59, 130, 246)"
```

- [ ] **Step 5 — Commit:**

```bash
git add app/styles/globals.css app/layout.tsx
git commit -m "feat(tokens): add unified semantic color taxonomy + scrim alpha scales

Introduces --color-surface/-surface-raised, --color-on-surface/-on-surface-muted,
--color-accent (+ --color-on-accent), and --scrim-dark-{10..90}/--scrim-light-{10..90}
in globals.css. These are the canonical roles the legacy color families migrate onto
in the following tasks. themeColor documented as the --color-surface literal.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 2 — Split the `--color-primary` near-black/blue collision + collapse the 4 `--color-danger` values

**Why:** `--color-primary` (`#212226`, near-black) is the brand near-black, but `ReorderOverlay.module.scss` references it expecting **blue** (`var(--color-primary, #3b82f6)`), so the selection outline silently resolves near-black — a latent bug (review §5; master-plan register). Separately, `--color-danger` has 4 distinct values (one declaration + 3 inline fallbacks) — there should be one.

**Files:**
- Modify: `app/components/Content/ReorderOverlay.module.scss:13,15,55`
- Modify: `app/styles/globals.css:105` (canonical `--color-danger` value)
- Modify (sweep): the 3 modules with `var(--color-danger, #…)` fallbacks

- [ ] **Step 1 — Fix the ReorderOverlay blue intent.** `--color-primary` (brand near-black) stays as the brand token; the *accent/selection* role is now `--color-accent` (blue, Task 1). In `ReorderOverlay.module.scss`:

```diff
   &.pickedUp {
-    outline: 3px solid var(--color-primary, #3b82f6);
+    outline: 3px solid var(--color-accent);
     outline-offset: -3px;
-    background: rgb(59, 130, 246, 0.1);
+    background: rgb(59 130 246 / 10%);
   }
```

and the pick-up button fill:

```diff
 .pickUpButton {
-  background: var(--color-primary, #3b82f6);
+  background: var(--color-accent);
   color: white;
 }
```

(The `rgb(59 130 246 / 10%)` is an accent-at-10% tint; left inline because there is no `--color-accent` alpha token — acceptable as a one-off, slash-normalized.)

- [ ] **Step 2 — Pick the one canonical danger value.** Keep the existing declaration `--color-danger: #dc3545;` (globals.css:105) as the single source of truth. The inline fallbacks `#c0392b`/`#e53e3e`/`#ef4444` are redundant — the token is always declared, so the fallback is dead. **Remove every inline fallback**, leaving bare `var(--color-danger)`.

  Run the exact sweep:

```bash
cd /Users/themancalledzac/Code/edens.zac
# Show the 3 distinct fallbacks (confirm before editing):
grep -rEho 'var\(--color-danger, *#[0-9a-fA-F]{3,6}\)' app --include='*.scss' | sort -u
# In-place strip the fallback from every var(--color-danger, #xxxxxx):
grep -rElZ 'var\(--color-danger, *#' app --include='*.scss' \
  | xargs -0 perl -pi -e 's/var\(--color-danger, *#[0-9a-fA-F]{3,6}\)/var(--color-danger)/g'
```

  **Transformation rule:** `var(--color-danger, #<hex>)` → `var(--color-danger)` (drop the comma + fallback). **Worked example** — `app/components/MetadataPage/MetadataPage.module.scss:206`:

```diff
-    color: var(--color-danger, #e53e3e);
+    color: var(--color-danger);
```

  and `ReorderOverlay.module.scss:60`:

```diff
 .cancelButton {
-  background: var(--color-danger, #ef4444);
+  background: var(--color-danger);
```

- [ ] **Step 3 — Verify no danger fallbacks remain + ReorderOverlay is blue:**

```bash
grep -rEn 'var\(--color-danger, *#' app --include='*.scss' ; echo "exit: $?"   # expect exit 1, no matches
grep -rn "color-primary" app/components/Content/ReorderOverlay.module.scss ; echo "exit: $?"  # expect exit 1
```

- [ ] **Step 4 — stylelint the touched files:**

```bash
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/Content/ReorderOverlay.module.scss' 'app/styles/globals.css' $(grep -rElZ 'var\(--color-danger' app --include='*.scss' | tr '\0' ' ')
```
Expected: no errors.

- [ ] **Step 5 — Verify in browser (reorder mode):** open a collection's manage/reorder view on :3001, pick up an image → the selection outline is **blue** (`rgb(59,130,246)`), not near-black. (CSS-only; not jest-testable.)

- [ ] **Step 6 — Commit:**

```bash
git add app/components/Content/ReorderOverlay.module.scss app/styles/globals.css app/components
git commit -m "fix(tokens): split brand/accent collision (ReorderOverlay blue) + collapse danger to one value

ReorderOverlay's selection outline used var(--color-primary, #3b82f6) expecting blue,
but --color-primary is the brand near-black (#212226) so it resolved near-black. Repointed
at the new --color-accent. Removed the 3 redundant inline --color-danger fallbacks
(#c0392b/#e53e3e/#ef4444); the canonical #dc3545 declaration is the single source.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 3 — Migrate legacy color families onto the new roles, then delete them + the alias block

**Why:** Review §6c step 5/6 — migrate call sites onto the semantic roles, then delete the dead families **last**. The legacy `--color-text-{primary,secondary,muted}` (26 usages), `--color-bg-{light,medium,dark}` (15 usages), and `--color-overlay-light-*` ramp (85 usages) all have a clean role mapping.

**Files:**
- Modify (sweep): ~40 `*.module.scss` files referencing the legacy tokens
- Modify: `app/styles/globals.css` (delete the legacy declarations + the Task 0.1 alias block)
- Modify: `.stylelintrc` (add the undeclared-`var()` guard)

- [ ] **Step 1 — Migrate the text family.** Mapping: `--color-text-primary` → `--color-on-surface`, `--color-text-secondary` → `--color-on-surface-muted`, `--color-text-muted` → `--color-on-surface-muted` (the `#999` vs `#666` distinction is dropped intentionally — review §6b collapses both to one muted role).

```bash
cd /Users/themancalledzac/Code/edens.zac
grep -rElZ 'color-text-(primary|secondary|muted)' app --include='*.scss' \
  | xargs -0 perl -pi -e '
      s/var\(--color-text-primary(?:, *[^)]*)?\)/var(--color-on-surface)/g;
      s/var\(--color-text-secondary(?:, *[^)]*)?\)/var(--color-on-surface-muted)/g;
      s/var\(--color-text-muted(?:, *[^)]*)?\)/var(--color-on-surface-muted)/g;
    '
```

  **Worked example** — `app/components/Content/ContentComponent.module.scss:796,850` (note these carry fallbacks):

```diff
-  color: var(--color-text-muted);
+  color: var(--color-on-surface-muted);
...
-  color: var(--color-text-muted, #6b7280);
+  color: var(--color-on-surface-muted);
```

- [ ] **Step 2 — Migrate the surface family.** Mapping: `--color-bg-light` → `--color-surface-raised`, `--color-bg-medium` → `--color-surface-raised`, `--color-bg-dark` → `--color-surface-raised` (the three near-identical greys `#f8f9fa`/`#e9ecef`/`#dee2e6` collapse to one raised-surface role; the `#fff` page canvas is `--color-surface`).

```bash
grep -rElZ 'color-bg-(light|medium|dark)' app --include='*.scss' \
  | xargs -0 perl -pi -e '
      s/var\(--color-bg-light(?:, *[^)]*)?\)/var(--color-surface-raised)/g;
      s/var\(--color-bg-medium(?:, *[^)]*)?\)/var(--color-surface-raised)/g;
      s/var\(--color-bg-dark(?:, *[^)]*)?\)/var(--color-surface-raised)/g;
    '
```

  **Worked example** — `ContentComponent.module.scss:792`:

```diff
-  background-color: var(--color-border-medium);
+  background-color: var(--color-surface-raised);
```

  (Note: `--color-border-medium` is a *border* token here misused as a placeholder fill; map the **placeholder** to `--color-surface-raised`. The border-token family — `--color-border-light/medium/dark` — keeps its `--color-border` role; collapse with the rule below.)

- [ ] **Step 3 — Migrate the border family.** Mapping: `--color-border-light` / `--color-border-medium` / `--color-border-dark` → `--color-border` (one border role).

```bash
grep -rElZ 'color-border-(light|medium|dark)' app --include='*.scss' \
  | xargs -0 perl -pi -e 's/var\(--color-border-(light|medium|dark)(?:, *[^)]*)?\)/var(--color-border)/g'
```

- [ ] **Step 4 — Migrate the overlay-light ramp onto `--scrim-light-*`.** The ramp step number maps 1:1 (`-50` → `--scrim-light-50`); the missing `-80` had a special-case alias in master-plan Task 0.1 and is now a real step.

```bash
grep -rElZ 'color-overlay-light-[0-9]' app --include='*.scss' \
  | xargs -0 perl -pi -e 's/var\(--color-overlay-light-0?(\d0|5)(?:, *[^)]*)?\)/"var(--scrim-light-" . ($1 eq "5" ? "10" : $1) . ")"/ge'
```

  **Transformation rule:** `var(--color-overlay-light-NN)` → `var(--scrim-light-NN)`, mapping the odd `-05` step up to the nearest real step `--scrim-light-10` (the 5% step has no scrim equivalent; 10% is the closest — acceptable since it's faint UI tint). **Worked example** — `fullscreen-image.module.scss:237,245,255`:

```diff
-  color: var(--color-overlay-light-90);
+  color: var(--scrim-light-90);
...
-  color: var(--color-overlay-light-50);
+  color: var(--scrim-light-50);
...
-  border-top: 1px solid var(--color-overlay-light-20);
+  border-top: 1px solid var(--scrim-light-20);
```

  After the sweep, **manually verify** any `-05` collapses look right (faint hover tints).

- [ ] **Step 5 — Verify all legacy usages are gone:**

```bash
grep -rEn 'color-text-(primary|secondary|muted)' app --include='*.scss' ; echo "text exit: $?"        # expect exit 1
grep -rEn 'color-bg-(light|medium|dark)'           app --include='*.scss' ; echo "bg exit: $?"          # expect exit 1
grep -rEn 'color-border-(light|medium|dark)'       app --include='*.scss' ; echo "border exit: $?"      # expect exit 1
grep -rn  'color-overlay-light-'                   app --include='*.scss' ; echo "overlay exit: $?"     # expect exit 1
```

  If any matches remain (e.g. a usage inside a comment or an unusual fallback shape), migrate by hand to the mapped role.

- [ ] **Step 6 — Delete the dead declarations from `globals.css`.** Remove these lines from the `:root` block (verified present at): `--color-bg-light` / `-medium` / `-dark` (88–90), `--color-border-light` / `-medium` (91–92), `--color-border-dark` (135), `--color-text-primary` / `-secondary` / `-muted` (93–95), and the **entire** `--color-overlay-light-05..90` ramp (109–117). **Also delete the Task 0.1 alias block** if Phases 0–3 added it (`--text-primary`, `--text-secondary`, `--text-muted`, `--text-base`, `--border-color`, `--color-bg-subtle`, `--color-bg-muted`, `--surface-secondary`, `--color-accent` alias, `--radius-sm`, `--color-overlay-light-80`) — Task 1 already declares the real `--color-accent`, so the alias line must go to avoid a redeclaration. **Keep**: `--color-fg`, `--color-bg`, `--color-fg-muted` (still referenced by the new roles and elsewhere — verify with grep before deleting any), `--color-white`, `--color-black`, `--color-primary`/`-dark`, `--color-success`/`-dark`, `--color-danger`, `--color-blue`/`-text`, `--color-overlay-strong`/`-soft`.

  Guard before deleting each: `grep -rn "<token>" app --include='*.scss' --include='*.css' --include='*.tsx'` must show only the declaration line.

- [ ] **Step 7 — Add the stylelint undeclared-`var()` guard.** Install the csstools plugin and wire it so any future `var(--undeclared)` fails CI:

```bash
/opt/homebrew/bin/node node_modules/.npm/_npx 2>/dev/null; \
/opt/homebrew/bin/node node_modules/.bin/npm i -D stylelint-value-no-unknown-custom-properties 2>/dev/null \
  || echo "If npm not runnable here, add the devDependency manually and run install."
```

  Then in `.stylelintrc`, add to a new `"plugins"` array and enable the rule (sourcing declarations from `globals.css` + the new `custom-media.css`):

```diff
 {
   "extends": [
     "stylelint-config-standard-scss",
     "stylelint-prettier/recommended"
   ],
+  "plugins": ["stylelint-value-no-unknown-custom-properties"],
   "rules": {
+    "csstools/value-no-unknown-custom-properties": [true, {
+      "importFrom": ["app/styles/globals.css", "app/styles/custom-media.css"]
+    }],
     "alpha-value-notation": null,
```

  (`custom-media.css` is created in Task 5; if running Task 3 before Task 5, list only `globals.css` and add the second path when Task 5 lands.)

- [ ] **Step 8 — Full verification:**

```bash
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/**/*.scss' 'app/**/*.css'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest
```
Expected: stylelint clean (the new guard reports **zero** undeclared `var()`); tsc clean; full jest suite green (no behavioral change in this task).

- [ ] **Step 9 — Commit:**

```bash
git add app/ .stylelintrc package.json package-lock.json
git commit -m "refactor(tokens): migrate legacy color families onto semantic roles + delete dead tokens

Codemods --color-text-*/-bg-*/-border-*/-overlay-light-* (≈126 usages) onto
--color-on-surface[-muted]/--color-surface[-raised]/--color-border/--scrim-light-*,
then deletes the legacy declarations and the Phase-0 alias block from globals.css.
Adds a stylelint guard (csstools/value-no-unknown-custom-properties) so undeclared
var() references can no longer regrow.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 4 — Motion tokens: `--duration-*` + `--ease-standard`, sweep the magic transitions

**Why:** 43 `transition:` declarations hardcode durations across 15 files (review §5 🟢). Distinct values cluster cleanly: `0.15s` (40×), `0.2s` (33×), `0.3s` (1×). Tokenizing them centralizes timing and lets a future reduced-motion / speed change be one edit.

**Files:**
- Modify: `app/styles/globals.css` (add tokens)
- Modify (sweep): the 15 `*.scss` files with literal transition durations

- [ ] **Step 1 — Declare the motion tokens** in `globals.css`, immediately after the `--shadow-sm` line (132) and before `--color-border-dark`/the Z-Index block:

```css

  /* Motion tokens (review §5). Replace ~43 magic-number transition durations.
     fast = micro UI (hover tint), base = standard, slow = larger affordances. */
  --duration-fast: 0.15s;
  --duration-base: 0.2s;
  --duration-slow: 0.3s;
  --ease-standard: ease;
```

- [ ] **Step 2 — Sweep literal durations onto the tokens.** Map `0.15s` → `var(--duration-fast)`, `0.2s` → `var(--duration-base)`, `0.3s` → `var(--duration-slow)`. **Scope the replacement to `transition` declarations only** (do NOT touch `animation`/`@keyframes` durations like the `1s`/`0.8s` spinners). The safe, reviewable approach is per-value within `transition`:

```bash
cd /Users/themancalledzac/Code/edens.zac
# Only rewrite durations that appear inside a transition: declaration.
grep -rElZ 'transition[^;{}]*[0-9]\.[0-9]+s' app --include='*.scss' \
  | xargs -0 perl -pi -e '
      s{(transition[^;{}]*?)0\.15s}{$1 . "var(--duration-fast)"}ge;
      s{(transition[^;{}]*?)0\.2s}{$1 . "var(--duration-base)"}ge;
      s{(transition[^;{}]*?)0\.3s}{$1 . "var(--duration-slow)"}ge;
    '
```

  **Transformation rule:** inside any `transition` value, the literal `0.15s`/`0.2s`/`0.3s` becomes `var(--duration-fast|base|slow)`; the easing keyword (`ease`, `ease-in`, `ease-out`) is left as-is (it's already terse and varies intentionally). **Worked example** — `fullscreen-image.module.scss:136,158`:

```diff
-  transition: opacity 0.2s ease-in;
+  transition: opacity var(--duration-base) ease-in;
...
-  transition: background-color 0.2s;
+  transition: background-color var(--duration-base);
```

  and a multi-line example — `ImageMetadataModal.module.scss` `transition: all 0.2s;` → `transition: all var(--duration-base);`; `CollectionListSelector.module.scss:94` `transition: all 0.15s ease;` → `transition: all var(--duration-fast) ease;`.

- [ ] **Step 3 — Verify no literal transition durations remain + spinners untouched:**

```bash
grep -rEn 'transition[^;{}]*[0-9]\.[0-9]+s' app --include='*.scss' ; echo "transition exit: $?"   # expect exit 1
grep -rn 'animation:.*1s\|animation:.*0.8s' app --include='*.scss'                                # spinners should still be literal
```

- [ ] **Step 4 — stylelint + commit:**

```bash
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/**/*.scss' 'app/styles/globals.css'
git add app/
git commit -m "refactor(tokens): add --duration-*/--ease-standard, tokenize the ~43 magic transitions

Adds --duration-fast(0.15s)/-base(0.2s)/-slow(0.3s) + --ease-standard to globals.css and
sweeps every literal duration inside transition: declarations onto them. Animation/keyframe
durations (spinners) intentionally left literal.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 5 — `@custom-media` breakpoint bridge: migrate the hardcoded 768/1024 queries, delete page.module.scss's `$bp`/`@mixin up()`

**Why:** Three competing breakpoint systems coexist (the `--breakpoint-*` tokens used by 0 of ~104 queries, raw `768px`/`1024px` literals, and `page.module.scss`'s SCSS `$bp-sm/$bp-md/$bp-lg` + `@mixin up()`) (review §5 🟢). CSS custom properties can't be used in media-query conditions, but `@custom-media` can — and `postcss-custom-media` resolves it at build. One named set replaces all three.

**Files:**
- Create: `postcss.config.mjs`, `app/styles/custom-media.css`
- Modify: `package.json` (devDependency), `app/layout.tsx` (import the custom-media css) — see Step 3
- Modify: `app/page.module.scss` (delete `$bp`/`@mixin up()`)
- Modify (sweep): all `*.scss` with `768px`/`1024px` media queries

- [ ] **Step 1 — Add the postcss plugin.** Next 16 uses its own built-in PostCSS pipeline; supplying a `postcss.config.mjs` **replaces** it, so it must re-declare Next's defaults. Install the plugin:

```bash
cd /Users/themancalledzac/Code/edens.zac
/opt/homebrew/bin/node node_modules/.bin/npm i -D postcss-custom-media 2>/dev/null \
  || echo "If npm not runnable here, add postcss-custom-media to devDependencies + install."
```

- [ ] **Step 2 — Create `postcss.config.mjs`** re-declaring Next's default plugin chain + `postcss-custom-media` (which must run first so `@custom-media` is resolved before Next's transforms):

```js
// Supplying this file replaces Next's built-in PostCSS config, so Next's default
// plugin (postcss-flexbugs-fixes + preset-env via next/font is handled internally;
// the documented default chain below mirrors Next 16). postcss-custom-media resolves
// @custom-media (sourced from app/styles/custom-media.css) into real media queries.
export default {
  plugins: {
    'postcss-custom-media': {
      importFrom: ['app/styles/custom-media.css'],
    },
  },
};
```

  > **Verify against installed Next:** before finalizing, run `/opt/homebrew/bin/node -e "console.log(require('next/dist/build/webpack/config/blocks/css/plugins').getPostCssPlugins?.toString?.())"` is brittle; instead confirm in the browser (Step 6) that existing Tailwind-free styling still compiles. Next 16 with Turbopack reads `postcss.config.mjs`; since this project uses `sassOptions` (SCSS, not PostCSS-nesting), the only PostCSS transform we depend on is autoprefixing, which SCSS-compiled output rarely needs for the `width >=` range syntax already in use. If a regression appears, the fallback is to **skip the plugin** and instead define the `@custom-media` values directly is not possible (CSS can't) — so keep the plugin; the config above is minimal and correct for an SCSS-module project.

- [ ] **Step 3 — Create `app/styles/custom-media.css`** sourcing the existing `--breakpoint-*` token values (`768/1024/1280`) + the fullscreen landscape height gate (`600px`):

```css
/* Named breakpoints — single source for media queries. Values mirror the
   --breakpoint-* tokens in globals.css (768/1024/1280) plus the fullscreen
   landscape height gate. Resolved at build by postcss-custom-media. */
@custom-media --bp-mobile (width >= 768px);
@custom-media --bp-tablet (width >= 1024px);
@custom-media --bp-desktop (width >= 1280px);
@custom-media --bp-landscape (width >= 768px) and (height >= 600px);
@custom-media --bp-landscape-strict (width > 768px) and (height >= 600px);
```

  Import it once at the top of `app/layout.tsx` (alongside the existing `globals.css` import) so the definitions are in scope for the global build:

```diff
 import './styles/globals.css';
+import './styles/custom-media.css';
```

- [ ] **Step 4 — Migrate the `768px`/`1024px` queries.** Mapping: `@media (width >= 768px)` → `@media (--bp-mobile)`; `@media (width >= 1024px)` → `@media (--bp-tablet)`; the fullscreen `(width >= 768px) and (height >= 600px)` → `@media (--bp-landscape)`; `(width > 768px) and (height >= 600px)` → `@media (--bp-landscape-strict)`.

```bash
cd /Users/themancalledzac/Code/edens.zac
grep -rElZ '768px|1024px' app --include='*.scss' \
  | xargs -0 perl -pi -e '
      s/\(width >= 768px\) and \(height >= 600px\)/(--bp-landscape)/g;
      s/\(width > 768px\) and \(height >= 600px\)/(--bp-landscape-strict)/g;
      s/\(width >= 768px\)/(--bp-mobile)/g;
      s/\(width >= 1024px\)/(--bp-tablet)/g;
    '
```

  **Transformation rule:** replace the *condition* inside `@media (...)`; the compound landscape gates are matched **first** (most specific) so the bare-width rules don't partially rewrite them. **Worked example** — `ContentComponent.module.scss:23,206` and the `:root` query in `globals.css:151,238`:

```diff
-  @media (width >= 768px) {
+  @media (--bp-mobile) {
```

  and `fullscreen-image.module.scss:24,45`:

```diff
-  @media (width > 768px) and (height >= 600px) {
+  @media (--bp-landscape-strict) {
...
-  @media (width >= 768px) and (height >= 600px) {
+  @media (--bp-landscape) {
```

  After the sweep, confirm the **two `:root` desktop-heading queries** in `globals.css` (lines 151, 238) also migrated — they're `(width >= 768px)` → `(--bp-mobile)`.

- [ ] **Step 5 — Delete `page.module.scss`'s SCSS breakpoint system.** In `app/page.module.scss`, remove the `$bp-sm/$bp-md/$bp-lg` declarations (lines 15–17) and the `@mixin up($bp)` (lines 19–23). Replace the two `@include up($bp-md)` call sites (`.coverImageTag` line 62, `.contentBlock` region) with `@media (--bp-mobile)` — note `$bp-md` is `768px` so it maps to `--bp-mobile`:

```diff
-/* SCSS breakpoints and mixin */
-$bp-sm: 480px;
-$bp-md: 768px;
-$bp-lg: 1024px;
-
-@mixin up($bp) {
-  @media (min-width: $bp) {
-    @content;
-  }
-}
-
 .main {
...
 .coverImageTag {
   @extend .contentBlock;

   /* Cap width on larger screens to keep parity with grid visuals */
-  @include up($bp-md) {
+  @media (--bp-mobile) {
     max-width: 600px;
   }
 }
```

  (`$bp-sm`/`$bp-lg` are unused after removal — confirm with `grep -n '\$bp' app/page.module.scss` returning nothing.)

- [ ] **Step 6 — Verify the sweep + build compiles:**

```bash
grep -rn '768px' app --include='*.scss' ; echo "768 exit: $?"     # expect exit 1 (all migrated)
grep -rn '1024px' app --include='*.scss' ; echo "1024 exit: $?"   # expect exit 1
grep -n '\$bp\|@mixin up\|@include up' app/page.module.scss ; echo "page exit: $?"  # expect exit 1
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/**/*.scss' 'app/**/*.css'
```
  Then **browser verification** (CSS build, not jest): start the dev server on :3001 and confirm a desktop-width and a mobile-width render are both correct (e.g. `ContentComponent` rows go from column to row at ≥768px; the SiteHeader title size changes at the `:root` breakpoint). If `@custom-media` did not resolve (raw `(--bp-mobile)` leaks to the browser and the media query is ignored), the postcss plugin isn't running — recheck Step 2's config path.

- [ ] **Step 7 — Commit:**

```bash
git add postcss.config.mjs app/styles/custom-media.css app/layout.tsx app/ package.json package-lock.json
git commit -m "refactor(css): add @custom-media breakpoint bridge, migrate 768/1024 queries, drop SCSS \$bp

Adds postcss-custom-media + app/styles/custom-media.css defining --bp-mobile/-tablet/
-desktop/-landscape from the existing --breakpoint values. Sweeps the 100 literal 768px
and 4 1024px media queries onto the named breakpoints and deletes page.module.scss's
competing \$bp-sm/-md/-lg + @mixin up().

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 6 — a11y polish: focus ring, banned `outline:none`, real `h1`, reduced-motion guard, gap-rule fix, rgb() syntax

This task bundles the remaining §5 🟢/🟡 a11y items. The CSS-only sub-steps verify via stylelint + browser; the **`h1` change gets a real RTL test**.

**Files:**
- Modify: `app/styles/globals.css` (`--focus-ring` token)
- Modify: the 6 modules with bare `outline: none` + `.stylelintrc`
- Modify: `app/components/ContentCollection/CollectionPage.tsx`, `app/components/ContentCollection/ContentCollectionPage.module.scss`
- Create: `tests/components/ContentCollection/CollectionPage.test.tsx`
- Modify: `app/hooks/useParallax.ts`
- Modify: `app/components/Content/ContentComponent.module.scss` (gap-rule)

### 6a — One `--focus-ring` token + ban bare `outline:none`

- [ ] **Step 1 — Add the token** in `globals.css` (after the motion tokens from Task 4):

```css

  /* Focus ring (review §5). One ring everywhere; bare outline:none is banned via stylelint. */
  --focus-ring: 2px solid var(--color-accent);
```

- [ ] **Step 2 — Replace the 9 bare `outline: none` with a focus-visible pattern.** The 9 occurrences fall in two categories:
  - **Genuine reset paired with a `:focus-visible` rule** (the fullscreen buttons at `fullscreen-image.module.scss:185,386` use `&:focus:not(:focus-visible) { outline: none; }` — that's the *correct* pattern, keep it but it triggers the lint ban). For these, the bare `outline: none` is acceptable; the stylelint rule (Step 3) will use a message-level exception via an inline disable comment on those two lines only.
  - **Bare resets with NO focus-visible fallback** (`fullscreen-image.module.scss:162` on `.metadataToggle`, `TextBlockCreateModal:135`, `MetadataPage:143`, `ContactForm:41,61`, `ClientGalleryGate:59`, `ImageMetadataModal:167`). For each, **replace** the bare reset with a focus-visible ring:

  **Worked example** — `ContactForm.module.scss:41,61`:

```diff
-  outline: none;
+  &:focus-visible {
+    outline: var(--focus-ring);
+    outline-offset: 2px;
+  }
```

  (If the `outline: none` is inside a `:focus` block, convert that block to `:focus-visible` and set the ring; never leave a focusable control with no visible focus indicator.)

  For `fullscreen-image.module.scss:162` `.metadataToggle` — it already has a `&:focus-visible { outline: 2px solid var(--color-overlay-light-50); }` at line 179 (now `--scrim-light-50` after Task 3) and a `&:focus:not(:focus-visible) { outline: none; }` at 185. Repoint the focus-visible to the token:

```diff
   &:focus-visible {
-    outline: 2px solid var(--color-overlay-light-50);
+    outline: var(--focus-ring);
     outline-offset: 2px;
   }
```

  and leave line 162's base `outline: none` (it's the resting state, paired with the focus-visible rule) — annotate it with the disable comment in Step 3. Same for the `.navButtonPrev/.navButtonNext` block (line 381 focus-visible → `--focus-ring`).

- [ ] **Step 3 — Add the stylelint ban + scoped exceptions.** In `.stylelintrc`, ban bare `outline: none` with a custom-message via the `declaration-property-value-disallowed-list` rule, and add `/* stylelint-disable-next-line */` on the two legitimate `:focus:not(:focus-visible)` resets:

```diff
   "rules": {
+    "declaration-property-value-disallowed-list": {
+      "outline": ["/^none$/"]
+    },
     "alpha-value-notation": null,
```

  Then on `fullscreen-image.module.scss` line 185 and 386 (the `&:focus:not(:focus-visible) { outline: none; }` resets, which are the *correct* keyboard-vs-mouse pattern):

```scss
  &:focus:not(:focus-visible) {
    /* stylelint-disable-next-line declaration-property-value-disallowed-list -- intentional: paired with :focus-visible ring above */
    outline: none;
  }
```

- [ ] **Step 4 — Verify the ban holds:**

```bash
/opt/homebrew/bin/node node_modules/.bin/stylelint 'app/**/*.scss'
```
  Expected: passes (the only `outline: none` left are the two annotated ones); any *new* bare `outline: none` would fail.

### 6b — Real `h1` per collection / home (titles are `div.textOverlay`)

- [ ] **Step 5 — Write the failing RTL test** `tests/components/ContentCollection/CollectionPage.test.tsx`. `CollectionPage` is a Server Component but renders synchronously (no `await`), so it can be unit-rendered. It pulls in `ContentBlockWithFullScreen` (a client tree) — mock it to isolate the heading assertion:

```tsx
import { render, screen } from '@testing-library/react';

import CollectionPage from '@/app/components/ContentCollection/CollectionPage';
import { CollectionType } from '@/app/types/Collection';
import { CollectionVisibility } from '@/app/types/CollectionVisibility';

// Isolate the heading: stub the heavy client render tree + SiteHeader.
jest.mock('@/app/components/Content/ContentBlockWithFullScreen', () => ({
  __esModule: true,
  default: () => <div data-testid="content-blocks" />,
}));
jest.mock('@/app/components/ContentCollection/CollectionPageClient', () => ({
  __esModule: true,
  default: () => <div data-testid="collection-client" />,
}));
jest.mock('@/app/components/SiteHeader/SiteHeader', () => ({
  __esModule: true,
  default: () => <header data-testid="site-header" />,
}));

const baseCollection = {
  id: 1,
  title: 'Iceland 2024',
  slug: 'iceland-2024',
  type: CollectionType.PORTFOLIO,
  visibility: CollectionVisibility.LISTED,
  content: [],
  coverImage: null,
  description: null,
  isPasswordProtected: false,
  createdAt: '2024-01-01',
  updatedAt: '2024-01-01',
  collectionDate: '2024-01-01',
};

describe('CollectionPage', () => {
  it('renders a single h1 with the collection title (single-collection view)', () => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- test fixture cast to model
    render(<CollectionPage collection={baseCollection as any} />);
    const heading = screen.getByRole('heading', { level: 1 });
    expect(heading).toHaveTextContent('Iceland 2024');
  });

  it('renders an h1 for the array (home/all-collections) view', () => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- test fixture cast to model
    render(<CollectionPage collection={[baseCollection] as any} />);
    expect(screen.getByRole('heading', { level: 1 })).toBeInTheDocument();
  });
});
```

```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ContentCollection/CollectionPage.test.tsx
```
  Expected: FAIL — `Unable to find an accessible element with the role "heading" and level "1"`.

- [ ] **Step 6 — Add the `.srOnly` heading style** to `ContentCollectionPage.module.scss` (mirror the verified `RatingStars.module.scss:24` pattern — the title still shows visually as the `textOverlay`; the `h1` is for AT/SEO):

```scss
.pageHeading {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
  border: 0;
}
```

- [ ] **Step 7 — Emit the `h1` in `CollectionPage.tsx`.** For the **single-collection** branch, use `collection.title`; for the **array** branch (home / all-collections), use a stable site-level title. Edit the two `<main>` blocks:

```diff
   if (!Array.isArray(collection)) {
     return (
       <div className={styles.container}>
         <main className={styles.main}>
           <SiteHeader pageType="collection" collectionSlug={collection.slug} />
+          <h1 className={styles.pageHeading}>{collection.title || collection.slug}</h1>
           <CollectionPageClient collection={collection} chunkSize={chunkSize} />
         </main>
       </div>
     );
   }
```

```diff
   return (
     <div className={styles.container}>
       <main className={styles.main}>
         <SiteHeader pageType="collectionsCollection" />
+        <h1 className={styles.pageHeading}>Zac Edens — Photography</h1>
         {contentBlocks.length > 0 ? (
```

- [ ] **Step 8 — Run the test; verify it passes:**

```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ContentCollection/CollectionPage.test.tsx
```
  Expected: PASS (2 tests).

### 6c — `prefers-reduced-motion` guard on `useParallax`

- [ ] **Step 9 — Guard the parallax effect** in `app/hooks/useParallax.ts`. Add a `matchMedia` check at the top of the effect so that, when the user prefers reduced motion, the hook does not attach scroll listeners (and clears any transform). Edit inside the `useEffect`:

```diff
   useEffect(() => {
     if (typeof window === 'undefined' || !elementRef.current || !enableParallax) return;
+
+    // Respect prefers-reduced-motion: skip the scroll-driven transform entirely (review §5).
+    const prefersReducedMotion =
+      typeof window.matchMedia === 'function' &&
+      window.matchMedia('(prefers-reduced-motion: reduce)').matches;
+    if (prefersReducedMotion) return;

     const element = elementRef.current;
```

  This is intentionally simple: when reduced motion is on, parallax is fully disabled and the image renders in its CSS resting position (it's scaled but static). No listeners attach, so there's nothing to clean up beyond the existing return.

- [ ] **Step 10 — Verify the hook still type-checks + existing parallax tests pass:**

```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest -t arallax 2>/dev/null || /opt/homebrew/bin/node node_modules/.bin/jest tests/hooks
```
  Expected: tsc clean; parallax/hook tests green. (Behavior under reduced-motion is a browser check: in DevTools, emulate `prefers-reduced-motion: reduce` and confirm scrolling a gallery no longer moves the image.)

### 6d — Fix the gap-rule violation (per-image directional padding → row gap)

- [ ] **Step 11 — Replace inter-item padding with a row `gap`.** In `ContentComponent.module.scss`, the desktop `.imageLeft`/`.imageRight`/`.imageMiddle` rules add `padding-{left,right}: 0.4rem` *between* items (the gap-rule violation per `ai_guidelines/ai_css.md` — spacing between siblings belongs on the parent's `gap`, review §5 🟢). The parent is `.row` (which is `flex-direction: row` at desktop). Add a `gap` to `.row`'s desktop block and remove the per-image padding:

```diff
   /* Desktop styles */
-  @media (--bp-mobile) {
+  @media (--bp-mobile) {
     flex-direction: row;
+    gap: 0.8rem; /* = 2× the old 0.4rem half-gap each item carried; spacing now on the parent */
     margin-bottom: var(--default-padding);
   }
```

  (Note: `@media (--bp-mobile)` reflects Task 5's migration; if Task 6 runs before Task 5, this is `@media (width >= 768px)`.) Then strip the directional padding from the three image variants:

```diff
 .imageLeft {
   @extend .image;
-
-  @media (--bp-mobile) {
-    padding-right: 0.4rem;
-  }
 }

 .imageRight {
   @extend .image;
-
-  @media (--bp-mobile) {
-    padding-left: 0.4rem;
-  }
 }

 .imageMiddle {
   @extend .image;
-
-  @media (--bp-mobile) {
-    padding-left: 0.4rem;
-    padding-right: 0.4rem;
-  }
 }
```

  `.imageSingle` (which explicitly zeroes `padding-left/right`) and the `:global(.imageLeft)` `!important` overrides in `.row` (lines 30–38, which strip padding off first/last items) can both stay — but note the now-removed per-item padding makes those overrides mostly redundant; verify visually that first/last items sit flush to the row edges and inter-item spacing is the single `0.8rem` gap.

- [ ] **Step 12 — Browser-verify the row spacing** on :3001: a desktop multi-image row shows equal `0.8rem` gaps between images and flush outer edges (matches the prior look, but the spacing is now gap-driven). CSS-only; not jest-testable.

### 6e — Standardize `rgb()` slash syntax

- [ ] **Step 13 — Enforce modern-notation `rgb()`.** The repo mixes 68 legacy-comma `rgb(0,…)` and 26 slash `rgb(0 0 0 / x%)`. Flip the stylelint rule from off to modern and let `--fix` rewrite. In `.stylelintrc`:

```diff
-    "alpha-value-notation": null,
+    "alpha-value-notation": "percentage",
-    "color-function-notation": null,
+    "color-function-notation": "modern",
```

  Then auto-fix the whole tree:

```bash
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/**/*.scss' 'app/**/*.css'
```

  **Worked example** — the rule rewrites `globals.css:11`:

```diff
-  --color-overlay-strong: rgb(0, 0, 0, 0.7);
+  --color-overlay-strong: rgb(0 0 0 / 70%);
```

  and `ContentComponent.module.scss:412`:

```diff
-  border-bottom: 1px solid rgb(0, 0, 0, 0.1);
+  border-bottom: 1px solid rgb(0 0 0 / 10%);
```

  Some literals (the brand `rgb(59, 130, 246)` opaque values with no alpha) become `rgb(59 130 246)` — that's fine. After `--fix`, re-run stylelint with no `--fix` to confirm **zero** remaining violations:

```bash
/opt/homebrew/bin/node node_modules/.bin/stylelint 'app/**/*.scss' 'app/**/*.css'
```
  Expected: exit 0, no `color-function-notation`/`alpha-value-notation` reports.

- [ ] **Step 14 — Full verification + commit:**

```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write 'app/components/ContentCollection/CollectionPage.tsx' 'app/hooks/useParallax.ts' 'tests/components/ContentCollection/CollectionPage.test.tsx'
/opt/homebrew/bin/node node_modules/.bin/eslint --fix 'app/components/ContentCollection/CollectionPage.tsx' 'app/hooks/useParallax.ts' 'tests/components/ContentCollection/CollectionPage.test.tsx'
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/**/*.scss' 'app/**/*.css'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest
git add app/ tests/ .stylelintrc
git commit -m "feat(a11y): focus-ring token, ban outline:none, real per-page h1, reduced-motion guard, gap-rule + rgb() sweep

Adds --focus-ring and bans bare outline:none (replacing 7 unfallbacked resets with
:focus-visible rings; 2 legitimate :focus:not(:focus-visible) resets annotated). Emits a
visually-hidden <h1> per collection/home (titles were div.textOverlay) with an RTL test.
Guards useParallax behind prefers-reduced-motion. Converts ContentComponent inter-image
padding to a row gap (gap-rule). Standardizes rgb() to modern slash/percentage notation.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Verification (run after each task; full pass before the PR)

```bash
cd /Users/themancalledzac/Code/edens.zac
# Format → lint → stylelint → type-check → test (project pipeline; npm/npx not on PATH)
/opt/homebrew/bin/node node_modules/.bin/prettier --write <touched .ts/.tsx>
/opt/homebrew/bin/node node_modules/.bin/eslint --fix <touched .ts/.tsx>
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/**/*.scss' 'app/**/*.css'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest
```

**CSS-only changes are verified by stylelint (clean) + browser computed-style — they are NOT jest-unit-testable.** Concretely:
- **Task 1/2/3/4:** stylelint clean + the csstools guard reports **zero** undeclared `var()`; in DevTools, `getComputedStyle(document.documentElement).getPropertyValue('--color-accent')` resolves blue and `--scrim-dark-50` resolves; ReorderOverlay pick-up outline is blue.
- **Task 5:** the dev build compiles and a `(--bp-mobile)` query actually applies (column→row at 768px); no raw `(--bp-mobile)` leaks to the browser inspector.
- **Task 6 CSS bits:** focused controls show a visible accent ring; row spacing is a single `0.8rem` gap; reduced-motion emulation freezes parallax.

**The one behavioral change — the per-page `h1` — has a real RTL test** (`tests/components/ContentCollection/CollectionPage.test.tsx`) asserting `getByRole('heading', { level: 1 })` for both the single-collection and array views.

**Final grep gates (all must return exit 1 / no matches):**

```bash
grep -rEn 'color-text-(primary|secondary|muted)|color-bg-(light|medium|dark)|color-border-(light|medium|dark)|color-overlay-light-' app --include='*.scss'   # Task 3
grep -rEn 'var\(--color-danger, *#' app --include='*.scss'                              # Task 2
grep -rEn 'transition[^;{}]*[0-9]\.[0-9]+s' app --include='*.scss'                       # Task 4
grep -rn '768px\|1024px' app --include='*.scss'                                          # Task 5
grep -rn 'color-primary' app/components/Content/ReorderOverlay.module.scss              # Task 2
```

---

## Suggested commit sequence

1. `feat(tokens): add unified semantic color taxonomy + scrim alpha scales` (Task 1)
2. `fix(tokens): split brand/accent collision (ReorderOverlay blue) + collapse danger to one value` (Task 2)
3. `refactor(tokens): migrate legacy color families onto semantic roles + delete dead tokens` (Task 3)
4. `refactor(tokens): add --duration-*/--ease-standard, tokenize the ~43 magic transitions` (Task 4)
5. `refactor(css): add @custom-media breakpoint bridge, migrate 768/1024 queries, drop SCSS $bp` (Task 5)
6. `feat(a11y): focus-ring token, ban outline:none, real per-page h1, reduced-motion guard, gap-rule + rgb() sweep` (Task 6)

Each commit passes `tsc --noEmit` + `jest` + `stylelint` independently. Tasks 1→3 are ordered (3 deletes what 1 introduces a replacement for); 4, 5, 6 are mutually independent and can be reordered or parallelized (one agent per task) — the only cross-reference is Task 6's gap-rule/focus-visible edits touching `@media (--bp-mobile)`, which assumes Task 5 ran first (noted inline with the `(width >= 768px)` fallback).

---

## Self-review: spec-coverage checklist

Maps each plan task to the design-review section it implements. Gaps flagged explicitly.

| Review section / finding | Plan task | Status |
|--------------------------|-----------|--------|
| §6b — one semantic taxonomy: surface/-raised, on-surface/-muted, border, accent (+on-accent), danger, success | Task 1 | ✅ |
| §6b — `--scrim-dark-{10..90}` / `--scrim-light-{10..90}` replacing `--color-overlay-light-*` ramp + inline `rgb(0 0 0 / x%)` | Task 1 (declare) + Task 3 (migrate 85 usages) | ✅ |
| §5 / register — `--color-primary` near-black vs blue collision; ReorderOverlay latent bug | Task 2 | ✅ |
| §5 — `--color-danger` has 4 values → collapse to 1 | Task 2 | ✅ |
| §6c step 5/6 — migrate legacy `--color-text-*` / `--color-bg-light/medium/dark` + alias block, then DELETE | Task 3 | ✅ |
| §1.3 — stylelint guard banning undeclared `var()` (the shadow namespace) | Task 3 Step 7 | ✅ |
| §5 — ~40 magic-number transitions → `--duration-*` + `--ease-standard` | Task 4 | ✅ |
| §5 — 3 competing breakpoint systems; 0/97 use `--breakpoint-*`; `@custom-media` bridge | Task 5 | ✅ |
| §5 — delete `page.module.scss`'s `$bp`/`@mixin up()` | Task 5 Step 5 | ✅ |
| §5 — one `--focus-ring` + ban bare `outline:none` (the 6 modules) | Task 6a | ✅ |
| §5 🟡 — real `h1` per collection/home (titles are `div.textOverlay`); RTL `getByRole('heading')` test | Task 6b | ✅ (the testable change) |
| §5 — `prefers-reduced-motion` guard on parallax | Task 6c | ✅ |
| §5 — gap-rule violation (per-image padding → row gap) in ContentComponent | Task 6d | ✅ |
| §5 — standardize `rgb()` slash syntax via stylelint | Task 6e | ✅ |
| §5 / §7 — plaintext client-gallery password | **Out of scope — backend** | ⚠ cross-repo (master-plan Phase 4 register; hand off to `edens.zac.backend`) |
| §7 "better idea": commit to intentional dark vs light theme | **Out of scope — product decision** | 📋 gated decision (master-plan Execution Handoff) — this plan keeps `--color-surface = white` and is theme-neutral by design |

**Plan tasks not in the spec:** none — every task maps to a §5/§6b/§6c/§1.3 finding.

**Spec items in §6b not yet covered here:** none. (`--color-on-accent` is declared in Task 1 even though no current call site needs it, so the role-set is complete for the migrated primitives.)

**Placeholder scan:** Tasks 1–6 contain complete code/diffs, exact paths, exact grep/perl sweep commands with transformation rules + worked examples, and exact verification commands with expected output. No TBD / "implement later" / "similar to above". The two intentional out-of-scope rows (plaintext password = backend; theme decision = product call) are surfaced, not hidden.

**Dead-code flagged + handled:** `--color-overlay-strong`/`-soft` are declared but have 0 usages — left in place (harmless, and the scrim ramp now supersedes them; a follow-up could remove them, noted but not in scope to avoid widening this plan). `$bp-sm`/`$bp-lg` in `page.module.scss` are unused → deleted in Task 5. The 3 redundant `--color-danger` inline fallbacks → removed in Task 2. The Task 0.1 alias block → deleted in Task 3.
