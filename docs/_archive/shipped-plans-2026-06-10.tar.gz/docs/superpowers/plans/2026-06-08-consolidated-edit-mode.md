# Consolidated Light Edit-Mode Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Relocate the bespoke dark `/manage` page into a light, in-place edit mode on the real collection page — one reusable `EditBar`, a `?manage=1` same-route entry (no full refresh), restructured tabs, with the public view byte-identical.

**Architecture:** Thread an `editMode` flag through the existing `CollectionPageClient`; lift `ManageClient`'s logic into a `useCollectionEdit` hook; replace both bespoke bottom bars (manage + image-modal) with one `EditBar` primitive that follows context. Manage is entered via a `?manage=1` searchParam on `/[slug]` (soft nav, no remount), gated by `requireAdmin`, rendered light (dark scope deferred).

**Tech Stack:** Next.js App Router, React 19 (named imports), strict TS (no `any`), SCSS modules + surface-aware design tokens, Jest + React Testing Library (jsdom).

**Spec:** `docs/superpowers/specs/2026-06-08-consolidated-edit-mode.md`

**Verification pipeline (run after every code change, before each commit):**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write <changed-files>
/opt/homebrew/bin/node node_modules/.bin/eslint --fix <changed-files>
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix <changed-scss>   # SCSS only
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest <relevant-test-or-all>
```
**Hard rule:** the existing suite (~1939 tests) stays green at every commit. The public `/[slug]` view (no `?manage`) must render byte-identical — visual-verify mobile + desktop before any commit that touches the render path.

**Conventions:** named React imports (`import { useState } from 'react'`); no `'use client'` unless hooks/interactivity needed; co-located `.module.scss` per component; no inline comments (concise docblocks only); CloudFront images via `next/image`; node = `/opt/homebrew/bin/node` (npm/npx not on PATH).

---

## File Structure

**New files**
- `app/components/ui/EditBar/EditBar.tsx` — the one reusable bottom bar (mode shape + edit shape). Pure presentational.
- `app/components/ui/EditBar/EditBar.module.scss` — consolidated uniform-cell styles (base from `MetadataModal.module.scss`, variants from `ManageClient.module.scss`), `z-index` below modals.
- `app/components/ui/EditBar/types.ts` — `EditBarCell`, `EditBarTab`, `EditBarProps`.
- `tests/components/ui/EditBar.test.tsx` — render + interaction tests.
- `app/hooks/useManageUrlState.ts` — read/toggle the `?manage=1` searchParam (mirrors `useFilterUrlState.ts`). Test: `tests/hooks/useManageUrlState.test.ts`.
- `app/components/ContentCollection/edit/useCollectionEdit.tsx` — composes the lifted manage hooks + update form + mode machine. Test: `tests/components/ContentCollection/useCollectionEdit.test.tsx`.
- `app/components/ContentCollection/edit/hooks/` — relocated from the manage route: `useContentReordering.ts`, `useCoverImageSelection.ts`, `useCollectionRetype.ts`, `useImageClickHandler.ts`, plus `manageUtils.ts` → `collectionEditUtils.ts`.
- `app/components/ContentCollection/edit/CollectionEditSheet.tsx` (+ `.module.scss`) — the slide-up tabbed sheet (Info/Tags/Structure), reusing the field groups.
- `app/components/ContentCollection/edit/sections/` — `InfoTab.tsx`, `TagsTab.tsx`, `StructureTab.tsx` (extracted from `ManageClient`'s inline tab JSX).
- `app/components/ContentCollection/edit/InlineEditableText.tsx` (+ `.module.scss`) — tap-to-edit title/description wrapper.

**Modified files**
- `app/components/Metadata/MetadataModal.tsx` — replace inline `.bottomTabRow` + `MetadataActionRow` with `<EditBar>` (image context).
- `app/components/ContentCollection/CollectionPageClient.tsx` — add `editMode?: boolean`; mount `useCollectionEdit` + `EditBar` + `CollectionEditSheet` + image modal + admin click-routing; pass `filterVisible=false`; inline-editable metadata.
- `app/[slug]/page.tsx` — read `manage` searchParam + `requireAdmin`; fetch `filterVisible=false` and pass `editMode` when admin+manage.
- `app/components/MenuDropdown/MenuDropdown.tsx` — `handleNavigation.update` → `router.push(\`/${collectionSlug}?manage=1\`)`.
- `app/utils/contentComponentHandlers.ts:80` — `getCollectionNavigationPath(slug, isAdmin)` admin branch → `\`/${slug}?manage=1\``.
- `app/components/Content/{ContentBlockWithFullScreen,BoxRenderer,Component}.tsx`, `boxRendererUtils.ts` — update the `ReorderMove` type import path (moves out of the deleted manage dir).

**Deleted files (Task 9, after relocation)**
- `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx`, `ManageClient.module.scss`, `page.tsx`, and any now-orphaned colocated files.

---

## Task 1: `EditBar` primitive (new, isolated)

**Files:**
- Create: `app/components/ui/EditBar/types.ts`
- Create: `app/components/ui/EditBar/EditBar.tsx`
- Create: `app/components/ui/EditBar/EditBar.module.scss`
- Test: `tests/components/ui/EditBar.test.tsx`

- [ ] **Step 1: Write `types.ts`**

```ts
export type EditBarCellVariant = 'default' | 'primary' | 'danger' | 'active';

export interface EditBarCell {
  key: string;
  label: string;
  onClick?: () => void;
  variant?: EditBarCellVariant;
  disabled?: boolean;
  /** When set, the cell renders as a <label> wrapping a hidden file input (e.g. Upload). */
  fileInput?: { accept?: string; multiple?: boolean; onFiles: (files: FileList) => void };
}

export interface EditBarTab {
  id: string;
  label: string;
}

export interface EditBarProps {
  /** Optional tab row (edit shape). Rendered above the action row when present. */
  tabs?: ReadonlyArray<EditBarTab>;
  activeTab?: string;
  onTabChange?: (id: string) => void;
  /** Action cells. In mode shape this is the only row. */
  cells: ReadonlyArray<EditBarCell>;
  ariaLabel?: string;
}
```

- [ ] **Step 2: Write the failing test** — `tests/components/ui/EditBar.test.tsx`

```tsx
import { fireEvent, render, screen } from '@testing-library/react';

import { EditBar } from '@/app/components/ui/EditBar/EditBar';

describe('EditBar', () => {
  it('renders action cells and fires onClick', () => {
    const onSelect = jest.fn();
    render(
      <EditBar
        ariaLabel="Manage"
        cells={[
          { key: 'select', label: 'Select', onClick: onSelect },
          { key: 'edit', label: 'Edit', variant: 'primary' },
        ]}
      />
    );
    fireEvent.click(screen.getByRole('button', { name: 'Select' }));
    expect(onSelect).toHaveBeenCalledTimes(1);
  });

  it('disables a cell when disabled is true', () => {
    render(<EditBar cells={[{ key: 'save', label: 'Save', disabled: true }]} />);
    expect(screen.getByRole('button', { name: 'Save' })).toBeDisabled();
  });

  it('renders a tab row and marks the active tab selected', () => {
    const onTabChange = jest.fn();
    render(
      <EditBar
        tabs={[
          { id: 'info', label: 'Info' },
          { id: 'tags', label: 'Tags' },
        ]}
        activeTab="info"
        onTabChange={onTabChange}
        cells={[{ key: 'save', label: 'Save' }]}
      />
    );
    const tags = screen.getByRole('tab', { name: 'Tags' });
    expect(screen.getByRole('tab', { name: 'Info' })).toHaveAttribute('aria-selected', 'true');
    fireEvent.click(tags);
    expect(onTabChange).toHaveBeenCalledWith('tags');
  });

  it('renders an upload cell as a label with a file input', () => {
    const onFiles = jest.fn();
    render(
      <EditBar
        cells={[{ key: 'upload', label: 'Upload', fileInput: { multiple: true, onFiles } }]}
      />
    );
    expect(screen.getByText('Upload').tagName).toBe('LABEL');
  });
});
```

- [ ] **Step 3: Run the test, verify it fails**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/EditBar.test.tsx`
Expected: FAIL — cannot find module `EditBar`.

- [ ] **Step 4: Implement `EditBar.tsx`**

```tsx
'use client';

import { type EditBarCell, type EditBarProps } from './types';

import styles from './EditBar.module.scss';

function cellClassName(variant: EditBarCell['variant']): string {
  const map = {
    primary: styles.barCellPrimary,
    danger: styles.barCellDanger,
    active: styles.barCellActive,
    default: '',
  } as const;
  return [styles.barCell, variant ? map[variant] : ''].filter(Boolean).join(' ');
}

/**
 * EditBar — the single fixed bottom bar used across collection-edit, image-edit,
 * and the transient manage modes. Two shapes: a tab row (optional) above an action
 * row of uniform-height cells. Emphasis is by color/weight, never size.
 */
export function EditBar({ tabs, activeTab, onTabChange, cells, ariaLabel }: EditBarProps) {
  return (
    <div className={styles.bottomBar} role="toolbar" aria-label={ariaLabel}>
      {tabs && tabs.length > 0 && (
        <nav className={styles.tabRow} role="tablist" aria-label={ariaLabel}>
          {tabs.map(tab => (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={activeTab === tab.id}
              className={[styles.barCell, activeTab === tab.id ? styles.barCellActive : '']
                .filter(Boolean)
                .join(' ')}
              onClick={() => onTabChange?.(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      )}
      <div className={styles.actionRow}>
        {cells.map(cell =>
          cell.fileInput ? (
            <label key={cell.key} className={cellClassName(cell.variant)}>
              {cell.label}
              <input
                type="file"
                hidden
                accept={cell.fileInput.accept}
                multiple={cell.fileInput.multiple}
                onChange={e => {
                  if (e.target.files) cell.fileInput!.onFiles(e.target.files);
                }}
              />
            </label>
          ) : (
            <button
              key={cell.key}
              type="button"
              className={cellClassName(cell.variant)}
              disabled={cell.disabled}
              onClick={cell.onClick}
            >
              {cell.label}
            </button>
          )
        )}
      </div>
    </div>
  );
}

export default EditBar;
```

- [ ] **Step 5: Implement `EditBar.module.scss`**

Copy the canonical uniform-cell rules from `app/components/Metadata/MetadataModal.module.scss:134-183` (`.bottomBar`, the tab row, `.barCell`, `.barCellActive`). Rename the tab-row class to `.tabRow`, add `.actionRow` (same flex row), and add the variant cells from `app/(admin)/collection/manage/[[...slug]]/ManageClient.module.scss:96-130` (`.barCellPrimary`, `.barCellDanger`, `.barCellUpload` → fold into `.barCell` label styling). **Critical:** the fixed/positioned wrapper must use `z-index: var(--z-sticky, 30)` — NOT `--z-modal-controls` — so it never floats above an open modal (the §3.1 bug). The bar is surface-aware via tokens (`--color-bg`, `--color-border`, `--color-fg`, `--color-on-surface-muted`), so it renders light on the light page and dark under a dark scope.

```scss
.bottomBar {
  position: fixed;
  inset-inline: 0;
  bottom: 0;
  z-index: var(--z-sticky, 30);
  background: var(--color-bg);
  border-top: 1px solid var(--color-border);
}

.tabRow,
.actionRow {
  display: flex;
  align-items: stretch;
}

.tabRow {
  border-bottom: 1px solid var(--color-border);
}

.barCell {
  flex: 1 1 0;
  min-width: 0;
  min-height: 44px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: var(--space-2);
  background: none;
  border: none;
  color: var(--color-on-surface-muted);
  font-size: var(--text-sm);
  font-weight: 500;
  white-space: nowrap;
  cursor: pointer;
  transition: color var(--duration-fast) var(--ease-standard), opacity var(--duration-fast) var(--ease-standard);

  &:hover:not(:disabled) { opacity: 0.7; }
  &:focus-visible { outline: var(--focus-ring); outline-offset: -2px; }
  &:disabled { opacity: 0.4; cursor: default; }
}

.barCellActive {
  font-weight: 700;
  color: var(--color-fg);
  box-shadow: inset 0 2px 0 0 var(--color-fg);
}

.barCellPrimary {
  font-weight: 700;
  color: var(--color-fg);
}

.barCellDanger {
  color: var(--color-danger, #d44);
}
```
(Confirm token names against `app/styles/globals.css` while implementing; reuse exactly what the two source modules used.)

- [ ] **Step 6: Run the test, verify it passes**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/EditBar.test.tsx`
Expected: PASS (4 tests).

- [ ] **Step 7: Verify pipeline + commit**

```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/components/ui/EditBar/ tests/components/ui/EditBar.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/components/ui/EditBar/*.tsx tests/components/ui/EditBar.test.tsx
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix app/components/ui/EditBar/EditBar.module.scss
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
git add app/components/ui/EditBar tests/components/ui/EditBar.test.tsx
git commit -m "feat(ui): add reusable EditBar bottom-bar primitive"
```

---

## Task 2: Adopt `EditBar` inside `MetadataModal` (image context)

**Files:**
- Modify: `app/components/Metadata/MetadataModal.tsx:225-255` (replace inline `.bottomBar` + `.bottomTabRow` + `<MetadataActionRow>` block)
- Modify: `app/components/Metadata/MetadataModal.module.scss` (remove now-unused `.bottomBar/.bottomTabRow/.barCell/.barCellActive` once EditBar owns them)
- Test: `tests/components/Metadata/MetadataModal.test.tsx` (existing — must stay green; add a tab-switch assertion if not present)

- [ ] **Step 1: Read** `MetadataModal.tsx` and confirm the `TABS` array (`info/camera/tags/collections`), `activeTab`/`setActiveTab` state, and the `MetadataActionRow` props (`isBulkEdit, selectedCount, saving, hasChanges, showRemove, onDelete, onRemove, onCancel`).

- [ ] **Step 2: Replace** the inline bottom-bar JSX with `<EditBar>` driven by the existing state. Map the action row to `cells`:

```tsx
<EditBar
  ariaLabel="Metadata sections"
  tabs={TABS}
  activeTab={activeTab}
  onTabChange={setActiveTab}
  cells={[
    ...(currentCollectionId
      ? [{ key: 'remove', label: 'Remove', variant: 'danger' as const, onClick: handleRemoveFromCollection, disabled: saving }]
      : [{ key: 'delete', label: 'Delete', variant: 'danger' as const, onClick: handleDelete, disabled: saving }]),
    { key: 'cancel', label: 'Cancel', onClick: handleCancel },
    { key: 'save', label: isBulkEdit ? `Save ${selectedIds.length}` : 'Save', variant: 'primary', disabled: !hasChanges || saving },
  ]}
/>
```
Save stays form-driven: keep the `<form onSubmit>` and make the Save cell's `onClick` call the form submit (or move the submit handler to the cell). Preserve the confirm-on-dirty behavior in `handleCancel`. Keep `MetadataActionRow` file for now if other code imports it; otherwise delete in Task 9 cleanup.

- [ ] **Step 3: Run the modal tests**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest tests/components/Metadata`
Expected: PASS (existing assertions + tab switch). Fix any selector drift (the buttons are now inside `EditBar`'s `role="tab"` / action `button`s).

- [ ] **Step 4: Visual-verify** in preview (port 3001): open the manage page, click an image → modal opens, tabs Info/Camera/Tags/Collections switch, Save/Delete/Cancel work, light rendering correct.

- [ ] **Step 5: Verify pipeline + commit**

```bash
git add app/components/Metadata tests/components/Metadata app/components/ui/EditBar
git commit -m "refactor(metadata): use EditBar for the image-editor bottom bar"
```

---

## Task 3: Fix the bar-bleed z-index bug (interim, on the current manage page)

**Files:**
- Modify: `app/(admin)/collection/manage/[[...slug]]/ManageClient.module.scss:42-45` (`.bottomBar` z-index)
- Modify: `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx` (hide the bar when the image modal is open)

This ships the most visible bug fix fast, before the full lift. (The code is deleted in Task 9; this is a cheap, correct interim fix.)

- [ ] **Step 1: Lower the bar z-index.** Change `ManageClient.module.scss:45` from `z-index: var(--z-modal-controls, 1002);` to `z-index: var(--z-sticky, 30);` so the manage bar never floats above the modal backdrop (`--z-modal, 1000`).

- [ ] **Step 2: Unmount the bar while the image modal is open.** In `ManageClient.tsx`, the bar render is gated so it does not render when `editingContent` is truthy:

```tsx
{!editingContent && renderBottomBar()}
```
(Read the current render site near the `renderBottomBar()` call to apply this exactly.)

- [ ] **Step 3: Visual-verify** in preview: click an image on the manage page → no yellow/red cells bleed through behind the modal; the manage bar is gone while editing; closing the modal restores it.

- [ ] **Step 4: Verify pipeline + commit**

```bash
git add "app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx" "app/(admin)/collection/manage/[[...slug]]/ManageClient.module.scss"
git commit -m "fix(admin): stop the manage bar from bleeding over the image modal"
```

---

## Task 4: Restructure the collection Edit-sheet tabs (in place)

**Files:**
- Modify: `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx` — tabs array (1286-1291) + Info tab (1454-1537) + Structure tab (1616-1862) + Access tab (1866-1937)

Do the field moves now (in the doomed file) so the field groupings are settled before extraction. Spec §4.5.

- [ ] **Step 1: Read** the three tab blocks (`info`, `structure`, `access`) to capture the exact field JSX + handlers.

- [ ] **Step 2: Move Visibility → Info.** Cut the Visibility `SegmentedControl` (ManageClient.tsx:1643) out of Structure and paste into the Info tab (after Location).

- [ ] **Step 3: Merge Access → Info.** Cut the Access tab's password + recipients + save-access/clear-password fields (1866-1937) into the Info tab as a conditional group rendered only when `collection.type === 'CLIENT_GALLERY' || isParent` (preserve the existing gating + `handleSaveAccess`/`handleClearPassword`).

- [ ] **Step 4: Remove the Access tab.** Update the tabs array (1286-1291) to `[{ id: 'info' }, { id: 'tags' }, { id: 'structure' }]`; delete the `access` branch. Structure keeps Type (1621), Display (1662), Row Density (1681), Collections (1797), home child-rating (1832); cover-picker (1743) stays contextual (parents only, while selecting — never a persistent thumbnail).

- [ ] **Step 5: Run tests + tsc.** `editTab` type narrows to `'info' | 'tags' | 'structure'` — fix the type and any exhaustive switches.

Run: `/opt/homebrew/bin/node node_modules/.bin/jest && /opt/homebrew/bin/node node_modules/.bin/tsc --noEmit`
Expected: green.

- [ ] **Step 6: Visual-verify** the Edit sheet: Info shows Title/Date/Description/Location/Visibility (+ gallery password/recipients for galleries); Structure shows Type/Display/Density/Collections; no Access tab.

- [ ] **Step 7: Commit**

```bash
git commit -am "refactor(admin): merge Access into Info, move Visibility to Info, drop Access tab"
```

---

## Task 5: Extract `useCollectionEdit` + relocate the manage hooks

**Files:**
- Create: `app/components/ContentCollection/edit/useCollectionEdit.tsx`
- Move: `useContentReordering.ts`, `useCoverImageSelection.ts`, `useCollectionRetype.ts`, `useImageClickHandler.ts`, `manageUtils.ts`→`collectionEditUtils.ts` into `app/components/ContentCollection/edit/hooks/`
- Modify: import paths in `Content/{ContentBlockWithFullScreen,BoxRenderer,Component}.tsx`, `boxRendererUtils.ts` for the `ReorderMove` type
- Test: `tests/components/ContentCollection/useCollectionEdit.test.tsx`

- [ ] **Step 1: Move the hook files** (git mv to preserve history) into `app/components/ContentCollection/edit/hooks/`; rename `manageUtils.ts` → `collectionEditUtils.ts`. Update all imports (grep `manage/[[...slug]]/manageUtils` and `manage/[[...slug]]/use*`). Run `tsc --noEmit`; fix paths until clean. Commit (`refactor: relocate manage hooks/utils under ContentCollection/edit`).

- [ ] **Step 2: Define the `useCollectionEdit` interface** (the surface `CollectionPageClient` consumes):

```tsx
export interface UseCollectionEditResult {
  manageMode: 'browse' | 'select' | 'reorder' | 'add' | 'edit';
  // grid wiring
  displayContent: AnyContentModel[];
  handleImageClick: (imageId: number) => void;
  reorder: ReturnType<typeof useContentReordering>;
  cover: ReturnType<typeof useCoverImageSelection>;
  // selection
  selectedIds: number[];
  isMultiSelectMode: boolean;
  // edit sheet
  editTab: 'info' | 'tags' | 'structure';
  setEditTab: (t: 'info' | 'tags' | 'structure') => void;
  isEditSheetOpen: boolean;
  updateData: CollectionUpdatePayload;
  setUpdateField: <K extends keyof CollectionUpdatePayload>(k: K, v: CollectionUpdatePayload[K]) => void;
  isUpdateDirty: boolean;
  saving: boolean;
  handleUpdate: () => Promise<void>;
  // image modal
  editingContent: EditableContent | null;
  closeEditor: () => void;
  // mode transitions
  enterSelect: () => void; enterReorder: () => void; enterAdd: () => void; enterEdit: () => void; exitToBrowse: () => void;
  // EditBar cells per mode (the bar config lives here so both contexts share it)
  bottomBarCells: EditBarCell[];
  bottomBarTabs?: EditBarTab[];
}

export function useCollectionEdit(collection: CollectionModel, slug: string): UseCollectionEditResult;
```
(Use the exact existing payload type — `manageUtils.buildUpdatePayload`'s input. Confirm names while reading `ManageClient.tsx:357-374, 514-631`.)

- [ ] **Step 3: Write the failing behavior test** — assert the mode machine + dirty detection:

```tsx
import { act, renderHook } from '@testing-library/react';
import { useCollectionEdit } from '@/app/components/ContentCollection/edit/useCollectionEdit';
import { makeCollection } from '@/tests/fixtures/collection'; // reuse existing fixture helper

jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: jest.fn(), replace: jest.fn(), prefetch: jest.fn() }),
}));

describe('useCollectionEdit', () => {
  it('starts in browse mode and transitions to edit', () => {
    const { result } = renderHook(() => useCollectionEdit(makeCollection(), 'demo'));
    expect(result.current.manageMode).toBe('browse');
    act(() => result.current.enterEdit());
    expect(result.current.manageMode).toBe('edit');
  });

  it('is not dirty until a field changes', () => {
    const { result } = renderHook(() => useCollectionEdit(makeCollection({ title: 'A' }), 'demo'));
    expect(result.current.isUpdateDirty).toBe(false);
    act(() => result.current.setUpdateField('title', 'B'));
    expect(result.current.isUpdateDirty).toBe(true);
  });
});
```
Run it, verify it fails (module missing). (If `tests/fixtures/collection` doesn't exist, build the minimal fixture inline — check `tests/` for an existing collection fixture first.)

- [ ] **Step 4: Implement `useCollectionEdit`** by lifting the state + handlers from `ManageClient.tsx` verbatim: `deriveManageMode` (357-364), `isUpdateDirty` (371-374), `handleUpdate` (514-580), `handleSavePeople`/`handleSaveAccess` (248-261, 586-631), and composing the relocated hooks. The bottom-bar cell config (the per-mode arrays from `renderBottomBar` 1181-1343) moves here as `bottomBarCells`/`bottomBarTabs` builders returning `EditBarCell[]`. **No behavior change** — this is a mechanical lift.

- [ ] **Step 5: Run the test + full suite + tsc.** Expected: green.

- [ ] **Step 6: Commit** (`feat: extract useCollectionEdit hook (mechanical lift from ManageClient)`).

---

## Task 6: Thread `editMode` into `CollectionPageClient`

**Files:**
- Modify: `app/components/ContentCollection/CollectionPageClient.tsx`
- Create: `app/components/ContentCollection/edit/CollectionEditSheet.tsx` (+ `.module.scss`) and `sections/{InfoTab,TagsTab,StructureTab}.tsx` (extract the tab JSX from `ManageClient`)
- Test: `tests/components/ContentCollection/CollectionPageClient.editMode.test.tsx`

- [ ] **Step 1: Add the prop.** `interface CollectionPageClientProps { …; editMode?: boolean }`. When `editMode` is falsy, the component renders **exactly as today** (no new mounts, no behavior change — verify by diffing the render output path).

- [ ] **Step 2: Write the failing test** — public mode mounts no EditBar; edit mode mounts it:

```tsx
import { render, screen } from '@testing-library/react';
import CollectionPageClient from '@/app/components/ContentCollection/CollectionPageClient';
import { makeCollection } from '@/tests/fixtures/collection';

jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: jest.fn() }),
  useSearchParams: () => new URLSearchParams(),
  usePathname: () => '/demo',
}));

describe('CollectionPageClient editMode', () => {
  it('renders no edit toolbar in public mode', () => {
    render(<CollectionPageClient collection={makeCollection()} />);
    expect(screen.queryByRole('toolbar', { name: 'Manage' })).toBeNull();
  });

  it('renders the EditBar in edit mode', () => {
    render(<CollectionPageClient collection={makeCollection()} editMode />);
    expect(screen.getByRole('toolbar', { name: 'Manage' })).toBeInTheDocument();
  });
});
```
Run, verify it fails.

- [ ] **Step 3: Mount the edit surfaces.** When `editMode`: call `useCollectionEdit`, render `<EditBar ariaLabel="Manage" cells={bottomBarCells} tabs={bottomBarTabs} … />`; wire the grid's `onImageClick={handleImageClick}` + `enableFullScreenView={false}`; render `<CollectionEditSheet>` when `manageMode==='edit'` and `<MetadataModal>` when `editingContent`; pass `filterVisible={false}` to the content-processing call. Extract the Info/Tags/Structure tab JSX from `ManageClient` into `sections/` components driven by `updateData`/`setUpdateField`.

- [ ] **Step 4: Run the new test + full suite + tsc.** Expected: green; the public test confirms no edit affordances leak.

- [ ] **Step 5: Visual-verify** by temporarily rendering `editMode` (e.g. a local prop) — bar morphs across browse/select/reorder/add/edit; image click → modal with EditBar; light rendering; **public route still pixel-identical** (load `/[slug]` with no param).

- [ ] **Step 6: Commit** (`feat(collection): mount edit affordances in CollectionPageClient behind editMode`).

---

## Task 7: Same-route `?manage=1` entry (no full refresh)

**Files:**
- Create: `app/hooks/useManageUrlState.ts` (mirror `useFilterUrlState.ts`) + `tests/hooks/useManageUrlState.test.ts`
- Modify: `app/[slug]/page.tsx`
- Modify: `app/components/MenuDropdown/MenuDropdown.tsx:68-71`
- Modify: `app/utils/contentComponentHandlers.ts:80`
- Modify: `app/components/ContentCollection/edit/hooks/useImageClickHandler.ts:51`

- [ ] **Step 1: Write `useManageUrlState.ts`** — reads `manage` from `useSearchParams`, exposes `isManage` + `enterManage(slug)` / `exitManage(slug)` via `router.push` (soft nav, `{ scroll: false }`), following `useFilterUrlState.ts`. Write its test (mock `next/navigation`, assert `push` called with `\`/${slug}?manage=1\`` and `\`/${slug}\``). Run, fail, implement, pass.

- [ ] **Step 2: Server entry in `app/[slug]/page.tsx`.** Read the `manage` searchParam (App Router `searchParams` prop). Compute `const isAdminManage = searchParams?.manage === '1' && (await requireAdmin())`. When `isAdminManage`: fetch the collection with `filterVisible: false` (admin fetch) and render `CollectionPageClient editMode`; else render exactly as today. Non-admins with `?manage=1` fall through to the public render (param ignored). Keep `generateMetadata` unchanged. (Read the current `page.tsx` + `requireAdmin` signature from `app/utils/admin.ts` first.)

- [ ] **Step 3: Repoint the nav.** `MenuDropdown.tsx` update → `router.push(\`/${collectionSlug}?manage=1\`)`; `getCollectionNavigationPath` admin branch → `\`/${slug}?manage=1\``; `useImageClickHandler.ts:51` child-collection nav → `\`/${collectionSlug}?manage=1\``. The EditBar `exitToBrowse` ✕ cell → `router.push(\`/${slug}\`)`.

- [ ] **Step 4: Verify NO remount/flash.** In preview: from a collection page, open the menu → Update → the page does **not** white-flash; date/location stay visible (light); the EditBar appears; hidden content appears. Click ✕ → returns to public view, no flash. (Use `preview_console_logs`/`preview_network` to confirm a soft transition, not a document reload.)

- [ ] **Step 5: Run full suite + tsc; commit** (`feat(collection): enter manage via ?manage=1 on the same route (no full refresh)`).

---

## Task 8: Inline edit title / description / location on the page

**Files:**
- Create: `app/components/ContentCollection/edit/InlineEditableText.tsx` (+ `.module.scss`) + test
- Modify: `app/components/Content/CollectionContentRenderer.tsx:182-296` (TEXT metadata block — mount inline editors only when an `editMode`/edit handlers prop is present)

- [ ] **Step 1: Write `InlineEditableText`** — read-only text that becomes an `Input`/`Textarea` on tap; commits on blur/Enter, cancels on Escape; calls `onCommit(value)`. Write its test (render, click, type, blur → `onCommit` called; Escape → not called). Run, fail, implement, pass.

- [ ] **Step 2: Wire into the metadata block.** Thread an optional `editMode` + `onEditField(field, value)` down from `CollectionPageClient` → `ContentBlockWithFullScreen` → `Component` → `BoxRenderer` → `CollectionContentRenderer` (these already pass `onImageClick`; add alongside). In the TEXT branch, when `editMode`, wrap Title (Input), Description (Textarea), Location (location picker) with `InlineEditableText`; `onCommit` calls `setUpdateField` + persists via the existing update path. **When not `editMode`, render exactly the current read-only markup** (no DOM change → public pixel-identical).

- [ ] **Step 3: Run full suite + tsc; visual-verify** inline edit works on the manage page and the public page is unchanged.

- [ ] **Step 4: Commit** (`feat(collection): inline-edit title/description/location in edit mode`).

---

## Task 9: Delete the old manage route + stop the dark scope

**Files:**
- Delete: `app/(admin)/collection/manage/[[...slug]]/{ManageClient.tsx,ManageClient.module.scss,page.tsx}` and any now-orphaned colocated files
- Modify: `app/(admin)/layout.tsx` — stop applying `data-surface="dark"` to the collection-edit experience (verify nothing else under `(admin)` still depends on it; if the admin hub does, scope the dark application to the hub only)
- Modify: remove now-dead imports of `MetadataActionRow` if Task 2 orphaned it

- [ ] **Step 1: Confirm no live references** to the deleted route/files: `grep -rn "manage/\[\[...slug\]\]\|ManageClient" app/ tests/`. Resolve every hit (should only be historical type-import paths already moved in Task 5).

- [ ] **Step 2: Delete the files.** Use `GIT_LITERAL_PATHSPECS=1 git rm` (the `[[...slug]]` dir is a glob to git).

- [ ] **Step 3: Stop the dark scope** for the edit experience; confirm the page renders light end-to-end.

- [ ] **Step 4: Run full suite + tsc + eslint; commit** (`refactor(admin): delete bespoke manage page; edit lives on the collection page`).

---

## Task 10: Public regression pass + cleanup

- [ ] **Step 1: Visual diff public `/[slug]`** (no param) vs `origin/main` — mobile + desktop, a parent collection, a client gallery, and a plain collection. Confirm byte-identical layout/typography/spacing.
- [ ] **Step 2: Remove orphaned styles** (unused `.barCell*`/`.bottomBar` rules left in `MetadataModal.module.scss` after Task 2; any dead `manageUtils` exports). Flag any dead params (e.g. unused callbacks) found during the lift.
- [ ] **Step 3: Full suite + tsc + eslint + stylelint** all green; commit (`chore: cleanup orphaned edit-mode styles and dead code`).
- [ ] **Step 4: Update the spec status** to "Implemented" and note any deviations.

---

## Self-Review

**Spec coverage (each spec section → task):**

| Spec section | Task |
|---|---|
| §3.1 yellow/red bar bleed | Task 3 (interim) + Task 2/6 (structural: one bar) |
| §3.2 no full refresh entering manage | Task 7 |
| §3.3 dark hides date/location → render light | Task 9 (+ light tokens throughout) |
| §4.1 editMode threaded through CollectionPageClient; same-route entry; delete ManageClient; stop dark | Tasks 6, 7, 9 |
| §4.2 one reusable EditBar (mode + edit shapes; ✕ exit) | Tasks 1, 2, 6, 7 |
| §4.3 inline edit title/description/location | Task 8 |
| §4.4 image edit = same EditBar, light | Tasks 2, 6 |
| §4.5 refined tabs (Access→Info, Visibility→Info, Type in Structure, Access tab gone; cover contextual) | Task 4 |
| §5 reuse map (lift hooks, keep image editor/text-block) | Tasks 5, 6 |
| §6 incremental commits, each verified | every task |
| §7 out of scope (dropdown polish, dark, 009, bulk-GIF) | not implemented (correct) |

**Placeholder scan:** No "TBD"/"add error handling"/"similar to Task N". Refactor tasks (4, 5, 6) instruct the executor to read the named file:line ranges and lift verbatim — the precise transformation + the test that proves no behavior change is given, which is the actionable spec for a mechanical lift.

**Type consistency:** `editTab`/`setEditTab` use `'info'|'tags'|'structure'` everywhere (Task 4 narrows it, Tasks 5–6 consume it). `EditBarCell`/`EditBarTab`/`EditBarProps` (Task 1) are the types used in Tasks 2, 5, 6. `useCollectionEdit` returns `bottomBarCells: EditBarCell[]` consumed by `CollectionPageClient` (Task 6). `manageMode` union matches `deriveManageMode`.

**Agent Teams note:** the build is largely sequential (each task builds on the prior). Task 1 (EditBar) and Task 4 (tab field moves) are the only loosely-independent pieces and could run in parallel before Task 5; the rest must be ordered. Subagent-driven-development (fresh subagent per task, review between) fits better than a parallel team here.
