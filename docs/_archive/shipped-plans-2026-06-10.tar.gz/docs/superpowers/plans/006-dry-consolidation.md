# 006 · DRY Consolidation Pass

_Chapter [006 · Code Health](../../006-code-health.md) · plan_

> **Status**: Partially Done (updated 2026-03-17)
> **Priority**: Medium

---

## Remaining

- [ ] **A3: Escape key handler consolidation** — `useImageMetadataEditor` could use `useClickOutside` instead of wiring its own listener.
- [ ] **B1: NaN fallback in `CollectionContentRenderer`** — redundant copy of logic from `contentRendererUtils.ts`. Keep defensive logging but remove the manual reconstruction.
- [ ] **B2: Two parallax converters** — `contentLayout.ts:convertCollectionContentToParallax` and `parallaxImageUtils.ts:buildParallaxImageFromContent` have overlapping logic.
- [ ] **B3: `imageWidth ?? width` dimension resolution** — scattered across 4 files, should call `getContentDimensions` from `contentTypeGuards.ts`.
- [ ] **D1: BoxRenderer CSS custom properties** — hardcoded gap values instead of CSS vars.

> _The DRY/dimension stragglers from the old `todo-random.md` (NaN-fallback dedup, the two parallax converters, `imageWidth ?? width` → `getContentDimensions`, BoxRenderer gap vars) all map onto B1/B2/B3/D1 above — nothing new to add._
