# 006 · Frontend Dependency Upgrades

_Chapter [006 · Code Health](../../006-code-health.md) · plan_

> **Status**: ✅ **Done — shipped to `main` 2026-06-06** ([#176](https://github.com/themancalledzac/edens.zac/pull/176) + idiom follow-up [#177](https://github.com/themancalledzac/edens.zac/pull/177))
> **Priority**: Medium

---

## Shipped

- [x] **React 18 → 19 upgrade (P0)** — `react`/`react-dom` `^18.3.1` → `^19.2.7`; the runtime now matches the `@types/react ^19` already installed. Transparent: `tsc` + `jest` + `next build` + live smoke all green, **zero source changes required**; the full [upgrade-guide](https://react.dev/blog/2024/04/25/react-19-upgrade-guide) audit found no further required changes. [#176](https://github.com/themancalledzac/edens.zac/pull/176) (`0171`). Optional React 19 idiom modernizations (Tile ref-as-prop, `<Context>` provider) followed in [#177](https://github.com/themancalledzac/edens.zac/pull/177) (`0174`). New-capability follow-ups (React Compiler, Form Actions, `useOptimistic`) critically assessed and **all deferred** → [006 · React 19 Follow-ups](006-react19-followups.md).
- [x] **lucide-react update** — `0.399.0` → `1.17` in [#176](https://github.com/themancalledzac/edens.zac/pull/176); better tree-shaking, transparent.
- [x] **eslint-disable without explanation** — the `useFullScreenImage.tsx` exhaustive-deps disable now carries a justifying inline comment (the effect is intentionally `currentIndex`-only), `e84713c` in [#176](https://github.com/themancalledzac/edens.zac/pull/176).
