# 006 · Inline JSX Config — Cross-File Wins
_Chapter [006 · Code Health](../../006-code-health.md) · plan · branch `01XX-inline-jsx-config-cross-file` (assign when picked up)_

> **For agentic workers:** REQUIRED SUB-SKILL: Use `superpowers:executing-plans`. This is a small MR (~6 files, 2 commits).

**Goal:** Eliminate the cross-file duplications of inline JSX static config surfaced by the 0159 follow-on investigation (2026-06-02). Total ~80 LoC saved + 2 real drift-risk fixes + 1 new `app/types/` const pattern extended.

**Predecessor:** The local lifts (LENS/FILM_STOCK/CAMERA add-new fields, RATING_OPTIONS) already shipped on 0159 (commit grafted in via the inline-config tack-on). This plan is the cross-file follow-up — anything touching `ManageClient.tsx` or net-new shared files.

**Dependency:** Ideally land AFTER the chapter-006 naming-cleanup MR (which touches `ManageClient.tsx` heavily — better to do one rename pass, then the cross-file extractions on stable names). Not strictly required; the changes don't conflict semantically.

> **Status:** ✅ **Complete — all wins shipped to `main` (2026-06-06).** Wins #1 & #2 in [#172](https://github.com/themancalledzac/edens.zac/pull/172) — `COLLECTION_TYPE_LABELS` (rendered via `ASSIGNABLE_COLLECTION_TYPES.map` in both `ManageClient` type `<select>` ladders) + shared `ui/Dropdown/commonAddNewFields.ts` (`LOCATION_ADD_NEW_FIELDS`/`PERSON_ADD_NEW_FIELDS`) adopted across `EssentialInfoSection`, `TagsPeopleSection`, and 2 `ManageClient` sites. **Win #3 in [#175](https://github.com/themancalledzac/edens.zac/pull/175) (`0173`)** — `TEXT_FORMAT_OPTIONS`/`TEXT_ALIGN_OPTIONS` lifted to `app/types/Content.ts` with the unions derived from the consts. Note: section files are now under `app/components/Metadata/sections/` (the `ImageMetadata`→`Metadata` rename, [#170](https://github.com/themancalledzac/edens.zac/pull/170)).

---

## Spec

### Win #1 — `COLLECTION_TYPE_LABELS` in `app/types/Collection.ts`

**Files:**
- Modify: `app/types/Collection.ts` — add `COLLECTION_TYPE_LABELS: Record<CollectionType, string>` next to the existing `CollectionType` enum export (mirror the existing `COLLECTION_VISIBILITY_LABELS` pattern in `app/types/CollectionVisibility.ts:11+`).
- Modify: `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx` — lines 1196–1211 currently render the Collection Type `<select>` with 5 hardcoded `<option>` tags. Replace with `Object.entries(COLLECTION_TYPE_LABELS).map(([value, label]) => <option key={value} value={value}>{label}</option>)`.

**Why this pattern:** the codebase already does this exact thing for `CollectionVisibility` (`COLLECTION_VISIBILITY_LABELS` + `COLLECTION_VISIBILITY_DESCRIPTIONS`). Extending it to `CollectionType` matches the established convention and prevents the same drift the visibility pattern was designed to prevent.

**Tests:** add a small unit test asserting `COLLECTION_TYPE_LABELS` has an entry for every `CollectionType` enum member (typed `Record<CollectionType, string>` already enforces this at compile time, but a test catches accidental enum additions without label updates).

**LoC saved:** ~10. **Risk:** LOW. **Backend changes:** None.

---

### Win #2 — Shared `addNewFields` for Location + Person

**Files:**
- Create: `app/components/ui/Dropdown/commonAddNewFields.ts` exporting `LOCATION_ADD_NEW_FIELDS` and `PERSON_ADD_NEW_FIELDS` (and potentially `TAG_ADD_NEW_FIELDS` if the placeholder text genuinely matches between contexts).
- Modify: `app/components/ImageMetadata/sections/EssentialInfoSection.tsx` — replace the inline Locations `addNewFields={[...]}` (lines ~107–115) with `addNewFields={LOCATION_ADD_NEW_FIELDS}`.
- Modify: `app/components/ImageMetadata/sections/TagsPeopleSection.tsx` — replace the inline Tags `addNewFields={[...]}` (lines ~41–49) and People `addNewFields={[...]}` (lines ~74–82) with the imported constants.
- Modify: `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx` — replace the inline Locations `addNewFields={[...]}` (lines ~1231–1239) and People `addNewFields={[...]}` (lines ~1285–1293) with the imported constants.

**Why this is the real win:** the `{ name: 'name', label: 'Location Name', placeholder: 'e.g., Seattle, WA' }` literal appears **verbatim** in both `EssentialInfoSection.tsx` and `ManageClient.tsx`. Same for People (`'e.g., John Smith'` or similar). The placeholder hint WILL eventually drift between admin and modal contexts unless extracted. Tags has the same shape — verify the placeholders match before unifying; if they don't (e.g. admin uses "Add taxonomy tag" but modal uses "Add tag"), keep them separate.

**Preflight check:** before writing the shared file, `grep -A 10 "addNewFields=" app/components/ImageMetadata/sections/EssentialInfoSection.tsx app/components/ImageMetadata/sections/TagsPeopleSection.tsx app/\(admin\)/collection/manage/\[\[...slug\]\]/ManageClient.tsx` and confirm the literals are actually identical per field (Location, Person, Tag). If any field has divergent placeholder/label text between the two contexts, that field stays inline (or gets two separate consts named for context).

**Tests:** existing Dropdown tests cover the prop; no new tests needed for the constants themselves (they're pure data). Smoke-test that the 5 modified components still render their respective Dropdowns without crash.

**LoC saved:** ~40 (8 LoC × 5 inline literals → 1 import + 1 reference per site). **Risk:** LOW. **Backend changes:** None.

---

### Win #3 (defer / optional) — `TEXT_FORMAT_OPTIONS` and `TEXT_ALIGN_OPTIONS` in TextBlockCreateModal

**Files:**
- Modify: `app/components/TextBlockCreateModal/TextBlockCreateModal.tsx` — replace the two inline `<select>` `<option>` ladders (lines ~94–116) with module-scope const arrays + `.map()` render.

**Why:** same shape as the Rating lift on 0159. Pure local cleanup, no cross-file aspect.

**Bonus:** with `as const`, the union types `'plain' | 'markdown' | 'html'` and `'left' | 'center' | 'right'` can be DERIVED from the constants rather than duplicated. Check whether those literal unions are typed in the file or in `app/types/Content.ts`; if the latter, the consts move there too.

**LoC saved:** ~10. **Risk:** LOW. **Backend changes:** None.

---

## Verification

```bash
cd /Users/themancalledzac/Code/edens.zac
/opt/homebrew/bin/node node_modules/.bin/prettier --write <touched>
/opt/homebrew/bin/node node_modules/.bin/eslint --fix <touched>
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest
```

Expected: all 80+ suites stay green; +1 small test for `COLLECTION_TYPE_LABELS` enum coverage. Total LoC drops ~60.

---

## Suggested commit sequence

1. `feat(types): add COLLECTION_TYPE_LABELS next to the enum; adopt in ManageClient` (Win #1)
2. `refactor(ui): shared commonAddNewFields for Location + Person; adopt across image + admin editors` (Win #2)
3. *(optional, only if you want to ship #3 in the same MR)* `refactor(text-block): lift format + align option ladders to module scope` (Win #3)

Each commit passes tsc + jest independently. All wins are mutually independent.

---

## Spec-coverage checklist

| Concern | This MR? | Notes |
|---|---|---|
| Identical `{name: 'name', label: 'Location Name', placeholder: 'e.g., Seattle, WA'}` in 2 files (drift risk) | ✅ Win #2 | Real fix. |
| Identical Person `addNewFields` in 2 files | ✅ Win #2 | Real fix. |
| CollectionType `<option>` ladder hardcoded inline | ✅ Win #1 | Matches existing `CollectionVisibility` pattern. |
| TextBlockCreateModal format/align `<option>` ladders | 🟡 Win #3 (optional) | Local cleanup, no drift risk. Bundle if convenient. |
| Tag `addNewFields` consolidation | ❓ Conditional on Win #2 preflight | Only if placeholder text genuinely matches across contexts. |
| `MetadataActionRow.tsx` inline labels | ❌ Out of scope | Single-line literals; the rule explicitly says don't lift. |
| `getDisplayName={lens => lens.name}` arrows | ❌ Out of scope | 1-line, more readable inline. |
| Trivial `onChange`/`onAddNew` handlers | ❌ Out of scope | Closure-bound, extracting adds ceremony. |
| Camera optimistic-create flow (`createCamera` async block, 36 LoC in CameraSettingsSection lines 59–95) | ❌ Out of scope (different category) | Separate "extract complex handler to hook" cleanup — file as its own concern if pursued. |

---

## Files referenced

- `app/types/Collection.ts` (Win #1 — add `COLLECTION_TYPE_LABELS`)
- `app/types/CollectionVisibility.ts` (Win #1 — pattern to mirror, lines 11+)
- `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx` (Wins #1, #2 — 3 call sites)
- `app/components/ui/Dropdown/commonAddNewFields.ts` (Win #2 — NEW shared file)
- `app/components/ImageMetadata/sections/EssentialInfoSection.tsx` (Win #2 — Location consumer)
- `app/components/ImageMetadata/sections/TagsPeopleSection.tsx` (Win #2 — Tag + Person consumers)
- `app/components/TextBlockCreateModal/TextBlockCreateModal.tsx` (Win #3 — optional)
- `ai_guidelines/ai_quick_reference.md` (the "Inline JSX Config Rule" this plan applies)
