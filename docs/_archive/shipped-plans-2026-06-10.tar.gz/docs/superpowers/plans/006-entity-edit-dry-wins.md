# 006 · Entity-Edit DRY Wins (toggle + diff utilities)
_Chapter [006 · Code Health](../../006-code-health.md) · plan · branch `0172-entity-edit-dry`_

> **Status:** ✅ **Shipped to `main` 2026-06-06** ([#174](https://github.com/themancalledzac/edens.zac/pull/174), `0172`) — generic `buildAssociationDiff` for tags/people, shared `toggleRelation` engine (`app/utils/collectionToggle.ts`), and the `useToggleTriple` hook adopted at 4 sites. `tsc` + `jest` green. The state-shape unification was intentionally **rejected** (see _Out of scope_ below).

> **For agentic workers:** REQUIRED SUB-SKILL: Use `superpowers:subagent-driven-development` or `superpowers:executing-plans`. This is a small MR (~5–7 files, 1–2 commits).

**Goal:** Eliminate 3 specific duplications between the image-edit flow (`app/components/ImageMetadata/`) and the collection-edit flow (`app/(admin)/collection/manage/[[...slug]]/`) — net ~115 LoC saved, all low-risk, all under existing test coverage. Surfaced by the 0159 follow-on investigation (`superpowers:code-reviewer` agent, 2026-06-02).

**Out of scope (intentionally):** unifying `ImageUpdateState` and `CollectionUpdateRequest`, unifying `visibility`, unifying people-save paths, building a `useEntityEditState` abstraction. The investigation report linked below documents WHY each of these would hurt more than help.

**Dependency:** Land AFTER the chapter-006 naming-cleanup MR (which renames `useImageMetadataState` → likely `useContentMetadataState`, etc.). This plan should sit on stable names so the consolidation isn't done across a moving rename.

---

## Spec

### Win #1 — Generic `buildAssociationDiff<T>` for tags/people

**Files:**
- Modify: `app/components/ImageMetadata/imageMetadataUtils.ts` — replace private `buildTagsDiff` (lines 532–559) and `buildPeopleDiff` (lines 564–591) with one call to a shared helper. Also collapse the inline GIF collections-diff in `useImageMetadataSubmit.ts:110–126` (the same pattern repeated a third time).

**Why:** the two builders are 90% byte-identical — same control flow, same `prev`/`newValue`/`remove` mechanic, same `id > 0` partitioning. Only the field name differs.

**Proposed shape:**
```ts
function buildAssociationDiff<T extends { id?: number; name: string }>(
  field: 'tags' | 'people',
  updateItems: T[] | undefined,
  currentItems: T[] | undefined,
  diff: Record<string, { prev?: number[]; newValue?: string[]; remove?: number[] }>
): void
```

**Tests:** `tests/components/ImageMetadata/imageMetadataUtils.test.ts` already covers both builders via 186 cases. Refactor under green; no new tests required unless behavior changes (it shouldn't).

**LoC saved:** ~50. **Risk:** LOW.

---

### Win #2 — Share the `toggleRelation` engine

**Files:**
- Promote: `app/(admin)/collection/manage/[[...slug]]/manageUtils.ts` `toggleRelation` (lines 42–79) → `app/utils/collectionToggle.ts` (new shared location).
- Modify: `app/components/ImageMetadata/hooks/useImageMetadataState.ts` — replace inline `handleCollectionToggle` (lines 142–161) with a call to the shared engine.

**Why:** `toggleRelation` is the canonical "toggle one entry within a `prev/newValue/remove` association" engine. Currently used twice in `ManageClient` (children + siblings). The image side reinvented the same logic inline — different state shape (image stores `collections: ChildCollection[]` flat; collection stores discrete `newValue`/`remove` arrays), but the **engine** is the same pure function.

**Subtle adapter:** the image side's flat-array representation needs a thin adapter that wraps `toggleRelation` and converts the result back into a flat array. The collection side calls the engine directly. Engine stays pure; adapters live at each call site.

**Tests:** `tests/(admin)/collection/manage/[[...slug]]/manageUtils.test.ts` (204 cases) covers the collection side. Add 2–3 cases for the image-side adapter.

**LoC saved:** ~25. **Risk:** LOW.

---

### Win #3 — `useToggleTriple` hook to derive `(savedIds, pendingAddIds, pendingRemoveIds)`

**Files:**
- Create: `app/hooks/useToggleTriple.ts` (shared hook, not under `ImageMetadata/` since both editors use it).
- Modify: `app/components/ImageMetadata/hooks/useImageMetadataState.ts` — replace 3 inline `useMemo`s (lines 111–140) with one hook call.
- Modify: `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx` — replace 3 inline `useMemo`s for children (lines 796–818) AND 3 inline `useMemo`s for siblings (lines 888–906) with two hook calls.

**Why:** the same three `useMemo`-derived `Set<number>`s appear in **three places** (image collections, child collections, sibling collections). This is the feeder pattern for `CollectionListSelector` — the picker consumes exactly these three sets. Centralizing the derivation locks the contract.

**Proposed shape:**
```ts
function useToggleTriple<T>(
  originalIds: number[],
  pendingAdds: T[] | undefined,
  pendingRemoves: number[] | undefined,
  getId: (item: T) => number,
): { savedIds: Set<number>; pendingAddIds: Set<number>; pendingRemoveIds: Set<number> }
```

**Tests:** new test file `tests/hooks/useToggleTriple.test.tsx` — 4–6 cases covering the four state transitions (initial / add / remove / re-add-after-remove). Existing call-site tests stay green unchanged.

**LoC saved:** ~40. **Risk:** LOW.

---

## Verification

```bash
cd /Users/themancalledzac/Code/edens.zac
/opt/homebrew/bin/node node_modules/.bin/prettier --write <touched>
/opt/homebrew/bin/node node_modules/.bin/eslint --fix <touched>
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest
```

Expected: all 80 suites stay green; ~5–10 new test cases for the extracted utilities and hook. Total test count goes up modestly, total LoC goes down ~115.

---

## Suggested commit sequence

1. `refactor(utils): extract buildAssociationDiff for tags + people; collapse GIF collections-diff duplicate` (Win #1)
2. `refactor(utils): promote toggleRelation to shared util; adopt in image-side handleCollectionToggle` (Win #2)
3. `feat(hooks): useToggleTriple — single source for CollectionListSelector feeder pattern (3 call sites)` (Win #3)

Each commit passes tsc + jest independently. All three are mutually independent and could be reordered or parallelized via Agent Teams (one subagent per win).

---

## Open question (defer to a future round)

Whether to build `useEntityEditState<T, U>` — a shared wrapper for the `useState(initialFromOriginal) + useEffect(reset on original change) + hasChanges` triad. User decision (2026-06-02): **deferred** — no third entity editor is on the roadmap, so today's 2-caller surface doesn't justify the abstraction. Revisit when a third surface (tag-admin / person-admin / camera-admin page) is being designed.

---

## Spec-coverage checklist

Every win maps to a specific named duplication. Surface that wasn't in scope:

| Concern | This MR? | Why / Status |
|---|---|---|
| `buildTagsDiff` ≈ `buildPeopleDiff` in `imageMetadataUtils.ts` | ✅ Win #1 | |
| `useImageMetadataSubmit.ts:110-126` inline GIF collections-diff | ✅ Win #1 (collapsed in same extraction) | |
| `toggleRelation` reinvented inline in `useImageMetadataState` | ✅ Win #2 | |
| 3× duplicated `useMemo` triple in image + ManageClient children + ManageClient siblings | ✅ Win #3 | |
| `ImageUpdateState` vs `CollectionUpdateRequest` shapes differ | ❌ Out of scope | Anti-consolidation — wire formats intentionally differ (image: live model + diff at submit; collection: in-place DTO mutation). Merging hurts more than helps. |
| `visibility` semantic clash (per-junction boolean vs categorical enum) | ❌ Out of scope | Anti-consolidation — codebase already documents the trap at `app/types/CollectionVisibility.ts:4-7`. Don't unify. |
| people save flow (image diff vs collection set-replace + regenerate action) | ❌ Out of scope | Anti-consolidation — collection side needs `setCollectionPeople` set-semantics for `regeneratePeople`. |
| `useEntityEditState<T, U>` wrapper | ❌ Deferred | Only 2 callers today; revisit when a 3rd surface exists. |

---

## Files referenced

- `app/components/ImageMetadata/imageMetadataUtils.ts` (Win #1)
- `app/components/ImageMetadata/hooks/useImageMetadataSubmit.ts` (Win #1)
- `app/components/ImageMetadata/hooks/useImageMetadataState.ts` (Wins #2, #3)
- `app/(admin)/collection/manage/[[...slug]]/manageUtils.ts` (Win #2 — promote)
- `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx` (Win #3)
- `app/components/CollectionListSelector/CollectionListSelector.tsx` (no edits; consumes the triple)
- `app/utils/collectionToggle.ts` (NEW, Win #2)
- `app/hooks/useToggleTriple.ts` (NEW, Win #3)

---

## Source investigation report (canonical)

Full per-field analysis + anti-consolidation rationale in the 2026-06-02 `superpowers:code-reviewer` investigation. Key findings retained in MemPalace: see decisions hall, topic `entity-edit-consolidation-investigation`.
