# 001 · Information Architecture & UX
_Chapter [001 · Design System Unification](../../001-design-review.md) · plan · branch `0151-ia-and-ux`_

> ✅ **SHIPPED — [PR #158](https://github.com/themancalledzac/edens.zac/pull/158) (merged 2026-06-03).** Public taxonomy front door, deep-linkable fullscreen (`?image=<id>` + history, Back-closes-modal, position counter), the previously-orphaned `parse/serializeFilterToParams` URL helpers wired into the gallery clients, footer + breadcrumb, and entity NAME on taxonomy pages. The plan below is preserved as the implementation record.

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Close the information-architecture and UX gaps the design review flagged: give the orphaned taxonomy (`/tag`, `/location`, `/people`) a public front door, make the fullscreen viewer deep-linkable and Back-button-correct with a position counter, wire the already-tested filter-URL helpers into the gallery clients so filtered views are shareable, kill the blank-on-load void with an eager first row + blur-up placeholders, add a persistent footer + breadcrumb so deep-linked visitors aren't stranded, and ensure every taxonomy page shows the entity NAME (not just "N photos").

**Architecture:** Six bite-sized, mostly independent tasks. New public route group `app/explore/` (the directory) reuses `getMetadata()`; new `app/components/Footer/` and `app/components/Breadcrumb/` compose the `NavLink`/`Tile` and `PageShell` primitives from the Nav+Shell plan. Fullscreen deep-linking lives entirely in `useFullScreenImage` + `FullScreenModal` (URL is the source of truth via `?image=<id>` + `history.pushState`/`popstate`). Filter-URL wiring threads `useSearchParams` + `router.replace` through `CollectionPageClient` and `LocationPageClient` using the existing pure `parseFilterFromParams`/`serializeFilterToParams`. The skeleton/blur-up work eager-renders the first BoxTree row(s) inside the existing `Component`/`CollectionContentRenderer` priority plumbing. Server-Component-friendly where possible; the URL-stateful pieces stay in the existing `'use client'` clients.

**Tech Stack:** Next.js 16 App Router, React 19, TypeScript (strict, no `any`), SCSS Modules with CSS custom properties (bare `var(--token)`, no `@use` partial), Jest + React Testing Library (tests mirror `app/` under `tests/`). `next/jest` maps CSS modules to identity proxies, so `styles.foo === 'foo'` in assertions.

> **Spec:** This plan implements the *Phase 3 — Information architecture & UX* section of [`001-design-system-unification.md`](001-design-system-unification.md), which itself implements [`../../001-design-review.md`](../../001-design-review.md). Review references like *(review §2)* / *(review §7)* / *(review §8)* point to the design review.
> **Predecessor / prerequisite plan:** [`001-design-system-unification.md`](001-design-system-unification.md) — **Phase 0** (painted dark-safe surface + token aliases) and the **Phase 2 Nav+Shell sub-plan** ([`001-nav-and-shell.md`](001-nav-and-shell.md): `NavLink`/`Tile`/`PageShell`) must land before Tasks 1, 5, and 6 here. See *Prerequisites* below.
> **Status:** Plan only. No code written yet.

---

## Prerequisites (must land before this plan)

This plan composes primitives produced by the master plan. Do not start Tasks 1, 5, or 6 until these exist:

- **Phase 0 (master plan):** `html, body` paint `var(--color-bg)`/`var(--color-fg)`, the `--text-*`/`--border-color`/`--color-accent` alias block is declared, `FsDebug` is deleted, the dead `/all-blogs` Blogs menu item is removed, and `About`/`ContactForm` no longer take `onBack`. **Tasks 1, 4, 5, 6 assume the painted surface; Task 2 assumes `FsDebug` is gone** (it removes the `?fsdebug=1` read entirely — if Phase 0 has not run, fold the `FsDebug` deletion from master-plan Task 0.2 into Task 2 Step 2 here).
- **Phase 2 Nav+Shell sub-plan:** `app/components/ui/NavLink/NavLink.tsx` (always a real `next/link` `<a>`, `variant` prop), `app/components/ui/Tile/Tile.tsx`, and `app/components/ui/PageShell/PageShell.tsx` (`container/main/SiteHeader/pageHeader` + `breadcrumbs?` slot). **Tasks 1, 5, 6 import these.** If the Nav+Shell sub-plan has not been executed when you reach this plan, promote it first (`superpowers:writing-plans`) — it is the natural home for `<Breadcrumb>` too, but this plan ships `<Breadcrumb>` in Task 5 if it does not already exist there.

**Coordination note (read before Task 3):** the master plan's **Task 1.3 (`<FilterToolbar>` + `<FilterChip>`)** merges `GalleryFilterState` + `CollectionFilterState` into one `FilterState` and rebuilds the filter bars. Task 3 here wires *the existing* filter state to the URL **without** waiting for Task 1.3, by serializing each client's current state shape. If Task 1.3 lands first, re-point Task 3's serialize/parse mapping at the unified `FilterState` (the URL keys are identical because both go through `serializeFilterToParams`). The two tasks are intentionally decoupled — Task 3 touches only the two client files and adds no new chip UI.

---

## File-structure map

**New (created by this plan):**

```
app/explore/
  page.tsx                          (Task 1 — public "Explore" directory, Server Component)
  Explore.module.scss               (Task 1)
app/components/Footer/
  Footer.tsx                        (Task 5 — Server Component)
  Footer.module.scss                (Task 5)
app/components/Breadcrumb/
  Breadcrumb.tsx                    (Task 5 — Server Component; skip if Nav+Shell sub-plan already shipped it)
  Breadcrumb.module.scss            (Task 5)
app/hooks/useFilterUrlState.ts      (Task 3 — shared URL<->filter sync hook)

tests/explore/page.test.tsx                       (Task 1)
tests/hooks/useFullScreenImage.deeplink.test.tsx  (Task 2)
tests/components/FullScreenModal/FullScreenModal.counter.test.tsx (Task 2)
tests/hooks/useFilterUrlState.test.tsx            (Task 3)
tests/components/Footer/Footer.test.tsx           (Task 5)
tests/components/Breadcrumb/Breadcrumb.test.tsx   (Task 5)
tests/components/TaxonomyPage/TaxonomyPage.test.tsx (Task 6)
```

**Modified:**

```
app/hooks/useFullScreenImage.tsx                  (Task 2 — URL sync + counter index source)
app/components/FullScreenModal/FullScreenModal.tsx (Task 2 — "3 / 12" counter; remove ?fsdebug=1 read)
app/components/ContentCollection/CollectionPageClient.tsx (Task 3 — useFilterUrlState)
app/components/LocationPage/LocationPageClient.tsx (Task 3 — useFilterUrlState)
app/components/Content/CollectionContentRenderer.tsx (Task 4 — blur-up placeholder on priority image)
app/components/Content/Component.tsx              (Task 4 — eager first-row skeleton sizing pass-through)
app/components/MenuDropdown/MenuDropdown.tsx      (Task 1 — "Explore" + "Browse all work" links)
app/layout.tsx                                    (Task 5 — render <Footer/> after children)
app/components/TaxonomyPage/TaxonomyPage.tsx      (Task 5 + 6 — breadcrumb slot; keep entity-name h1)
app/components/LocationPage/LocationPage.tsx      (Task 5 — breadcrumb slot)
app/styles/fullscreen-image.module.scss          (Task 2 — .positionCounter)
```

---

## Task 1 — Public taxonomy directory (`/explore`) + nav links

**Why:** `/tag`, `/location`, `/people` are well-built and SEO-clean but **orphaned** — reachable only via Google or inline chips. `/people` has **zero** entry points anywhere in the UI. The public `/all-collections` page exists but nothing links to it ("Browse all work" is missing). *(review §2 IA map, §5, §8 — "Browse-by-tag/location/person directory pages for humans"; §7 "A public taxonomy directory — turn the existing `/metadata` data into a public Explore index".)*

`getMetadata()` already returns `{ tags, people, locations, … }` (`GeneralMetadataDTO`) where each tag/person/location carries `{ id, name, slug }` (locations also `count?`). We render them as real `NavLink`s. This is a Server Component (no `'use client'`).

**Files:**
- Create: `app/explore/page.tsx`
- Create: `app/explore/Explore.module.scss`
- Modify: `app/components/MenuDropdown/MenuDropdown.tsx` (add Explore + Browse all work nav)
- Test: `tests/explore/page.test.tsx`

- [ ] **Step 1 — Write the failing test** `tests/explore/page.test.tsx`. Mock `getMetadata` and assert the page renders a section per dimension with real links to `/tag/<slug>`, `/people/<slug>`, `/location/<slug>`:

```tsx
import '@testing-library/jest-dom';

import { render, screen } from '@testing-library/react';

jest.mock('@/app/lib/api/collections', () => ({
  getMetadata: jest.fn(),
}));

import ExplorePage from '@/app/explore/page';
import { getMetadata } from '@/app/lib/api/collections';

const mockGetMetadata = getMetadata as jest.MockedFunction<typeof getMetadata>;

describe('ExplorePage', () => {
  it('renders a NavLink per tag, person, and location', async () => {
    mockGetMetadata.mockResolvedValue({
      tags: [{ id: 1, name: 'Mountains', slug: 'mountains' }],
      people: [{ id: 2, name: 'Jane Doe', slug: 'jane-doe' }],
      locations: [{ id: 3, name: 'Patagonia', slug: 'patagonia', count: 12 }],
      cameras: [],
      lenses: [],
      filmTypes: [],
      filmFormats: [],
      collections: [],
    });

    render(await ExplorePage());

    expect(screen.getByRole('link', { name: /Mountains/ })).toHaveAttribute('href', '/tag/mountains');
    expect(screen.getByRole('link', { name: /Jane Doe/ })).toHaveAttribute('href', '/people/jane-doe');
    expect(screen.getByRole('link', { name: /Patagonia/ })).toHaveAttribute(
      'href',
      '/location/patagonia'
    );
  });

  it('renders a fallback message when metadata fails to load', async () => {
    mockGetMetadata.mockResolvedValue(null);
    render(await ExplorePage());
    expect(screen.getByText(/Unable to load/i)).toBeInTheDocument();
  });
});
```

- [ ] **Step 2 — Run it; verify it fails:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/explore/page.test.tsx
```
Expected: FAIL — `Cannot find module '@/app/explore/page'`.

- [ ] **Step 3 — Implement `app/explore/page.tsx`** (Server Component; reuses `PageShell` + `NavLink` from the Nav+Shell sub-plan):

```tsx
import { type Metadata } from 'next';

import { NavLink } from '@/app/components/ui/NavLink/NavLink';
import { PageShell } from '@/app/components/ui/PageShell/PageShell';
import { getMetadata } from '@/app/lib/api/collections';

import styles from './Explore.module.scss';

// Render on every request — getMetadata() calls fetchAdminGetApi which can fail
// mid-build before the proxy is live. Same rationale as app/metadata/page.tsx.
export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Explore',
  description: 'Browse photography by tag, person, and location.',
};

export default async function ExplorePage() {
  let data;
  try {
    data = await getMetadata();
  } catch {
    data = null;
  }

  if (!data) {
    return (
      <PageShell title="Explore">
        <p className={styles.empty}>Unable to load the directory right now. Please try again later.</p>
      </PageShell>
    );
  }

  const { tags, people, locations } = data;

  return (
    <PageShell title="Explore">
      <p className={styles.intro}>Browse the archive by tag, person, or location.</p>

      <section className={styles.section} aria-labelledby="explore-locations">
        <h2 id="explore-locations" className={styles.sectionHeading}>
          Locations
        </h2>
        <ul className={styles.linkList}>
          {locations.map(loc => (
            <li key={loc.id}>
              <NavLink href={`/location/${loc.slug}`} className={styles.directoryLink}>
                <span>{loc.name}</span>
                {typeof loc.count === 'number' && (
                  <span className={styles.count} aria-hidden="true">
                    {loc.count}
                  </span>
                )}
              </NavLink>
            </li>
          ))}
        </ul>
      </section>

      <section className={styles.section} aria-labelledby="explore-people">
        <h2 id="explore-people" className={styles.sectionHeading}>
          People
        </h2>
        <ul className={styles.linkList}>
          {people.map(person => (
            <li key={person.id}>
              <NavLink href={`/people/${person.slug}`} className={styles.directoryLink}>
                <span>{person.name}</span>
              </NavLink>
            </li>
          ))}
        </ul>
      </section>

      <section className={styles.section} aria-labelledby="explore-tags">
        <h2 id="explore-tags" className={styles.sectionHeading}>
          Tags
        </h2>
        <ul className={styles.linkList}>
          {tags.map(tag => (
            <li key={tag.id}>
              <NavLink href={`/tag/${tag.slug}`} className={styles.directoryLink}>
                <span>{tag.name}</span>
              </NavLink>
            </li>
          ))}
        </ul>
      </section>
    </PageShell>
  );
}
```

> **NavLink fallback:** if the Nav+Shell sub-plan has not shipped `NavLink`/`PageShell` yet, this Task is blocked — promote that sub-plan first (see *Prerequisites*). Do NOT inline a `div onClick` or a bare `<a>`; the whole point of the directory is crawlable real links.

- [ ] **Step 4 — Implement `app/explore/Explore.module.scss`** (tokens only):

```scss
.intro {
  margin: 0 var(--page-padding-mobile) var(--space-5);
  color: var(--color-fg-muted);
  font-size: var(--text-md);

  @media (width >= 768px) {
    margin-left: 0;
    margin-right: 0;
  }
}

.section {
  margin-bottom: var(--space-7);
  padding: 0 var(--page-padding-mobile);

  @media (width >= 768px) {
    padding: 0;
  }
}

.sectionHeading {
  font-size: var(--text-lg);
  font-weight: 600;
  margin-bottom: var(--space-4);
  color: var(--color-fg);
}

.linkList {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-3);
}

.directoryLink {
  display: inline-flex;
  align-items: baseline;
  gap: var(--space-2);
  padding: var(--space-1) var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-1);
  color: var(--color-fg);
  font-size: var(--text-sm);

  &:hover {
    background-color: var(--color-bg-light);
  }
}

.count {
  color: var(--color-fg-muted);
  font-size: var(--text-xs);
}

.empty {
  padding: var(--space-7) var(--page-padding-mobile);
  text-align: center;
  color: var(--color-fg-muted);
}
```

- [ ] **Step 5 — Run the test; verify it passes:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/explore/page.test.tsx
```
Expected: PASS (2 tests).

- [ ] **Step 6 — Link `/explore` and `/all-collections` from the menu.** In `app/components/MenuDropdown/MenuDropdown.tsx`, add two new navigation handlers and two public menu items at the top of the public group (these are NOT gated behind `isLocalEnvironment()` — they are public). Add to the `handleNavigation` object (after `update`):

```tsx
    explore: () => {
      router.push('/explore');
      onClose();
    },
    allCollections: () => {
      router.push('/all-collections');
      onClose();
    },
```

Then, in the public section of the dropdown (after the Contact item / `{showContactForm && …}` block, where the dead Blogs item used to be — removed in Phase 0), add:

```tsx
        <div className={styles.dropdownMenuItem}>
          <button
            type="button"
            className={styles.dropdownMenuButton}
            onClick={handleNavigation.allCollections}
          >
            <span className={styles.dropdownMenuOptions}>Browse all work</span>
          </button>
        </div>

        <div className={styles.dropdownMenuItem}>
          <button
            type="button"
            className={styles.dropdownMenuButton}
            onClick={handleNavigation.explore}
          >
            <span className={styles.dropdownMenuOptions}>Explore</span>
          </button>
        </div>
```

> These remain `button`+`router.push` to match `MenuDropdown`'s existing idiom and its scroll-lock/close lifecycle. The crawlable real-link requirement is satisfied by the **Footer** (Task 5) and the `/explore` page itself; the menu is a JS-only convenience overlay.

- [ ] **Step 7 — Lint + type-check + commit:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/explore/page.tsx app/explore/Explore.module.scss app/components/MenuDropdown/MenuDropdown.tsx tests/explore/page.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/explore/page.tsx app/components/MenuDropdown/MenuDropdown.tsx tests/explore/page.test.tsx
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/explore/Explore.module.scss'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest tests/explore/page.test.tsx
git add app/explore app/components/MenuDropdown/MenuDropdown.tsx tests/explore
git commit -m "feat(ia): public /explore taxonomy directory + Explore/Browse-all-work nav

Turns the existing getMetadata() data into a crawlable public index of tags,
people, and locations as real NavLinks. /people previously had zero entry
points. Adds Explore + Browse all work to the menu.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 2 — Deep-linkable fullscreen (URL sync + Back closes + position counter)

**Why:** Opening an image into fullscreen is excellent in-modal but **React-state-only** — not shareable, and the browser **Back button exits the whole collection** instead of closing the modal (the biggest mobile journey gap). Add `?image=<id>` to the URL on open + `history.pushState`, restore on load (shared link reopens to the image), close the modal on `popstate` (Back), and show a `3 / 12` position counter. *(review §2, §5 "Fullscreen not deep-linkable; Back button exits collection", §8.)*

**Design (URL is a reflection of state, state stays the source of truth):**
- On `showImage`, push a history entry and set `?image=<id>` (replacing any existing `image` param). The collection page itself remains the previous history entry, so Back returns to it.
- A `popstate` listener calls the existing `setFullScreenState(null)` path when the `image` param disappears, closing the modal without navigating away.
- On mount, if the URL already has `?image=<id>` AND the caller passed a matching block, open it (handled by the consuming wrapper, which knows the block list — see Step 6).
- `hideImage` pops the pushed entry with `history.back()` only if we pushed one; otherwise it strips the param via `replaceState`. Tracked with a `pushedHistoryRef` so we never over-pop.

**Files:**
- Modify: `app/hooks/useFullScreenImage.tsx`
- Modify: `app/components/FullScreenModal/FullScreenModal.tsx` (counter + remove `?fsdebug=1` read)
- Modify: `app/styles/fullscreen-image.module.scss` (`.positionCounter`)
- Test: `tests/hooks/useFullScreenImage.deeplink.test.tsx`
- Test: `tests/components/FullScreenModal/FullScreenModal.counter.test.tsx`

- [ ] **Step 1 — Write the failing hook test** `tests/hooks/useFullScreenImage.deeplink.test.tsx`. Use `renderHook` + `act`; mock `next/navigation` per the project pattern; spy on `history.pushState`:

```tsx
import { act, renderHook } from '@testing-library/react';

import { useFullScreenImage } from '@/app/hooks/useFullScreenImage';
import type { ContentImageModel } from '@/app/types/Content';

jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: jest.fn(), replace: jest.fn(), prefetch: jest.fn() }),
  useSearchParams: () => new URLSearchParams(),
}));

jest.mock('@/app/hooks/useBodyScrollLock', () => ({ useBodyScrollLock: jest.fn() }));

const img = (id: number): ContentImageModel =>
  ({
    id,
    contentType: 'IMAGE',
    imageUrl: `https://cdn.example/${id}.jpg`,
    orderIndex: id,
    visible: true,
  }) as ContentImageModel;

describe('useFullScreenImage — deep linking', () => {
  beforeEach(() => {
    window.history.replaceState({}, '', '/collection-x');
  });

  it('pushes ?image=<id> to history on showImage', () => {
    const pushSpy = jest.spyOn(window.history, 'pushState');
    const { result } = renderHook(() => useFullScreenImage());

    act(() => {
      result.current.showImage(img(7), [img(6), img(7), img(8)]);
    });

    expect(result.current.isOpen).toBe(true);
    expect(result.current.fullScreenState?.currentIndex).toBe(1);
    expect(pushSpy).toHaveBeenCalled();
    expect(window.location.search).toContain('image=7');
    pushSpy.mockRestore();
  });

  it('updates ?image= when navigating next', () => {
    const { result } = renderHook(() => useFullScreenImage());
    act(() => {
      result.current.showImage(img(6), [img(6), img(7), img(8)]);
    });
    act(() => {
      result.current.navigateToNext();
    });
    expect(result.current.fullScreenState?.currentIndex).toBe(1);
    expect(window.location.search).toContain('image=7');
  });

  it('closes the modal on popstate when the image param is gone (Back button)', () => {
    const { result } = renderHook(() => useFullScreenImage());
    act(() => {
      result.current.showImage(img(7), [img(7), img(8)]);
    });
    expect(result.current.isOpen).toBe(true);

    // Simulate browser Back: URL returns to the collection, popstate fires.
    act(() => {
      window.history.replaceState({}, '', '/collection-x');
      window.dispatchEvent(new PopStateEvent('popstate'));
    });

    expect(result.current.isOpen).toBe(false);
  });
});
```

- [ ] **Step 2 — Run it; verify it fails:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/hooks/useFullScreenImage.deeplink.test.tsx
```
Expected: FAIL — `pushState` not called / `isOpen` still true after popstate (no URL sync yet).

- [ ] **Step 3 — Add URL sync to `app/hooks/useFullScreenImage.tsx`.** Add a `pushedHistoryRef` and three helpers, and call them from `showImage`, `navigate`, and `hideImage`. The hook already imports `useRouter`, `useCallback`, `useEffect`, `useRef`, `useState`.

First, add the ref next to the other refs (after `const isSwiping = useRef<boolean>(false);`):

```tsx
  // Tracks whether *we* pushed a history entry for the open modal, so hideImage
  // pops exactly one entry and popstate (Back) is distinguished from our own pop.
  const pushedHistoryRef = useRef<boolean>(false);
```

Add this URL helper (module scope, above the hook) so the logic is testable and pure:

```tsx
/** Build a search string with `image` set to the given id, preserving other params. */
function buildImageSearch(id: number): string {
  const params = new URLSearchParams(
    typeof window !== 'undefined' ? window.location.search : ''
  );
  params.set('image', String(id));
  const qs = params.toString();
  return qs ? `?${qs}` : '';
}

/** Build a search string with `image` removed, preserving other params. */
function buildSearchWithoutImage(): string {
  const params = new URLSearchParams(
    typeof window !== 'undefined' ? window.location.search : ''
  );
  params.delete('image');
  const qs = params.toString();
  return qs ? `?${qs}` : '';
}
```

Rewrite `showImage` to push history + sync the URL:

```tsx
  const showImage = useCallback((image: ImageBlock, allImages?: ImageBlock[]) => {
    const images = allImages || [image];
    const currentIndex = allImages?.findIndex(img => img.id === image.id) ?? 0;
    const resolvedIndex = currentIndex !== -1 ? currentIndex : 0;

    setFullScreenState({
      images,
      currentIndex: resolvedIndex,
      scrollPosition: window.scrollY,
    });

    // Push a single history entry the first time the modal opens so the browser
    // Back button closes the modal (popstate) instead of leaving the collection.
    if (typeof window !== 'undefined') {
      const search = buildImageSearch(image.id);
      if (!pushedHistoryRef.current) {
        window.history.pushState({ fsImage: image.id }, '', `${window.location.pathname}${search}`);
        pushedHistoryRef.current = true;
      } else {
        window.history.replaceState(
          { fsImage: image.id },
          '',
          `${window.location.pathname}${search}`
        );
      }
    }
  }, []);
```

Rewrite `hideImage` to unwind the pushed entry:

```tsx
  const hideImage = useCallback(() => {
    setFullScreenState(null);
    setShowMetadata(false);
    setLoadedImageIds(new Set());

    if (typeof window !== 'undefined') {
      if (pushedHistoryRef.current) {
        // We own one pushed entry — pop it so the URL + history return to the collection.
        pushedHistoryRef.current = false;
        window.history.back();
      } else {
        // Opened from a deep link (no pushed entry): just strip the param in place.
        window.history.replaceState(
          {},
          '',
          `${window.location.pathname}${buildSearchWithoutImage()}`
        );
      }
    }
  }, []);
```

Sync the URL when navigating between images (inside the existing `navigate` callback, after computing `newIndex`, only on a successful move):

```tsx
  const navigate = useCallback((direction: 'next' | 'previous') => {
    setFullScreenState(prev => {
      if (!prev) return null;
      const delta = direction === 'next' ? 1 : -1;
      const newIndex = prev.currentIndex + delta;

      if (newIndex >= 0 && newIndex < prev.images.length) {
        const nextImage = prev.images[newIndex];
        if (nextImage && typeof window !== 'undefined') {
          window.history.replaceState(
            { fsImage: nextImage.id },
            '',
            `${window.location.pathname}${buildImageSearch(nextImage.id)}`
          );
        }
        return { ...prev, currentIndex: newIndex };
      }
      return prev;
    });
  }, []);
```

Add a `popstate` effect (Back button) that closes the modal when the `image` param is gone. Place it after the existing keyboard effect:

```tsx
  // Browser Back: when the user navigates back and the `image` param is gone,
  // close the modal in place (do NOT push/replace again — the URL already moved).
  useEffect(() => {
    const handlePopState = () => {
      const hasImageParam = new URLSearchParams(window.location.search).has('image');
      if (!hasImageParam) {
        pushedHistoryRef.current = false;
        setFullScreenState(null);
        setShowMetadata(false);
        setLoadedImageIds(new Set());
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);
```

> **No new return value needed** for popstate; the existing `fullScreenState`/`isOpen` already reflect closure. `currentIndex` (already returned via `fullScreenState`) feeds the counter in Step 5.

- [ ] **Step 4 — Run the hook test; verify it passes:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/hooks/useFullScreenImage.deeplink.test.tsx
```
Expected: PASS (3 tests).

- [ ] **Step 5 — Add the "3 / 12" position counter to `app/components/FullScreenModal/FullScreenModal.tsx`.** The component already derives `fullScreenState.currentIndex` and `fullScreenState.images.length`. Add a counter element inside `modalContent`, just before the close button (`<button className={styles.closeButton} …>`):

```tsx
      <div className={styles.positionCounter} aria-live="polite">
        {fullScreenState.currentIndex + 1} / {fullScreenState.images.length}
      </div>
```

In the same edit, **remove the `?fsdebug=1` diagnostic** (Phase 0 deletes `FsDebug.tsx`; this removes its last reader): delete the `import { FsDebug } from './FsDebug';` line, the `const fsdebug = …` block (lines reading `window.location.search`), and the `{fsdebug && <FsDebug />}` render. *(If Phase 0 has already deleted these, this sub-step is a no-op — verify with the grep in Step 8.)*

- [ ] **Step 6 — Reopen on deep link (consuming wrapper).** Deep-link restore lives where the block list is known — `app/components/Content/ContentBlockWithFullScreen.tsx`. Add an effect that, on mount, reads `?image=<id>` and opens the matching block **without** pushing a new history entry (it's already the current URL). Add to that file, after `viewableBlocks` is defined and after the `useFullScreenImage()` destructure:

```tsx
  // Deep-link restore: if the page loads with ?image=<id> and we have that block,
  // open the viewer to it. Runs once on mount; showImage replaceState-syncs (no extra push).
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const id = new URLSearchParams(window.location.search).get('image');
    if (!id) return;
    const parsed = Number.parseInt(id, 10);
    if (Number.isNaN(parsed)) return;
    const block = viewableBlocks.find(b => b.id === parsed);
    if (block) showImage(block, viewableBlocks);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
```

> On a deep-link open, `pushedHistoryRef` stays `false` (the modal opened from the existing URL), so `hideImage` strips the param in place and `popstate` still closes correctly. The first `showImage` call from a *click* sets `pushedHistoryRef = true` and pushes — see Step 3.

- [ ] **Step 7 — Add the counter style + write the modal counter test.** In `app/styles/fullscreen-image.module.scss`, add (tokens only; positioned bottom-center, above the image, legible over photos):

```scss
.positionCounter {
  position: fixed;
  bottom: var(--space-4);
  left: 50%;
  transform: translateX(-50%);
  padding: var(--space-1) var(--space-3);
  border-radius: var(--radius-1);
  background-color: var(--color-overlay-strong);
  color: var(--color-white);
  font-size: var(--text-sm);
  font-variant-numeric: tabular-nums;
  z-index: var(--z-modal-content, 1001);
  pointer-events: none;
}
```

Write `tests/components/FullScreenModal/FullScreenModal.counter.test.tsx`:

```tsx
import '@testing-library/jest-dom';

import { render, screen } from '@testing-library/react';

import { FullScreenModal } from '@/app/components/FullScreenModal/FullScreenModal';
import type { ContentImageModel } from '@/app/types/Content';

const img = (id: number): ContentImageModel =>
  ({
    id,
    contentType: 'IMAGE',
    imageUrl: `https://cdn.example/${id}.jpg`,
    imageWidth: 1000,
    imageHeight: 800,
    orderIndex: id,
    visible: true,
  }) as ContentImageModel;

const noop = () => {};

describe('FullScreenModal — position counter', () => {
  it('shows "2 / 3" for the middle image', () => {
    render(
      <FullScreenModal
        fullScreenState={{ images: [img(1), img(2), img(3)], currentIndex: 1, scrollPosition: 0 }}
        loadedImageIds={new Set()}
        setLoadedImageIds={noop}
        modalRef={{ current: null }}
        hideImage={noop}
        isSwiping={{ current: false }}
        showMetadata={false}
        toggleMetadata={noop}
        router={{ push: jest.fn(), replace: jest.fn(), prefetch: jest.fn() } as never}
        navigateToNext={noop}
        navigateToPrevious={noop}
      />
    );
    expect(screen.getByText('2 / 3')).toBeInTheDocument();
  });
});
```

- [ ] **Step 8 — Verify FsDebug is fully gone, then full check + commit:**
```bash
grep -rn "FsDebug\|fsdebug" app/ ; echo "exit: $?"   # expect no matches (grep exit 1)
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/hooks/useFullScreenImage.tsx app/components/FullScreenModal/FullScreenModal.tsx app/components/Content/ContentBlockWithFullScreen.tsx app/styles/fullscreen-image.module.scss tests/hooks/useFullScreenImage.deeplink.test.tsx tests/components/FullScreenModal/FullScreenModal.counter.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/hooks/useFullScreenImage.tsx app/components/FullScreenModal/FullScreenModal.tsx app/components/Content/ContentBlockWithFullScreen.tsx tests/hooks/useFullScreenImage.deeplink.test.tsx tests/components/FullScreenModal/FullScreenModal.counter.test.tsx
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/styles/fullscreen-image.module.scss'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest tests/hooks/useFullScreenImage.deeplink.test.tsx tests/components/FullScreenModal/FullScreenModal.counter.test.tsx
git add app/hooks/useFullScreenImage.tsx app/components/FullScreenModal app/components/Content/ContentBlockWithFullScreen.tsx app/styles/fullscreen-image.module.scss tests/hooks/useFullScreenImage.deeplink.test.tsx tests/components/FullScreenModal/FullScreenModal.counter.test.tsx
git commit -m "feat(fullscreen): deep-linkable viewer (?image=<id>) + Back closes + position counter

Open syncs ?image=<id> via pushState so a shared link reopens to the image and
the browser Back button closes the modal instead of exiting the collection.
Next/prev replaceState-sync the param; popstate closes in place. Adds a tabular
'N / total' counter. Removes the last ?fsdebug=1 reader.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 3 — Wire filter URL state into the gallery clients

**Why:** `contentFilter.ts` exports `parseFilterFromParams` (line 493) and `serializeFilterToParams` (line 567) — fully tested, **imported by zero pages**. Filter state is local `useState` in `CollectionPageClient` and `LocationPageClient`, so filtered views aren't shareable and the Back button doesn't restore them. *(review §5 "filter state never URL-driven … despite tested serialize/parse existing, wired to nothing"; §7 "Wire the existing filter-URL helpers".)*

We add a small shared hook `useFilterUrlState` that: (a) on mount, seeds local filter state from the URL via `parseFilterFromParams`, and (b) on every filter change, writes the serialized params back with `router.replace` (no history spam; Back still works because each distinct filtered URL is a `replace`, and the *navigation into the page* is the Back target). The two clients keep their own state shapes — the hook converts at the edges.

**Files:**
- Create: `app/hooks/useFilterUrlState.ts`
- Modify: `app/components/ContentCollection/CollectionPageClient.tsx`
- Modify: `app/components/LocationPage/LocationPageClient.tsx`
- Test: `tests/hooks/useFilterUrlState.test.tsx`

- [ ] **Step 1 — Write the failing hook test** `tests/hooks/useFilterUrlState.test.tsx`. Mock `next/navigation` per the project pattern (with a captured `replace` mock) and `useSearchParams` returning a seeded `URLSearchParams`:

```tsx
import { act, renderHook } from '@testing-library/react';

import { useFilterUrlState } from '@/app/hooks/useFilterUrlState';
import type { ContentFilterCriteria } from '@/app/utils/contentFilter';

const replaceMock = jest.fn();
let searchParams = new URLSearchParams();

jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: jest.fn(), replace: replaceMock, prefetch: jest.fn() }),
  usePathname: () => '/some-collection',
  useSearchParams: () => searchParams,
}));

describe('useFilterUrlState', () => {
  beforeEach(() => {
    replaceMock.mockClear();
    searchParams = new URLSearchParams();
  });

  it('parses initial criteria from the URL', () => {
    searchParams = new URLSearchParams('rating=4&tag=mountains');
    const { result } = renderHook(() => useFilterUrlState());
    expect(result.current.initialCriteria.minRating).toBe(4);
    expect(result.current.initialCriteria.tags).toEqual(['mountains']);
  });

  it('writes serialized criteria back via router.replace', () => {
    const { result } = renderHook(() => useFilterUrlState());
    const criteria: ContentFilterCriteria = { minRating: 5, tags: ['ocean'] };
    act(() => {
      result.current.syncToUrl(criteria);
    });
    expect(replaceMock).toHaveBeenCalledTimes(1);
    const arg = replaceMock.mock.calls[0][0] as string;
    expect(arg).toContain('/some-collection');
    expect(arg).toContain('rating=5');
    expect(arg).toContain('tag=ocean');
  });

  it('replaces with the bare pathname when criteria are empty', () => {
    const { result } = renderHook(() => useFilterUrlState());
    act(() => {
      result.current.syncToUrl({});
    });
    expect(replaceMock).toHaveBeenCalledWith('/some-collection', { scroll: false });
  });
});
```

- [ ] **Step 2 — Run it; verify it fails:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/hooks/useFilterUrlState.test.tsx
```
Expected: FAIL — `Cannot find module '@/app/hooks/useFilterUrlState'`.

- [ ] **Step 3 — Implement `app/hooks/useFilterUrlState.ts`:**

```ts
'use client';

import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { useCallback, useMemo } from 'react';

import {
  type ContentFilterCriteria,
  parseFilterFromParams,
  serializeFilterToParams,
} from '@/app/utils/contentFilter';

/**
 * Bridges the tested filter-URL helpers (parseFilterFromParams /
 * serializeFilterToParams) to a gallery client's local filter state so filtered
 * views are shareable and Back-correct.
 *
 * - `initialCriteria` seeds local state from the URL on first render.
 * - `syncToUrl(criteria)` writes serialized params back via router.replace
 *   (no history entry per keystroke; the page-entry remains the Back target).
 */
export function useFilterUrlState(): {
  initialCriteria: ContentFilterCriteria;
  syncToUrl: (criteria: ContentFilterCriteria) => void;
} {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const initialCriteria = useMemo(
    () => parseFilterFromParams(new URLSearchParams(searchParams.toString())),
    // Parse once from the first-render params; subsequent URL writes are ours.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const syncToUrl = useCallback(
    (criteria: ContentFilterCriteria) => {
      const params = serializeFilterToParams(criteria);
      const qs = params.toString();
      router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false });
    },
    [router, pathname]
  );

  return { initialCriteria, syncToUrl };
}
```

- [ ] **Step 4 — Run the hook test; verify it passes:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/hooks/useFilterUrlState.test.tsx
```
Expected: PASS (3 tests).

- [ ] **Step 5 — Wire `LocationPageClient` (simplest mapping first).** `LocationPageClient` holds `GalleryFilterState`. Add the hook, seed initial state from `initialCriteria`, and sync on change. At the top of the component body, replace the bare `useState` seed and the `handleFilterChange` callback:

```tsx
  const { initialCriteria, syncToUrl } = useFilterUrlState();

  const [filterState, setFilterState] = useState<GalleryFilterState>(() => ({
    ...INITIAL_GALLERY_FILTER_STATE,
    highlyRatedOnly: initialCriteria.minRating !== undefined && initialCriteria.minRating >= 4,
    filmFilter:
      initialCriteria.isFilm === true ? 'film' : initialCriteria.isFilm === false ? 'digital' : 'off',
    selectedTags: initialCriteria.tags ?? [],
    selectedPeople: initialCriteria.people ?? [],
  }));
```

Then make `handleFilterChange` write the URL after computing the next state (build criteria from the *next* state using the same mapping the component already uses for `criteria`):

```tsx
  const handleFilterChange = useCallback(
    (update: Partial<GalleryFilterState>) => {
      setFilterState(prev => {
        const next = { ...prev, ...update };
        syncToUrl({
          ...(next.highlyRatedOnly ? { minRating: 4 } : {}),
          ...(next.filmFilter === 'film' ? { isFilm: true } : {}),
          ...(next.filmFilter === 'digital' ? { isFilm: false } : {}),
          ...(next.selectedCollectionIds.length > 0
            ? { collectionIds: [...next.selectedCollectionIds] }
            : {}),
          ...(next.selectedTags.length > 0 ? { tags: [...next.selectedTags] } : {}),
          ...(next.selectedPeople.length > 0 ? { people: [...next.selectedPeople] } : {}),
        });
        return next;
      });
    },
    [syncToUrl]
  );
```

Add the import at the top of the file:

```tsx
import { useFilterUrlState } from '@/app/hooks/useFilterUrlState';
```

> The `dateSortDirection` field has no URL key in `serializeFilterToParams` (it's a sort, not a filter), so it intentionally stays local — that is correct and matches the helper's contract.

- [ ] **Step 6 — Wire `CollectionPageClient`.** It holds `CollectionFilterState`. Add the hook, seed initial state, and sync on change. Replace the `useState` seed:

```tsx
  const { initialCriteria, syncToUrl } = useFilterUrlState();

  const [filterState, setFilterState] = useState<CollectionFilterState>(() => ({
    ...INITIAL_COLLECTION_FILTER_STATE,
    highlyRatedOnly: initialCriteria.minRating !== undefined && initialCriteria.minRating >= 4,
    selectedTags: initialCriteria.tags ?? [],
    selectedPeople: initialCriteria.people ?? [],
    selectedCameras: initialCriteria.cameras ?? [],
    selectedLocations: initialCriteria.locations ?? [],
  }));
```

Replace `handleFilterChange` to sync (mirror the existing `criteria` mapping; lens-type is local-only — it has no URL key, same rationale as `dateSortDirection`):

```tsx
  const handleFilterChange = useCallback(
    (update: Partial<CollectionFilterState>) => {
      setFilterState(prev => {
        const next = { ...prev, ...update };
        syncToUrl({
          ...(next.highlyRatedOnly ? { minRating: 4 } : {}),
          ...(next.selectedTags.length > 0
            ? { tags: [...next.selectedTags], tagMatchMode: 'AND' }
            : {}),
          ...(next.selectedPeople.length > 0
            ? { people: [...next.selectedPeople], peopleMatchMode: 'AND' }
            : {}),
          ...(next.selectedCameras.length > 0
            ? { cameras: [...next.selectedCameras], cameraMatchMode: 'AND' }
            : {}),
          ...(next.selectedLocations.length > 0 ? { locations: [...next.selectedLocations] } : {}),
        });
        return next;
      });
    },
    [syncToUrl]
  );
```

Add the import:

```tsx
import { useFilterUrlState } from '@/app/hooks/useFilterUrlState';
```

> `selectedLenses` and `selectedLensTypes` stay local: `serializeFilterToParams` has no `lens` key (only `camera`), and lens-type is a derived client filter. This is a deliberate scope boundary, not an omission — flagged in the self-review table. When master-plan Task 1.3 unifies the filter state and (if desired) extends the serializer with a `lens` key, extend the mapping here.

- [ ] **Step 7 — Verify the helpers are now imported, then full check + commit:**
```bash
grep -rln "useFilterUrlState\|parseFilterFromParams\|serializeFilterToParams" app/components/ContentCollection/CollectionPageClient.tsx app/components/LocationPage/LocationPageClient.tsx app/hooks/useFilterUrlState.ts
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/hooks/useFilterUrlState.ts app/components/ContentCollection/CollectionPageClient.tsx app/components/LocationPage/LocationPageClient.tsx tests/hooks/useFilterUrlState.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/hooks/useFilterUrlState.ts app/components/ContentCollection/CollectionPageClient.tsx app/components/LocationPage/LocationPageClient.tsx tests/hooks/useFilterUrlState.test.tsx
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest tests/hooks/useFilterUrlState.test.tsx
git add app/hooks/useFilterUrlState.ts app/components/ContentCollection/CollectionPageClient.tsx app/components/LocationPage/LocationPageClient.tsx tests/hooks/useFilterUrlState.test.tsx
git commit -m "feat(filter): sync gallery filter state to URL via tested parse/serialize helpers

Wires parseFilterFromParams/serializeFilterToParams (previously imported by no
page) into CollectionPageClient + LocationPageClient through a shared
useFilterUrlState hook. Filtered views are now shareable and Back-correct;
filters seed from the URL on load and write back via router.replace.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 4 — Skeleton / blur-up (kill the blank-on-load void)

**Why:** The grid is computed client-only (`Component.tsx` returns `rows: []` until `useViewport().contentWidth` is measured), so the leaf gallery shows the header then a **blank void** until layout settles and lazy-gated images stream in. *(review §1, §2 "blank black void until lazy-gated images stream in", §5 "Blank-on-load", §8 "Skeleton loading state".)*

Two complementary moves, both inside the existing priority plumbing (`Component` passes `priority={rowIndex === priorityIndex}` → `BoxRenderer` → `CollectionContentRenderer`'s `priority` prop): (a) render a sized skeleton block while `rows` is empty so the first screenful reserves space instead of collapsing, and (b) add `next/image` `placeholder="blur"` to the priority (first-row) image so it fades in from a blur instead of popping. We only add `blurDataURL` when present on the model; otherwise we skip `placeholder` (Next requires a `blurDataURL` for static `placeholder="blur"` on remote images).

**Files:**
- Modify: `app/components/Content/Component.tsx` (skeleton while measuring)
- Modify: `app/components/Content/CollectionContentRenderer.tsx` (blur-up on priority image)
- Test: extend `tests/components/Content/CollectionContentRenderer.test.tsx`

- [ ] **Step 1 — Write the failing test** (append to `tests/components/Content/CollectionContentRenderer.test.tsx`). Assert a priority image with a `blurDataURL` gets `placeholder="blur"`. The existing file already mocks `next/navigation`, `useParallax`, and `CollectionFilterContext`. `next/image` renders an `<img>` and forwards `placeholder`/`blurDataURL` as attributes under `next/jest`. Add:

```tsx
describe('CollectionContentRenderer — blur-up placeholder', () => {
  const imageProps = {
    contentId: 7,
    className: 'imageSingle',
    width: 300,
    height: 200,
    isMobile: false,
    imageUrl: 'https://cdn.example/7.jpg',
    imageWidth: 300,
    imageHeight: 200,
    alt: 'hero',
    enableParallax: false,
    contentType: 'IMAGE' as const,
  };

  it('applies placeholder="blur" when priority and a blurDataURL is provided', () => {
    render(
      <CollectionContentRenderer
        {...imageProps}
        priority
        blurDataURL="data:image/jpeg;base64,abc"
      />
    );
    const img = screen.getByAltText('hero');
    expect(img).toHaveAttribute('placeholder', 'blur');
  });

  it('omits placeholder when no blurDataURL is provided', () => {
    render(<CollectionContentRenderer {...imageProps} priority />);
    const img = screen.getByAltText('hero');
    expect(img).not.toHaveAttribute('placeholder', 'blur');
  });
});
```

> This requires `blurDataURL` to exist as an optional prop on `CollectionContentRendererProps`. If `ContentImageModel`/the renderer props don't yet carry it, add `blurDataURL?: string` to `app/types/ContentRenderer.ts`'s `CollectionContentRendererProps` (Step 3). Do NOT use `any`.

- [ ] **Step 2 — Run it; verify it fails:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/Content/CollectionContentRenderer.test.tsx -t "blur-up"
```
Expected: FAIL — `placeholder` not set (renderer doesn't pass it yet) / type error on `blurDataURL`.

- [ ] **Step 3 — Add `blurDataURL` plumbing + blur-up to `CollectionContentRenderer.tsx`.** Add `blurDataURL?: string;` to `CollectionContentRendererProps` in `app/types/ContentRenderer.ts`. Destructure it in the component signature (alongside `priority`):

```tsx
  priority = false,
  blurDataURL,
```

Then extend the `imageProps` object (the still-image branch) to set blur only when both `priority` and a `blurDataURL` are present:

```tsx
  const imageProps = {
    src: imageUrl,
    alt,
    width: imageWidth,
    height: imageHeight,
    sizes: `(max-width: 768px) 100vw, ${Math.round(width)}px`,
    loading: priority ? ('eager' as const) : ('lazy' as const),
    priority: priority ?? false,
    fetchPriority: priority ? ('high' as const) : undefined,
    unoptimized: isGif,
    onError: handleImageError,
    ...(priority && blurDataURL
      ? { placeholder: 'blur' as const, blurDataURL }
      : {}),
    ...(enableParallax
      ? {
          className: `parallax-bg ${variantStyles.parallaxImage}`,
        }
      : {
          className: cbStyles.nonParallaxImage,
          style: {
            cursor: hasClickHandler ? ('pointer' as const) : ('default' as const),
          },
        }),
  };
```

> `blurDataURL` flows from the content model when the backend supplies one. `BoxRenderer`/`Component` already thread `priority`; if the model carries a `blurDataURL`, plumb it the same way (`BoxRenderer` passes `content.blurDataURL` into `CollectionContentRenderer`). If the model has no such field today, this is a forward-compatible no-op (the omit-branch keeps current behavior) — verified by the second test.

- [ ] **Step 4 — Add a measuring skeleton to `Component.tsx`.** Currently `if (rows.length === 0) return <div />;` collapses to nothing while `contentWidth` is being measured. Replace that early return with a sized skeleton that reserves a first-screenful of vertical space (using the measured `viewportHeight` when available) so the page doesn't jump:

```tsx
  if (rows.length === 0) {
    // While the layout is being measured (contentWidth not yet known) reserve a
    // screenful so the gallery doesn't collapse to a blank void on first paint.
    const skeletonHeight = viewportHeight > 0 ? viewportHeight : 600;
    return (
      <div className={cbStyles.wrapper}>
        <div
          className={cbStyles.layoutSkeleton}
          style={{ height: skeletonHeight }}
          aria-hidden="true"
          data-testid="layout-skeleton"
        />
      </div>
    );
  }
```

Add the skeleton style to `app/components/Content/ContentComponent.module.scss` (token-driven shimmer; respects reduced motion):

```scss
.layoutSkeleton {
  width: 100%;
  background: linear-gradient(
    90deg,
    var(--color-bg-light) 25%,
    var(--color-bg-medium) 37%,
    var(--color-bg-light) 63%
  );
  background-size: 400% 100%;
  animation: layoutSkeletonShimmer 1.4s ease infinite;

  @media (prefers-reduced-motion: reduce) {
    animation: none;
  }
}

@keyframes layoutSkeletonShimmer {
  0% {
    background-position: 100% 50%;
  }

  100% {
    background-position: 0 50%;
  }
}
```

- [ ] **Step 5 — Run the renderer tests; verify they pass:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/Content/CollectionContentRenderer.test.tsx
```
Expected: PASS (existing TEXT-branch tests + 2 new blur-up tests).

- [ ] **Step 6 — Lint + type-check + commit:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/components/Content/Component.tsx app/components/Content/CollectionContentRenderer.tsx app/types/ContentRenderer.ts app/components/Content/ContentComponent.module.scss tests/components/Content/CollectionContentRenderer.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/components/Content/Component.tsx app/components/Content/CollectionContentRenderer.tsx app/types/ContentRenderer.ts tests/components/Content/CollectionContentRenderer.test.tsx
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/Content/ContentComponent.module.scss'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/Content/CollectionContentRenderer.test.tsx
git add app/components/Content/Component.tsx app/components/Content/CollectionContentRenderer.tsx app/types/ContentRenderer.ts app/components/Content/ContentComponent.module.scss tests/components/Content/CollectionContentRenderer.test.tsx
git commit -m "feat(gallery): measuring skeleton + blur-up on first-row priority image

Reserves a screenful with a reduced-motion-aware skeleton while the BoxTree
layout is measured client-side (was a blank void), and fades the priority
(first-row) image in via next/image placeholder=blur when a blurDataURL exists.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 5 — Persistent footer + breadcrumb

**Why:** The hamburger is the *only* nav; there's no footer and no "up to parent" affordance, so deep-linked visitors are stranded and nothing is crawlable beyond the header. *(review §2, §5, §7 "A minimal footer (About/Contact/IG/GitHub) + a breadcrumb / 'up to parent' affordance", §8.)*

The footer renders site-wide via the root layout and uses real `NavLink`/`<a>` (crawlable). The breadcrumb is a small Server Component that takes an ordered list of `{ label, href? }` and renders real links; deep pages (taxonomy, location) pass a trail back to `/explore` or the parent. "Browse all work" links the existing public `/all-collections`.

**Files:**
- Create: `app/components/Footer/Footer.tsx` + `Footer.module.scss`
- Create: `app/components/Breadcrumb/Breadcrumb.tsx` + `Breadcrumb.module.scss` (skip if Nav+Shell sub-plan shipped it)
- Modify: `app/layout.tsx` (render `<Footer/>`)
- Modify: `app/components/TaxonomyPage/TaxonomyPage.tsx` + `app/components/LocationPage/LocationPage.tsx` (breadcrumb)
- Test: `tests/components/Footer/Footer.test.tsx`, `tests/components/Breadcrumb/Breadcrumb.test.tsx`

- [ ] **Step 1 — Write the failing footer test** `tests/components/Footer/Footer.test.tsx`:

```tsx
import '@testing-library/jest-dom';

import { render, screen } from '@testing-library/react';

import { Footer } from '@/app/components/Footer/Footer';

describe('Footer', () => {
  it('renders crawlable links to all-collections, explore, and external socials', () => {
    render(<Footer />);
    expect(screen.getByRole('link', { name: /Browse all work/i })).toHaveAttribute(
      'href',
      '/all-collections'
    );
    expect(screen.getByRole('link', { name: /Explore/i })).toHaveAttribute('href', '/explore');
    expect(screen.getByRole('link', { name: /Instagram/i })).toHaveAttribute(
      'href',
      'https://instagram.com/themancalledzac'
    );
    expect(screen.getByRole('link', { name: /GitHub/i })).toHaveAttribute(
      'href',
      'https://github.com/themancalledzac'
    );
  });
});
```

- [ ] **Step 2 — Write the failing breadcrumb test** `tests/components/Breadcrumb/Breadcrumb.test.tsx`:

```tsx
import '@testing-library/jest-dom';

import { render, screen } from '@testing-library/react';

import { Breadcrumb } from '@/app/components/Breadcrumb/Breadcrumb';

describe('Breadcrumb', () => {
  it('renders links for items with href and plain text for the current item', () => {
    render(
      <Breadcrumb
        items={[
          { label: 'Explore', href: '/explore' },
          { label: 'People', href: '/explore#people' },
          { label: 'Jane Doe' },
        ]}
      />
    );
    expect(screen.getByRole('link', { name: 'Explore' })).toHaveAttribute('href', '/explore');
    expect(screen.getByRole('link', { name: 'People' })).toHaveAttribute('href', '/explore#people');
    // current item is not a link
    expect(screen.queryByRole('link', { name: 'Jane Doe' })).not.toBeInTheDocument();
    expect(screen.getByText('Jane Doe')).toBeInTheDocument();
  });
});
```

- [ ] **Step 3 — Run both; verify they fail:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/Footer tests/components/Breadcrumb
```
Expected: FAIL — modules not found.

- [ ] **Step 4 — Implement `app/components/Breadcrumb/Breadcrumb.tsx`** (Server Component; uses `NavLink`):

```tsx
import { Fragment } from 'react';

import { NavLink } from '@/app/components/ui/NavLink/NavLink';

import styles from './Breadcrumb.module.scss';

export interface BreadcrumbItem {
  label: string;
  /** Omit on the current (last) item — it renders as plain text. */
  href?: string;
}

export interface BreadcrumbProps {
  items: BreadcrumbItem[];
}

/**
 * Ordered "up to parent" trail of real links. The final item is the current
 * page and renders as text (no link), per WAI-ARIA breadcrumb practice.
 */
export function Breadcrumb({ items }: BreadcrumbProps) {
  if (items.length === 0) return null;

  return (
    <nav aria-label="Breadcrumb" className={styles.breadcrumb}>
      <ol className={styles.list}>
        {items.map((item, index) => {
          const isLast = index === items.length - 1;
          return (
            <Fragment key={`${item.label}-${index}`}>
              <li className={styles.item}>
                {item.href && !isLast ? (
                  <NavLink href={item.href} className={styles.link}>
                    {item.label}
                  </NavLink>
                ) : (
                  <span aria-current={isLast ? 'page' : undefined}>{item.label}</span>
                )}
              </li>
              {!isLast && (
                <li className={styles.separator} aria-hidden="true">
                  /
                </li>
              )}
            </Fragment>
          );
        })}
      </ol>
    </nav>
  );
}
```

`app/components/Breadcrumb/Breadcrumb.module.scss`:

```scss
.breadcrumb {
  padding: var(--space-2) var(--page-padding-mobile);

  @media (width >= 768px) {
    padding-left: 0;
    padding-right: 0;
  }
}

.list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--space-2);
  font-size: var(--text-sm);
  color: var(--color-fg-muted);
}

.item {
  display: inline-flex;
}

.link {
  color: var(--color-fg-muted);

  &:hover {
    color: var(--color-fg);
  }
}

.separator {
  color: var(--color-fg-muted);
}
```

> If the Nav+Shell sub-plan already shipped `Breadcrumb`, skip Step 4 and import its component instead; keep the test as a regression guard.

- [ ] **Step 5 — Implement `app/components/Footer/Footer.tsx`** (Server Component; internal links via `NavLink`, external via plain `<a>` with `rel`):

```tsx
import { NavLink } from '@/app/components/ui/NavLink/NavLink';

import styles from './Footer.module.scss';

/**
 * Persistent site footer. Gives every page (including deep-linked taxonomy and
 * fullscreen-shared URLs) a crawlable way back into the site without the
 * hamburger. Internal routes use NavLink (real next/link); socials are external.
 */
export function Footer() {
  return (
    <footer className={styles.footer}>
      <nav className={styles.nav} aria-label="Footer">
        <NavLink href="/all-collections" className={styles.link}>
          Browse all work
        </NavLink>
        <NavLink href="/explore" className={styles.link}>
          Explore
        </NavLink>
        <a
          href="https://instagram.com/themancalledzac"
          className={styles.link}
          target="_blank"
          rel="noopener noreferrer"
        >
          Instagram
        </a>
        <a
          href="https://github.com/themancalledzac"
          className={styles.link}
          target="_blank"
          rel="noopener noreferrer"
        >
          GitHub
        </a>
      </nav>
      <p className={styles.copyright}>© {new Date().getFullYear()} Zac Edens</p>
    </footer>
  );
}

export default Footer;
```

> About/Contact live in the `MenuDropdown` panels (not standalone routes), so the footer surfaces the two public *routes* (Browse all work, Explore) + socials. If/when About/Contact become real routes, add them here. This is a deliberate scope note, not an omission.

`app/components/Footer/Footer.module.scss`:

```scss
.footer {
  margin-top: var(--space-7);
  padding: var(--space-6) var(--page-padding-mobile);
  border-top: 1px solid var(--color-border);
  background-color: var(--color-bg);
  color: var(--color-fg-muted);

  @media (width >= 768px) {
    padding: var(--space-6) var(--default-padding);
  }
}

.nav {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-4);
  margin-bottom: var(--space-3);
}

.link {
  color: var(--color-fg-muted);
  font-size: var(--text-sm);

  &:hover {
    color: var(--color-fg);
  }
}

.copyright {
  margin: 0;
  font-size: var(--text-xs);
}
```

- [ ] **Step 6 — Render the footer site-wide** in `app/layout.tsx`. Import and place it after `{children}` inside `<body>`:

```tsx
import { Footer } from '@/app/components/Footer/Footer';
```

```tsx
      <body className={inter.className}>
        {children}
        <Footer />
      </body>
```

- [ ] **Step 7 — Add breadcrumbs to deep pages.** In `app/components/TaxonomyPage/TaxonomyPage.tsx`, render a `<Breadcrumb>` above the `pageHeader` (the entity name stays the current/last crumb, satisfying Task 6's name requirement too). Add the import and place it inside `<main>` before `<div className={styles.pageHeader}>`:

```tsx
import { Breadcrumb } from '@/app/components/Breadcrumb/Breadcrumb';
```

```tsx
        <Breadcrumb items={[{ label: 'Explore', href: '/explore' }, { label: entityName }]} />
```

Do the same in `app/components/LocationPage/LocationPage.tsx` (above `locationHeader`):

```tsx
import { Breadcrumb } from '@/app/components/Breadcrumb/Breadcrumb';
```

```tsx
        <Breadcrumb items={[{ label: 'Explore', href: '/explore' }, { label: locationName }]} />
```

- [ ] **Step 8 — Run the tests; verify they pass:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/Footer tests/components/Breadcrumb
```
Expected: PASS (1 footer test, 1 breadcrumb test).

- [ ] **Step 9 — Lint + type-check + commit:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/components/Footer/Footer.tsx app/components/Footer/Footer.module.scss app/components/Breadcrumb/Breadcrumb.tsx app/components/Breadcrumb/Breadcrumb.module.scss app/layout.tsx app/components/TaxonomyPage/TaxonomyPage.tsx app/components/LocationPage/LocationPage.tsx tests/components/Footer/Footer.test.tsx tests/components/Breadcrumb/Breadcrumb.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/components/Footer/Footer.tsx app/components/Breadcrumb/Breadcrumb.tsx app/layout.tsx app/components/TaxonomyPage/TaxonomyPage.tsx app/components/LocationPage/LocationPage.tsx tests/components/Footer/Footer.test.tsx tests/components/Breadcrumb/Breadcrumb.test.tsx
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/Footer/Footer.module.scss' 'app/components/Breadcrumb/Breadcrumb.module.scss'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/Footer tests/components/Breadcrumb
git add app/components/Footer app/components/Breadcrumb app/layout.tsx app/components/TaxonomyPage/TaxonomyPage.tsx app/components/LocationPage/LocationPage.tsx tests/components/Footer tests/components/Breadcrumb
git commit -m "feat(nav): persistent footer + breadcrumb on deep pages

Site-wide footer (Browse all work / Explore / Instagram / GitHub) via the root
layout gives every page a crawlable way home. Adds an 'Explore > <entity>'
breadcrumb to taxonomy and location pages so deep-linked visitors aren't
stranded.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 6 — Taxonomy titles (entity NAME on every taxonomy/person page)

**Why:** The review flagged that a person page "shows only N photos" with no name → no orientation. *(review §2, §8 "a person page shows only '2 photos', never the name".)* **Current state (verified):** `TaxonomyPage.tsx` already renders `<h1 className={styles.pageName}>{entityName}</h1>` and `LocationPage.tsx` already renders `<h1 className={styles.locationName}>{locationName}</h1>`, and the `[slug]` routes pass the resolved `matchedTag.name` / `matchedPerson.name` / `location.name`. So the *name* is present today. This task **locks that in with a regression test** and **hardens the fallback** so a name is shown even when the entity didn't resolve cleanly — closing the original gap permanently rather than re-fixing a non-bug.

**Files:**
- Test: `tests/components/TaxonomyPage/TaxonomyPage.test.tsx`
- Modify (only if test surfaces a gap): `app/components/TaxonomyPage/TaxonomyPage.tsx`

- [ ] **Step 1 — Write the regression test** `tests/components/TaxonomyPage/TaxonomyPage.test.tsx`. Mock `SiteHeader`, `ContentBlockWithFullScreen`, and `Breadcrumb` (kept light so the test targets the heading), and assert the name renders as an `h1`:

```tsx
import '@testing-library/jest-dom';

import { render, screen } from '@testing-library/react';

import TaxonomyPage from '@/app/components/TaxonomyPage/TaxonomyPage';
import type { ContentImageModel } from '@/app/types/Content';

jest.mock('@/app/components/SiteHeader/SiteHeader', () => ({
  __esModule: true,
  default: () => <div data-testid="site-header" />,
}));
jest.mock('@/app/components/Content/ContentBlockWithFullScreen', () => ({
  __esModule: true,
  default: () => <div data-testid="content" />,
}));
jest.mock('@/app/components/Breadcrumb/Breadcrumb', () => ({
  Breadcrumb: () => <nav data-testid="breadcrumb" />,
}));

const img = (id: number): ContentImageModel =>
  ({ id, contentType: 'IMAGE', imageUrl: `${id}.jpg`, orderIndex: id, visible: true }) as ContentImageModel;

describe('TaxonomyPage', () => {
  it('renders the entity name as the page h1', () => {
    render(<TaxonomyPage entityName="Jane Doe" images={[img(1), img(2)]} />);
    expect(screen.getByRole('heading', { level: 1, name: 'Jane Doe' })).toBeInTheDocument();
  });

  it('still shows the photo count alongside the name', () => {
    render(<TaxonomyPage entityName="Mountains" images={[img(1)]} />);
    expect(screen.getByRole('heading', { level: 1, name: 'Mountains' })).toBeInTheDocument();
    expect(screen.getByText('1 photo')).toBeInTheDocument();
  });

  it('renders a fallback heading when entityName is empty (hardening)', () => {
    render(<TaxonomyPage entityName="" images={[img(1)]} />);
    expect(screen.getByRole('heading', { level: 1 })).toHaveTextContent(/Photos|Untitled|\S/);
  });
});
```

- [ ] **Step 2 — Run it:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/TaxonomyPage/TaxonomyPage.test.tsx
```
Expected: the first two PASS immediately (name + count already render). The third may FAIL if an empty `entityName` renders an empty `h1`.

- [ ] **Step 3 — Harden the empty-name fallback (only if Step 2's third test fails).** In `app/components/TaxonomyPage/TaxonomyPage.tsx`, guard the heading so an empty/whitespace name falls back to a sensible label:

```tsx
export default function TaxonomyPage({ entityName, images }: TaxonomyPageProps) {
  const contentBlocks = processContentBlocks(images, true);
  const displayName = entityName.trim() || 'Photos';
```

and render `{displayName}` in the `<h1>`. (The `[slug]` routes already provide a decoded-slug fallback when the entity doesn't resolve — `person?.name ?? decodeURIComponent(slug)…` — so an empty name is an edge case, but the guard makes the heading-always-present invariant explicit.)

- [ ] **Step 4 — Lint + type-check + commit:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/components/TaxonomyPage/TaxonomyPage.tsx tests/components/TaxonomyPage/TaxonomyPage.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/components/TaxonomyPage/TaxonomyPage.tsx tests/components/TaxonomyPage/TaxonomyPage.test.tsx
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/TaxonomyPage/TaxonomyPage.test.tsx
git add app/components/TaxonomyPage/TaxonomyPage.tsx tests/components/TaxonomyPage/TaxonomyPage.test.tsx
git commit -m "test(taxonomy): lock entity-name h1 + harden empty-name fallback

Regression-tests that taxonomy/person pages render the entity NAME as the page
h1 alongside the photo count (the review's 'shows only N photos' gap), and
guards an empty entityName to a sensible fallback heading.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Verification (run after each task; full pass before any PR)

```bash
cd /Users/themancalledzac/Code/edens.zac
# Format → lint → type-check → test (project pipeline, per CLAUDE.md; npm/npx not on PATH)
/opt/homebrew/bin/node node_modules/.bin/prettier --write <touched files>
/opt/homebrew/bin/node node_modules/.bin/eslint --fix <touched .ts/.tsx>
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix '<touched .scss>'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest
```

**Visual (dev server :3001 — user keeps :3000):**
- **Task 1:** visit `/explore` → tags/people/locations are real links (middle-click / open-in-new-tab work); the menu shows "Browse all work" + "Explore".
- **Task 2:** open an image → URL becomes `?image=<id>`; reload → reopens to that image; press browser **Back** → modal closes and you stay in the collection; counter reads e.g. `3 / 12` and updates on arrow/swipe.
- **Task 3:** apply a filter → URL gains `?rating=…&tag=…`; copy the URL into a new tab → the filter is pre-applied; **Back** returns to the unfiltered page.
- **Task 4:** hard-reload a leaf gallery on a throttled connection → a sized shimmer fills the first screenful (no blank void); the hero image fades in from blur (when a `blurDataURL` exists).
- **Task 5:** every page has a footer with crawlable links; taxonomy/location pages show an `Explore / <name>` breadcrumb.
- **Task 6:** a person/tag/location page shows the entity name as the heading + photo count.

---

## Suggested commit sequence

1. `feat(ia): public /explore taxonomy directory + Explore/Browse-all-work nav` (Task 1)
2. `feat(fullscreen): deep-linkable viewer (?image=<id>) + Back closes + position counter` (Task 2)
3. `feat(filter): sync gallery filter state to URL via tested parse/serialize helpers` (Task 3)
4. `feat(gallery): measuring skeleton + blur-up on first-row priority image` (Task 4)
5. `feat(nav): persistent footer + breadcrumb on deep pages` (Task 5)
6. `test(taxonomy): lock entity-name h1 + harden empty-name fallback` (Task 6)

Each commit passes `tsc --noEmit` + `jest` independently. Tasks 2, 3, 4, 6 have **no dependency** on the Nav+Shell sub-plan and can run first / in parallel; Tasks 1 and 5 depend on `NavLink`/`PageShell` (see *Prerequisites*). Tasks parallelize well across agents — Task 2 (hook+modal), Task 3 (filter hook+clients), and Task 4 (renderer) touch disjoint files.

---

## Self-review: spec-coverage checklist

Maps every Phase 3 bullet (from the master plan) and the source design-review findings to a task here. Gaps flagged explicitly.

| Phase 3 bullet (master plan) / review finding | Task | Status |
|-----------------------------------------------|------|--------|
| Public taxonomy directory; `/people` has zero entry points (review §2, §5, §8) | Task 1 | ✅ `/explore` + menu links |
| "Browse all work" missing though `/all-collections` exists (review §8) | Task 1 (menu) + Task 5 (footer) | ✅ |
| Deep-linkable fullscreen `?image=<id>` + pushState; Back closes modal (review §2, §5, §8) | Task 2 | ✅ |
| `3 / 12` position counter (review §7, §8) | Task 2 | ✅ |
| Wire tested `parse/serializeFilterToParams` (imported by 0 pages) into gallery clients (review §5, §7) | Task 3 | ✅ Collection + Location clients |
| Skeleton / blur-up; kill blank-on-load (review §1, §2, §5, §8) | Task 4 | ✅ measuring skeleton + blur-up |
| Persistent footer (About/Contact/IG/GitHub + Browse all work) (review §7, §8) | Task 5 | ✅ (About/Contact are menu panels, not routes — footer links the two public routes + socials; noted) |
| Breadcrumb / "up to parent" on deep pages (review §2, §8) | Task 5 | ✅ taxonomy + location |
| Taxonomy/person page shows the entity NAME (review §2, §8) | Task 6 | ✅ already renders; locked by test + hardened fallback |
| Remove last `?fsdebug=1` reader (master Phase 0 / review §5) | Task 2 Step 5 | ✅ (or no-op if Phase 0 already removed it) |
| `/metadata` → public Explore index *or* index routes `/tag` `/location` `/people` (review §7) | Task 1 | ⚠ Built `/explore` as the single directory; did NOT add separate `/tag` `/location` `/people` *index* routes (only the existing `[slug]` detail routes). Deliberate: one directory is simpler and the master plan's "and/or" allows it. Moving `/metadata` under `(admin)` with auth is **master Phase 2 (MetadataList + auth)**, not this plan. |

**Out of scope (deferred by design, not gaps):**
- `dateSortDirection`, `selectedLenses`, `selectedLensTypes` are **not** URL-synced — `serializeFilterToParams` has no keys for them (sort ≠ filter; no `lens` key). Documented in Task 3 Steps 5–6; extend when master Task 1.3 unifies the filter state + serializer.
- Client-gallery download progress / favorites / "forgot password" (review §8) — future feature, explicitly out of Phase 3.
- The filter *toolbar* redesign + `FilterState` unification is master **Task 1.3**, not here (Task 3 only wires URL state to the existing bars). Coordination note at top.
- About/Contact as standalone routes — they are `MenuDropdown` panels today; footer links the public routes that exist. Surfaced in Task 5.

**Type consistency:** `BreadcrumbItem`/`BreadcrumbProps` (Task 5), `ContentFilterCriteria` (reused from `contentFilter.ts` in Task 3), and `blurDataURL?: string` on `CollectionContentRendererProps` (Task 4) are each introduced once and referenced consistently. No `any`. All `next/navigation` mocks follow the project pattern: `useRouter: () => ({ push, replace, prefetch })`, `useSearchParams: () => new URLSearchParams()` (with `usePathname` added where the hook reads it).

**Placeholder scan:** every task has complete code, exact paths, exact commands, and Expected output. The only conditional code is Task 6 Step 3 (hardening, gated on the test result) — stated explicitly, not hidden. No TBDs, no "implement later", no "similar to above".

---

## Files referenced
- **New:** `app/explore/{page.tsx,Explore.module.scss}`, `app/components/Footer/{Footer.tsx,Footer.module.scss}`, `app/components/Breadcrumb/{Breadcrumb.tsx,Breadcrumb.module.scss}`, `app/hooks/useFilterUrlState.ts`, and the mirrored tests under `tests/`.
- **Modified:** `app/hooks/useFullScreenImage.tsx`, `app/components/FullScreenModal/FullScreenModal.tsx`, `app/components/Content/ContentBlockWithFullScreen.tsx`, `app/components/Content/Component.tsx`, `app/components/Content/CollectionContentRenderer.tsx`, `app/types/ContentRenderer.ts`, `app/components/ContentCollection/CollectionPageClient.tsx`, `app/components/LocationPage/LocationPageClient.tsx`, `app/components/MenuDropdown/MenuDropdown.tsx`, `app/layout.tsx`, `app/components/TaxonomyPage/TaxonomyPage.tsx`, `app/components/LocationPage/LocationPage.tsx`, `app/styles/fullscreen-image.module.scss`, `app/components/Content/ContentComponent.module.scss`.
- **Depends on (from sibling plans):** `app/components/ui/NavLink/NavLink.tsx`, `app/components/ui/Tile/Tile.tsx`, `app/components/ui/PageShell/PageShell.tsx` (Nav+Shell sub-plan); painted surface + token aliases (master Phase 0).

---

## Execution Handoff

**Plan complete and saved to [`001-ia-and-ux.md`](001-ia-and-ux.md) (chapter [001 · Design System Unification](../../001-design-review.md)).**

This is the bite-sized expansion of the master plan's *Phase 3 — Information architecture & UX*. Tasks 2, 3, 4, and 6 are self-contained and can start immediately (no Nav+Shell dependency); Tasks 1 and 5 need `NavLink`/`PageShell` from the Phase 2 Nav+Shell sub-plan first.

**Execution options:**
1. **Subagent-Driven (recommended)** — REQUIRED SUB-SKILL `superpowers:subagent-driven-development`: fresh subagent per task + two-stage review. Run Task 2 (fullscreen) first — highest user-visible payoff.
2. **Inline Execution** — REQUIRED SUB-SKILL `superpowers:executing-plans`: batch with checkpoints.
3. **Parallel** — Tasks 2 / 3 / 4 touch disjoint files; dispatch them concurrently, then Task 6, then Tasks 1 + 5 once Nav+Shell lands.
