# 006 · Thin-Component / Co-located Helper Extraction Sweep — Implementation Plan

_Chapter [006 · Code Health](../../006-code-health.md) · plan · sibling to [function decomposition](006-function-decomposition.md) (logic-extraction axis vs. its sub-component-split axis)._

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax.

**Goal:** Critically review every client component and extract inline *derivation/business logic* into co-located, unit-tested `*Utils.ts` helpers — so each component reads as `hooks → helper calls → JSX`, mirroring the `Component.tsx` refactor (302 → 200 lines).

**Architecture:** Two phases. **Phase 1 (Audit):** score every `'use client'` component against a candidate rubric and produce a per-component report with exact extraction targets. **Phase 2 (Refactor):** apply a fixed, behavior-preserving recipe per candidate — move pure logic to `<Component>Utils.ts`, unit-test each helper, keep existing component tests green. Both phases are file-parallel (independent components) and a strong fit for parallel agents / `/agent-teams`.

**Tech Stack:** Next.js App Router, React 19, TypeScript (strict, no `any`), Jest + Testing Library. Toolchain (CLAUDE.md): `/opt/homebrew/bin/node node_modules/.bin/{tsc,jest,eslint,prettier,stylelint}`.

---

## The reference refactor (pattern definition — read first)

The worked example this whole sweep generalizes is commit `7d8bdac` (`Component.tsx`). The pattern:

**Before** — derivations + business logic inline in the component body:

```tsx
const useMeasured = shouldUseMeasuredWidth(...);
const effectiveContentWidth = useMeasured ? measured.contentWidth : (serverContentWidth ?? ...);
const effectiveViewportHeight = ...;
const effectiveIsMobile = ...;
const { rows, layoutError } = useMemo(() => { /* 35 lines: targetAR + processContentForDisplay + try/catch */ }, [...]);
const firstNonVisibleRowIndex = useMemo(() => { /* 20 lines */ }, [...]);
```

**After** — pure helpers in co-located `componentUtils.ts`, component reads top-to-bottom:

```tsx
const measured = useViewport();
const viewport = useMemo(() => resolveEffectiveViewport(measured, {server...}, TOL), [...]);
const { rows, layoutError } = useMemo(() => buildContentRows(content, collectionData, viewport, chunkSize), [...]);
const firstNonVisibleRowIndex = useMemo(() => computeFirstNonVisibleRowIndex(rows, currentCollectionId), [...]);
// early returns + JSX
```

**Rules that define "done" for one component:**
1. Pure logic (no hooks, no JSX) → exported functions in `app/components/<Path>/<Component>Utils.ts` (co-located, like `manageUtils.ts` ↔ `ManageClient.tsx`). Do **not** bury component-specific helpers in broad shared utils (`contentLayout.ts`).
2. Each extracted helper is individually unit-tested in `tests/<mirrored-path>/<Component>Utils.test.ts`.
3. The component keeps: hook calls, `useMemo`/`useCallback` wrappers that *call* the helpers, early returns, and JSX. No multi-line derivation bodies remain inline.
4. **Behavior-preserving.** Existing component tests stay green unchanged; for visually-observable components, a browser smoke check confirms identical render.
5. Collapse redundant locals (e.g. `effectiveIsMobile` → `viewport.isMobile`).

**Not a candidate (leave alone):** presentational components that are already mostly JSX (props → markup) with no real derivation — e.g. `ReorderOverlay.tsx`, `ErrorBoundary.tsx`, `BoxRenderer.tsx`, the ui/ primitives. Extracting from these adds indirection with no testability gain.

**Relationship to existing plans (DRY — do not duplicate):**
- `006-function-decomposition.md` already lists complex *functions* to split (incl. `CollectionContentRenderer`, `normalizeContentToRendererProps`, `buildRows`). Where a component appears in both, coordinate: this plan extracts the component's *inline derivation logic*; 006 may additionally split it into *sub-components* (`TextContentBlock`/`GifContentBlock`). Do the logic extraction here; reference 006 for the sub-component split and don't redo it.
- `006-inline-jsx-config-cross-file.md` + the inline-style→SCSS rule are a *separate* code-quality axis. Flag static inline styles found during the audit (see Phase 1 Step 3) but fix them under that plan, not this one.

---

## Candidate rubric (used in Phase 1)

Score each `'use client'` component 0–2 on each axis; **total ≥ 4 → candidate**, 2–3 → optional, 0–1 → skip:

| Axis | 0 | 1 | 2 |
|---|---|---|---|
| **Inline derivation** (computed `const`s, multi-line `useMemo`/`useCallback` bodies, inline `transform`/`map` fns) | none | 1–2 small | 3+ or any >10-line body |
| **Pure logic testable in isolation** (currently only reachable via component render) | n/a | some | substantial untested pure logic |
| **Size / mixed concerns** | < 120 lines | 120–300 | > 300 lines or many branches |

A function/derivation is **extractable** when it depends only on its arguments (no hooks, no closures over component state it can't receive as args). `useMemo`/`useCallback` stays in the component as a thin wrapper; its *body* moves to a helper.

---

## Phase 1 — Audit (the critical review)

**Goal:** a committed report at `docs/superpowers/plans/006-thin-component-audit-report.md` listing every candidate, its score, and exact extraction targets. This is the input to Phase 2.

**Survey baseline (already gathered — `'use client'` components by lines | hooks | logic-consts):**

| Lines | Hooks | LogicConst | File |
|---|---|---|---|
| 1719 | 53 | 37 | `(admin)/collection/manage/[[...slug]]/ManageClient.tsx` |
| 641 | 4 | 10 | `components/Content/CollectionContentRenderer.tsx` |
| 485 | — | 21 | `components/ui/Dropdown/Dropdown.tsx` |
| 370 | 25 | 25 | `components/ContentCollection/CollectionPageClient.tsx` |
| 342 | 2 | 4 | `components/ImageMetadata/sections/CameraSettingsSection.tsx` |
| 340 | 2 | 5 | `components/FullScreenModal/FullScreenModal.tsx` |
| 290 | 8 | 4 | `components/MenuDropdown/MenuDropdown.tsx` |
| 241 | 10 | 6 | `components/Content/ContentBlockWithFullScreen.tsx` |
| 237 | 4 | 2 | `components/CollectionListSelector/CollectionListSelector.tsx` |
| 219 | 4 | 6 | `components/ui/FilterToolbar/FilterToolbar.tsx` |
| 161 | 8 | 7 | `components/LocationPage/LocationPageClient.tsx` |

(Full list of 30 in the survey; `Component.tsx`, `ClientGalleryDownload.tsx` are already done.)

- [ ] **Step 1: Regenerate the survey** (don't trust a stale snapshot).

Run (from repo root):
```bash
for f in $(grep -rl "'use client'" app --include="*.tsx"); do
  printf "%5s | hooks:%-3s | %s\n" "$(wc -l < "$f")" "$(grep -cE 'useMemo|useCallback|useState|useEffect|useRef' "$f")" "${f#app/}"
done | sort -rn
```
Expected: a ranked list; the top ~12 are the audit focus.

- [ ] **Step 2: Audit each component against the rubric.** For EACH `'use client'` component (mirror MemPalace first per CLAUDE.md: `mempalace_search('<component> logic', wing='edens-zac')` before reading a batch), Read it and record in the report:
  - score per axis + total;
  - **extraction targets** — for each: the inline logic (name + line range), proposed helper signature, and whether it's pure or needs args threaded;
  - proposed helper file path (`app/components/<dir>/<Component>Utils.ts`) and test path;
  - est. effort (S/M/L) and risk (low/med/high);
  - any overlap with `006-function-decomposition.md`;
  - **flag** (don't fix here) static inline `style={{...}}`, dead params, stale TODOs.

  Report row format (one block per candidate):
  ```markdown
  ### CollectionPageClient.tsx — score 6/6 — L / med risk
  Extract → `collectionPageClientUtils.ts`:
  - `extractCollectionFilterOptions(images, refs)` (already partly in contentFilter.ts — consolidate, don't fork)
  - `buildCriteria(filterState)` (the `criteria` useMemo body)
  - `filterCollectionContent(allContent, allImages, criteria, filterState)` (the `filteredContent` useMemo body)
  - `hasActiveFilters(filterState)`, `hasOptions(baseOptions, showHighlyRated, hasDateVariance)`
  Existing tests guarding behavior: `tests/.../CollectionPageClient*` (none today → add characterization first). Browser smoke: `/<a collection>` filter bar.
  ```

- [ ] **Step 3: Prioritize.** Sort candidates by `(score desc, risk asc)`. Put `ManageClient.tsx` (1719 lines) in its OWN follow-up plan — it's too large for one pass and already has `manageUtils.ts` + `useImageClickHandler.ts`; recommend an incremental sub-plan, do NOT attempt it wholesale here. Note this explicitly in the report.

- [ ] **Step 4: Commit the report.**
```bash
git add docs/superpowers/plans/006-thin-component-audit-report.md
git commit -m "docs: thin-component extraction audit report"
```
(Note: `docs/superpowers/` is gitignored in this repo, so this commit is local-only by convention — the report still lives on disk for Phase 2.)

**Parallelization:** assign disjoint component subsets to N agents (e.g. by directory: `Content/`, `ContentCollection/`, `ImageMetadata/`, `ui/`, `FullScreenModal/+MenuDropdown/`). Each returns its report section; merge. No write conflicts (read-only audit).

---

## Phase 2 — Refactor (per-candidate recipe)

Apply this **exact recipe** to each candidate from the report, **one component per task/commit**, in priority order. The candidates below carry initial extraction hypotheses; the report's targets are authoritative.

### The recipe (every candidate follows these steps)

- [ ] **Step 1: Pin current behavior.** Run the component's existing tests; they are the regression guard and must stay green untouched.
```bash
/opt/homebrew/bin/node node_modules/.bin/jest <tests for the component> 2>&1 | tail -5
```
If the component has **no** test covering the logic you're about to move, write a *characterization test* first (assert current rendered output / current return values) so the extraction is provably behavior-preserving. Show the test code; run it; see it pass against the un-refactored component.

- [ ] **Step 2: Create the co-located helper file** `app/components/<dir>/<Component>Utils.ts`. Move each target's body verbatim into a pure exported function; thread the values it used as parameters (do not close over component state). Keep `'use client'` OUT of the utils file (pure TS).

- [ ] **Step 3: Write unit tests** `tests/components/<dir>/<Component>Utils.test.ts` — one `describe` per helper, covering the branches the inline code had (guards, clamps, empty inputs, the main path). Use `@/tests/fixtures/contentFixtures` for content. Run them; see them pass.

- [ ] **Step 4: Rewire the component** to call the helpers (wrap in `useMemo`/`useCallback` as before, deps = the primitive inputs). Delete the now-dead inline logic and any imports it alone needed. Collapse redundant locals.

- [ ] **Step 5: Verify behavior-preserving.**
```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest <component tests> <new util tests>
/opt/homebrew/bin/node node_modules/.bin/eslint --fix <changed files>
```
Expected: tsc 0, all tests pass (existing component tests UNCHANGED), eslint 0. For a visually-observable component, browser-smoke the relevant page (preview on `:3001`) and confirm identical render (rows/controls present, no console error, no overflow).

- [ ] **Step 6: Commit.**
```bash
git add app/components/<dir>/<Component>.tsx app/components/<dir>/<Component>Utils.ts tests/components/<dir>/<Component>Utils.test.ts
git commit -m "refactor(<area>): extract <Component> logic into <Component>Utils"
```

### Candidate tasks (apply the recipe; targets from the audit report are authoritative)

- [ ] **Task A — `CollectionPageClient.tsx`** → `collectionPageClientUtils.ts`. Extract: `buildCriteria(filterState)`, `filterCollectionContent(...)` (the `filteredContent` body), `hasActiveFilters(filterState)`, `hasOptions(...)`, `hasDateVariance(images)`, `hasRatingVariance(images)`, and consolidate the local `extractCollectionFilterOptions` (reuse `app/utils/contentFilter.ts` rather than forking). Highest value (25 inline derivations). Browser smoke: a collection page's filter bar (grey-out, date sort, density).

- [ ] **Task B — `FullScreenModal.tsx`** → `fullScreenModalUtils.ts`. Extract: `resolveDisplayLocations(image, collectionData)`, `resolveDisplayDate(image, collectionData)`, and any metadata-shaping currently inline. Pure, easily tested. Browser smoke: open an image, check metadata overlay.

- [ ] **Task C — `ContentBlockWithFullScreen.tsx`** → `contentBlockUtils.ts`. Extract: the `viewableBlocks` filter, the deep-link `?image=` parse/restore selection, and the load-more/pagination math (`visibleBlocks`, `hasMore`). Keep the hooks (`useFullScreenImage`, observers) in the component.

- [ ] **Task D — `CollectionContentRenderer.tsx`** → `collectionContentRendererUtils.ts`. Extract: `toCollectionDimensions(options)` (already a module fn — move + test), the `hasClickHandler`/`isSlugNav` predicates, and the synthetic-`ViewableContent` builder inside `handleClick`. **Coordinate with `006-function-decomposition.md`** (sub-component split into `TextContentBlock`/`GifContentBlock`) — do logic extraction here; leave the sub-component split to 006. Medium risk (640 lines, parallax/overlay branches) — browser-smoke a parallax collection + a client gallery.

- [ ] **Task E — `ui/Dropdown.tsx`** → `dropdownUtils.ts`. Extract: option-list filtering/keyboard-navigation index math and positioning calc (21 inline derivations). Keep focus/effect hooks in the component. Browser smoke: a filter dropdown open/keyboard.

- [ ] **Task F — `LocationPageClient.tsx`**, **`CameraSettingsSection.tsx`**, **`FilterToolbar.tsx`**, **`MenuDropdown.tsx`** — smaller candidates; same recipe, lower priority. Confirm against the report before doing (some may score < 4 and drop out).

- [ ] **Task G (separate plan) — `ManageClient.tsx`** (1719 lines). Do **not** attempt in this sweep. The audit should spin out `006-manageclient-decomposition.md` for an incremental, multi-commit decomposition (it already has `manageUtils.ts`/`useImageClickHandler.ts`; the remaining state machine needs careful, test-guarded extraction).

---

## Verification & guardrails (whole sweep)

- Every component refactor is **behavior-preserving**: existing component tests pass **unchanged**; new tests only cover the extracted helpers. If an existing test must change, the extraction changed behavior — stop and reassess.
- No `any`; strict types on every helper signature.
- After each task: `tsc --noEmit` clean, full `jest` green, `eslint`/`prettier` clean (and `stylelint` if SCSS touched — this sweep generally shouldn't touch SCSS).
- Visual components get a browser smoke check on `:3001` (preview) before commit.
- One component per commit (easy revert, clean review).

## Agent Teams / parallelization

Both phases parallelize cleanly because candidates live in **disjoint files**:
- **Phase 1 audit:** read-only; split components across agents by directory.
- **Phase 2 refactor:** each candidate touches only its own `<Component>.tsx` + new `*Utils.ts` + new test — no cross-file conflicts. Run several candidates concurrently (subagent-driven-development, or `/agent-teams` with one component per agent), each self-verifying via Step 5 before committing.
- **Exception:** `CollectionContentRenderer` (Task D) overlaps `006`; serialize those two or assign to the same agent to avoid stepping on each other.

## Spec coverage checklist

| Requirement (from the ask) | Plan coverage |
|---|---|
| "Based on the Component.tsx refactor" | Reference refactor section codifies the exact pattern (`7d8bdac`) as the recipe |
| "Critical review of ALL our components" | Phase 1 audits every `'use client'` component against the rubric → committed report |
| "Look for components that can use the same style of refactor" | Rubric + scored candidate list + per-component extraction targets |
| Same *style* (co-located helpers, thin JSX, testable) | Recipe enforces co-located `*Utils.ts` + unit tests + behavior-preserving (the 5 "done" rules) |
| Not in the ask but required for quality | Behavior-preserving guardrails; ManageClient spun to its own plan; DRY with `006`; inline-style flags deferred to their own plan |

**Gaps / out of scope (explicit):** hooks (`useFullScreenImage.tsx`, 340 lines) are not "components" but host the same extractable logic — note them in the report as a stretch set, but the ask is components. Sub-component splitting (`TextContentBlock` etc.) belongs to `006`, not here.
