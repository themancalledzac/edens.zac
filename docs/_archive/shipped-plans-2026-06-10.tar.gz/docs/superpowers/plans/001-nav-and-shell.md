# 001 · Navigation, Shell & Remaining Primitives
_Chapter [001 · Design System Unification](../../001-design-review.md) · plan · branch `0149-nav-and-shell`_

> ✅ **SHIPPED — [PR #156](https://github.com/themancalledzac/edens.zac/pull/156) (merged 2026-06-03).** All primitives landed under `app/components/ui/`: `Tile`/`NavLink`, `PageShell`/`CollectionHeader`, `StatusPage`, `Badge`, the `Field` set, `MetadataList<T>`. The "`/metadata` behind admin auth" security item shipped as its own follow-up — [PR #157](https://github.com/themancalledzac/edens.zac/pull/157) (`0150-admin-route-gating`) gated `/all-collections` + `/all-images`. The plan below is preserved as the implementation record.

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the wrong-element navigation (tiles via `div onClick`+`router.push`), the eight copy-pasted page scaffolds, the chrome-less/invisible 404 & error pages, the three duplicated badge definitions, the parallel form scaffolding, and the three near-identical metadata lists with one set of canonical, token-driven primitives in `app/components/ui/` — `Tile`/`NavLink`, `PageShell`/`CollectionHeader`, `StatusPage`, `Badge`, the `Field` form set, and a generic `MetadataList<T>` — and move `/metadata` behind the same auth gate the rest of admin uses.

**Architecture:** This is **Phase 2** of the design-system unification ([`001-design-system-unification.md`](001-design-system-unification.md)). Each primitive ships test-first under `app/components/ui/` with a sibling `tests/components/ui/*.test.tsx`, then the existing call sites migrate onto it and the per-feature SCSS / duplicated rules are deleted. New presentational primitives are Server-Component-friendly (no hooks → no `'use client'`); only `Tile` and the migrated `CollectionContentRenderer` keep `'use client'` because they own parallax / fullscreen handlers. The painted, dark-safe page surface (Phase 0) is reused — `PageShell` owns the `container/main/SiteHeader/pageHeader` scaffold so the surface lives in one place.

**Tech Stack:** Next.js 16 App Router, React 19 (named imports), TypeScript (strict, no `any`), SCSS Modules with CSS custom properties (bare `var(--token)`, no `@use` partial), Jest + React Testing Library (tests mirror `app/` under `tests/`; with `next/jest`, CSS-module class names are identity-mapped so `styles.foo === 'foo'`).

> **Spec:** This plan implements the Phase 2 scope of [`../../001-design-review.md`](../../001-design-review.md) (the design review — the spec). Section references like *(review §1.4)* point there. Specifically it covers: §1.4 (primary nav uses the wrong element), §2 (UX/IA: orphaned content, status-page dead-ends, a person page shows only "2 photos"), §3 (the consolidation catalog: page scaffold ×8, badge ×3, form set, status pages, 3 near-identical metadata lists), §5 (severity-ranked failures: non-link tiles, chrome-less 404/error, public `CollectionType` leak, ContactForm labels, `/metadata` unguarded CRUD), and §6a ranks 5 (NavLink/Tile), 6 (PageShell/CollectionHeader), 7 (Badge), 8 (Form set), 9 (StatusPage).

> **Predecessor (PREREQUISITE — must land first):** [`001-design-system-unification.md`](001-design-system-unification.md) — **Phase 0** (paint the canvas + token-alias layer; delete `FsDebug`; remove dead `/all-blogs` link, duplicate "Create", dead `onBack`) **and Phase 1 · Task 1.1** (`<Button>` + `<IconButton>` + `<CloseButton>`). `StatusPage` (Task 3) and the `Field` form set (Task 5) compose `<Button>`; the painted surface from Phase 0 Task 0.1 is what `PageShell` (Task 2) and `StatusPage` (Task 3) render onto. **Do not start this plan until Phase 0 + Task 1.1 are merged.**

> **Status:** Plan only. No code written yet.

---

## Prerequisite check (run before Task 1)

Confirm the Phase 0 + Task 1.1 deliverables exist; if any of these fail, stop and land the master plan's Phase 0/1.1 first.

```bash
cd /Users/themancalledzac/Code/edens.zac
test -f app/components/ui/Button/Button.tsx && echo "Button OK" || echo "MISSING Button — land master Task 1.1 first"
test -f app/components/ui/CloseButton/CloseButton.tsx && echo "CloseButton OK" || echo "MISSING CloseButton"
grep -q "background-color: var(--color-bg)" app/styles/globals.css && echo "canvas painted OK" || echo "MISSING painted canvas — land master Task 0.1 first"
test -f app/components/FullScreenModal/FsDebug.tsx && echo "WARN FsDebug still present — land master Task 0.2" || echo "FsDebug removed OK"
```

Expected: `Button OK`, `CloseButton OK`, `canvas painted OK`, `FsDebug removed OK`.

> **Note on `<Badge>` and `<StatusPage>` ordering.** Task 4 (`<Badge>`) removes the duplicated `.dateBadge`/`.cardTypeBadge` rules from `globals.css` and `ContentComponent.module.scss`. Task 1 (`<Tile>`) keeps composing `<BadgeOverlay>` until Task 4 promotes it to `<Badge>`. Run the tasks in numeric order (1 → 6) so the migration seams line up; each task is independently green and committable.

---

## File-structure map

**New (created by this plan):**

```
app/components/ui/
  Tile/            Tile.tsx              Tile.module.scss        (Task 1; 'use client')
  NavLink/         NavLink.tsx           NavLink.module.scss     (Task 1; server-friendly)
  PageShell/       PageShell.tsx         PageShell.module.scss   (Task 2; server-friendly)
  CollectionHeader/CollectionHeader.tsx  CollectionHeader.module.scss (Task 2)
  StatusPage/      StatusPage.tsx        StatusPage.module.scss  (Task 3; server-friendly)
  Badge/           Badge.tsx             Badge.module.scss       (Task 4; promotes BadgeOverlay)
  Field/           Field.tsx             Input.tsx  Select.tsx
                   Textarea.tsx          Checkbox.tsx FormError.tsx
                   Field.module.scss                              (Task 5; server-friendly)
  MetadataList/    MetadataList.tsx      MetadataList.module.scss (Task 6; 'use client')

app/(admin)/metadata/   page.tsx                                 (Task 6 — moved from app/metadata/)

tests/components/ui/
  Tile.test.tsx  NavLink.test.tsx  PageShell.test.tsx  CollectionHeader.test.tsx
  StatusPage.test.tsx  Badge.test.tsx  Field.test.tsx  MetadataList.test.tsx
```

**Modified:**

- Task 1: `app/components/Content/CollectionContentRenderer.tsx` (tile nav → `<Tile href>`), `app/types/ContentRenderer.ts` (no change needed — `hasSlug` already present).
- Task 2: `app/components/ContentCollection/ContentCollectionPage.module.scss`, `app/components/TaxonomyPage/TaxonomyPage.tsx` + `.module.scss`, `app/components/LocationPage/LocationPage.tsx` + `.module.scss`, `app/(admin)/admin/page.tsx` + `page.module.scss`, `app/(admin)/comments/page.tsx` + `Comments.module.scss`, `app/components/MetadataPage/MetadataPageClient.tsx` + `MetadataPage.module.scss`.
- Task 3: `app/not-found.tsx`, `app/error.tsx`, `app/(admin)/error.tsx`.
- Task 4: `app/components/Content/BadgeOverlay.tsx` (re-export shim), `app/components/Content/CollectionContentRenderer.tsx` (use `<Badge>`), `app/components/Content/ContentComponent.module.scss` (delete badge rules), `app/styles/globals.css` (delete badge rules), `app/utils/contentRendererUtils.ts` (curated label mapping).
- Task 5: `app/components/ContactForm/ContactForm.tsx` + `.module.scss`, `tests/components/ContactForm.test.tsx`.
- Task 6: `app/components/MetadataPage/{MetadataTagList,MetadataPersonList,MetadataLocationList}.tsx` (deleted, replaced by `MetadataList.tsx`), `app/components/MetadataPage/MetadataPageClient.tsx`, `proxy.ts` (gate `/metadata`), `app/metadata/page.tsx` → `app/(admin)/metadata/page.tsx`.

---

## Task 1 — `<Tile>` / `<NavLink>`: real `<a>` navigation

**Why:** Primary navigation (home + collection tiles) navigates via `router.push` on a `<div onClick>` — no `<a href>` (review §1.2, §1.4, §5 🔴). Result: no SEO crawlability, no middle-click / open-in-new-tab, weak keyboard semantics on the site's *main* navigation. `CollectionContentRenderer.tsx:104-111` runs `router.push(\`/${_hasSlug}\`)` from `handleClick`. The fix: a `Tile` primitive that is always a real `next/link` `<a>` and composes the parallax image + overlay + badge as children; `onClick` is reserved for fullscreen-open only.

**Files:**
- Create: `app/components/ui/NavLink/NavLink.tsx`, `app/components/ui/NavLink/NavLink.module.scss`
- Create: `app/components/ui/Tile/Tile.tsx`, `app/components/ui/Tile/Tile.module.scss`
- Test: `tests/components/ui/NavLink.test.tsx`, `tests/components/ui/Tile.test.tsx`
- Modify: `app/components/Content/CollectionContentRenderer.tsx`

- [ ] **Step 1 — Write the failing `NavLink` test** `tests/components/ui/NavLink.test.tsx`:

```tsx
import { render, screen } from '@testing-library/react';

import { NavLink } from '@/app/components/ui/NavLink/NavLink';

describe('NavLink', () => {
  it('renders a real anchor with the href', () => {
    render(<NavLink href="/all-collections">Browse all work</NavLink>);
    const link = screen.getByRole('link', { name: 'Browse all work' });
    expect(link).toBeInTheDocument();
    expect(link).toHaveAttribute('href', '/all-collections');
  });

  it('applies its own class plus any passed className', () => {
    render(
      <NavLink href="/about" className="extra">
        About
      </NavLink>
    );
    const link = screen.getByRole('link', { name: 'About' });
    expect(link.className).toMatch(/navLink/);
    expect(link.className).toMatch(/extra/);
  });
});
```

- [ ] **Step 2 — Run it; verify it fails:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/NavLink.test.tsx
```
Expected: FAIL — `Cannot find module '@/app/components/ui/NavLink/NavLink'`.

- [ ] **Step 3 — Implement `app/components/ui/NavLink/NavLink.tsx`** (server-friendly — no hooks):

```tsx
import Link, { type LinkProps } from 'next/link';
import { type AnchorHTMLAttributes, type ReactNode } from 'react';

import styles from './NavLink.module.scss';

export interface NavLinkProps
  extends LinkProps,
    Omit<AnchorHTMLAttributes<HTMLAnchorElement>, keyof LinkProps> {
  children: ReactNode;
  className?: string;
}

/**
 * Canonical text navigation link. Always a real next/link <a> — crawlable,
 * middle-clickable, open-in-new-tab. Use for menu/footer/breadcrumb links;
 * use <Tile> for image-tile navigation.
 */
export function NavLink({ children, className, ...rest }: NavLinkProps) {
  const classes = [styles.navLink, className].filter(Boolean).join(' ');
  return (
    <Link className={classes} {...rest}>
      {children}
    </Link>
  );
}
```

- [ ] **Step 4 — Implement `app/components/ui/NavLink/NavLink.module.scss`** (tokens only):

```scss
.navLink {
  color: inherit;
  text-decoration: none;
  cursor: pointer;

  &:hover {
    text-decoration: underline;
  }

  &:focus-visible {
    outline: 2px solid var(--color-accent);
    outline-offset: 2px;
  }
}
```

- [ ] **Step 5 — Run the `NavLink` test; verify it passes:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/NavLink.test.tsx
```
Expected: PASS (2 tests).

- [ ] **Step 6 — Write the failing `Tile` test** `tests/components/ui/Tile.test.tsx`:

```tsx
import { fireEvent, render, screen } from '@testing-library/react';

import { Tile } from '@/app/components/ui/Tile/Tile';

describe('Tile', () => {
  it('renders a real anchor with the href and contains its children', () => {
    render(
      <Tile href="/landscapes" aria-label="Landscapes">
        <span>cover</span>
      </Tile>
    );
    const link = screen.getByRole('link', { name: 'Landscapes' });
    expect(link).toHaveAttribute('href', '/landscapes');
    expect(link).toContainHTML('<span>cover</span>');
  });

  it('forwards onClick (used for fullscreen-open, not navigation)', () => {
    const onClick = jest.fn();
    render(
      <Tile href="/landscapes" aria-label="Landscapes" onClick={onClick}>
        cover
      </Tile>
    );
    fireEvent.click(screen.getByRole('link', { name: 'Landscapes' }));
    expect(onClick).toHaveBeenCalledTimes(1);
  });

  it('passes through inline style and data attributes for parallax wiring', () => {
    render(
      <Tile
        href="/x"
        aria-label="X"
        style={{ width: 300 }}
        data-parallax-container=""
      >
        cover
      </Tile>
    );
    const link = screen.getByRole('link', { name: 'X' });
    expect(link).toHaveStyle({ width: '300px' });
    expect(link).toHaveAttribute('data-parallax-container');
  });
});
```

- [ ] **Step 7 — Run it; verify it fails:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/Tile.test.tsx
```
Expected: FAIL — `Cannot find module '@/app/components/ui/Tile/Tile'`.

- [ ] **Step 8 — Implement `app/components/ui/Tile/Tile.tsx`.** It must accept a `ref` (the parallax hook returns one), so it is `'use client'` and uses `forwardRef`. It always renders a `next/link` `<a>`; `onClick` is forwarded for fullscreen-open but never used for navigation (the `href` does that):

```tsx
'use client';

import Link, { type LinkProps } from 'next/link';
import { type AnchorHTMLAttributes, forwardRef, type ReactNode } from 'react';

import styles from './Tile.module.scss';

export interface TileProps
  extends LinkProps,
    Omit<AnchorHTMLAttributes<HTMLAnchorElement>, keyof LinkProps> {
  /** Accessible name for the tile (the visible title is inside an overlay). */
  'aria-label': string;
  children: ReactNode;
  className?: string;
}

/**
 * Image-tile navigation primitive. Always a real next/link <a> so tiles are
 * crawlable, middle-clickable, open-in-new-tab, and keyboard-activatable.
 * Composes the parallax image + title overlay + badge as children. `onClick`
 * is reserved for genuine non-nav actions (fullscreen-open); navigation is the
 * <a href>, so middle-click / cmd-click keep working.
 */
export const Tile = forwardRef<HTMLAnchorElement, TileProps>(function Tile(
  { children, className, ...rest },
  ref
) {
  const classes = [styles.tile, className].filter(Boolean).join(' ');
  return (
    <Link ref={ref} className={classes} {...rest}>
      {children}
    </Link>
  );
});
```

- [ ] **Step 9 — Implement `app/components/ui/Tile/Tile.module.scss`** (tokens only; the `<a>` must behave like the old wrapper `<div>` — block, relative, full-size, no underline):

```scss
.tile {
  position: relative;
  display: block;
  width: 100%;
  height: 100%;
  box-sizing: border-box;
  color: inherit;
  text-decoration: none;
  cursor: pointer;

  &:focus-visible {
    outline: 2px solid var(--color-accent);
    outline-offset: 2px;
  }
}
```

- [ ] **Step 10 — Run the `Tile` test; verify it passes:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/Tile.test.tsx
```
Expected: PASS (3 tests).

- [ ] **Step 11 — Migrate the COLLECTION tile navigation in `CollectionContentRenderer.tsx`.** Only the COLLECTION render path navigates by slug (`_hasSlug && !onImageClick`); IMAGE/GIF/TEXT keep `onClick`-only fullscreen behavior. Replace the slug-navigating branch of `handleClick` with a real `<Tile href>`, leaving the fullscreen path on `onClick`.

  **Before** (the COLLECTION/parallax IMAGE render path — the wrapper `<div>` at lines ~542-547 and the slug branch in `handleClick` at ~108-111):

```tsx
  const handleClick = useCallback(() => {
    if (contentType === 'TEXT') return;
    if (isReorderMode) return;

    if (_hasSlug && !onImageClick) {
      router.push(`/${_hasSlug}`);
      return;
    }
    // … fullscreen stand-in …
  }, [/* … router, _hasSlug … */]);
  // …
  return (
    <div
      key={contentId}
      {...wrapperProps}
      {...(enableParallax ? { 'data-parallax-container': '' } : { 'data-image-wrapper': '' })}
    >
      <div className={cbStyles.imageWrapper} onClick={handleClick}>
        {imageWrapperContent}
      </div>
      {/* overlays … */}
    </div>
  );
```

  **After** — split the wrapper: when `_hasSlug && !onImageClick && !isReorderMode` render a `<Tile href={\`/${_hasSlug}\`}>` (real link, no `router.push`); otherwise keep the `<div onClick>` for fullscreen-open. The parallax `ref`, inline style, and `data-parallax-container` move onto the `<Tile>`:

```tsx
  // Slug-based collection navigation is now a real <a>; fullscreen is onClick.
  const isSlugNav = !!_hasSlug && !onImageClick && !isReorderMode && contentType !== 'TEXT';

  const handleClick = useCallback(() => {
    if (contentType === 'TEXT') return;
    if (isReorderMode) return;
    if (_hasSlug && !onImageClick) return; // navigation handled by <Tile href>

    const fullScreenContent: ViewableContent =
      contentType === 'GIF'
        ? ({
            id: contentId,
            contentType: 'GIF',
            gifUrl: imageUrl || '',
            title: alt,
            orderIndex: 0,
            visible: true,
          } as ContentGifModel)
        : ({
            id: contentId,
            contentType: 'IMAGE',
            imageUrl: imageUrl || '',
            title: alt,
            orderIndex: 0,
            visible: true,
          } as ContentImageModel);

    const handler = createContentClickHandler(
      contentId,
      onImageClick,
      enableFullScreenView,
      onFullScreenImageClick,
      fullScreenContent
    );
    handler?.();
  }, [
    contentId,
    contentType,
    imageUrl,
    alt,
    onImageClick,
    enableFullScreenView,
    onFullScreenImageClick,
    _hasSlug,
    isReorderMode,
  ]);
```

  Then in the final return, replace the outer `<div>` with a conditional. Keep `wrapperProps` (it carries `className`, `style`, and — for parallax — `ref`), but `Tile` needs the ref on itself:

```tsx
  if (isSlugNav) {
    return (
      <Tile
        href={`/${_hasSlug}`}
        aria-label={overlayText ?? alt}
        className={wrapperProps.className}
        style={wrapperProps.style}
        {...(enableParallax ? { ref: parallaxRef, 'data-parallax-container': '' } : { 'data-image-wrapper': '' })}
      >
        <span className={cbStyles.imageWrapper}>{imageWrapperContent}</span>
        {!enableParallax && (
          <ImageOverlays
            contentType={contentType}
            isNotVisible={isNotVisible}
            shouldShowOverlay={shouldShowOverlay}
            isSelected={isSelected}
          />
        )}
      </Tile>
    );
  }

  return (
    <div
      key={contentId}
      {...wrapperProps}
      {...(enableParallax ? { 'data-parallax-container': '' } : { 'data-image-wrapper': '' })}
    >
      <div className={cbStyles.imageWrapper} onClick={handleClick}>
        {imageWrapperContent}
      </div>
      {!enableParallax && (
        <ImageOverlays
          contentType={contentType}
          isNotVisible={isNotVisible}
          shouldShowOverlay={shouldShowOverlay}
          isSelected={isSelected}
        />
      )}
      {isClientGallery && contentType === 'IMAGE' && <ImageDownloadOverlay imageId={contentId} />}
      {isReorderMode &&
        onArrowMove &&
        onPickUp &&
        onPlace &&
        onCancelImageMove &&
        contentId !== currentCoverImageId && (
          <ReorderOverlay
            isPickedUp={isPickedUp}
            pickedUpImageId={pickedUpImageId}
            hasMoved={hasMoved}
            isFirst={isFirstInOrder}
            isLast={isLastInOrder}
            onArrowLeft={() => onArrowMove(contentId, -1)}
            onArrowRight={() => onArrowMove(contentId, 1)}
            onPickUp={() => onPickUp(contentId)}
            onPlace={() => onPlace(contentId)}
            onCancel={() => onCancelImageMove(contentId)}
          />
        )}
    </div>
  );
```

  Add the import at the top of `CollectionContentRenderer.tsx`:
```tsx
import { Tile } from '@/app/components/ui/Tile/Tile';
```
  Remove the now-unused `useRouter` import and the `const router = useRouter();` line **only if** no other call site in the file still uses `router` — the TEXT branch's `handleTagClick` still calls `router.push(\`/tag/...\`)`, so **keep `useRouter`**. (Verify with the grep in Step 12; do not remove it.)

  > **Note:** `<span className={cbStyles.imageWrapper}>` replaces the inner `<div>` because a `<div>` is not valid inside an `<a>` in strict HTML; `imageWrapper` already uses `display: block` so the visual result is identical.

- [ ] **Step 12 — Verify the nav is now a real link and `router` is still needed by the TEXT branch:**
```bash
grep -n "router.push" app/components/Content/CollectionContentRenderer.tsx   # expect only the /tag/ push in handleTagClick
grep -n "useRouter" app/components/Content/CollectionContentRenderer.tsx      # expect still imported + used
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/Tile.test.tsx tests/components/ui/NavLink.test.tsx
```
Expected: the only `router.push` left is `/tag/${...}`; `useRouter` still present; tsc clean; both ui tests PASS.

- [ ] **Step 13 — Lint, type-check, format:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write 'app/components/ui/Tile/**/*' 'app/components/ui/NavLink/**/*' app/components/Content/CollectionContentRenderer.tsx tests/components/ui/Tile.test.tsx tests/components/ui/NavLink.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix 'app/components/ui/Tile/Tile.tsx' 'app/components/ui/NavLink/NavLink.tsx' app/components/Content/CollectionContentRenderer.tsx
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/ui/Tile/Tile.module.scss' 'app/components/ui/NavLink/NavLink.module.scss'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
```
Expected: all clean.

- [ ] **Step 14 — Commit:**
```bash
git add app/components/ui/Tile app/components/ui/NavLink tests/components/ui/Tile.test.tsx tests/components/ui/NavLink.test.tsx app/components/Content/CollectionContentRenderer.tsx
git commit -m "feat(ui): add Tile/NavLink primitives; migrate collection tiles to real <a>

Home/collection tiles navigated via div onClick + router.push (no <a href>):
no SEO crawl, no middle-click / open-in-new-tab, weak keyboard semantics on
the site's primary nav. Tile is always a real next/link <a>; onClick is reserved
for fullscreen-open only. Fixes review §1.4 / §5.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

**Acceptance** *(review §1.4, §5)*: collection tiles are middle-clickable, open-in-new-tab, crawlable, and keyboard-activatable (the `<a>` is focusable); fullscreen-open still works on image/GIF tiles via `onClick`.

---

## Task 2 — `<PageShell>` + `<CollectionHeader>`: one page scaffold

**Why:** The `.container` / `.main` / `.pageHeader` scaffold is copy-pasted verbatim across **8 modules** while the shared `layout.module.scss` holds only 3 trivial rules (review §3 dup catalog, §6a-rank-6). Verified identical-or-near-identical scaffolds: `ContentCollectionPage.module.scss`, `TaxonomyPage.module.scss`, `LocationPage.module.scss`, `(admin)/admin/page.module.scss`, `(admin)/comments/Comments.module.scss`, `MetadataPage.module.scss` (plus ManageClient and AllImagesClient noted in the master plan). One `PageShell` owns the painted surface + `SiteHeader`; one `CollectionHeader` renders the title + count + optional cover + breadcrumb slot.

**Files:**
- Create: `app/components/ui/PageShell/PageShell.tsx`, `app/components/ui/PageShell/PageShell.module.scss`
- Create: `app/components/ui/CollectionHeader/CollectionHeader.tsx`, `app/components/ui/CollectionHeader/CollectionHeader.module.scss`
- Test: `tests/components/ui/PageShell.test.tsx`, `tests/components/ui/CollectionHeader.test.tsx`
- Modify (migrate onto the shell; delete duplicated SCSS): `TaxonomyPage.tsx` + `.module.scss`, `LocationPage.tsx` + `.module.scss`, `(admin)/admin/page.tsx` + `page.module.scss`, `(admin)/comments/page.tsx` + `Comments.module.scss`, `MetadataPageClient.tsx` + `MetadataPage.module.scss`, `ContentCollectionPage.module.scss`.

- [ ] **Step 1 — Write the failing `PageShell` test** `tests/components/ui/PageShell.test.tsx`:

```tsx
import { render, screen } from '@testing-library/react';

import { PageShell } from '@/app/components/ui/PageShell/PageShell';

jest.mock('@/app/components/SiteHeader/SiteHeader', () => ({
  __esModule: true,
  default: ({ pageType }: { pageType?: string }) => (
    <div data-testid="site-header" data-page-type={pageType} />
  ),
  SiteHeader: ({ pageType }: { pageType?: string }) => (
    <div data-testid="site-header" data-page-type={pageType} />
  ),
}));

describe('PageShell', () => {
  it('renders SiteHeader, a <main>, and its children', () => {
    render(
      <PageShell>
        <p>page body</p>
      </PageShell>
    );
    expect(screen.getByTestId('site-header')).toBeInTheDocument();
    expect(screen.getByRole('main')).toBeInTheDocument();
    expect(screen.getByText('page body')).toBeInTheDocument();
  });

  it('forwards pageType and collectionSlug to SiteHeader', () => {
    render(
      <PageShell pageType="collectionsCollection" collectionSlug="abc">
        x
      </PageShell>
    );
    expect(screen.getByTestId('site-header')).toHaveAttribute(
      'data-page-type',
      'collectionsCollection'
    );
  });

  it('omits SiteHeader when withHeader={false}', () => {
    render(<PageShell withHeader={false}>x</PageShell>);
    expect(screen.queryByTestId('site-header')).not.toBeInTheDocument();
    expect(screen.getByRole('main')).toBeInTheDocument();
  });
});
```

- [ ] **Step 2 — Run it; verify it fails:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/PageShell.test.tsx
```
Expected: FAIL — `Cannot find module '@/app/components/ui/PageShell/PageShell'`.

- [ ] **Step 3 — Implement `app/components/ui/PageShell/PageShell.tsx`** (server-friendly; `SiteHeader` is itself a client component but can be rendered from a server tree). The `pageType`/`collectionSlug` props mirror the real `SiteHeaderProps` signature (`'default' | 'manage' | 'collection' | 'collectionsCollection'`):

```tsx
import { type ReactNode } from 'react';

import SiteHeader from '@/app/components/SiteHeader/SiteHeader';

import styles from './PageShell.module.scss';

export interface PageShellProps {
  children: ReactNode;
  /** Forwarded to SiteHeader; mirrors SiteHeaderProps['pageType']. */
  pageType?: 'default' | 'manage' | 'collection' | 'collectionsCollection';
  collectionSlug?: string;
  /** Render the site header (default true). Status pages pass false. */
  withHeader?: boolean;
  className?: string;
}

/**
 * Canonical page scaffold: the painted, dark-safe surface (container/main) plus
 * the SiteHeader. Replaces the 8 copy-pasted .container/.main scaffolds. The
 * page-specific header (title/count/cover/breadcrumbs) is composed via
 * <CollectionHeader>, passed as the first child.
 */
export function PageShell({
  children,
  pageType = 'default',
  collectionSlug,
  withHeader = true,
  className,
}: PageShellProps) {
  const mainClasses = [styles.main, className].filter(Boolean).join(' ');
  return (
    <div className={styles.container}>
      <main className={mainClasses}>
        {withHeader && <SiteHeader pageType={pageType} collectionSlug={collectionSlug} />}
        {children}
      </main>
    </div>
  );
}

export default PageShell;
```

- [ ] **Step 4 — Implement `app/components/ui/PageShell/PageShell.module.scss`** — lift the verified-identical `.container` + `.main` rules out of the 8 modules (mobile-first; desktop padding at `768px`):

```scss
.container {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.main {
  flex: 1;
  margin: 0 auto;
  width: 100%;
  max-width: var(--page-max-width);
  position: relative;
  padding-left: 0;
  padding-right: 0;
  padding-top: var(--page-padding-mobile);

  @media (width >= 768px) {
    padding-left: var(--default-padding);
    padding-right: var(--default-padding);
    padding-top: var(--default-padding);
  }
}
```

- [ ] **Step 5 — Run the `PageShell` test; verify it passes:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/PageShell.test.tsx
```
Expected: PASS (3 tests).

- [ ] **Step 6 — Write the failing `CollectionHeader` test** `tests/components/ui/CollectionHeader.test.tsx`:

```tsx
import { render, screen } from '@testing-library/react';

import { CollectionHeader } from '@/app/components/ui/CollectionHeader/CollectionHeader';

describe('CollectionHeader', () => {
  it('renders the title as an h1', () => {
    render(<CollectionHeader title="Iceland" />);
    expect(screen.getByRole('heading', { level: 1, name: 'Iceland' })).toBeInTheDocument();
  });

  it('renders a pluralized photo count when count is given', () => {
    render(<CollectionHeader title="Iceland" count={3} />);
    expect(screen.getByText('3 photos')).toBeInTheDocument();
  });

  it('uses the singular form for a count of 1', () => {
    render(<CollectionHeader title="Iceland" count={1} />);
    expect(screen.getByText('1 photo')).toBeInTheDocument();
  });

  it('omits the count entirely when undefined', () => {
    render(<CollectionHeader title="Iceland" />);
    expect(screen.queryByText(/photo/)).not.toBeInTheDocument();
  });

  it('renders a cover image with the title as alt when cover is given', () => {
    render(<CollectionHeader title="Iceland" cover={{ src: 'https://cdn/x.jpg' }} />);
    expect(screen.getByRole('img', { name: 'Iceland' })).toBeInTheDocument();
  });

  it('renders the breadcrumb slot before the heading', () => {
    render(<CollectionHeader title="Iceland" breadcrumb={<a href="/">Home</a>} />);
    expect(screen.getByRole('link', { name: 'Home' })).toBeInTheDocument();
  });
});
```

- [ ] **Step 7 — Run it; verify it fails:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/CollectionHeader.test.tsx
```
Expected: FAIL — `Cannot find module '@/app/components/ui/CollectionHeader/CollectionHeader'`.

- [ ] **Step 8 — Implement `app/components/ui/CollectionHeader/CollectionHeader.tsx`** (server-friendly; uses `next/image` with `fill` for the optional cover, matching `LocationPage`'s pattern). This also resolves review §2 — a person page that today shows only "2 photos" gains a real name `<h1>`:

```tsx
import Image from 'next/image';
import { type ReactNode } from 'react';

import styles from './CollectionHeader.module.scss';

export interface CollectionHeaderCover {
  src: string;
  /** Optional override for the cover sizes attribute. */
  sizes?: string;
}

export interface CollectionHeaderProps {
  title: string;
  /** Photo count; rendered as "N photo(s)". Omitted when undefined. */
  count?: number;
  /** Optional cover thumbnail (location pages). Alt text is the title. */
  cover?: CollectionHeaderCover;
  /** Optional breadcrumb / "up to parent" affordance, rendered above the title. */
  breadcrumb?: ReactNode;
}

/**
 * Canonical page header: title (real <h1>) + optional count + optional cover
 * thumbnail + optional breadcrumb slot. Replaces the bespoke .pageHeader blocks
 * across taxonomy / location / admin / metadata pages and gives every page a
 * real heading (review §2 — taxonomy pages lacked an orienting name).
 */
export function CollectionHeader({ title, count, cover, breadcrumb }: CollectionHeaderProps) {
  const info = (
    <div className={styles.info}>
      {breadcrumb && <div className={styles.breadcrumb}>{breadcrumb}</div>}
      <h1 className={styles.title}>{title}</h1>
      {count !== undefined && (
        <span className={styles.count}>
          {count} {count === 1 ? 'photo' : 'photos'}
        </span>
      )}
    </div>
  );

  if (!cover) {
    return <header className={styles.header}>{info}</header>;
  }

  return (
    <header className={`${styles.header} ${styles.withCover}`}>
      <div className={styles.coverWrapper}>
        <Image
          src={cover.src}
          alt={title}
          fill
          sizes={cover.sizes ?? '(min-width: 768px) 240px, 140px'}
          className={styles.cover}
          priority
        />
      </div>
      {info}
    </header>
  );
}

export default CollectionHeader;
```

- [ ] **Step 9 — Implement `app/components/ui/CollectionHeader/CollectionHeader.module.scss`** — consolidate the verified header rules from `TaxonomyPage`/`LocationPage`/`MetadataPage`/admin, all on tokens (replacing the legacy `var(--text-primary, #111)` / `var(--text-secondary, #888)` fallbacks — those now resolve via the Phase 0 alias layer):

```scss
.header {
  padding: var(--space-5) var(--page-padding-mobile);
  margin-bottom: var(--space-4);
  border-bottom: 1px solid var(--color-border);

  @media (width >= 768px) {
    padding: var(--space-6) 0;
    margin-bottom: var(--space-5);
  }
}

.withCover {
  display: flex;
  align-items: flex-start;
  gap: var(--space-4);

  @media (width >= 768px) {
    gap: var(--space-5);
  }
}

.coverWrapper {
  position: relative;
  width: 140px;
  aspect-ratio: 4 / 3;
  overflow: hidden;
  border-radius: var(--radius-1);
  flex-shrink: 0;

  @media (width >= 768px) {
    width: 240px;
  }
}

.cover {
  object-fit: cover;
  object-position: center;
}

.info {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

.breadcrumb {
  font-size: var(--text-sm);
  color: var(--color-fg-muted);
}

.title {
  font-size: var(--text-3xl);
  font-weight: 700;
  margin: 0;
  color: var(--color-fg);
}

.count {
  font-size: var(--text-sm);
  color: var(--color-fg-muted);
  font-weight: 500;
}
```

- [ ] **Step 10 — Run the `CollectionHeader` test; verify it passes:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/CollectionHeader.test.tsx
```
Expected: PASS (6 tests).

- [ ] **Step 11 — Migrate `TaxonomyPage.tsx`** onto the shell + header (deletes its scaffold + bespoke `pageHeader`):

```tsx
import ContentBlockWithFullScreen from '@/app/components/Content/ContentBlockWithFullScreen';
import { CollectionHeader } from '@/app/components/ui/CollectionHeader/CollectionHeader';
import { PageShell } from '@/app/components/ui/PageShell/PageShell';
import { type ContentImageModel } from '@/app/types/Content';
import { processContentBlocks } from '@/app/utils/contentLayout';

interface TaxonomyPageProps {
  entityName: string;
  images: ContentImageModel[];
}

export default function TaxonomyPage({ entityName, images }: TaxonomyPageProps) {
  const contentBlocks = processContentBlocks(images, true);

  return (
    <PageShell>
      <CollectionHeader title={entityName} count={images.length} />
      {contentBlocks.length > 0 && (
        <ContentBlockWithFullScreen
          content={contentBlocks}
          priorityBlockIndex={0}
          enableFullScreenView
          initialPageSize={30}
          chunkSize={4}
        />
      )}
    </PageShell>
  );
}
```
  Then **delete `app/components/TaxonomyPage/TaxonomyPage.module.scss`** (no rules remain referenced).

- [ ] **Step 12 — Migrate `LocationPage.tsx`** onto the shell + header, passing the cover thumbnail through `CollectionHeader`'s `cover` prop (deletes its scaffold + bespoke header CSS):

```tsx
import { CollectionHeader } from '@/app/components/ui/CollectionHeader/CollectionHeader';
import { PageShell } from '@/app/components/ui/PageShell/PageShell';
import { type CollectionModel } from '@/app/types/Collection';
import { type ContentImageModel } from '@/app/types/Content';

import LocationPageClient from './LocationPageClient';

interface LocationPageProps {
  locationName: string;
  collections: CollectionModel[];
  images: ContentImageModel[];
  coverImage: ContentImageModel | null;
}

export default function LocationPage({
  locationName,
  collections,
  images,
  coverImage,
}: LocationPageProps) {
  return (
    <PageShell>
      <CollectionHeader
        title={locationName}
        count={images.length}
        cover={coverImage?.imageUrl ? { src: coverImage.imageUrl } : undefined}
      />
      <LocationPageClient images={images} collections={collections} />
    </PageShell>
  );
}
```
  Then **delete `app/components/LocationPage/LocationPage.module.scss`** (the cover + header rules now live in `CollectionHeader.module.scss`; `LocationPageClient` keeps its own styles).

- [ ] **Step 13 — Migrate `(admin)/comments/page.tsx`** onto the shell. Comments has a custom header (title + total + `contentArea`), so keep a lightweight inline header but drop the `.container`/`.main` scaffold:

```tsx
import { getAdminMessages } from '@/app/lib/api/messages';
import { PageShell } from '@/app/components/ui/PageShell/PageShell';

import styles from './Comments.module.scss';
import { CommentsList } from './CommentsList';

export const dynamic = 'force-dynamic';

export default async function CommentsPage() {
  const data = await getAdminMessages(50, 0);
  const messages = data?.messages ?? [];
  const total = data?.total ?? 0;

  return (
    <PageShell>
      <div className={styles.pageHeader}>
        <h1 className={styles.pageTitle}>Comments</h1>
        <span className={styles.total}>{total} total</span>
      </div>
      <div className={styles.contentArea}>
        <CommentsList initialMessages={messages} initialTotal={total} />
      </div>
    </PageShell>
  );
}
```
  Then in `Comments.module.scss` **delete the `.container` and `.main` rules** (lines 1-21); keep `.pageHeader`, `.pageTitle`, `.contentArea`, `.total`, and the list/row/button rules.

- [ ] **Step 14 — Migrate `(admin)/admin/page.tsx`** onto the shell (keep the bespoke admin `.pageHeader` with its subtitle); delete the `.container`/`.main` rules from `page.module.scss`:

```tsx
import { getAdminHomeTiles } from '@/app/lib/api/adminHome';
import { PageShell } from '@/app/components/ui/PageShell/PageShell';

import AdminHubGrid from './AdminHubGrid';
import { ADMIN_TILES, type AdminTileMerged } from './adminTiles';
import styles from './page.module.scss';

export const dynamic = 'force-dynamic';

export default async function AdminHubPage() {
  const apiTiles = await getAdminHomeTiles().catch(() => []);
  const apiByKey = new Map(apiTiles.map(t => [t.tileKey, t]));

  const tiles: AdminTileMerged[] = ADMIN_TILES.map(config => ({
    ...config,
    coverImageUrl: apiByKey.get(config.tileKey)?.coverImageUrl ?? null,
  }));

  return (
    <PageShell pageType="collectionsCollection">
      <div className={styles.pageHeader}>
        <h1 className={styles.pageTitle}>Admin</h1>
        <span className={styles.subtitle}>local dev console</span>
      </div>
      <AdminHubGrid tiles={tiles} />
    </PageShell>
  );
}
```
  Then in `app/(admin)/admin/page.module.scss` **delete the `.container` and `.main` rules** (lines 5-21); keep `.pageHeader`, `.pageTitle`, `.subtitle`.

- [ ] **Step 15 — Strip the scaffold from `ContentCollectionPage.module.scss` and `MetadataPage.module.scss`.** In `ContentCollectionPage.module.scss` delete the `.container` (lines 6-10) and `.main` (12-29) rules — its consumer renders inside `PageShell` after this task (the `CollectionPageWrapper` migration is tracked in the master plan; here, just remove the now-shared rules and confirm no consumer references `styles.container`/`styles.main` of that module via the grep in Step 17). In `MetadataPage.module.scss` delete `.container` (1-5) and `.main` (7-21) — `MetadataPageClient` is migrated in Task 6 Step 6; for now leave the rest of `MetadataPage.module.scss` intact.

  > If a grep in Step 17 shows a module's `.container`/`.main` is still referenced (e.g. `ContentCollectionPage` is consumed by a wrapper not migrated in this plan), **do not delete those two rules from that module** — instead leave them and note it in the commit body. Only delete rules that are provably unreferenced after the page migrations above. This keeps each commit green.

- [ ] **Step 16 — Migrate `MetadataPageClient.tsx`** onto the shell (the metadata grid keeps its own `.grid` rule; the scaffold + `.pageHeader` move to `PageShell` + `CollectionHeader`). This file is further touched in Task 6 (generic list); here only swap the scaffold:

```tsx
'use client';

import { CollectionHeader } from '@/app/components/ui/CollectionHeader/CollectionHeader';
import { PageShell } from '@/app/components/ui/PageShell/PageShell';
import type { LocationModel } from '@/app/types/Collection';
import type { ContentPersonModel, ContentTagModel } from '@/app/types/ImageMetadata';

import { MetadataLocationList } from './MetadataLocationList';
import styles from './MetadataPage.module.scss';
import { MetadataPersonList } from './MetadataPersonList';
import { MetadataTagList } from './MetadataTagList';

interface MetadataPageClientProps {
  tags: ContentTagModel[];
  people: ContentPersonModel[];
  locations: LocationModel[];
}

export function MetadataPageClient({ tags, people, locations }: MetadataPageClientProps) {
  return (
    <PageShell>
      <CollectionHeader title="Metadata" />
      <div className={styles.grid}>
        <MetadataTagList items={tags} />
        <MetadataPersonList items={people} />
        <MetadataLocationList items={locations} />
      </div>
    </PageShell>
  );
}
```
  Then in `MetadataPage.module.scss` **delete `.pageHeader` (23-31) and `.pageTitle` (33-42)** in addition to the `.container`/`.main` from Step 15 (the header is now `CollectionHeader`). Keep `.grid` and the list rules (the list rules are removed in Task 6).

- [ ] **Step 17 — Verify no dangling scaffold references and run the full migrated-page test surface:**
```bash
grep -rn "styles.container\|styles.main" app/components/TaxonomyPage app/components/LocationPage app/components/MetadataPage app/\(admin\)/admin app/\(admin\)/comments ; echo "exit: $?"
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/PageShell.test.tsx tests/components/ui/CollectionHeader.test.tsx
```
Expected: no `styles.container`/`styles.main` matches in the migrated modules (grep exit 1); tsc clean; both ui tests PASS.

- [ ] **Step 18 — Lint, format, type-check:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write 'app/components/ui/PageShell/**/*' 'app/components/ui/CollectionHeader/**/*' app/components/TaxonomyPage/TaxonomyPage.tsx app/components/LocationPage/LocationPage.tsx app/\(admin\)/admin/page.tsx app/\(admin\)/comments/page.tsx app/components/MetadataPage/MetadataPageClient.tsx tests/components/ui/PageShell.test.tsx tests/components/ui/CollectionHeader.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix 'app/components/ui/PageShell/PageShell.tsx' 'app/components/ui/CollectionHeader/CollectionHeader.tsx' app/components/TaxonomyPage/TaxonomyPage.tsx app/components/LocationPage/LocationPage.tsx 'app/(admin)/admin/page.tsx' 'app/(admin)/comments/page.tsx' app/components/MetadataPage/MetadataPageClient.tsx
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/ui/PageShell/PageShell.module.scss' 'app/components/ui/CollectionHeader/CollectionHeader.module.scss' app/components/MetadataPage/MetadataPage.module.scss 'app/(admin)/admin/page.module.scss' 'app/(admin)/comments/Comments.module.scss' app/components/ContentCollection/ContentCollectionPage.module.scss
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
```
Expected: all clean.

- [ ] **Step 19 — Commit:**
```bash
git add app/components/ui/PageShell app/components/ui/CollectionHeader tests/components/ui/PageShell.test.tsx tests/components/ui/CollectionHeader.test.tsx app/components/TaxonomyPage app/components/LocationPage app/components/MetadataPage 'app/(admin)/admin/page.tsx' 'app/(admin)/admin/page.module.scss' 'app/(admin)/comments/page.tsx' 'app/(admin)/comments/Comments.module.scss' app/components/ContentCollection/ContentCollectionPage.module.scss
git commit -m "feat(ui): add PageShell + CollectionHeader; migrate page scaffolds

Replaces the .container/.main/.pageHeader scaffold copy-pasted across 8 modules
with one PageShell (painted surface + SiteHeader) and one CollectionHeader
(title/count/cover/breadcrumb). Gives taxonomy/location/metadata pages a real
<h1> name (review §2). Deletes the duplicated scaffold SCSS. Fixes review §3/§6a-6.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

**Acceptance** *(review §2, §3 dup catalog)*: TaxonomyPage / LocationPage / admin / comments / MetadataPage all compose `PageShell` (+ `CollectionHeader` where they have a title); the duplicated `.container`/`.main`/`.pageHeader` SCSS is removed; every migrated page renders a real `<h1>`.

---

## Task 3 — `<StatusPage>`: token-driven 404 / error / empty on the painted surface

**Why:** `not-found.tsx` and `error.tsx` render through `layout.module.scss .main` (padding only) with no site chrome, and (before Phase 0) were invisible in OS dark mode (review §1.3, §5 🔴, §3 dup catalog "Status pages"). `error.tsx` also has a bare `<button onClick>` (no `type="button"`) and no home link. `ErrorBoundary` already has the readable pattern (`role="alert"` + `type="button"` retry) — `StatusPage` reuses it on the painted `PageShell` surface.

**Files:**
- Create: `app/components/ui/StatusPage/StatusPage.tsx`, `app/components/ui/StatusPage/StatusPage.module.scss`
- Test: `tests/components/ui/StatusPage.test.tsx`
- Modify: `app/not-found.tsx`, `app/error.tsx`, `app/(admin)/error.tsx`

- [ ] **Step 1 — Write the failing test** `tests/components/ui/StatusPage.test.tsx` (mock `SiteHeader` and `next/link` is real; mock the heavy header to keep the test focused):

```tsx
import { fireEvent, render, screen } from '@testing-library/react';

import { StatusPage } from '@/app/components/ui/StatusPage/StatusPage';

jest.mock('@/app/components/SiteHeader/SiteHeader', () => ({
  __esModule: true,
  default: () => <div data-testid="site-header" />,
  SiteHeader: () => <div data-testid="site-header" />,
}));

describe('StatusPage', () => {
  it('renders the title as an h1 and the message', () => {
    render(<StatusPage title="404 — Not Found" message="That page doesn’t exist." />);
    expect(screen.getByRole('heading', { level: 1, name: '404 — Not Found' })).toBeInTheDocument();
    expect(screen.getByText('That page doesn’t exist.')).toBeInTheDocument();
  });

  it('renders a home link by default', () => {
    render(<StatusPage title="404" message="m" />);
    const home = screen.getByRole('link', { name: /home/i });
    expect(home).toHaveAttribute('href', '/');
  });

  it('renders a retry button (type=button) when onRetry is provided and calls it', () => {
    const onRetry = jest.fn();
    render(<StatusPage title="Error" message="m" onRetry={onRetry} />);
    const btn = screen.getByRole('button', { name: /try again/i });
    expect(btn).toHaveAttribute('type', 'button');
    fireEvent.click(btn);
    expect(onRetry).toHaveBeenCalledTimes(1);
  });

  it('does not render a retry button when onRetry is omitted', () => {
    render(<StatusPage title="404" message="m" />);
    expect(screen.queryByRole('button')).not.toBeInTheDocument();
  });
});
```

- [ ] **Step 2 — Run it; verify it fails:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/StatusPage.test.tsx
```
Expected: FAIL — `Cannot find module '@/app/components/ui/StatusPage/StatusPage'`.

- [ ] **Step 3 — Implement `app/components/ui/StatusPage/StatusPage.tsx`.** It composes `PageShell` (painted surface + header) and the canonical `<Button>` (prerequisite) for retry, plus a `NavLink` home link. It is server-friendly (no hooks); the retry handler is passed in by the caller (`error.tsx` is the client component that owns `reset`):

```tsx
import { type ReactNode } from 'react';

import { Button } from '@/app/components/ui/Button/Button';
import { NavLink } from '@/app/components/ui/NavLink/NavLink';
import { PageShell } from '@/app/components/ui/PageShell/PageShell';

import styles from './StatusPage.module.scss';

export interface StatusPageProps {
  title: string;
  message: string;
  /** Optional detail line (e.g. an error digest). */
  detail?: ReactNode;
  /** When provided, renders a "Try again" button wired to this handler. */
  onRetry?: () => void;
  /** Show the "Return home" link (default true). */
  showHomeLink?: boolean;
  /** Render the SiteHeader chrome (default true). */
  withHeader?: boolean;
}

/**
 * Canonical 404 / error / empty-state page on the painted, dark-safe surface.
 * Reuses ErrorBoundary's readable pattern (role="alert", type=button retry).
 * Replaces the chrome-less, invisible not-found.tsx / error.tsx. Review §5.
 */
export function StatusPage({
  title,
  message,
  detail,
  onRetry,
  showHomeLink = true,
  withHeader = true,
}: StatusPageProps) {
  return (
    <PageShell withHeader={withHeader}>
      <div className={styles.status} role="alert">
        <h1 className={styles.title}>{title}</h1>
        <p className={styles.message}>{message}</p>
        {detail && <p className={styles.detail}>{detail}</p>}
        <div className={styles.actions}>
          {onRetry && (
            <Button type="button" variant="primary" onClick={onRetry}>
              Try again
            </Button>
          )}
          {showHomeLink && <NavLink href="/">Return home</NavLink>}
        </div>
      </div>
    </PageShell>
  );
}

export default StatusPage;
```

- [ ] **Step 4 — Implement `app/components/ui/StatusPage/StatusPage.module.scss`** (tokens only; centered, on the painted surface):

```scss
.status {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: var(--space-4);
  padding: var(--space-8) var(--page-padding-mobile);
  color: var(--color-fg);

  @media (width >= 768px) {
    padding: var(--space-8) var(--page-padding-desktop);
  }
}

.title {
  font-size: var(--text-2xl);
  font-weight: 700;
  margin: 0;
}

.message {
  margin: 0;
  color: var(--color-fg-muted);
  font-size: var(--text-md);
}

.detail {
  margin: 0;
  color: var(--color-fg-muted);
  font-size: var(--text-sm);
}

.actions {
  display: flex;
  align-items: center;
  gap: var(--space-4);
  margin-top: var(--space-2);
}
```

- [ ] **Step 5 — Run the test; verify it passes:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/StatusPage.test.tsx
```
Expected: PASS (4 tests).

- [ ] **Step 6 — Adopt it in `app/not-found.tsx`** (stays a Server Component — no `onRetry`):

```tsx
/**
 * Global 404 Not Found Page
 *
 * Renders when routes fail to resolve or notFound() is called. Uses the
 * canonical StatusPage on the painted, dark-safe surface (review §5).
 */
import { StatusPage } from '@/app/components/ui/StatusPage/StatusPage';

export default function NotFound() {
  return (
    <StatusPage
      title="404 — Not Found"
      message="The page you’re looking for doesn’t exist."
    />
  );
}
```

- [ ] **Step 7 — Adopt it in `app/error.tsx`** (stays a Client Component — it owns `reset`; gains the home link + `type="button"` retry via `StatusPage`):

```tsx
'use client';

import { useEffect } from 'react';

import { StatusPage } from '@/app/components/ui/StatusPage/StatusPage';
import { logger } from '@/app/utils/logger';

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    logger.error('app', 'Unhandled error boundary', error);
  }, [error]);

  return (
    <StatusPage
      title="Something went wrong"
      message="An unexpected error occurred. You can retry, or head back home."
      detail={error?.digest ? `Error ID: ${error.digest}` : undefined}
      onRetry={() => reset()}
    />
  );
}
```

- [ ] **Step 8 — Adopt it in `app/(admin)/error.tsx`** (same shape, admin copy):

```tsx
'use client';

import { useEffect } from 'react';

import { StatusPage } from '@/app/components/ui/StatusPage/StatusPage';
import { logger } from '@/app/utils/logger';

export default function AdminError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    logger.error('admin', 'Unhandled admin error boundary', error);
  }, [error]);

  return (
    <StatusPage
      title="Admin Error — Something went wrong"
      message="An unexpected error occurred in the admin area."
      detail={error?.digest ? `Error ID: ${error.digest}` : undefined}
      onRetry={() => reset()}
    />
  );
}
```

- [ ] **Step 9 — Confirm the legacy `layout.module.scss` rules are now unreferenced** (so they can be removed; if `ErrorBoundary` or another file still imports them, leave them):
```bash
grep -rn "styles/layout.module.scss\|layout.module.scss" app/ ; echo "exit: $?"
```
Expected: no remaining imports from `not-found.tsx`/`error.tsx`/`(admin)/error.tsx`. If `app/styles/layout.module.scss` is now imported by nothing, note it for deletion in the commit; if still imported elsewhere, leave it.

- [ ] **Step 10 — Type-check + run:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write 'app/components/ui/StatusPage/**/*' app/not-found.tsx app/error.tsx 'app/(admin)/error.tsx' tests/components/ui/StatusPage.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix 'app/components/ui/StatusPage/StatusPage.tsx' app/not-found.tsx app/error.tsx 'app/(admin)/error.tsx'
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/ui/StatusPage/StatusPage.module.scss'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/StatusPage.test.tsx
```
Expected: all clean; StatusPage test PASS.

- [ ] **Step 11 — Commit:**
```bash
git add app/components/ui/StatusPage tests/components/ui/StatusPage.test.tsx app/not-found.tsx app/error.tsx 'app/(admin)/error.tsx'
git commit -m "feat(ui): add StatusPage; 404/error adopt it on the painted surface

404 and error pages rendered chrome-less and (pre-Phase-0) invisible in dark
mode. StatusPage reuses ErrorBoundary's readable pattern on PageShell; error.tsx
gains a home link + type=button retry. Fixes review §5.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

**Acceptance** *(review §5)*: `not-found.tsx` / `error.tsx` / `(admin)/error.tsx` render on the painted surface with site chrome; error pages have a home link and a `type="button"` retry; the readable `role="alert"` pattern matches `ErrorBoundary`.

---

## Task 4 — `<Badge>`: promote `BadgeOverlay`, dedupe CSS, curate public labels

**Why:** `.dateBadge`/`.cardTypeBadge` are defined in **both** `globals.css` (lines 223-246) **and** `ContentComponent.module.scss` (lines 160-196) with `BadgeOverlay.tsx` on top (review §3 dup catalog, §6a-rank-7). Worse, `BadgeOverlay` is fed the **raw `CollectionType` enum** via `contentRendererUtils.ts:173` (`cardTypeBadge: content.collectionType`) → visitors see `PARENT` / `PORTFOLIO` (review §1.5, §5 🟡). The fix: one `<Badge>` with `tone` + `position` props; a curated `CollectionType` → public-label map (suppressing internal types); the duplicated CSS removed from both global and module sources.

**Files:**
- Create: `app/components/ui/Badge/Badge.tsx`, `app/components/ui/Badge/Badge.module.scss`
- Test: `tests/components/ui/Badge.test.tsx`
- Modify: `app/components/Content/BadgeOverlay.tsx` (becomes a thin re-export shim for back-compat), `app/components/Content/CollectionContentRenderer.tsx` (render `<Badge>`), `app/utils/contentRendererUtils.ts` (curated label), `app/components/Content/ContentComponent.module.scss` (delete badge rules), `app/styles/globals.css` (delete badge rules)

- [ ] **Step 1 — Write the failing test** `tests/components/ui/Badge.test.tsx`:

```tsx
import { render, screen } from '@testing-library/react';

import { Badge, collectionTypeToPublicLabel } from '@/app/components/ui/Badge/Badge';
import { CollectionType } from '@/app/types/Collection';

describe('Badge', () => {
  it('renders its label', () => {
    render(<Badge label="2024" />);
    expect(screen.getByText('2024')).toBeInTheDocument();
  });

  it('applies tone and position classes', () => {
    render(<Badge label="x" tone="card" position="start" />);
    const el = screen.getByText('x');
    expect(el.className).toMatch(/card/);
    expect(el.className).toMatch(/start/);
  });

  it('renders nothing when label is null', () => {
    const { container } = render(<Badge label={null} />);
    expect(container).toBeEmptyDOMElement();
  });
});

describe('collectionTypeToPublicLabel', () => {
  it('maps public types to curated labels', () => {
    expect(collectionTypeToPublicLabel(CollectionType.ART_GALLERY)).toBe('Gallery');
    expect(collectionTypeToPublicLabel(CollectionType.BLOG)).toBe('Story');
  });

  it('suppresses internal types (PARENT, PORTFOLIO, HOME, CLIENT_GALLERY, MISC)', () => {
    expect(collectionTypeToPublicLabel(CollectionType.PARENT)).toBeNull();
    expect(collectionTypeToPublicLabel(CollectionType.PORTFOLIO)).toBeNull();
    expect(collectionTypeToPublicLabel(CollectionType.HOME)).toBeNull();
    expect(collectionTypeToPublicLabel(CollectionType.CLIENT_GALLERY)).toBeNull();
    expect(collectionTypeToPublicLabel(CollectionType.MISC)).toBeNull();
  });
});
```

- [ ] **Step 2 — Run it; verify it fails:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/Badge.test.tsx
```
Expected: FAIL — `Cannot find module '@/app/components/ui/Badge/Badge'`.

- [ ] **Step 3 — Implement `app/components/ui/Badge/Badge.tsx`** (server-friendly). `tone` distinguishes the old `cardTypeBadge` (start, uppercase) from `dateBadge` (end). The curated label map only surfaces visitor-appropriate types; everything internal returns `null` (badge suppressed):

```tsx
import { type ReactElement } from 'react';

import { CollectionType } from '@/app/types/Collection';

import styles from './Badge.module.scss';

export type BadgeTone = 'card' | 'date';
export type BadgePosition = 'start' | 'end';

export interface BadgeProps {
  /** Text to display. When null, the badge renders nothing. */
  label: string | null;
  /** Visual treatment: `card` (uppercase type chip) or `date`. Default `date`. */
  tone?: BadgeTone;
  /** Corner: `start` (top-left) or `end` (top-right). Defaults from tone. */
  position?: BadgePosition;
}

/**
 * Curated public label for a CollectionType. Internal/organizational types
 * (PARENT, PORTFOLIO, HOME, CLIENT_GALLERY, MISC) return null so they are never
 * surfaced to visitors as a badge (review §1.5). Only visitor-facing types map
 * to a friendly label.
 */
export function collectionTypeToPublicLabel(type: CollectionType): string | null {
  switch (type) {
    case CollectionType.ART_GALLERY:
      return 'Gallery';
    case CollectionType.BLOG:
      return 'Story';
    case CollectionType.PARENT:
    case CollectionType.PORTFOLIO:
    case CollectionType.HOME:
    case CollectionType.CLIENT_GALLERY:
    case CollectionType.MISC:
      return null;
    default:
      return null;
  }
}

/**
 * Canonical overlay badge. Replaces BadgeOverlay + the duplicated
 * .dateBadge/.cardTypeBadge rules in globals.css and ContentComponent.module.scss.
 */
export function Badge({ label, tone = 'date', position }: BadgeProps): ReactElement | null {
  if (label === null) {
    return null;
  }
  const pos: BadgePosition = position ?? (tone === 'card' ? 'start' : 'end');
  const classes = [styles.badge, styles[tone], styles[pos]].filter(Boolean).join(' ');
  return <span className={classes}>{label}</span>;
}

export default Badge;
```

- [ ] **Step 4 — Implement `app/components/ui/Badge/Badge.module.scss`** — the single source of the badge rules lifted from the two duplicated definitions, including the small-card shrink container query (verbatim behavior, tokens preserved):

```scss
.badge {
  position: absolute;
  top: 0;
  background-color: var(--color-badge-bg);
  color: var(--color-white);
  padding: var(--space-2) var(--space-3);
  font-size: var(--text-xs);
  font-weight: 600;
  border-radius: var(--radius-0);
  pointer-events: none;
  z-index: var(--z-overlay);
}

.start {
  left: 0;
}

.end {
  right: 0;
}

.card {
  text-transform: uppercase;
  letter-spacing: 1px;
}

.date {
  letter-spacing: 0.5px;
}

@media (width >= 768px) {
  .badge {
    font-size: 0.8rem;
  }
}

@container (max-width: 300px) {
  .badge {
    padding: 0.375rem 0.5625rem;
    font-size: 0.5625rem;
  }
}
```

- [ ] **Step 5 — Run the Badge test; verify it passes:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/Badge.test.tsx
```
Expected: PASS (5 tests).

- [ ] **Step 6 — Curate the label at the source in `contentRendererUtils.ts`.** Today the COLLECTION branch sets `cardTypeBadge: content.collectionType` (the raw enum). Map it through the curated helper so internal types never reach the renderer. Edit the COLLECTION return (around line 173):

  **Before:**
```tsx
      cardTypeBadge: content.collectionType,
```
  **After** — add the import at the top of the file:
```tsx
import { collectionTypeToPublicLabel } from '@/app/components/ui/Badge/Badge';
```
  and change the field to a curated label (the type stays `string | undefined`, matching `ContentRendererProps.cardTypeBadge`):
```tsx
      cardTypeBadge: collectionTypeToPublicLabel(content.collectionType) ?? undefined,
```

- [ ] **Step 7 — Render `<Badge>` in `CollectionContentRenderer.tsx`.** Replace the `<BadgeOverlay>` usage in `imageWrapperContent` (lines ~469-474):

  **Before:**
```tsx
      {cardTypeBadge && (
        <BadgeOverlay
          contentType={isCollection ? 'collection' : 'content'}
          badgeValue={cardTypeBadge}
        />
      )}
```
  **After** — `cardTypeBadge` is now an already-curated string (or undefined). A collection shows the curated type chip (`tone="card"`); a non-collection date badge keeps `tone="date"`:
```tsx
      {cardTypeBadge && (
        <Badge label={cardTypeBadge} tone={isCollection ? 'card' : 'date'} />
      )}
```
  Update imports: replace `import { BadgeOverlay } from './BadgeOverlay';` with `import { Badge } from '@/app/components/ui/Badge/Badge';`.

- [ ] **Step 8 — Make `BadgeOverlay.tsx` a thin back-compat shim** (any other importers keep working; it now delegates to `<Badge>` and applies the curated map when handed a `CollectionType`). Replace the whole file:

```tsx
import { type ReactElement } from 'react';

import { Badge, collectionTypeToPublicLabel } from '@/app/components/ui/Badge/Badge';
import { CollectionType } from '@/app/types/Collection';

export type BadgeContentType = 'collection' | 'content';

export interface BadgeOverlayProps {
  contentType: BadgeContentType;
  badgeValue: string | CollectionType | null;
}

/**
 * @deprecated Use <Badge> from app/components/ui/Badge directly. Retained as a
 * shim so existing call sites keep compiling; collection values are routed
 * through the curated public-label map (no raw enum reaches visitors).
 */
export function BadgeOverlay({ contentType, badgeValue }: BadgeOverlayProps): ReactElement | null {
  if (badgeValue === null) {
    return null;
  }
  const isCollection = contentType === 'collection';
  const label =
    isCollection && Object.values(CollectionType).includes(badgeValue as CollectionType)
      ? collectionTypeToPublicLabel(badgeValue as CollectionType)
      : String(badgeValue);
  return <Badge label={label} tone={isCollection ? 'card' : 'date'} />;
}

export default BadgeOverlay;
```

- [ ] **Step 9 — Delete the duplicated badge CSS.** In `app/styles/globals.css` **remove** the `.dateBadge` block (lines 222-236) and the `@media (width >= 768px)` block that styles `.cardTypeBadge`/`.dateBadge` (lines 238-246). In `app/components/Content/ContentComponent.module.scss` **remove** the `.imageWrapper .cardTypeBadge, .imageWrapper .dateBadge` rule (160-165), the `.cardTypeBadge` block (167-181), the `.dateBadge` block (183-196), and the `@container (max-width: 300px)` block targeting `.cardTypeBadge, .dateBadge` (273-279). The behavior now lives in `Badge.module.scss`.

  > Keep `.textOverlay`'s own container query (266-270) — it is unrelated to badges.

- [ ] **Step 10 — Verify the duplicates are gone and nothing references the removed classes:**
```bash
grep -n "dateBadge\|cardTypeBadge" app/styles/globals.css app/components/Content/ContentComponent.module.scss ; echo "exit: $?"
grep -rn "cbStyles.dateBadge\|cbStyles.cardTypeBadge" app/ ; echo "exit: $?"
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
```
Expected: no `dateBadge`/`cardTypeBadge` matches in either SCSS file (grep exit 1); no `cbStyles.*Badge` references (the renderer uses `<Badge>` now); tsc clean.

- [ ] **Step 11 — Lint, format, type-check, test:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write 'app/components/ui/Badge/**/*' app/components/Content/BadgeOverlay.tsx app/components/Content/CollectionContentRenderer.tsx app/utils/contentRendererUtils.ts tests/components/ui/Badge.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix 'app/components/ui/Badge/Badge.tsx' app/components/Content/BadgeOverlay.tsx app/components/Content/CollectionContentRenderer.tsx app/utils/contentRendererUtils.ts
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/ui/Badge/Badge.module.scss' app/components/Content/ContentComponent.module.scss app/styles/globals.css
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/Badge.test.tsx
```
Expected: all clean; Badge test PASS.

- [ ] **Step 12 — Commit:**
```bash
git add app/components/ui/Badge tests/components/ui/Badge.test.tsx app/components/Content/BadgeOverlay.tsx app/components/Content/CollectionContentRenderer.tsx app/utils/contentRendererUtils.ts app/components/Content/ContentComponent.module.scss app/styles/globals.css
git commit -m "feat(ui): promote BadgeOverlay to Badge; dedupe CSS; curate public labels

One <Badge> with tone+position replaces .dateBadge/.cardTypeBadge defined twice
(globals.css + ContentComponent.module.scss). CollectionType is mapped to curated
public labels so PARENT/PORTFOLIO/HOME/CLIENT_GALLERY never reach visitors.
Fixes review §1.5 / §5 and the 3-badge duplication.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

**Acceptance** *(review §1.5, §5)*: there is one badge definition (`Badge.module.scss`); a visitor never sees a raw `CollectionType` enum (internal types are suppressed, public types show curated labels); `tone`+`position` props drive placement/treatment.

---

## Task 5 — Form set: `<Field>` + `<Input>`/`<Select>`/`<Textarea>`/`<Checkbox>`/`<FormError>`

**Why:** `formGroup`/`Label`/`Input`/`Select`/`Textarea` are re-declared across `ImageMetadataModal`, `TextBlockCreateModal`, `ContactForm`, and `forms.module.scss` (review §3 dup catalog, §6a-rank-8). Separately, `ContactForm`'s inputs have **no `<label>`** and the success/error status is **not announced** to assistive tech (review §5 🟡). The fix: one token-themed SCSS source + a `Field` wrapper that owns the `<label htmlFor>` association, plus thin `Input`/`Select`/`Textarea`/`Checkbox`/`FormError` controls; `ContactForm` adopts them and gains `role="status"` + `aria-live`.

**Files:**
- Create: `app/components/ui/Field/Field.tsx`, `Input.tsx`, `Select.tsx`, `Textarea.tsx`, `Checkbox.tsx`, `FormError.tsx`, `Field.module.scss`
- Test: `tests/components/ui/Field.test.tsx`
- Modify: `app/components/ContactForm/ContactForm.tsx`, `app/components/ContactForm/ContactForm.module.scss`, `tests/components/ContactForm.test.tsx`

- [ ] **Step 1 — Write the failing test** `tests/components/ui/Field.test.tsx`:

```tsx
import { render, screen } from '@testing-library/react';

import { Checkbox } from '@/app/components/ui/Field/Checkbox';
import { Field } from '@/app/components/ui/Field/Field';
import { FormError } from '@/app/components/ui/Field/FormError';
import { Input } from '@/app/components/ui/Field/Input';
import { Select } from '@/app/components/ui/Field/Select';
import { Textarea } from '@/app/components/ui/Field/Textarea';

describe('Field', () => {
  it('associates the label with the control via htmlFor/id', () => {
    render(
      <Field label="Email" htmlFor="email">
        <Input id="email" type="email" />
      </Field>
    );
    const input = screen.getByLabelText('Email');
    expect(input).toHaveAttribute('type', 'email');
    expect(input).toHaveAttribute('id', 'email');
  });

  it('Input forwards native attributes', () => {
    render(<Input id="i" placeholder="Your email" maxLength={320} />);
    const input = screen.getByPlaceholderText('Your email') as HTMLInputElement;
    expect(input.maxLength).toBe(320);
  });

  it('Textarea renders as a textarea and forwards attributes', () => {
    render(<Textarea id="t" placeholder="Your message" maxLength={5000} />);
    const ta = screen.getByPlaceholderText('Your message') as HTMLTextAreaElement;
    expect(ta.tagName).toBe('TEXTAREA');
    expect(ta.maxLength).toBe(5000);
  });

  it('Select renders options', () => {
    render(
      <Select id="s" aria-label="pick">
        <option value="a">A</option>
      </Select>
    );
    expect(screen.getByRole('combobox', { name: 'pick' })).toBeInTheDocument();
  });

  it('Checkbox renders a checkbox input', () => {
    render(<Checkbox id="c" aria-label="agree" />);
    expect(screen.getByRole('checkbox', { name: 'agree' })).toBeInTheDocument();
  });

  it('FormError renders with role=alert when a message is present', () => {
    render(<FormError>Bad email</FormError>);
    expect(screen.getByRole('alert')).toHaveTextContent('Bad email');
  });

  it('FormError renders nothing when empty', () => {
    const { container } = render(<FormError>{null}</FormError>);
    expect(container).toBeEmptyDOMElement();
  });
});
```

- [ ] **Step 2 — Run it; verify it fails:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/Field.test.tsx
```
Expected: FAIL — `Cannot find module '@/app/components/ui/Field/Field'`.

- [ ] **Step 3 — Implement `app/components/ui/Field/Field.tsx`** (server-friendly wrapper; owns the label association):

```tsx
import { type ReactNode } from 'react';

import styles from './Field.module.scss';

export interface FieldProps {
  label: string;
  /** id of the control this label points at. */
  htmlFor: string;
  /** Optional helper/hint text below the label. */
  hint?: ReactNode;
  children: ReactNode;
  className?: string;
}

/** Labeled form field wrapper. Owns the <label htmlFor> ↔ control association. */
export function Field({ label, htmlFor, hint, children, className }: FieldProps) {
  const classes = [styles.field, className].filter(Boolean).join(' ');
  return (
    <div className={classes}>
      <label className={styles.label} htmlFor={htmlFor}>
        {label}
      </label>
      {hint && <span className={styles.hint}>{hint}</span>}
      {children}
    </div>
  );
}

export default Field;
```

- [ ] **Step 4 — Implement the controls.** `app/components/ui/Field/Input.tsx`:

```tsx
import { type InputHTMLAttributes } from 'react';

import styles from './Field.module.scss';

export type InputProps = InputHTMLAttributes<HTMLInputElement>;

export function Input({ className, type = 'text', ...rest }: InputProps) {
  const classes = [styles.control, styles.input, className].filter(Boolean).join(' ');
  return <input type={type} className={classes} {...rest} />;
}

export default Input;
```

  `app/components/ui/Field/Textarea.tsx`:

```tsx
import { type TextareaHTMLAttributes } from 'react';

import styles from './Field.module.scss';

export type TextareaProps = TextareaHTMLAttributes<HTMLTextAreaElement>;

export function Textarea({ className, ...rest }: TextareaProps) {
  const classes = [styles.control, styles.textarea, className].filter(Boolean).join(' ');
  return <textarea className={classes} {...rest} />;
}

export default Textarea;
```

  `app/components/ui/Field/Select.tsx`:

```tsx
import { type SelectHTMLAttributes } from 'react';

import styles from './Field.module.scss';

export type SelectProps = SelectHTMLAttributes<HTMLSelectElement>;

export function Select({ className, children, ...rest }: SelectProps) {
  const classes = [styles.control, styles.select, className].filter(Boolean).join(' ');
  return (
    <select className={classes} {...rest}>
      {children}
    </select>
  );
}

export default Select;
```

  `app/components/ui/Field/Checkbox.tsx`:

```tsx
import { type InputHTMLAttributes } from 'react';

import styles from './Field.module.scss';

export type CheckboxProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'type'>;

export function Checkbox({ className, ...rest }: CheckboxProps) {
  const classes = [styles.checkbox, className].filter(Boolean).join(' ');
  return <input type="checkbox" className={classes} {...rest} />;
}

export default Checkbox;
```

  `app/components/ui/Field/FormError.tsx`:

```tsx
import { type ReactNode } from 'react';

import styles from './Field.module.scss';

export interface FormErrorProps {
  children: ReactNode;
}

/** Inline form error. Announces via role="alert"; renders nothing when empty. */
export function FormError({ children }: FormErrorProps) {
  if (!children) {
    return null;
  }
  return (
    <p className={styles.error} role="alert">
      {children}
    </p>
  );
}

export default FormError;
```

- [ ] **Step 5 — Implement `app/components/ui/Field/Field.module.scss`** (one token-themed source for all controls):

```scss
.field {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
}

.label {
  font-size: var(--text-sm);
  font-weight: 600;
  color: var(--color-fg);
}

.hint {
  font-size: var(--text-xs);
  color: var(--color-fg-muted);
}

.control {
  font-family: inherit;
  font-size: var(--text-md);
  padding: var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-1);
  background-color: var(--color-bg);
  color: var(--color-fg);

  &::placeholder {
    color: var(--color-fg-muted);
  }

  &:focus-visible {
    outline: 2px solid var(--color-accent);
    outline-offset: 2px;
    border-color: var(--color-fg);
  }
}

.input {
  height: var(--menu-item-height);
}

.textarea {
  resize: none;
  min-height: 8rem;
}

.select {
  appearance: none;
  cursor: pointer;
}

.checkbox {
  width: 1rem;
  height: 1rem;
  accent-color: var(--color-fg);
  cursor: pointer;

  &:focus-visible {
    outline: 2px solid var(--color-accent);
    outline-offset: 2px;
  }
}

.error {
  margin: 0;
  font-size: var(--text-sm);
  color: var(--color-danger);
}
```

- [ ] **Step 6 — Run the Field test; verify it passes:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/Field.test.tsx
```
Expected: PASS (7 tests).

- [ ] **Step 7 — Migrate `ContactForm.tsx`** onto `Field`/`Input`/`Textarea`/`Button`, adding real labels and an `aria-live` status region. Keep the existing placeholders, `name`s, `maxLength`s, char-counter, disabled logic, and `onSubmit`/`onBack` props exactly (the existing test depends on `getByPlaceholderText`, `getByRole('form')`, `getByRole('button', { name: /send/i })`, and the `4499/4501 / 5000` counter). Replace the body:

```tsx
'use client';

import { type FormEvent, useState } from 'react';

import { Button } from '@/app/components/ui/Button/Button';
import { Field } from '@/app/components/ui/Field/Field';
import { Input } from '@/app/components/ui/Field/Input';
import { Textarea } from '@/app/components/ui/Field/Textarea';
import { type ContactResult, submitContactMessage } from '@/app/utils/contactApi';

import styles from './ContactForm.module.scss';

type Status = 'idle' | 'submitting' | 'success' | 'error';

interface ContactFormProps {
  onBack: () => void;
  onSubmit: () => void;
}

export function ContactForm({ onBack: _onBack, onSubmit }: ContactFormProps) {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState<Status>('idle');
  const [errorResult, setErrorResult] = useState<Extract<ContactResult, { ok: false }> | null>(
    null
  );

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus('submitting');
    setErrorResult(null);

    const result = await submitContactMessage({ email, message });

    if (result.ok) {
      setEmail('');
      setMessage('');
      setStatus('success');
      onSubmit();
    } else {
      setStatus('error');
      setErrorResult(result);
    }
  };

  return (
    <div className={styles.contactFormContainer}>
      <div className={styles.formWrapper}>
        <div className={styles.statusRegion} role="status" aria-live="polite">
          {status === 'success' && (
            <div className={`${styles.statusBanner} ${styles.statusBannerSuccess}`}>
              Message sent!
            </div>
          )}
          {status === 'error' && errorResult && (
            <div className={`${styles.statusBanner} ${styles.statusBannerError}`}>
              {errorResult.message}
            </div>
          )}
        </div>
        <form aria-label="contact form" className={styles.contactForm} onSubmit={handleSubmit}>
          <Field label="Email" htmlFor="contact-email">
            <Input
              id="contact-email"
              type="email"
              name="email"
              placeholder="Your email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              maxLength={320}
              required
            />
          </Field>
          <Field label="Message" htmlFor="contact-message" className={styles.messageField}>
            <Textarea
              id="contact-message"
              name="message"
              placeholder="Your message"
              className={styles.messageTextarea}
              value={message}
              onChange={e => setMessage(e.target.value)}
              maxLength={5000}
              required
            />
          </Field>
          <small
            className={`${styles.charCounter} ${message.length > 4500 ? styles.charCounterWarn : ''}`}
          >
            {message.length} / 5000
          </small>
          <Button
            type="submit"
            variant="primary"
            loading={status === 'submitting'}
            disabled={message.length === 0 || message.length > 5000}
          >
            {status === 'submitting' ? 'Sending...' : 'Send'}
          </Button>
        </form>
      </div>
    </div>
  );
}
```

  > **Test impact:** the existing `ContactForm.test.tsx` queries the button by `name: /sending/i` while submitting and expects it disabled — `<Button loading>` sets `disabled` + `aria-busy`, and the visible text is still "Sending...", so `getByRole('button', { name: /sending/i })` still resolves. The `name: /^send$/i` idle query still matches "Send". No assertion change is required for those, **but** the success/error text now lives inside a `role="status"` region — update the test (Step 8) to keep `queryByRole('link')` assertions valid (the status region is not a link) and to assert the new `aria-live` region.

- [ ] **Step 8 — Update `tests/components/ContactForm.test.tsx`** to cover the new labels + live region (additive; do not weaken existing assertions). Add these two tests inside the `describe('ContactForm', …)` block:

```tsx
  it('associates labels with the email and message controls', () => {
    render(<ContactForm {...defaultProps} />);
    expect(screen.getByLabelText('Email')).toHaveAttribute('type', 'email');
    expect(screen.getByLabelText('Message').tagName).toBe('TEXTAREA');
  });

  it('renders an aria-live status region', () => {
    render(<ContactForm {...defaultProps} />);
    expect(screen.getByRole('status')).toBeInTheDocument();
  });
```

  > The existing `getByPlaceholderText('Your email')` / `getByPlaceholderText('Your message')` queries still pass because the placeholders are unchanged. The `getByRole('form')` query still passes (`aria-label="contact form"` is preserved). The success-banner text `'Message sent!'` is still queryable by `getByText`.

- [ ] **Step 9 — Trim `ContactForm.module.scss`.** The `.emailInput`/`.messageTextarea`/`.submitButton`/`.statusBanner*` input styling now comes from `Field.module.scss` + `<Button>`. Keep the layout (`.contactFormContainer`, `.formWrapper`, `.contactForm`, `.charCounter`, `.charCounterWarn`, `.statusBanner*` for the banner color), add a `.statusRegion` and `.messageField`/`.messageTextarea` for the flex-grow textarea, and **delete** `.emailInput` and `.submitButton` (now unused). Replace the file with:

```scss
/*
  ContactForm layout styles. Field controls + the submit button now come from
  the shared Field set and <Button>; this module only owns layout + the status
  banner colors + the char counter.
*/

.contactFormContainer {
  display: flex;
  flex-direction: column;
  padding-top: var(--space-4);

  @media (width >= 768px) {
    padding-top: var(--default-padding);
  }
}

.formWrapper {
  flex: 1;
  display: flex;
  flex-direction: column;
  width: 100%;
  height: calc(100vh - 15rem);
  overflow-y: auto;
}

.statusRegion {
  min-height: 0;
}

.contactForm {
  display: flex;
  flex-direction: column;
  height: 100%;
  gap: var(--default-padding);
  padding-bottom: 5px;
}

.messageField {
  flex: 1;
}

.messageTextarea {
  flex: 1;
  min-height: 360px;
}

.statusBanner {
  padding: var(--space-2);
  border-radius: var(--radius-1);
  font-size: var(--text-md);
  margin-bottom: var(--space-2);
}

.statusBannerSuccess {
  background-color: #f0fdf4;
  color: var(--color-success-dark);
  border: 1px solid var(--color-success);
}

.statusBannerError {
  background-color: var(--color-error-bg);
  color: var(--color-error-text);
  border: 1px solid var(--color-error-border);

  a {
    color: var(--color-error-text);
    font-weight: 500;
  }
}

.charCounter {
  align-self: flex-end;
  font-size: var(--text-sm);
  color: var(--color-fg-muted);
  margin-top: calc(var(--space-2) * -1);
}

.charCounterWarn {
  color: var(--color-error-text, #c00);
}
```

- [ ] **Step 10 — Run the ContactForm test + Field test; verify both pass:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ContactForm.test.tsx tests/components/ui/Field.test.tsx
```
Expected: PASS (existing ContactForm tests + 2 new ones; 7 Field tests).

- [ ] **Step 11 — Lint, format, type-check:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write 'app/components/ui/Field/**/*' app/components/ContactForm/ContactForm.tsx app/components/ContactForm/ContactForm.module.scss tests/components/ui/Field.test.tsx tests/components/ContactForm.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix 'app/components/ui/Field/'*.tsx app/components/ContactForm/ContactForm.tsx
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/ui/Field/Field.module.scss' app/components/ContactForm/ContactForm.module.scss
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
```
Expected: all clean.

- [ ] **Step 12 — Commit:**
```bash
git add app/components/ui/Field tests/components/ui/Field.test.tsx app/components/ContactForm/ContactForm.tsx app/components/ContactForm/ContactForm.module.scss tests/components/ContactForm.test.tsx
git commit -m "feat(ui): add Field form set; ContactForm gains labels + aria-live status

One token-themed Field/Input/Select/Textarea/Checkbox/FormError set replaces the
parallel form scaffolding. ContactForm now has real <label htmlFor> associations
and a role=status / aria-live region announcing success/error. Fixes review §5 a11y.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

**Acceptance** *(review §5 a11y)*: `ContactForm` inputs are labeled (queryable via `getByLabelText`); status is announced via `role="status"` + `aria-live="polite"`; the shared `Field` set is the one form-control SCSS source.

---

## Task 6 — `MetadataList<T>`: collapse the 3 lists; move `/metadata` behind auth

**Why:** `MetadataTagList`, `MetadataPersonList`, and `MetadataLocationList` are ~95% identical — same state (`items`/`editedNames`/`error`/`saving`), same `handleNameChange`/`handleUpdate`/`handleDelete`/`isEdited`, same JSX (review §3 dup catalog). The only differences: the type, the API path segment (`tags`/`people`/`locations`), the section title + empty label, and an optional "go to" link (`/people/[slug]` and `/location/[slug]`; tags have none). Separately, `/metadata` lives at `app/metadata/page.tsx` (top-level) and is gated only by being `force-dynamic` — `proxy.ts` does **not** match `/metadata`, so it is a fully public, unguarded CRUD screen (review §5 🟠). The fix: one generic `MetadataList<T extends { id: number; name: string; slug?: string }>` and move the route into the `(admin)` group + the proxy matcher.

**Files:**
- Create: `app/components/ui/MetadataList/MetadataList.tsx`, `app/components/ui/MetadataList/MetadataList.module.scss`
- Test: `tests/components/ui/MetadataList.test.tsx`
- Modify: `app/components/MetadataPage/MetadataPageClient.tsx`; delete `MetadataTagList.tsx`/`MetadataPersonList.tsx`/`MetadataLocationList.tsx`
- Move: `app/metadata/page.tsx` → `app/(admin)/metadata/page.tsx`; modify `proxy.ts`

- [ ] **Step 1 — Write the failing test** `tests/components/ui/MetadataList.test.tsx`. It mocks the admin API helpers and asserts the generic list renders, edits, updates, and deletes; and that a `getHref` prop produces a "go to" link:

```tsx
import { fireEvent, render, screen, waitFor } from '@testing-library/react';

import { MetadataList } from '@/app/components/ui/MetadataList/MetadataList';
import * as core from '@/app/lib/api/core';

jest.mock('@/app/lib/api/core');

const mockPut = core.fetchAdminPutJsonApi as jest.MockedFunction<typeof core.fetchAdminPutJsonApi>;
const mockDelete = core.fetchAdminDeleteApi as jest.MockedFunction<typeof core.fetchAdminDeleteApi>;

interface Item {
  id: number;
  name: string;
  slug?: string;
}

const items: Item[] = [
  { id: 1, name: 'forest', slug: 'forest' },
  { id: 2, name: 'river', slug: 'river' },
];

describe('MetadataList', () => {
  beforeEach(() => jest.clearAllMocks());

  it('renders the title, count, and one row per item', () => {
    render(<MetadataList title="Tags" emptyLabel="No tags" items={items} basePath="/metadata/tags" />);
    expect(screen.getByRole('heading', { level: 2, name: 'Tags' })).toBeInTheDocument();
    expect(screen.getByText('2')).toBeInTheDocument();
    expect(screen.getAllByRole('textbox')).toHaveLength(2);
  });

  it('shows the empty label when there are no items', () => {
    render(<MetadataList title="Tags" emptyLabel="No tags" items={[]} basePath="/metadata/tags" />);
    expect(screen.getByText('No tags')).toBeInTheDocument();
  });

  it('PUTs the new name on Update and replaces the row', async () => {
    mockPut.mockResolvedValue({ id: 1, name: 'woods', slug: 'woods' });
    render(<MetadataList title="Tags" emptyLabel="No tags" items={items} basePath="/metadata/tags" />);

    const firstInput = screen.getAllByRole('textbox')[0];
    fireEvent.change(firstInput, { target: { value: 'woods' } });
    fireEvent.click(screen.getByRole('button', { name: /update/i }));

    await waitFor(() => expect(mockPut).toHaveBeenCalledWith('/metadata/tags/1', { name: 'woods' }));
  });

  it('DELETEs after confirm and removes the row', async () => {
    jest.spyOn(window, 'confirm').mockReturnValue(true);
    mockDelete.mockResolvedValue(undefined);
    render(<MetadataList title="Tags" emptyLabel="No tags" items={items} basePath="/metadata/tags" />);

    fireEvent.click(screen.getAllByRole('button', { name: /delete/i })[0]);
    await waitFor(() => expect(mockDelete).toHaveBeenCalledWith('/metadata/tags/1'));
  });

  it('renders a go-to link when getHref is provided', () => {
    render(
      <MetadataList
        title="People"
        emptyLabel="No people"
        items={items}
        basePath="/metadata/people"
        getHref={item => `/people/${item.slug}`}
      />
    );
    const link = screen.getAllByRole('link')[0];
    expect(link).toHaveAttribute('href', '/people/forest');
  });
});
```

- [ ] **Step 2 — Run it; verify it fails:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/MetadataList.test.tsx
```
Expected: FAIL — `Cannot find module '@/app/components/ui/MetadataList/MetadataList'`.

- [ ] **Step 3 — Implement `app/components/ui/MetadataList/MetadataList.tsx`** (`'use client'`; generic over the item shape; `basePath` replaces the per-list endpoint, `getHref` replaces the optional go-to link). Uses the shared `Button` for actions:

```tsx
'use client';

import Link from 'next/link';
import { useState } from 'react';

import { Button } from '@/app/components/ui/Button/Button';
import { fetchAdminDeleteApi, fetchAdminPutJsonApi } from '@/app/lib/api/core';

import styles from './MetadataList.module.scss';

export interface MetadataListItem {
  id: number;
  name: string;
  slug?: string;
}

export interface MetadataListProps<T extends MetadataListItem> {
  title: string;
  emptyLabel: string;
  items: T[];
  /** REST base for PUT/DELETE, e.g. "/metadata/tags". Item id is appended. */
  basePath: string;
  /** Optional "go to" target for an item (e.g. /people/[slug]). */
  getHref?: (item: T) => string | null;
}

/**
 * Generic editable metadata list (tags / people / locations). Collapses the
 * three ~95%-identical Metadata*List components into one. Review §3.
 */
export function MetadataList<T extends MetadataListItem>({
  title,
  emptyLabel,
  items: initialItems,
  basePath,
  getHref,
}: MetadataListProps<T>) {
  const [items, setItems] = useState<T[]>(initialItems);
  const [editedNames, setEditedNames] = useState<Record<number, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState<number | null>(null);

  const handleNameChange = (id: number, value: string) => {
    setEditedNames(prev => ({ ...prev, [id]: value }));
  };

  const clearEdit = (id: number) => {
    setEditedNames(prev => {
      const next = { ...prev };
      delete next[id];
      return next;
    });
  };

  const handleUpdate = async (item: T) => {
    const newName = editedNames[item.id]?.trim();
    if (!newName || saving !== null) return;

    setError(null);
    setSaving(item.id);
    try {
      const response = await fetchAdminPutJsonApi<T>(`${basePath}/${item.id}`, { name: newName });
      if (response !== null) {
        setItems(prev => prev.map(i => (i.id === item.id ? response : i)));
        clearEdit(item.id);
      } else {
        setError(`Failed to update '${item.name}'`);
      }
    } catch {
      setError(`Failed to update '${item.name}'`);
    } finally {
      setSaving(null);
    }
  };

  const handleDelete = async (item: T) => {
    if (!window.confirm(`Delete '${item.name}'?`) || saving !== null) return;

    setError(null);
    setSaving(item.id);
    try {
      await fetchAdminDeleteApi(`${basePath}/${item.id}`);
      setItems(prev => prev.filter(i => i.id !== item.id));
      clearEdit(item.id);
    } catch {
      setError(`Failed to delete '${item.name}'`);
    } finally {
      setSaving(null);
    }
  };

  const isEdited = (item: T) => {
    const edited = editedNames[item.id];
    return edited !== undefined && edited.trim() !== item.name;
  };

  return (
    <div className={styles.listSection}>
      <div className={styles.listHeader}>
        <h2 className={styles.listTitle}>{title}</h2>
        <span className={styles.listCount}>{items.length}</span>
      </div>

      {items.length === 0 ? (
        <p className={styles.emptyState}>{emptyLabel}</p>
      ) : (
        <div className={styles.list}>
          {items.map(item => {
            const href = getHref?.(item) ?? null;
            return (
              <div key={item.id} className={styles.row}>
                {href && (
                  <Link href={href} className={styles.goToLink} title={`Go to ${item.name}`}>
                    &rarr;
                  </Link>
                )}
                <input
                  type="text"
                  className={styles.itemNameInput}
                  value={editedNames[item.id] ?? item.name}
                  onChange={e => handleNameChange(item.id, e.target.value)}
                />
                <div className={styles.rowActions}>
                  {isEdited(item) && (
                    <Button
                      type="button"
                      variant="secondary"
                      size="sm"
                      loading={saving === item.id}
                      disabled={saving !== null}
                      onClick={() => handleUpdate(item)}
                    >
                      Update
                    </Button>
                  )}
                  <Button
                    type="button"
                    variant="danger"
                    size="sm"
                    disabled={saving !== null}
                    onClick={() => handleDelete(item)}
                  >
                    Delete
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {error && <p className={styles.error}>{error}</p>}
    </div>
  );
}

export default MetadataList;
```

- [ ] **Step 4 — Implement `app/components/ui/MetadataList/MetadataList.module.scss`** — lift the row/list rules from `MetadataPage.module.scss` (tokens; the legacy `var(--text-*, #…)` fallbacks resolve via the Phase 0 alias layer, but use the canonical tokens directly here):

```scss
.listSection {
  display: flex;
  flex-direction: column;
}

.listHeader {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  padding-bottom: var(--space-2);
  margin-bottom: var(--space-3);
  border-bottom: 1px solid var(--color-border);
}

.listTitle {
  font-size: var(--text-md);
  font-weight: 600;
  margin: 0;
  color: var(--color-fg);
}

.listCount {
  font-size: var(--text-sm);
  color: var(--color-fg-muted);
  font-weight: 400;
}

.list {
  display: flex;
  flex-direction: column;
  max-height: 60vh;
  overflow-y: auto;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-1);
}

.row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: var(--space-2) var(--space-3);
  border-bottom: 1px solid var(--color-border);

  &:last-child {
    border-bottom: none;
  }

  &:hover {
    background: var(--color-overlay-soft);
  }
}

.goToLink {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  width: 24px;
  height: 24px;
  border-radius: var(--radius-1);
  color: var(--color-fg-muted);
  text-decoration: none;
  font-size: var(--text-sm);
  transition:
    color 0.15s,
    background-color 0.15s;

  &:hover {
    color: var(--color-accent);
    background: var(--color-overlay-soft);
  }
}

.itemNameInput {
  font-size: var(--text-sm);
  color: var(--color-fg);
  background: transparent;
  border: 1px solid transparent;
  border-radius: var(--radius-1);
  padding: var(--space-1);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  flex: 1;
  min-width: 0;
  font-family: inherit;
  transition:
    border-color 0.15s,
    background-color 0.15s;

  &:hover {
    border-color: var(--color-border);
  }

  &:focus-visible {
    outline: 2px solid var(--color-accent);
    outline-offset: 2px;
    border-color: var(--color-fg-muted);
  }
}

.rowActions {
  display: flex;
  align-items: center;
  flex-shrink: 0;
  gap: var(--space-1);
  margin-left: var(--space-2);
}

.error {
  margin-top: var(--space-2);
  padding: var(--space-2) var(--space-3);
  font-size: var(--text-xs);
  color: var(--color-danger);
  background: var(--color-overlay-soft);
  border-radius: var(--radius-1);
}

.emptyState {
  padding: var(--space-4);
  text-align: center;
  color: var(--color-fg-muted);
  font-size: var(--text-sm);
}
```

- [ ] **Step 5 — Run the MetadataList test; verify it passes:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/MetadataList.test.tsx
```
Expected: PASS (5 tests).

- [ ] **Step 6 — Rewire `MetadataPageClient.tsx`** to the generic list (this supersedes the Task 2 Step 16 version), and **delete** the three old list components:

```tsx
'use client';

import { CollectionHeader } from '@/app/components/ui/CollectionHeader/CollectionHeader';
import { MetadataList } from '@/app/components/ui/MetadataList/MetadataList';
import { PageShell } from '@/app/components/ui/PageShell/PageShell';
import type { LocationModel } from '@/app/types/Collection';
import type { ContentPersonModel, ContentTagModel } from '@/app/types/ImageMetadata';

import styles from './MetadataPage.module.scss';

interface MetadataPageClientProps {
  tags: ContentTagModel[];
  people: ContentPersonModel[];
  locations: LocationModel[];
}

export function MetadataPageClient({ tags, people, locations }: MetadataPageClientProps) {
  return (
    <PageShell>
      <CollectionHeader title="Metadata" />
      <div className={styles.grid}>
        <MetadataList title="Tags" emptyLabel="No tags" items={tags} basePath="/metadata/tags" />
        <MetadataList
          title="People"
          emptyLabel="No people"
          items={people}
          basePath="/metadata/people"
          getHref={item => (item.slug ? `/people/${item.slug}` : null)}
        />
        <MetadataList
          title="Locations"
          emptyLabel="No locations"
          items={locations}
          basePath="/metadata/locations"
          getHref={item => (item.slug ? `/location/${item.slug}` : null)}
        />
      </div>
    </PageShell>
  );
}
```
  Then:
```bash
git rm app/components/MetadataPage/MetadataTagList.tsx app/components/MetadataPage/MetadataPersonList.tsx app/components/MetadataPage/MetadataLocationList.tsx
```
  And in `MetadataPage.module.scss` **delete** the now-unused list rules (`.listSection`, `.listHeader`, `.listTitle`, `.listCount`, `.list`, `.row`, `.goToLink`, `.itemNameInput`, `.rowActions`, `.updateButton`, `.deleteButton`, `.error`, `.emptyState` — lines 57-226), keeping only `.grid` (the page header/scaffold rules were already removed in Task 2 Steps 15-16).

- [ ] **Step 7 — Move `/metadata` into the `(admin)` group.** The `(admin)` route group does not change the URL (`/metadata` stays `/metadata`), but co-locating it under `(admin)` gives it the admin `error.tsx` and groups it logically. Move the page:
```bash
mkdir -p 'app/(admin)/metadata'
git mv app/metadata/page.tsx 'app/(admin)/metadata/page.tsx'
rmdir app/metadata 2>/dev/null || true
```
  The page's import of `@/app/components/MetadataPage/MetadataPageClient` is an absolute alias, so it needs no change.

- [ ] **Step 8 — Gate `/metadata` in `proxy.ts`.** Add it to the `isAdminRoute` predicate and the matcher so it gets the same protection as `/comments` (allowed in local; flag + auth in prod). Edit the predicate (after the `/comments` clause, ~line 56):

  **Before:**
```ts
  const isAdminRoute =
    pathname === '/collection/manage' ||
    pathname.startsWith('/collection/manage/') ||
    /\/collection\/.+\/edit$/.test(pathname) ||
    pathname === '/comments' ||
    pathname.startsWith('/comments/');
```
  **After:**
```ts
  const isAdminRoute =
    pathname === '/collection/manage' ||
    pathname.startsWith('/collection/manage/') ||
    /\/collection\/.+\/edit$/.test(pathname) ||
    pathname === '/comments' ||
    pathname.startsWith('/comments/') ||
    pathname === '/metadata' ||
    pathname.startsWith('/metadata/');
```
  And add to the `config.matcher` array (after the `/comments/:path*` entry):
```ts
    '/metadata',
    '/metadata/:path*',
```

- [ ] **Step 9 — Verify the move, the gate, and that nothing references the deleted list components:**
```bash
test -f 'app/(admin)/metadata/page.tsx' && echo "moved OK" || echo "MOVE FAILED"
test -e app/metadata && echo "WARN old app/metadata still present" || echo "old route removed OK"
grep -rn "MetadataTagList\|MetadataPersonList\|MetadataLocationList" app/ ; echo "exit: $?"   # expect no matches
grep -n "'/metadata'" proxy.ts                                                                 # expect predicate + matcher entries
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
```
Expected: `moved OK`; `old route removed OK`; no references to the deleted components (grep exit 1); `/metadata` present in proxy.ts; tsc clean.

- [ ] **Step 10 — Lint, format, type-check, full metadata test surface:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write 'app/components/ui/MetadataList/**/*' app/components/MetadataPage/MetadataPageClient.tsx app/components/MetadataPage/MetadataPage.module.scss 'app/(admin)/metadata/page.tsx' proxy.ts tests/components/ui/MetadataList.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix 'app/components/ui/MetadataList/MetadataList.tsx' app/components/MetadataPage/MetadataPageClient.tsx 'app/(admin)/metadata/page.tsx' proxy.ts
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/ui/MetadataList/MetadataList.module.scss' app/components/MetadataPage/MetadataPage.module.scss
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/MetadataList.test.tsx
```
Expected: all clean; MetadataList test PASS.

- [ ] **Step 11 — Commit:**
```bash
git add app/components/ui/MetadataList tests/components/ui/MetadataList.test.tsx app/components/MetadataPage/MetadataPageClient.tsx app/components/MetadataPage/MetadataPage.module.scss 'app/(admin)/metadata/page.tsx' proxy.ts
git commit -m "feat(ui): generic MetadataList; move /metadata behind admin auth

Collapses the 3 near-identical Metadata{Tag,Person,Location}List components into
one generic MetadataList<T> (basePath + getHref). Moves the unguarded /metadata
CRUD route into the (admin) group and gates it in proxy.ts like /comments.
Fixes review §3 / §5.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

**Acceptance** *(review §3, §5)*: one `MetadataList<T>` renders tags/people/locations (the three old components are deleted); `/metadata` is no longer reachable in non-local environments without admin auth (proxy returns 401/403); editing/deleting still works via `basePath`.

---

## Verification (run after each task; full pass before any PR)

```bash
cd /Users/themancalledzac/Code/edens.zac
# Format → lint → type-check → test (project pipeline, per CLAUDE.md; npm/npx not on PATH)
/opt/homebrew/bin/node node_modules/.bin/prettier --write <touched files>
/opt/homebrew/bin/node node_modules/.bin/eslint --fix <touched .ts/.tsx>
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix '<touched .scss>'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest
```

**Full suite (before PR):**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest
```
Expected: all existing tests + the 8 new `tests/components/ui/*.test.tsx` files PASS; no decrease in count.

**Visual (dev server :3001 — user keeps :3000):**
- Task 1: collection tiles middle-click / cmd-click open in a new tab; right-click → "Open in new tab" works; Tab focuses a tile and Enter navigates; fullscreen still opens on image tiles.
- Task 2: TaxonomyPage / LocationPage / `/metadata` / admin / comments all render with the painted surface + a real `<h1>`; a person page shows the person's name, not just "2 photos".
- Task 3: visit `/this-route-does-not-exist` → 404 renders on the painted surface with site chrome + a "Return home" link; trigger an error → retry button + home link present.
- Task 4: a PARENT/PORTFOLIO collection tile shows **no** badge (suppressed); an ART_GALLERY tile shows "Gallery"; date badges still render top-right.
- Task 5: ContactForm fields are labeled; submitting announces "Message sent!" / the error via the live region.
- Task 6: in a non-local env, `/metadata` redirects/401s; locally it renders the three editable lists.

---

## Suggested commit sequence

1. `feat(ui): add Tile/NavLink primitives; migrate collection tiles to real <a>` (Task 1)
2. `feat(ui): add PageShell + CollectionHeader; migrate page scaffolds` (Task 2)
3. `feat(ui): add StatusPage; 404/error adopt it on the painted surface` (Task 3)
4. `feat(ui): promote BadgeOverlay to Badge; dedupe CSS; curate public labels` (Task 4)
5. `feat(ui): add Field form set; ContactForm gains labels + aria-live status` (Task 5)
6. `feat(ui): generic MetadataList; move /metadata behind admin auth` (Task 6)

Each commit passes `tsc --noEmit` + `jest` independently. Tasks 1, 3, 4, 5 are mutually independent and can be done in any order or in parallel (Agent Teams: one agent per primitive); Task 2 should land before Task 6 (the MetadataPageClient migration in Task 6 builds on the PageShell/CollectionHeader from Task 2).

---

## Self-review: spec-coverage checklist

Maps every Phase 2 task to its design-review finding. Gaps flagged explicitly.

| Review section / finding | Plan task | Status |
|--------------------------|-----------|--------|
| §1.2 / §1.4 / §5 🔴 — tiles are non-link `div onClick`+`router.push`; no SEO / new-tab / keyboard | Task 1 (`Tile`/`NavLink`) | ✅ |
| §3 dup / §6a-6 — `.container/.main/.pageHeader` copy-pasted across 8 modules | Task 2 (`PageShell`/`CollectionHeader`) | ✅ |
| §2 — taxonomy/person pages lack an orienting name (person page shows only "2 photos") | Task 2 (`CollectionHeader` real `<h1>`) | ✅ |
| §5 🔴 / §3 dup — 404/error chrome-less + (pre-Phase-0) invisible; `error.tsx` bare button, no home link | Task 3 (`StatusPage`) | ✅ |
| §1.5 / §5 🟡 — public `CollectionType` leaked as a badge (`PARENT`/`PORTFOLIO`) | Task 4 (`Badge` curated label map) | ✅ |
| §3 dup / §6a-7 — 3 badge definitions (`globals.css` + `ContentComponent.module.scss` + `BadgeOverlay`) | Task 4 (dedupe to `Badge.module.scss`) | ✅ |
| §3 dup / §6a-8 — parallel form scaffolding (ImageMetadataModal/TextBlockCreateModal/ContactForm/forms) | Task 5 (`Field` set) | ✅ (ContactForm migrated; modal/textblock forms tracked in master Phase 1.2/1.4) |
| §5 🟡 — ContactForm inputs have no labels; status not announced | Task 5 (`<label htmlFor>` + `role=status`/`aria-live`) | ✅ |
| §3 — `Metadata{Tag,Person,Location}List` ~95% identical | Task 6 (`MetadataList<T>`) | ✅ |
| §5 🟠 — `/metadata` unguarded public CRUD | Task 6 (move to `(admin)` + proxy gate) | ✅ |
| §6a-5 — `NavLink`/`Tile` always a real `<a>` | Task 1 | ✅ |
| Prerequisite: §1.1/§5 painted surface; §5 FsDebug/dead-link cleanup; §6a-2 Button | master plan Phase 0 + Task 1.1 | ⛓ prereq |

**Out of this plan's scope (tracked elsewhere, not gaps):**
- Modal/Filter/Dropdown primitives (§6a ranks 1/3/4) — master plan Tasks 1.2-1.4.
- The full `Field` migration of `ImageMetadataModal` / `TextBlockCreateModal` forms — those modals are migrated alongside the Modal primitive (master Phase 1.2); this plan migrates `ContactForm` and ships the reusable set.
- Public taxonomy directory, deep-linkable fullscreen, footer/breadcrumb wiring, skeleton loaders — master plan **Phase 3 (IA & UX)**. (`CollectionHeader` ships a `breadcrumb` *slot* here; wiring breadcrumbs into pages is Phase 3.)
- Color-token collapse, motion/breakpoint tokens, focus-ring sweep — master plan **Phase 4**. (New primitives use `var(--color-accent)` for focus rings, which resolves via the Phase 0 alias layer until Phase 4 promotes a real `--focus-ring`.)

**Dead-code flagged & handled in this plan:**
- `BadgeOverlay.tsx` reduced to a deprecated back-compat shim (Task 4) rather than left as a third badge source.
- The three `Metadata*List.tsx` components are deleted, not left orphaned (Task 6).
- `app/styles/layout.module.scss` becomes unreferenced once `not-found.tsx`/`error.tsx` adopt `StatusPage` (Task 3 Step 9) — flagged for deletion there if no other importer remains.
- `ContactForm`'s dead `_onBack` prop is removed in **master plan Task 0.3** (prerequisite); this plan preserves the prop signature so the existing test's `defaultProps = { onBack, onSubmit }` keeps compiling whether or not 0.3 has landed.

**Placeholder scan:** every task contains complete code, exact paths, exact commands, and expected output — no TBDs, no "implement later", no "similar to above". All APIs (`SiteHeaderProps`, `LoadingSpinner`, `ContactResult`, `CollectionType`, `ContentRendererProps`, `fetchAdminPutJsonApi`/`fetchAdminDeleteApi`, `IdNameModel`/`LocationModel`) are verified against the source.

**Type consistency:** `BadgeTone`/`BadgePosition`, `MetadataListItem`, `PageShellProps`, `CollectionHeaderProps`, `StatusPageProps`, and the `Field` control prop types are each introduced once and reused; `collectionTypeToPublicLabel` is the single curated-label source consumed by both `contentRendererUtils.ts` and the `BadgeOverlay` shim.
