# 001 · Dropdown Primitive
_Chapter [001 · Design System Unification](../../001-design-review.md) · plan_

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Promote the already-correct generic selector at `app/components/ImageMetadata/UnifiedMetadataSelector.tsx` into the canonical shared primitive `app/components/ui/Dropdown/Dropdown.tsx` with its own **portable** SCSS module — so the menu, filter dropdowns, and metadata selectors can all adopt one keyboard / click-outside / inline-add implementation instead of re-rolling it. The component is moved verbatim in behavior; its only API change is generalizing the undocumented `simpleChips` boolean into a `variant` prop, and its only structural change is owning its styles instead of borrowing `ImageMetadataModal.module.scss`.

**Architecture:** This is **Task 1.4** of the master plan [`001-design-system-unification.md`](001-design-system-unification.md), expanded to bite-sized TDD. The new primitive lives in `app/components/ui/Dropdown/` next to `Button` (Task 1.1). It keeps the generic `Dropdown<T extends MetadataItem>` signature, the `AddNewField` config (text/number/checkbox/select + `showWhen` predicates), multi/single select, Enter/Escape keyboard handling, and the existing `useClickOutsideMultiple` hook. The SCSS rules `UnifiedMetadataSelector` consumes are **extracted** (copied, then deleted from the source after migration) out of `ImageMetadataModal.module.scss` so the primitive is self-contained. All existing importers are re-pointed to the new path; behavior is verified identical by an isolated test suite plus the existing `ManageClient` mock that already swaps the selector for a stub.

**Tech Stack:** Next.js 16 App Router, React 19, TypeScript (strict, no `any`), SCSS Modules with CSS custom properties (bare `var(--token)`, no `@use` partial), Jest + React Testing Library (tests mirror `app/` under `tests/`). The component uses `useState`/`useRef`/`useCallback`, so it must keep `'use client'`.

> **Spec:** This sub-plan implements **Task 1.4** of [`001-design-system-unification.md`](001-design-system-unification.md), which in turn implements [`../../001-design-review.md`](../../001-design-review.md). The review names this component the model to follow:
> *"`ImageMetadata/UnifiedMetadataSelector.tsx` — A real generic `Dropdown<T>` (multi/single select, inline add, `showWhen`, keyboard, click-outside). **Proof the team can build canonical primitives — promote it.**"* (review §3)
> Ranked move 4 (review §6a): *"`<Dropdown<T>>` — promote `UnifiedMetadataSelector` (give it portable SCSS) — menu items, filter dropdowns, metadata selectors."*

> **Predecessor (prerequisite):** Phase 0 + Task 1.1 (`<Button>`) of the master plan must land first. Phase 0 declares the `--radius-sm` / `--color-accent` aliases in `globals.css`; Task 1.1 creates the `app/components/ui/` directory and the mirrored `tests/components/ui/` test folder this plan extends. This plan does **not** depend on Modal (1.2) or FilterChip (1.3).
> **Status:** Plan only. No code written yet.

---

## How to use this plan (Scope Check)

This is a **single coherent task** (promote one component + extract one stylesheet + re-point three importers + add one test file). It is **not** decomposed into sub-plans — every step below has complete code, exact paths, and exact commands. Per the writing-plans Scope Check, it is sized to execute directly with one subagent or inline with checkpoints. There is one ordering constraint: the SCSS must be extracted (Task 2) before the source `ImageMetadataModal.module.scss` rules are deleted (Task 5), because `ImageMetadataModal.tsx` still references many of the surviving classes (`formInput`, `formSelect`, `formLabel`, `checkboxGroup`, etc.) for its own form — only the **Dropdown-exclusive** rules are removed.

---

## File-structure map

**New (created by this plan):**

```
app/components/ui/Dropdown/
  Dropdown.tsx            (moved from app/components/ImageMetadata/UnifiedMetadataSelector.tsx)
  Dropdown.module.scss    (extracted from app/components/ImageMetadata/ImageMetadataModal.module.scss)

tests/components/ui/
  Dropdown.test.tsx       (new isolated suite)
```

**Deleted:**

```
app/components/ImageMetadata/UnifiedMetadataSelector.tsx   (moved → ui/Dropdown/Dropdown.tsx)
```

**Modified (re-pointed importers + style cleanup):**

```
app/components/ImageMetadata/ImageMetadataModal.tsx                          (import path; 6 call sites)
app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx                   (import path; 2 call sites)
tests/(admin)/collection/manage/[[...slug]]/ManageClient.galleryAccess.test.tsx (jest.mock path)
app/components/ImageMetadata/ImageMetadataModal.module.scss                  (delete Dropdown-exclusive rules)
```

---

## Verified facts this plan is built on (read the sources, not guessed)

- **Default export.** `UnifiedMetadataSelector` is a **default** export: `export default function UnifiedMetadataSelector<T extends MetadataItem>(...)`. `ImageMetadataModal.tsx:46` and `ManageClient.tsx:17` import it as `import UnifiedMetadataSelector from '...'`. The plan preserves a default export named `Dropdown` so the move is mechanical.
- **Exported types.** The module also `export`s `MetadataItem`, `AddNewFieldFormData`, and `AddNewField`. These move with the component; no current file imports them by name (verified: only the default import is used), but they are part of the public surface and must remain exported.
- **`simpleChips` has no external callers.** `grep -rn "simpleChips"` finds it only inside `UnifiedMetadataSelector.tsx` (the prop declaration, its default `= false`, and the one ternary at the render site). No call site passes it. Therefore the `variant` generalization can default to the current behavior with **zero call-site changes** for the variant itself.
- **Classes the component consumes** from `ImageMetadataModal.module.scss` (the exact set to extract): `formGroup`, `formLabelRow`, `formLabel`, `cameraDisplay`, `cameraValue`, `cameraEmpty`, `cameraNewIndicator`, `selectedChips`, `chip`, `chipRemove`, `chipSimple`, `cameraDropdownList`, `cameraDropdownItem`, `cameraDropdownItemActive`, `cameraDropdownAddPlus`, `cameraDropdownEmpty`, `addNewInput`, `checkboxGroup`, `checkboxLabel`, `formSelect`, `formInput`, `addNewButtons`, `confirmButton`, `cancelSmallButton`.
- **Shared-but-still-needed classes.** `formGroup`, `formLabelRow`, `formLabel`, `formInput`, `formSelect`, `checkboxGroup`, `checkboxLabel`, `addNewInput`, `addNewButtons`, `confirmButton`, `cancelSmallButton` are **also used by `ImageMetadataModal.tsx` itself** for its own form. They are **copied** into `Dropdown.module.scss` (so the primitive is portable) but **left in place** in `ImageMetadataModal.module.scss`. Only the **Dropdown-exclusive** classes — `cameraDisplay`, `cameraValue`, `cameraEmpty`, `cameraNewIndicator`, `selectedChips`, `chip`, `chipRemove`, `chipSimple`, `cameraDropdownList`, `cameraDropdownItem`, `cameraDropdownItemActive`, `cameraDropdownAddPlus`, `cameraDropdownEmpty` — are deleted from the source in Task 5 (after confirming no other file references them).
- **next/jest CSS-module identity.** Under `next/jest`, `styles.foo === 'foo'`, so the tests match class names with `toMatch(/cameraDropdownItem/)` etc., and `@/*` maps to `<rootDir>/$1` (verified in `jest.config`).

---

## Task 1 — Move the component to `ui/Dropdown/Dropdown.tsx` (generalize `simpleChips` → `variant`)

**Why:** The component is already the canonical generic dropdown (review §3). Moving it makes the canonical location obvious and lets other surfaces import it without reaching into `ImageMetadata/`. The one API improvement is replacing the opaque `simpleChips: boolean` with a self-documenting `variant: 'detailed' | 'simple'`.

**Files:**
- Create: `app/components/ui/Dropdown/Dropdown.tsx`
- Delete: `app/components/ImageMetadata/UnifiedMetadataSelector.tsx` (done in Task 5 after importers are re-pointed)

- [ ] **Step 1 — Create `app/components/ui/Dropdown/Dropdown.tsx`** with the full component below. It is `UnifiedMetadataSelector` verbatim with four mechanical changes: (a) the SCSS import points at the new local `./Dropdown.module.scss`; (b) the props interface is renamed `DropdownProps` and `simpleChips?: boolean` is replaced by `variant?: DropdownVariant`; (c) the render-site ternary keys off `variant === 'simple'` instead of `simpleChips`; (d) the function is named `Dropdown` and `export default`ed. A back-compat type alias `UnifiedMetadataSelectorProps` is **not** added — no file imports the props type by name (verified), so the surface stays clean.

```tsx
'use client';

import { Plus } from 'lucide-react';
import { useCallback, useRef, useState } from 'react';

import { useClickOutsideMultiple } from '@/app/hooks/useClickOutside';

import styles from './Dropdown.module.scss';

/**
 * Generic metadata item interface.
 * All metadata items must have an optional id and a name/displayName.
 * Additional properties are allowed for specialized items (e.g., defaultIso for film types).
 */
export interface MetadataItem {
  id?: number;
  name?: string;
  displayName?: string;
}

/**
 * Field configuration for "Add New" forms.
 *
 * - `text` / `number` render a plain input.
 * - `checkbox` renders a labelled checkbox. `required` is ignored for checkboxes.
 * - `select` renders a `<select>` driven by `options`. `required: true` means
 *   the empty value cannot be submitted.
 * - `showWhen` is an optional predicate evaluated against the live form data;
 *   when it returns `false`, the field is not rendered.
 */
export type AddNewFieldFormData = Record<string, string | boolean>;

export interface AddNewField {
  name: string;
  label: string;
  type: 'text' | 'number' | 'checkbox' | 'select';
  placeholder?: string;
  required?: boolean;
  min?: number;
  /** For `type: 'select'` */
  options?: Array<{ value: string; label: string }>;
  /** Only render this field when the predicate returns true. */
  showWhen?: (formData: AddNewFieldFormData) => boolean;
}

/**
 * Chip rendering style for multi-select values.
 * - `detailed` (default): pill with an explicit "×" remove button (used in ImageMetadataModal).
 * - `simple`: borderless click-to-remove pill, no × button (used in admin ManageClient lists).
 */
export type DropdownVariant = 'detailed' | 'simple';

interface DropdownProps<T extends MetadataItem> {
  label: string;
  multiSelect: boolean;
  options: T[];
  /** Single-select only */
  selectedValue?: T | null;
  /** Multi-select only */
  selectedValues?: T[];
  onChange: (value: T | T[] | null) => void;
  allowAddNew?: boolean;
  onAddNew?: (data: Record<string, string | number | boolean | null>) => void;
  addNewFields?: AddNewField[];
  /** Custom display text for items */
  getDisplayName?: (item: T) => string;
  /** Custom key for list items */
  getItemKey?: (item: T) => string | number;
  emptyText?: string;
  /** Show "🔴 Will be added" for items not in database */
  showNewIndicator?: boolean;
  /** Placeholder for add new inputs */
  placeholder?: string;
  /** Chip rendering style for multi-select values (default `detailed`). */
  variant?: DropdownVariant;
}

/**
 * Dropdown<T> — flexible click-to-open selector for metadata fields.
 *
 * Canonical primitive promoted from ImageMetadata/UnifiedMetadataSelector
 * (design-review §3 / §6a-rank-4). Owns its own portable SCSS.
 *
 * UX: the value box itself is the click target. Clicking it toggles the
 * dropdown. The dropdown ends with a big "+" row when `allowAddNew` is set,
 * which opens the inline add-new form. Selecting an item closes the dropdown
 * — single AND multi-select — for consistency across Camera/Lens/Film/Tags/People.
 */
export default function Dropdown<T extends MetadataItem>({
  label,
  multiSelect,
  options,
  selectedValue,
  selectedValues = [],
  onChange,
  allowAddNew = false,
  onAddNew,
  addNewFields = [],
  getDisplayName,
  getItemKey,
  emptyText = `No ${label.toLowerCase()} set`,
  showNewIndicator = false,
  placeholder,
  variant = 'detailed',
}: DropdownProps<T>) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isSelectingFromDropdown, setIsSelectingFromDropdown] = useState(false);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [formData, setFormData] = useState<AddNewFieldFormData>({});

  const handleCloseAll = useCallback(() => {
    setIsSelectingFromDropdown(false);
    setIsAddingNew(false);
    setFormData({});
  }, []);

  useClickOutsideMultiple(containerRef, [isSelectingFromDropdown, isAddingNew], handleCloseAll);

  /**
   * Uses custom getter if provided, otherwise falls back to displayName or name.
   * Always returns a string, never an object.
   */
  const getItemDisplayName = (item: T | null | undefined): string => {
    if (!item) return '';
    if (getDisplayName) {
      const result = getDisplayName(item);
      if (typeof result === 'string') return result;
      return '';
    }
    return item.displayName || item.name || '';
  };

  /** Uses custom getter if provided, otherwise uses id or name. */
  const getKey = (item: T): string | number => {
    if (getItemKey) return getItemKey(item);
    return item.id ?? item.name ?? '';
  };

  /** Check if an item exists in the database (has a valid id > 0). */
  const itemExistsInDatabase = (item: T | null | undefined): boolean => {
    if (!item) return true;
    return Boolean(item.id && item.id > 0);
  };

  const isItemSelected = (item: T): boolean => {
    if (multiSelect) {
      return selectedValues.some(selected => {
        if (selected.id && item.id) return selected.id === item.id;
        return getItemDisplayName(selected) === getItemDisplayName(item);
      });
    }
    if (!selectedValue) return false;
    if (selectedValue.id && item.id) return selectedValue.id === item.id;
    return getItemDisplayName(selectedValue) === getItemDisplayName(item);
  };

  const handleToggleDropdown = () => {
    setIsSelectingFromDropdown(prev => !prev);
    setIsAddingNew(false);
  };

  const handleDisplayKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handleToggleDropdown();
    }
  };

  const getDisplayAriaSummary = (): string => {
    if (multiSelect) {
      return selectedValues.length > 0
        ? selectedValues.map(getItemDisplayName).join(', ')
        : emptyText;
    }
    return selectedValue ? getItemDisplayName(selectedValue) : emptyText;
  };

  const handleSelectItem = (item: T) => {
    if (multiSelect) {
      const isCurrentlySelected = isItemSelected(item);
      if (isCurrentlySelected) {
        const newSelection = selectedValues.filter(selected => {
          if (selected.id && item.id) return selected.id !== item.id;
          return getItemDisplayName(selected) !== getItemDisplayName(item);
        });
        onChange(newSelection);
      } else {
        onChange([...selectedValues, item]);
      }
    } else {
      onChange(item);
    }
    // Close on every select — single OR multi. To add another item the user
    // re-opens the dropdown. Same UX across every metadata field.
    setIsSelectingFromDropdown(false);
  };

  const handleRemoveItem = (e: React.MouseEvent | React.KeyboardEvent, item: T) => {
    e.stopPropagation();
    if (!multiSelect) return;

    const newSelection = selectedValues.filter(selected => {
      if (selected.id && item.id) return selected.id !== item.id;
      return getItemDisplayName(selected) !== getItemDisplayName(item);
    });
    onChange(newSelection);
  };

  const isFieldVisible = (field: AddNewField): boolean =>
    field.showWhen ? field.showWhen(formData) : true;

  const handleAddNew = () => {
    // Validate visible, required fields. Hidden fields (showWhen → false) are skipped.
    const missing = addNewFields.filter(isFieldVisible).filter(field => {
      if (!field.required) return false;
      const value = formData[field.name];
      if (field.type === 'checkbox') return false; // checkboxes never "missing"
      if (value === undefined || value === null) return true;
      return value.toString().trim() === '';
    });
    if (missing.length > 0) return;

    const processedData: Record<string, string | number | boolean | null> = {};
    for (const field of addNewFields) {
      // Drop fields that are hidden so the parent doesn't get stale values from
      // a sibling toggle (e.g. defaultFilmFormat when isFilm flips off).
      if (!isFieldVisible(field)) continue;
      const value = formData[field.name];
      if (field.type === 'checkbox') {
        processedData[field.name] = value === true;
      } else if (field.type === 'number') {
        processedData[field.name] =
          typeof value === 'string' && value !== '' ? Number.parseInt(value, 10) : null;
      } else if (typeof value === 'string') {
        processedData[field.name] = value.trim() || null;
      } else {
        processedData[field.name] = value ? String(value) : null;
      }
    }

    if (onAddNew) {
      onAddNew(processedData);
    }

    setFormData({});
    setIsAddingNew(false);
  };

  const isAddNewFormValid = (): boolean => {
    return addNewFields
      .filter(isFieldVisible)
      .filter(field => field.required)
      .every(field => {
        const value = formData[field.name];
        if (field.type === 'checkbox') return true;
        if (value === undefined || value === null) return false;
        if (field.type === 'number') {
          const numValue = typeof value === 'string' ? Number.parseInt(value, 10) : Number.NaN;
          return !Number.isNaN(numValue) && numValue > 0;
        }
        return value.toString().trim().length > 0;
      });
  };

  const handleFieldChange = (fieldName: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [fieldName]: value }));
  };

  const handleFieldKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (isAddNewFormValid()) {
        handleAddNew();
      }
    } else if (e.key === 'Escape') {
      setIsAddingNew(false);
      setFormData({});
    }
  };

  return (
    <div className={styles.formGroup} ref={containerRef}>
      <div className={styles.formLabelRow}>
        <label className={styles.formLabel}>{label}</label>
      </div>

      {/* Current Selection Display — itself the dropdown trigger */}
      <div
        className={styles.cameraDisplay}
        role="button"
        tabIndex={0}
        aria-expanded={isSelectingFromDropdown}
        aria-label={`${label}: ${getDisplayAriaSummary()}. Click to change.`}
        onClick={handleToggleDropdown}
        onKeyDown={handleDisplayKeyDown}
      >
        <div className={styles.cameraValue}>
          {!multiSelect &&
            (selectedValue ? (
              <>
                {getItemDisplayName(selectedValue)}
                {showNewIndicator && !itemExistsInDatabase(selectedValue) && (
                  <span className={styles.cameraNewIndicator}>🔴 Will be added</span>
                )}
              </>
            ) : (
              <span className={styles.cameraEmpty}>{emptyText}</span>
            ))}

          {multiSelect &&
            (selectedValues.length === 0 ? (
              <span className={styles.cameraEmpty}>{emptyText}</span>
            ) : (
              <div className={styles.selectedChips}>
                {selectedValues.map(item =>
                  variant === 'simple' ? (
                    <div
                      key={getKey(item)}
                      className={styles.chipSimple}
                      onClick={e => handleRemoveItem(e, item)}
                      role="button"
                      tabIndex={0}
                      onKeyDown={e => {
                        if (e.key === 'Enter') handleRemoveItem(e, item);
                      }}
                      aria-label={`Remove ${getItemDisplayName(item)}`}
                    >
                      {getItemDisplayName(item)}
                    </div>
                  ) : (
                    <div key={getKey(item)} className={styles.chip}>
                      <span>{getItemDisplayName(item)}</span>
                      <button
                        type="button"
                        onClick={e => handleRemoveItem(e, item)}
                        className={styles.chipRemove}
                        aria-label={`Remove ${getItemDisplayName(item)}`}
                      >
                        ×
                      </button>
                    </div>
                  )
                )}
              </div>
            ))}
        </div>
      </div>

      {/* Dropdown Selection */}
      {isSelectingFromDropdown && (
        <div className={styles.cameraDropdownList}>
          {options.length > 0 ? (
            options.map(item => {
              const isSelected = isItemSelected(item);
              return (
                <button
                  key={getKey(item)}
                  type="button"
                  onClick={() => handleSelectItem(item)}
                  className={`${styles.cameraDropdownItem} ${
                    isSelected ? styles.cameraDropdownItemActive : ''
                  }`}
                >
                  {getItemDisplayName(item)}
                  {isSelected && ' ✓'}
                </button>
              );
            })
          ) : (
            <div className={styles.cameraDropdownEmpty}>
              No {label.toLowerCase()} available.
              {allowAddNew && ' Click the + below to create one.'}
            </div>
          )}
          {allowAddNew && (
            <button
              type="button"
              onClick={() => {
                setIsAddingNew(true);
                setIsSelectingFromDropdown(false);
              }}
              className={styles.cameraDropdownAddPlus}
              aria-label={`Add new ${label.toLowerCase()}`}
            >
              <Plus size={24} aria-hidden="true" />
            </button>
          )}
        </div>
      )}

      {/* Add New Form */}
      {isAddingNew && (
        <div className={styles.addNewInput}>
          {addNewFields.map((field, index) => {
            if (!isFieldVisible(field)) return null;
            const rawValue = formData[field.name];

            if (field.type === 'checkbox') {
              const checked = rawValue === true;
              return (
                <div key={field.name} className={styles.checkboxGroup}>
                  <label className={styles.checkboxLabel}>
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={e => handleFieldChange(field.name, e.target.checked)}
                    />
                    <span>{field.label}</span>
                  </label>
                </div>
              );
            }

            if (field.type === 'select') {
              const selectValue = typeof rawValue === 'string' ? rawValue : '';
              return (
                <div key={field.name} className={styles.formGroup}>
                  <label className={styles.formLabel}>{field.label}</label>
                  <select
                    value={selectValue}
                    onChange={e => handleFieldChange(field.name, e.target.value)}
                    className={styles.formSelect}
                    autoFocus={index === 0}
                  >
                    <option value="">
                      {field.placeholder ?? `Select ${field.label.toLowerCase()}`}
                    </option>
                    {(field.options ?? []).map(opt => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </div>
              );
            }

            const inputValue = typeof rawValue === 'string' ? rawValue : '';
            return (
              <div key={field.name} className={styles.formGroup}>
                <label className={styles.formLabel}>{field.label}</label>
                <input
                  type={field.type}
                  value={inputValue}
                  onChange={e => handleFieldChange(field.name, e.target.value)}
                  onKeyDown={handleFieldKeyDown}
                  placeholder={
                    field.placeholder || placeholder || `Enter ${field.label.toLowerCase()}`
                  }
                  className={styles.formInput}
                  min={field.type === 'number' ? field.min : undefined}
                  autoFocus={index === 0}
                />
              </div>
            );
          })}

          <div className={styles.addNewButtons}>
            <button
              type="button"
              onClick={handleAddNew}
              className={styles.confirmButton}
              disabled={!isAddNewFormValid()}
            >
              {multiSelect ? `Add ${label}` : `Set ${label}`}
            </button>
            <button
              type="button"
              onClick={() => {
                setIsAddingNew(false);
                setFormData({});
              }}
              className={styles.cancelSmallButton}
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
```

- [ ] **Step 2 — Type-check the new file in isolation** (it will not compile against importers yet — that is Task 4; here we only confirm the new file itself is self-consistent, which `tsc --noEmit` over the project will report once the SCSS exists. Defer the full check to Task 6 and just confirm the file parses):
```bash
/opt/homebrew/bin/node node_modules/.bin/eslint app/components/ui/Dropdown/Dropdown.tsx
```
Expected: no errors from the new file (it may warn that `Dropdown.module.scss` is missing — resolved in Task 2).

This task has no commit of its own; it is committed together with Tasks 2–5 (the move + extract + re-point must land atomically so the tree compiles).

---

## Task 2 — Extract the SCSS into `Dropdown.module.scss` (copy the exact rules)

**Why:** The primitive must be portable — it cannot import `ImageMetadataModal.module.scss`. The exact rules `Dropdown.tsx` references are copied here verbatim (tokens preserved, no value changes), so the rendered output is byte-identical.

**Files:**
- Create: `app/components/ui/Dropdown/Dropdown.module.scss`

- [ ] **Step 1 — Create `app/components/ui/Dropdown/Dropdown.module.scss`** with the rules below. These are the **exact** rules `Dropdown.tsx` consumes, copied out of `ImageMetadataModal.module.scss` (lines 131–152, 207–231, 154–185, 429–476, 569–809). No declarations are changed — only relocated.

```scss
/* Dropdown primitive styles — extracted verbatim from ImageMetadataModal.module.scss
   so the canonical Dropdown<T> is portable (design-review §3 / §6a-rank-4). */

/* Form scaffolding the inline add-new form reuses */
.formGroup {
  margin-bottom: 16px;
}

.formLabelRow {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 6px;
}

.formLabel {
  display: block;
  font-size: 13px;
  font-weight: 500;
  margin-bottom: 6px;
  color: var(--color-overlay-light-70);

  .formLabelRow & {
    margin-bottom: 0;
  }
}

.formInput,
.formSelect {
  width: 100%;
  padding: 10px 12px;
  font-size: 14px;
  background: var(--color-overlay-light-05);
  border: 1px solid var(--color-overlay-light-20);
  border-radius: var(--radius-1);
  color: white;
  transition: all 0.2s;

  &:focus {
    outline: none;
    border-color: var(--color-overlay-light-50);
    background: rgb(255, 255, 255, 0.08);
  }

  &::placeholder {
    color: var(--color-overlay-light-40);
  }
}

.formSelect {
  cursor: pointer;
}

/* Checkbox add-new field */
.checkboxGroup {
  display: flex;
  gap: 24px;
  margin-top: 16px;
}

.checkboxLabel {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  font-size: 14px;
  color: var(--color-overlay-light-90);

  input[type='checkbox'] {
    width: 18px;
    height: 18px;
    cursor: pointer;
    accent-color: white;
  }

  &:hover {
    color: white;
  }
}

/* Inline add-new form container + its action buttons */
.addNewInput {
  margin-bottom: 12px;
  padding: 12px;
  background: var(--color-overlay-light-05);
  border: 1px solid var(--color-overlay-light-30);
  border-radius: var(--radius-1);
}

.addNewButtons {
  display: flex;
  gap: 8px;
  margin-top: 8px;
}

.confirmButton,
.cancelSmallButton {
  padding: 6px 14px;
  font-size: 13px;
  font-weight: 500;
  border-radius: var(--radius-1);
  cursor: pointer;
  transition: all 0.2s;
  border: none;
}

.confirmButton {
  background: white;
  color: black;

  &:hover:not(:disabled) {
    background: var(--color-overlay-light-90);
  }

  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
}

.cancelSmallButton {
  background: transparent;
  color: white;
  border: 1px solid var(--color-overlay-light-30);

  &:hover {
    background: var(--color-overlay-light-10);
  }
}

/* The value box — itself the dropdown trigger */
.cameraDisplay {
  display: flex;
  padding: 12px 16px;
  background: var(--color-overlay-light-05);
  border: 1px solid var(--color-overlay-light-20);
  border-radius: var(--radius-1);
  margin-bottom: 8px;
  cursor: pointer;
  transition:
    background-color 0.15s,
    border-color 0.15s;

  &:hover {
    background: var(--color-overlay-light-10);
    border-color: var(--color-overlay-light-30);
  }

  &:focus-visible {
    outline: 2px solid var(--color-overlay-light-50);
    outline-offset: 2px;
  }
}

.cameraValue {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 14px;
  color: var(--color-overlay-light-90);
  font-weight: 500;
}

.cameraEmpty {
  color: var(--color-overlay-light-40);
  font-style: italic;
}

.cameraNewIndicator {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 3px 8px;
  background: var(--color-danger-subtle);
  border: 1px solid var(--color-danger-dark);
  border-radius: 3px;
  font-size: 11px;
  font-weight: 600;
  color: var(--color-danger-text);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

/* The open option list */
.cameraDropdownList {
  max-height: 250px;
  overflow-y: auto;
  border: 1px solid var(--color-overlay-light-20);
  border-radius: var(--radius-1);
  background: rgb(255, 255, 255, 0.03);
  margin-bottom: 12px;

  /* Custom scrollbar */
  &::-webkit-scrollbar {
    width: 6px;
  }

  &::-webkit-scrollbar-track {
    background: var(--color-overlay-light-05);
  }

  &::-webkit-scrollbar-thumb {
    background: var(--color-overlay-light-20);
    border-radius: 3px;

    &:hover {
      background: var(--color-overlay-light-30);
    }
  }
}

.cameraDropdownItem {
  display: block;
  width: 100%;
  padding: 12px 16px;
  text-align: left;
  background: transparent;
  border: none;
  border-bottom: 1px solid var(--color-overlay-light-05);
  color: var(--color-overlay-light-90);
  font-size: 14px;
  cursor: pointer;
  transition: background-color 0.15s;

  &:last-child {
    border-bottom: none;
  }

  &:hover {
    background: rgb(255, 255, 255, 0.08);
  }
}

.cameraDropdownItemActive {
  background: rgb(255, 255, 255, 0.15);
  font-weight: 600;

  &:hover {
    background: var(--color-overlay-light-20);
  }
}

.cameraDropdownAddPlus {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  padding: 14px 16px;
  background: transparent;
  border: none;
  border-top: 1px solid var(--color-overlay-light-20);
  color: var(--color-overlay-light-90);
  cursor: pointer;
  transition: background-color 0.15s;

  &:hover {
    background: rgb(255, 255, 255, 0.08);
  }

  &:focus-visible {
    outline: 2px solid var(--color-overlay-light-50);
    outline-offset: -2px;
  }
}

.cameraDropdownEmpty {
  padding: 20px;
  text-align: center;
  color: var(--color-overlay-light-50);
  font-size: 13px;
  font-style: italic;
}

/* Selected chips (multi-select) */
.selectedChips {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 4px 10px;
  background: var(--color-overlay-light-10);
  border: 1px solid var(--color-overlay-light-20);
  border-radius: 3px;
  font-size: 13px;
  color: var(--color-overlay-light-80);
  font-weight: 500;

  span {
    user-select: none;
  }
}

.chipRemove {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  padding: 0;
  background: transparent;
  border: none;
  border-radius: 2px;
  color: var(--color-overlay-light-50);
  font-size: 14px;
  line-height: 1;
  cursor: pointer;
  transition: all 0.2s;

  &:hover {
    background: rgb(220, 38, 38, 0.3);
    color: var(--color-danger-text);
  }

  &:active {
    transform: scale(0.95);
  }
}

/* Simplified chip style for admin pages — click to remove */
.chipSimple {
  display: inline-flex;
  align-items: center;
  padding: 6px 14px;
  background: transparent;
  border: 1px solid var(--color-overlay-light-30);
  border-radius: var(--radius-1);
  font-size: 13px;
  color: var(--color-overlay-light-90);
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  user-select: none;

  &:hover {
    background: var(--color-danger-subtle);
    border-color: rgb(220, 38, 38, 0.5);
    color: var(--color-danger-text);
  }

  &:active {
    transform: scale(0.98);
  }
}
```

- [ ] **Step 2 — Lint the new SCSS:**
```bash
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/ui/Dropdown/Dropdown.module.scss'
```
Expected: clean (stylelint may normalize `rgb()` slash syntax; the source file uses the same legacy commas, so the diff should be minimal or none).

---

## Task 3 — Write the isolated test suite (TDD: write it, watch it fail against the new module)

**Why:** The component had no dedicated test (it was only exercised indirectly via `ImageMetadataModal`). Promoting it to a primitive is the moment to give it the canonical Dropdown test: open on trigger, list options, single vs multi select, inline add-new, close on outside click, keyboard Enter/Escape.

**Files:**
- Create: `tests/components/ui/Dropdown.test.tsx`

- [ ] **Step 1 — Write `tests/components/ui/Dropdown.test.tsx`:**

```tsx
import { fireEvent, render, screen } from '@testing-library/react';

import Dropdown, { type MetadataItem } from '@/app/components/ui/Dropdown/Dropdown';

interface TagItem extends MetadataItem {
  id: number;
  name: string;
}

const OPTIONS: TagItem[] = [
  { id: 1, name: 'Mountains' },
  { id: 2, name: 'Ocean' },
];

describe('Dropdown', () => {
  it('renders the label and the empty-state trigger, with the list closed', () => {
    render(<Dropdown<TagItem> label="Tags" multiSelect options={OPTIONS} onChange={jest.fn()} />);
    // Trigger is a role="button" whose aria-label includes the empty text.
    expect(screen.getByRole('button', { name: /Tags: No tags set/i })).toBeInTheDocument();
    // Options are not rendered until opened.
    expect(screen.queryByRole('button', { name: 'Mountains' })).not.toBeInTheDocument();
  });

  it('opens on trigger click and lists every option', () => {
    render(<Dropdown<TagItem> label="Tags" multiSelect options={OPTIONS} onChange={jest.fn()} />);
    fireEvent.click(screen.getByRole('button', { name: /Tags:/i }));
    expect(screen.getByRole('button', { name: 'Mountains' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Ocean' })).toBeInTheDocument();
  });

  it('single-select calls onChange with the chosen item and closes', () => {
    const onChange = jest.fn();
    render(
      <Dropdown<TagItem> label="Camera" multiSelect={false} options={OPTIONS} onChange={onChange} />
    );
    fireEvent.click(screen.getByRole('button', { name: /Camera:/i }));
    fireEvent.click(screen.getByRole('button', { name: 'Ocean' }));
    expect(onChange).toHaveBeenCalledWith(OPTIONS[1]);
    // List closed after select.
    expect(screen.queryByRole('button', { name: 'Mountains' })).not.toBeInTheDocument();
  });

  it('multi-select appends to the selected array and renders a removable chip', () => {
    const onChange = jest.fn();
    render(
      <Dropdown<TagItem>
        label="Tags"
        multiSelect
        options={OPTIONS}
        selectedValues={[OPTIONS[0]]}
        onChange={onChange}
      />
    );
    fireEvent.click(screen.getByRole('button', { name: /Tags:/i }));
    fireEvent.click(screen.getByRole('button', { name: 'Ocean' }));
    expect(onChange).toHaveBeenCalledWith([OPTIONS[0], OPTIONS[1]]);
    // The already-selected value shows a remove control (detailed variant default).
    expect(screen.getByRole('button', { name: 'Remove Mountains' })).toBeInTheDocument();
  });

  it('inline add-new: opens the form, validates, and calls onAddNew with processed data', () => {
    const onAddNew = jest.fn();
    render(
      <Dropdown<TagItem>
        label="Tags"
        multiSelect
        options={[]}
        onChange={jest.fn()}
        allowAddNew
        onAddNew={onAddNew}
        addNewFields={[{ name: 'name', label: 'Tag Name', type: 'text', required: true }]}
      />
    );
    fireEvent.click(screen.getByRole('button', { name: /Tags:/i }));
    fireEvent.click(screen.getByRole('button', { name: /Add new tags/i }));
    const input = screen.getByLabelText('Tag Name');
    fireEvent.change(input, { target: { value: 'Sunsets' } });
    // Enter submits when valid.
    fireEvent.keyDown(input, { key: 'Enter' });
    expect(onAddNew).toHaveBeenCalledWith({ name: 'Sunsets' });
  });

  it('inline add-new: Escape closes the form without calling onAddNew', () => {
    const onAddNew = jest.fn();
    render(
      <Dropdown<TagItem>
        label="Tags"
        multiSelect
        options={[]}
        onChange={jest.fn()}
        allowAddNew
        onAddNew={onAddNew}
        addNewFields={[{ name: 'name', label: 'Tag Name', type: 'text', required: true }]}
      />
    );
    fireEvent.click(screen.getByRole('button', { name: /Tags:/i }));
    fireEvent.click(screen.getByRole('button', { name: /Add new tags/i }));
    const input = screen.getByLabelText('Tag Name');
    fireEvent.change(input, { target: { value: 'Discarded' } });
    fireEvent.keyDown(input, { key: 'Escape' });
    expect(onAddNew).not.toHaveBeenCalled();
    expect(screen.queryByLabelText('Tag Name')).not.toBeInTheDocument();
  });

  it('closes the open list on outside click (Escape via document keydown)', () => {
    render(<Dropdown<TagItem> label="Tags" multiSelect options={OPTIONS} onChange={jest.fn()} />);
    fireEvent.click(screen.getByRole('button', { name: /Tags:/i }));
    expect(screen.getByRole('button', { name: 'Mountains' })).toBeInTheDocument();
    // useClickOutsideMultiple listens on document keydown for Escape.
    fireEvent.keyDown(document, { key: 'Escape' });
    expect(screen.queryByRole('button', { name: 'Mountains' })).not.toBeInTheDocument();
  });

  it('opens via keyboard (Enter on the trigger)', () => {
    render(<Dropdown<TagItem> label="Tags" multiSelect options={OPTIONS} onChange={jest.fn()} />);
    const trigger = screen.getByRole('button', { name: /Tags:/i });
    fireEvent.keyDown(trigger, { key: 'Enter' });
    expect(screen.getByRole('button', { name: 'Mountains' })).toBeInTheDocument();
  });

  it('simple variant renders click-to-remove chips without an explicit remove button', () => {
    render(
      <Dropdown<TagItem>
        label="People"
        multiSelect
        options={OPTIONS}
        selectedValues={[OPTIONS[0]]}
        onChange={jest.fn()}
        variant="simple"
      />
    );
    // The whole chip is the remove control; there is no separate "×" button child.
    const chip = screen.getByRole('button', { name: 'Remove Mountains' });
    expect(chip).toHaveTextContent('Mountains');
    expect(chip.querySelector('button')).toBeNull();
  });
});
```

- [ ] **Step 2 — Run it; verify it fails for the right reason** (the module import resolves once Task 1 + 2 exist; run after those). If run before Task 1/2:
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/Dropdown.test.tsx
```
Expected (before Task 1/2): FAIL — `Cannot find module '@/app/components/ui/Dropdown/Dropdown'`. After Task 1/2 exist: PASS (10 tests).

---

## Task 4 — Re-point all importers to the new path

**Why:** `UnifiedMetadataSelector` is imported by two app files (6 + 2 call sites) and mocked by one test. The behavior and props are unchanged (default export, same prop names), so every change is a path swap — except the optional `variant` rename has zero call-site impact because no site passed `simpleChips`.

**Files:**
- Modify: `app/components/ImageMetadata/ImageMetadataModal.tsx`
- Modify: `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx`
- Modify: `tests/(admin)/collection/manage/[[...slug]]/ManageClient.galleryAccess.test.tsx`

- [ ] **Step 1 — `ImageMetadataModal.tsx`.** Change the import on line 46 and rename the 6 JSX tags. Replace:
```tsx
import UnifiedMetadataSelector from './UnifiedMetadataSelector';
```
with:
```tsx
import Dropdown from '@/app/components/ui/Dropdown/Dropdown';
```
Then rename all 6 element usages (`<UnifiedMetadataSelector<...>` → `<Dropdown<...>` and their closing context is self-closing `/>`, so only the opening tag changes) at lines 617, 735, 812, 914, 988, 1017:
```bash
/opt/homebrew/bin/node node_modules/.bin/eslint --rule '{}' --no-eslintrc app/components/ImageMetadata/ImageMetadataModal.tsx > /dev/null 2>&1 || true
# Do the rename mechanically (each occurrence is "UnifiedMetadataSelector<" → "Dropdown<"):
grep -c "UnifiedMetadataSelector" app/components/ImageMetadata/ImageMetadataModal.tsx
```
Expected before edit: `7` (1 import + 6 tags). Perform the rename via Edit (replace-all of the token `UnifiedMetadataSelector` with `Dropdown` in that file is safe — the string appears nowhere else there). Expected after edit: `grep -c "UnifiedMetadataSelector"` → `0`.

- [ ] **Step 2 — `ManageClient.tsx`.** Change the import on line 17 and rename the 2 JSX tags (lines 1226, 1271). Replace:
```tsx
import UnifiedMetadataSelector from '@/app/components/ImageMetadata/UnifiedMetadataSelector';
```
with:
```tsx
import Dropdown from '@/app/components/ui/Dropdown/Dropdown';
```
Then replace-all `UnifiedMetadataSelector` → `Dropdown` in this file (the token appears only as the import + 2 tags).
```bash
grep -c "UnifiedMetadataSelector" 'app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx'
```
Expected after edit: `0`.

- [ ] **Step 3 — `ManageClient.galleryAccess.test.tsx`.** Update the `jest.mock` path (line 133). Replace:
```tsx
jest.mock('@/app/components/ImageMetadata/UnifiedMetadataSelector', () => ({
```
with:
```tsx
jest.mock('@/app/components/ui/Dropdown/Dropdown', () => ({
```
(The `default: () => null` stub body is unchanged — the default-export shape is preserved.)

- [ ] **Step 4 — Verify no stale references remain anywhere:**
```bash
grep -rn "UnifiedMetadataSelector" app/ tests/ docs/ ; echo "exit: $?"
```
Expected: the only matches are inside this plan doc and the master plan doc (`docs/`). **No matches under `app/` or `tests/`** (the relevant lines should be the doc references only). If `app/`/`tests/` show any hit, fix it before continuing.

---

## Task 5 — Delete the old file + the Dropdown-exclusive SCSS rules from `ImageMetadataModal.module.scss`

**Why:** Finish the move (the old component file is now orphaned) and remove the duplicated style rules that only the dropdown used, so the styles live in exactly one place. Rules still used by `ImageMetadataModal.tsx`'s own form stay.

**Files:**
- Delete: `app/components/ImageMetadata/UnifiedMetadataSelector.tsx`
- Modify: `app/components/ImageMetadata/ImageMetadataModal.module.scss`

- [ ] **Step 1 — Confirm the old component file has no remaining importers** (Task 4 should have cleared them), then delete it:
```bash
grep -rn "ImageMetadata/UnifiedMetadataSelector" app/ tests/ ; echo "exit: $?"   # expect no matches
git rm app/components/ImageMetadata/UnifiedMetadataSelector.tsx
```
Expected: grep exit 1 (no matches); `git rm` succeeds.

- [ ] **Step 2 — Confirm the Dropdown-exclusive SCSS classes are referenced by no other file**, then delete them from `ImageMetadataModal.module.scss`. Check each:
```bash
grep -rn "cameraDisplay\|cameraValue\|cameraEmpty\|cameraNewIndicator\|cameraDropdownList\|cameraDropdownItem\|cameraDropdownItemActive\|cameraDropdownAddPlus\|cameraDropdownEmpty\|selectedChips\|chipSimple\|\.chip\b\|chipRemove" app/ ; echo "exit: $?"
```
Expected: the **only** remaining `app/` matches are inside `app/components/ui/Dropdown/Dropdown.module.scss` (the new home) and `app/components/ui/Dropdown/Dropdown.tsx` (the `styles.*` references). If `ImageMetadataModal.tsx` shows a hit for any of these classes, that class is NOT exclusive — leave it in `ImageMetadataModal.module.scss` and remove it from the deletion set. (Per the source read, `ImageMetadataModal.tsx` does not use the `camera*`/`chip*`/`selectedChips` classes — they were dropdown-only.)

- [ ] **Step 3 — Delete the Dropdown-exclusive rule blocks** from `app/components/ImageMetadata/ImageMetadataModal.module.scss`: the `.cameraDisplay`, `.cameraValue`, `.cameraEmpty`, `.cameraNewIndicator`, `.cameraDropdownList`, `.cameraDropdownItem`, `.cameraDropdownItemActive`, `.cameraDropdownAddPlus`, `.cameraDropdownEmpty`, `.selectedChips`, `.chip`, `.chipRemove`, and `.chipSimple` blocks (source lines ~569–809, plus the `/* Camera Selector Styles */` comment header). **Keep** `.formGroup`, `.formLabelRow`, `.formLabel`, `.formInput`/`.formTextarea`/`.formSelect`, `.checkboxGroup`, `.checkboxLabel`, `.addNewInput`, `.addNewButtons`, `.confirmButton`/`.cancelSmallButton` — those are still used by `ImageMetadataModal.tsx`'s own form and by the surrounding modal. (The duplication of these between the two modules is intentional and accepted: it is the price of a portable primitive. The master plan's Phase 2 Form-set task is where the shared form scaffolding gets unified — out of scope here.)

- [ ] **Step 4 — Lint the trimmed SCSS:**
```bash
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/ImageMetadata/ImageMetadataModal.module.scss'
```
Expected: clean.

---

## Task 6 — Full verification + atomic commit

**Why:** The move only makes sense as one atomic commit (the tree must compile at every commit boundary; a half-moved component would not). Run the full project pipeline, then commit.

- [ ] **Step 1 — Format → lint → stylelint → type-check the touched files:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write \
  app/components/ui/Dropdown/Dropdown.tsx \
  tests/components/ui/Dropdown.test.tsx \
  app/components/ImageMetadata/ImageMetadataModal.tsx \
  'app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx' \
  'tests/(admin)/collection/manage/[[...slug]]/ManageClient.galleryAccess.test.tsx'
/opt/homebrew/bin/node node_modules/.bin/prettier --write \
  'app/components/ui/Dropdown/Dropdown.module.scss' \
  'app/components/ImageMetadata/ImageMetadataModal.module.scss'
/opt/homebrew/bin/node node_modules/.bin/eslint --fix \
  app/components/ui/Dropdown/Dropdown.tsx \
  tests/components/ui/Dropdown.test.tsx \
  app/components/ImageMetadata/ImageMetadataModal.tsx \
  'app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx' \
  'tests/(admin)/collection/manage/[[...slug]]/ManageClient.galleryAccess.test.tsx'
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix \
  'app/components/ui/Dropdown/Dropdown.module.scss' \
  'app/components/ImageMetadata/ImageMetadataModal.module.scss'
```
Expected: all clean (no errors).

- [ ] **Step 2 — Type-check the whole project:**
```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
```
Expected: no errors. (Catches any missed `<UnifiedMetadataSelector>` tag or import.)

- [ ] **Step 3 — Run the new suite + the importer suites:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/Dropdown.test.tsx
/opt/homebrew/bin/node node_modules/.bin/jest 'tests/(admin)/collection/manage'
```
Expected: `Dropdown.test.tsx` → PASS (10 tests). `ManageClient` suite → PASS (unchanged; it mocks the component, so only the mock path needed updating).

- [ ] **Step 4 — Full test run (regression guard for `ImageMetadataModal` consumers):**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest
```
Expected: the full suite is green (same pass count as before this plan + the 10 new Dropdown tests).

- [ ] **Step 5 — Commit (one atomic commit):**
```bash
git add app/components/ui/Dropdown tests/components/ui/Dropdown.test.tsx \
  app/components/ImageMetadata/ImageMetadataModal.tsx \
  app/components/ImageMetadata/ImageMetadataModal.module.scss \
  'app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx' \
  'tests/(admin)/collection/manage/[[...slug]]/ManageClient.galleryAccess.test.tsx'
git rm app/components/ImageMetadata/UnifiedMetadataSelector.tsx 2>/dev/null || true
git commit -m "refactor(ui): promote UnifiedMetadataSelector to canonical Dropdown primitive

Moves the generic selector to app/components/ui/Dropdown/Dropdown.tsx with
its own portable SCSS (extracted from ImageMetadataModal.module.scss), and
generalizes the undocumented simpleChips boolean into a variant prop
('detailed' | 'simple'). Re-points the ImageMetadataModal + ManageClient
importers and the ManageClient test mock. Adds tests/components/ui/Dropdown.test.tsx
covering open/list/single+multi-select/inline-add/outside-click/keyboard.

Behavior unchanged; this is the design-review §3 / §6a-rank-4 promotion.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 7 (follow-up note — NOT executed here) — Adopters

**Why:** The whole point of promoting the primitive is reuse. Two future adopters were identified in the review (§6a-rank-4: "menu items, filter dropdowns, metadata selectors"). They are **out of scope for this plan** — each is its own change — but recorded so the work isn't lost:

- **`app/components/MenuDropdown/MenuDropdown.tsx`** hand-rolls three effects (click-outside, Escape, body-scroll-lock) plus its own option markup (verified: `useEffect` blocks at lines 115–145 reimplement what `useClickOutside` already provides). Its nav items are not a `Dropdown<T>` of metadata, so the fit is partial — the realistic reuse is folding its click-outside/Esc onto the shared `useClickOutside` hook (already done in `Dropdown`) and, once `<Modal variant="sheet">` (master-plan Task 1.2) lands, hosting the menu in that. Track under Task 1.2's MenuDropdown migration, not here.
- **The filter dropdowns** (`app/components/ContentCollection/CollectionFilterBar.tsx`) can adopt `Dropdown<T>`'s open/keyboard/positioning once `<FilterChip>`/`<FilterToolbar>` (master-plan Task 1.3) defines the facet model. Track under Task 1.3.

**Action:** none in this plan. When executing master-plan Tasks 1.2 / 1.3, import from `@/app/components/ui/Dropdown/Dropdown` rather than re-rolling open/keyboard logic.

---

## Verification (run before the PR)

```bash
cd /Users/themancalledzac/Code/edens.zac
# Project pipeline (npm/npx not on PATH — per CLAUDE.md)
/opt/homebrew/bin/node node_modules/.bin/prettier --write \
  'app/components/ui/Dropdown/**/*.{ts,tsx,scss}' 'tests/components/ui/Dropdown.test.tsx'
/opt/homebrew/bin/node node_modules/.bin/eslint --fix \
  app/components/ui/Dropdown/Dropdown.tsx tests/components/ui/Dropdown.test.tsx
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/ui/Dropdown/Dropdown.module.scss'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest
# No stale references survive the move:
grep -rn "UnifiedMetadataSelector" app/ tests/ ; echo "exit (want 1 / no matches): $?"
```
**Visual (dev server :3001 — user keeps :3000):** open `ImageMetadataModal` (click an image's edit on `/collection/...` in local env) → Camera/Lens/Film/Location/Tags/People selectors open, list, single+multi select, and inline "+" add still work and look identical. Open `/collection/manage/...` (admin) → the collection-level Locations and People selectors (the `label=""` People one is multi-select) behave identically.

---

## Suggested commit sequence

This plan is **one atomic commit** (the move must land whole or the tree won't compile):

1. `refactor(ui): promote UnifiedMetadataSelector to canonical Dropdown primitive` — Tasks 1–6 together.

Then, separately and later (their own plans/commits):

2. *(master-plan Task 1.2)* MenuDropdown adopts `<Modal variant="sheet">` + shared click-outside.
3. *(master-plan Task 1.3)* Filter dropdowns adopt `Dropdown<T>` open/keyboard logic.

The single commit passes `tsc --noEmit` + `jest` independently.

---

## Self-review: spec-coverage checklist

Maps every requirement (this plan's scope + the master-plan Task 1.4 spec) to a task. Gaps flagged explicitly.

| Requirement (master-plan Task 1.4 / review §3, §6a-4) | Plan task | Status |
|--------------------------------------------------------|-----------|--------|
| Move `UnifiedMetadataSelector.tsx` → `app/components/ui/Dropdown/Dropdown.tsx` | Task 1 (create) + Task 5 (delete old) | ✅ |
| Keep generic `<T extends MetadataItem>`, multi/single select | Task 1 (signature preserved) | ✅ |
| Keep `AddNewField` config + `showWhen` predicates | Task 1 (types + `isFieldVisible` unchanged) | ✅ |
| Keep keyboard handling (Enter/Escape; Enter/Space on trigger) | Task 1 + Task 3 (tested) | ✅ |
| Keep `useClickOutsideMultiple` usage | Task 1 (unchanged import + call) | ✅ |
| Generalize `simpleChips` boolean → `variant` prop | Task 1 (`DropdownVariant`, render ternary) | ✅ |
| Create `Dropdown.module.scss` by **extracting exact rules** from `ImageMetadataModal.module.scss` | Task 2 (verbatim copy, classes listed) | ✅ |
| Show the rules being moved | Task 2 (full SCSS) + Task 5 (deletion set) | ✅ |
| Re-point all existing importers (grep) | Task 4 (ImageMetadataModal ×7 tokens, ManageClient ×3, test mock) | ✅ |
| Add `tests/components/ui/Dropdown.test.tsx`: open, list, single vs multi, inline add, outside-click close, keyboard Enter/Escape | Task 3 (10 tests incl. simple-variant) | ✅ |
| Follow-up: MenuDropdown + filter dropdowns can later adopt | Task 7 (note, not executed) | ✅ noted |
| Prerequisite: Phase 0 + Button (master plan) | Header "Predecessor" | ✅ stated |

**Placeholder scan:** Every step has complete code (full `Dropdown.tsx`, full `Dropdown.module.scss`, full test file), exact paths, and exact commands with Expected output. No TBDs, no "implement later", no "similar to above".

**Dead-code flag (carried from the source read):** `simpleChips` was a declared-but-unused-by-callers prop. This plan resolves it by promoting it to the documented `variant` prop with `'detailed'` default (= current behavior), rather than deleting it — the `simple` rendering path is real (intended for admin lists per the source comment) even though no call site opts in today. The `ManageClient` People selector (`label=""`, multi-select) is a candidate to pass `variant="simple"` in a future change, but this plan keeps behavior identical (default `detailed`) and does not change call-site props.

**Type consistency:** `MetadataItem`, `AddNewField`, `AddNewFieldFormData` keep their names and exports across the move; `DropdownVariant` is introduced once (Task 1) and referenced by the test (Task 3) and the follow-up note (Task 7).
