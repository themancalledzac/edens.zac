# 001 · ImageMetadataModal Decomposition
_Chapter [001 · Design System Unification](../../001-design-review.md) · plan · branch `0159-image-metadata-modal-decomposition`_

> ✅ **SHIPPED — [PR #160](https://github.com/themancalledzac/edens.zac/pull/160) (merged 2026-06-03).** Modal **1099 → 203 LoC** orchestrator + `useImageMetadataState`/`useImageMetadataSubmit` hooks + 5 section subcomponents on the `ui/` primitives; the 4 raw `*Button` classes deleted. +75 net-new component tests (surface had ~0 before). Post-merge follow-ups: dark-surface Save/Cancel visibility (`739fd6d`), fullscreen overlay `--fs-matte` alignment (`2d30a7f`), camera optimistic-create race ([#162](https://github.com/themancalledzac/edens.zac/pull/162), → [006](006-camera-optimistic-create-race.md)), and test de-fragilization ([#163](https://github.com/themancalledzac/edens.zac/pull/163)). The "drop-the-Image-prefix" rename remains a separate 006 item. The plan below is preserved as the implementation record.

> **Why this lives under 001, not 006:** the modal is the single biggest consumer that didn't fully migrate onto the new `ui/` primitives during PR #158. The 4 raw `*Button` classes Task 8 deletes were literally on PR #158's migration target list — they got carved out for scope reasons but always belonged with the unification. This MR is the **tail of the 001 chapter**, not a separate code-health refactor. Code-health-only follow-ups (the `ImageMetadataModal` → drop-"Image"-prefix rename, etc.) properly belong in 006 — those are filed separately.

> **For agentic workers:** REQUIRED SUB-SKILL: Use `superpowers:subagent-driven-development` (recommended) or `superpowers:executing-plans` to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Decompose `app/components/ImageMetadata/ImageMetadataModal.tsx` (currently **1099 LoC** — the biggest single component in the app after the 001 design-system unification) into 2 custom hooks + 5 subcomponents, all wired through the existing `ui/` primitives (`<Button>`, `<Input>`, `<Textarea>`, `<Select>`, `<Checkbox>`, `<FormError>`, `<Dropdown>`, `<Modal>`, `<CloseButton>`). The orchestrator drops to **~200 LoC** of state-routing + JSX-composition. **Zero behavior change** — this is a pure structural refactor.

**Architecture:** The current monolith owns: (1) edit-state with derived memos for collection diffs, (2) async submit/delete/remove handlers with three routing branches (single-image / bulk-image / single-GIF), (3) image preview with 3 render paths (single image, single GIF/MP4 video, bulk grid), (4) 4 form sections each ~50–250 LoC, (5) action button row with 4 raw `*Button` classes that never adopted the `<Button>` primitive in PR #158. Target architecture splits state into `useImageMetadataState` + `useImageMetadataSubmit` hooks, extracts the preview and each form section into a subcomponent under `app/components/ImageMetadata/sections/`, and migrates the action row onto `<Button>` so the 4 raw button classes can be deleted from `ImageMetadataModal.module.scss`.

**Tech Stack:** Next.js 16 App Router, React 19 (named imports), strict TypeScript (no `any`), SCSS Modules with bare `var(--token)`, Jest + React Testing Library. Builds on the new primitives shipped in PR #158 and the token foundation in `0152-token-collapse-a11y`.

> **Predecessor:** PR #158 (0151-ia-and-ux) created the `<Modal>`, `<Field>` set, and `<Dropdown>` primitives this plan migrates onto. PR #157 (0150-admin-route-gating) doesn't touch this surface. The 0152 branch deletes the legacy color tokens this SCSS would have referenced — verified `ImageMetadataModal.module.scss` only uses the post-0152 tokens (`--scrim-light-*`, `--duration-base`, `--focus-ring`), so this branch is correctly based on `0152-token-collapse-a11y`.
>
> **Out of scope (carved out for a separate MR):** the naming smell flagged in mempalace `user-2373731890` — `ImageMetadataModal` / `useImageMetadataEditor` / `selectedImageIds` should rename to drop the "Image" prefix since the modal now also edits GIF/MP4 content. That's a project-wide identifier rename touching ManageClient + tests + the hook — owns its own MR after this one ships.
>
> **Status:** Plan only. No code written yet.

---

## Risk: zero existing component tests for `ImageMetadataModal`

Per mempalace `user-f6143eb7` (the 0147 checkpoint decision): "4 of 5 shells (FullScreenModal, ImageMetadataModal, TextBlockCreateModal, MenuDropdown) have NO component tests." Verified on `main` — `tests/components/ImageMetadata/` is empty; only `imageMetadataUtils.test.ts` exists (and is well-covered).

**This is the biggest risk in the plan.** A refactor without a test net silently breaks behavior — the migration in PR #158 even noted this: "4/5 shells have NO component tests so parent must browser-verify" (mempalace `user-83131d61`).

**Mitigation: Task 1 is a smoke-test scaffold, written BEFORE any decomposition.** The smoke tests assert orchestrator-level behavior (renders for single/bulk/GIF; Save disabled when no changes; Cancel calls `onClose`; Delete shows confirm) and must stay green through every subsequent task. Each extracted hook/subcomponent ALSO gets its own focused test in the same step it ships. By the end of the plan we go from 0 → ~30 test cases for this surface.

---

## File-structure map

**New:**
```
app/components/ImageMetadata/
  hooks/
    useImageMetadataState.ts          (Task 2 — state + collection diff memos)
    useImageMetadataSubmit.ts         (Task 3 — saving/error + submit/delete/remove handlers)
  sections/
    MediaPreview.tsx                  (Task 4 — single image / GIF video / bulk grid)
    EssentialInfoSection.tsx          (Task 5 — title, caption, alt, author, locations, rating, visibility)
    CameraSettingsSection.tsx         (Task 6 — camera, lens, ISO/F-Stop, shutter/focal, B&W/film, film stock/format)
    TagsPeopleSection.tsx             (Task 7 — tags + people Dropdowns)
    MetadataActionRow.tsx             (Task 8 — delete/remove/cancel/save buttons via <Button>)

tests/components/ImageMetadata/
  ImageMetadataModal.smoke.test.tsx           (Task 1 — orchestrator smoke tests)
  hooks/useImageMetadataState.test.tsx        (Task 2)
  hooks/useImageMetadataSubmit.test.tsx       (Task 3)
  sections/MediaPreview.test.tsx              (Task 4)
  sections/EssentialInfoSection.test.tsx      (Task 5)
  sections/CameraSettingsSection.test.tsx     (Task 6)
  sections/TagsPeopleSection.test.tsx         (Task 7)
  sections/MetadataActionRow.test.tsx         (Task 8)
```

**Modified:**
```
app/components/ImageMetadata/ImageMetadataModal.tsx           (shrinks from 1099 → ~200 LoC across all tasks)
app/components/ImageMetadata/ImageMetadataModal.module.scss   (Task 8 — delete .deleteButton/.removeButton/.cancelButton/.saveButton + .loadingLabel rules)
```

**Not touched:**
```
app/components/ImageMetadata/imageMetadataUtils.ts            (already well-factored; tests already green)
app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx    (consumer; props interface is stable)
app/components/ui/**                                          (primitives we adopt; no edits)
```

---

## Verified source facts (read from `ImageMetadataModal.tsx` on `0152-token-collapse-a11y`)

- File is **1099 LoC**. Consumer is **single**: `ManageClient.tsx:16` (import) + `:1690` (call site). Props interface stable.
- Top-level helper `renderSinglePreview` (lines 67–109) — pure function, already extracted; will move into `MediaPreview.tsx`.
- Local types `ImageUpdateState` (lines 54–57) + `EditableContent` (line 60) — `ImageUpdateState` becomes hook-internal; `EditableContent` is part of the props contract and stays in the orchestrator file.
- State (lines 190–247): `updateState`/`setUpdateState`, `useEffect` re-init on `[selectedImages, availableLocations]`, `hasChanges` memo, `saving`/`error` state, `originalCollectionIds` memo, `pendingAddIds` memo, `pendingRemoveIds` memo, `handleCollectionToggle` callback. **All move to `useImageMetadataState`** except `saving`/`error` which belong with the submit hook.
- Handlers (lines 285–471): `handleSubmit` (95 LoC, three branches — single-GIF / bulk-image / single-image), `handleCancel` (7 LoC, confirms on `hasChanges`), `handleDelete` (39 LoC, GIF branch + image branch), `handleRemoveFromCollection` (43 LoC). **All move to `useImageMetadataSubmit`.**
- Derived flags (lines 270–283): `previewImage` (early-return guard), `isGif`, `previewImageAsImage`, `previewImageAsGif`. Stay in orchestrator (props-derived, no state).
- JSX sections (lines 473–1097):
  - Lines 477–506: image preview (single + bulk grid) → `MediaPreview`
  - Lines 510–518: heading + error message → stay in orchestrator (3 lines each)
  - Lines 522–685: **Essential Info** (Title `<input>`, Caption `<textarea>` with `aria-disabled` for GIF, Alt `<input>`, Author `<input>`, Locations `<Dropdown>`, Rating `<select>`, Collection Visibility `<input type="checkbox">`) → `EssentialInfoSection`
  - Lines 687–945: **Camera Settings** (Camera `<Dropdown>`, Lens `<Dropdown>`, ISO/F-Stop 2-col, Shutter/Focal 2-col, B&W/Film checkboxes, conditional Film Stock + Film Format) → `CameraSettingsSection`
  - Lines 947–1012: **Tags & People** (two `<Dropdown>`s) → `TagsPeopleSection`
  - Lines 1014–1025: **Collections** (`<CollectionListSelector>` only) → stays inline (single child, no extraction value)
  - Lines 1028–1088: action button row (4 raw `*Button` classes: `.deleteButton`, `.removeButton`, `.cancelButton`, `.saveButton`) → `MetadataActionRow`, **migrated onto `<Button>` primitive** so the SCSS rules can be deleted
  - Lines 1093–1096: `<CloseButton>` (already on primitive; stays)
- **4 raw button classes that PR #158 missed:** `.deleteButton`, `.removeButton`, `.cancelButton`, `.saveButton` in `ImageMetadataModal.module.scss`. Variant mapping: `danger` / `danger` / `ghost` / `primary`. The `<Button loading={saving}>` prop replaces the bespoke `LoadingSpinner + .loadingLabel` block at every site (4 occurrences).
- **3 inline `style={isGif ? { opacity: 0.4, pointerEvents: 'none' } : undefined}` props** (lines 538, 690) for the GIF-disabled sections. Replace with a single `.sectionDisabled` SCSS class on the section subcomponent's root, keyed by an `isDisabled` prop. (Inline style → SCSS module is consistent with the broader pattern in `0151`'s `commit 6363ba8 refactor(ui): move static inline styles into SCSS modules`.)
- **One inline `style` left in place:** the GIF/MP4 `<video>` element's intrinsic dimensions (Task 4 keeps this — they're JS-derived from `IMAGE.defaultWidth`).
- Two `eslint-disable-next-line react-hooks/exhaustive-deps` annotations (lines 196, 212) — both documented; carry forward into the hook unchanged.

---

## Task 1 — Smoke tests for the current monolith (write FIRST, no source changes)

**Why:** Locks the orchestrator's observable behavior before any extraction. Every later task must keep these green.

**Files:**
- Create: `tests/components/ImageMetadata/ImageMetadataModal.smoke.test.tsx`

- [ ] **Step 1 — Identify the test fixtures.** The smoke tests use:
  - A `ContentImageModel` fixture (id 101, has `imageUrl`, `title: 'Hero Image'`, `contentType: 'IMAGE'`).
  - A `ContentGifModel` fixture (id 202, has `gifUrl`, `thumbnailUrl`, `title: 'Hero GIF'`, `contentType: 'GIF'`).
  - Two `ContentImageModel` fixtures for the bulk-edit path.
  - Empty arrays for `availableTags`/`availablePeople`/etc.
  - Spy on `window.confirm` (mock to return `false` first, then `true`) so Delete confirmation can be tested without firing the network call.
  - **Do not stub `updateImages`/`deleteImages`** — the smoke tests should never reach the network because they don't click Save with changes. If a test does need to click Save, mock `@/app/lib/api/content` for that test only.

- [ ] **Step 2 — Write the failing smoke tests:**

```tsx
import { fireEvent, render, screen } from '@testing-library/react';

import ImageMetadataModal from '@/app/components/ImageMetadata/ImageMetadataModal';
import type { ContentGifModel, ContentImageModel } from '@/app/types/Content';

const imageFixture = (id: number, overrides: Partial<ContentImageModel> = {}): ContentImageModel =>
  ({
    id,
    contentType: 'IMAGE',
    imageUrl: `https://cdn.example.com/${id}.jpg`,
    imageWidth: 4000,
    imageHeight: 3000,
    title: `Image ${id}`,
    alt: `Alt ${id}`,
    rating: null,
    blackAndWhite: false,
    isFilm: false,
    collections: [],
    tags: [],
    people: [],
    locations: [],
    ...overrides,
  }) as ContentImageModel;

const gifFixture = (id: number, overrides: Partial<ContentGifModel> = {}): ContentGifModel =>
  ({
    id,
    contentType: 'GIF',
    gifUrl: `https://cdn.example.com/${id}.mp4`,
    thumbnailUrl: `https://cdn.example.com/${id}.webp`,
    width: 1920,
    height: 1080,
    title: `Gif ${id}`,
    alt: `Alt ${id}`,
    rating: null,
    collections: [],
    ...overrides,
  }) as ContentGifModel;

describe('ImageMetadataModal — smoke', () => {
  const baseProps = {
    onClose: jest.fn(),
    selectedImageIds: [101],
    selectedImages: [imageFixture(101)],
  };

  beforeEach(() => {
    jest.clearAllMocks();
    jest.spyOn(window, 'confirm').mockReturnValue(false);
  });

  it('renders the edit-image heading for a single-image edit', () => {
    render(<ImageMetadataModal {...baseProps} />);
    expect(screen.getByRole('heading', { name: /edit image metadata/i })).toBeInTheDocument();
  });

  it('renders a bulk-edit heading with the count', () => {
    const images = [imageFixture(101), imageFixture(102), imageFixture(103)];
    render(
      <ImageMetadataModal
        {...baseProps}
        selectedImageIds={[101, 102, 103]}
        selectedImages={images}
      />
    );
    expect(screen.getByRole('heading', { name: /edit 3 images/i })).toBeInTheDocument();
  });

  it('renders the GIF preview as a <video> element for a single-GIF edit', () => {
    const gif = gifFixture(202);
    const { container } = render(
      <ImageMetadataModal {...baseProps} selectedImageIds={[202]} selectedImages={[gif]} />
    );
    expect(container.querySelector('video')).toBeInTheDocument();
  });

  it('disables Save when there are no pending changes', () => {
    render(<ImageMetadataModal {...baseProps} />);
    const save = screen.getByRole('button', { name: /save changes/i });
    expect(save).toBeDisabled();
  });

  it('Cancel calls onClose when there are no changes (no confirm)', () => {
    const onClose = jest.fn();
    render(<ImageMetadataModal {...baseProps} onClose={onClose} />);
    fireEvent.click(screen.getByRole('button', { name: /^cancel$/i }));
    expect(onClose).toHaveBeenCalledTimes(1);
    expect(window.confirm).not.toHaveBeenCalled();
  });

  it('Delete shows a confirmation dialog before doing anything', () => {
    render(<ImageMetadataModal {...baseProps} />);
    fireEvent.click(screen.getByRole('button', { name: /^delete image$/i }));
    expect(window.confirm).toHaveBeenCalled();
  });

  it('Delete button label reflects bulk-edit count', () => {
    render(
      <ImageMetadataModal
        {...baseProps}
        selectedImageIds={[101, 102]}
        selectedImages={[imageFixture(101), imageFixture(102)]}
      />
    );
    expect(screen.getByRole('button', { name: /delete 2 images/i })).toBeInTheDocument();
  });

  it('renders Remove-from-collection only when currentCollectionId is set', () => {
    const { rerender } = render(<ImageMetadataModal {...baseProps} />);
    expect(screen.queryByRole('button', { name: /remove image/i })).not.toBeInTheDocument();
    rerender(<ImageMetadataModal {...baseProps} currentCollectionId={42} />);
    expect(screen.getByRole('button', { name: /remove image/i })).toBeInTheDocument();
  });
});
```

- [ ] **Step 3 — Run; verify PASS:**

```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ImageMetadata/ImageMetadataModal.smoke.test.tsx
```

Expected: 8 PASS. (These describe current behavior; if any fail, the orchestrator already drifted from the spec and that's a separate bug to fix before continuing.)

- [ ] **Step 4 — Lint + commit:**

```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write tests/components/ImageMetadata/ImageMetadataModal.smoke.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix tests/components/ImageMetadata/ImageMetadataModal.smoke.test.tsx
git add tests/components/ImageMetadata/ImageMetadataModal.smoke.test.tsx
git commit -m "test(image-metadata): smoke tests for the modal orchestrator

Locks single/bulk/GIF render paths, Save-disabled-when-clean, Cancel-without-confirm,
Delete confirmation, Remove-from-collection visibility. These tests stay green through
every step of the 0159 decomposition.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 2 — Extract `useImageMetadataState` hook

**Why:** ~57 LoC of edit-state + 3 collection-diff memos + 1 callback live as inline blocks inside the orchestrator. Pulling them into a hook (a) shrinks the orchestrator by ~60 LoC, (b) makes the state logic unit-testable in isolation, (c) sets up Task 3's submit hook (which depends on `updateState`).

**Files:**
- Create: `app/components/ImageMetadata/hooks/useImageMetadataState.ts`
- Create: `tests/components/ImageMetadata/hooks/useImageMetadataState.test.tsx`
- Modify: `app/components/ImageMetadata/ImageMetadataModal.tsx` (delete the migrated blocks, replace with one hook call)

- [ ] **Step 1 — Write the failing hook test:**

```tsx
import { act, renderHook } from '@testing-library/react';

import { useImageMetadataState } from '@/app/components/ImageMetadata/hooks/useImageMetadataState';
import type { ContentImageModel } from '@/app/types/Content';

const img = (id: number, overrides: Partial<ContentImageModel> = {}) =>
  ({ id, contentType: 'IMAGE', collections: [], tags: [], people: [], locations: [], ...overrides }) as ContentImageModel;

describe('useImageMetadataState', () => {
  it('seeds updateState from the single selected image', () => {
    const { result } = renderHook(() =>
      useImageMetadataState({ selectedImages: [img(1, { title: 'Hero' })], availableLocations: [] })
    );
    expect(result.current.updateState.title).toBe('Hero');
    expect(result.current.hasChanges).toBe(false);
  });

  it('seeds updateState with common values for bulk edit', () => {
    const a = img(1, { title: 'Same', rating: 4 });
    const b = img(2, { title: 'Same', rating: 4 });
    const { result } = renderHook(() =>
      useImageMetadataState({ selectedImages: [a, b], availableLocations: [] })
    );
    expect(result.current.updateState.title).toBe('Same');
    expect(result.current.updateState.rating).toBe(4);
  });

  it('updateStateField merges partial updates', () => {
    const { result } = renderHook(() =>
      useImageMetadataState({ selectedImages: [img(1)], availableLocations: [] })
    );
    act(() => result.current.updateStateField({ title: 'Renamed' }));
    expect(result.current.updateState.title).toBe('Renamed');
    expect(result.current.hasChanges).toBe(true);
  });

  it('handleCollectionToggle adds a collection when absent and removes when present', () => {
    const { result } = renderHook(() =>
      useImageMetadataState({ selectedImages: [img(1)], availableLocations: [] })
    );
    act(() => result.current.handleCollectionToggle({ id: 5, name: 'Iceland' } as never));
    expect(result.current.updateState.collections?.[0]?.collectionId).toBe(5);
    act(() => result.current.handleCollectionToggle({ id: 5, name: 'Iceland' } as never));
    expect(result.current.updateState.collections).toEqual([]);
  });

  it('exposes pendingAddIds and pendingRemoveIds based on the original', () => {
    const original = img(1, { collections: [{ collectionId: 10, name: 'A', visible: true, orderIndex: 0 }] });
    const { result } = renderHook(() =>
      useImageMetadataState({ selectedImages: [original], availableLocations: [] })
    );
    act(() => result.current.handleCollectionToggle({ id: 20, name: 'B' } as never));
    act(() => result.current.handleCollectionToggle({ id: 10, name: 'A' } as never));
    expect([...result.current.pendingAddIds]).toEqual([20]);
    expect([...result.current.pendingRemoveIds]).toEqual([10]);
  });
});
```

- [ ] **Step 2 — Run; verify FAIL** (module not found):

```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ImageMetadata/hooks/useImageMetadataState.test.tsx
```

- [ ] **Step 3 — Implement the hook.** Create `app/components/ImageMetadata/hooks/useImageMetadataState.ts` by lifting lines 173–268 of the current `ImageMetadataModal.tsx` verbatim into a `useImageMetadataState({ selectedImages, availableLocations })` function. The hook's return shape:

```ts
export interface UseImageMetadataStateResult {
  updateState: ImageUpdateState;
  updateStateField: (updates: Partial<ImageUpdateState>) => void;
  hasChanges: boolean;
  originalCollectionIds: Set<number>;
  pendingAddIds: Set<number>;
  pendingRemoveIds: Set<number>;
  handleCollectionToggle: (collection: CollectionListModel) => void;
}
```

The two `eslint-disable-next-line react-hooks/exhaustive-deps` annotations carry forward unchanged (they're correct — see existing comments at the call site).

- [ ] **Step 4 — Wire into the orchestrator.** Replace lines 173–268 of `ImageMetadataModal.tsx` with:

```tsx
const {
  updateState,
  updateStateField,
  hasChanges,
  originalCollectionIds,
  pendingAddIds,
  pendingRemoveIds,
  handleCollectionToggle,
} = useImageMetadataState({ selectedImages, availableLocations });
```

Import the hook at the top of the file. Delete the now-unused `convertLocationsToModels`, `getCommonValues`, `hasObjectChanges` imports if no other call site in the file needs them — re-check by `grep`ing the file after the edit.

- [ ] **Step 5 — Verify smoke tests + new hook tests stay green:**

```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ImageMetadata
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
```

Expected: 8 smoke + 5 hook tests pass; tsc clean (modulo the pre-existing `.next/types/validator.ts` stubs).

- [ ] **Step 6 — Lint + commit:**

```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/components/ImageMetadata/hooks/useImageMetadataState.ts app/components/ImageMetadata/ImageMetadataModal.tsx tests/components/ImageMetadata/hooks/useImageMetadataState.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/components/ImageMetadata/hooks/useImageMetadataState.ts app/components/ImageMetadata/ImageMetadataModal.tsx tests/components/ImageMetadata/hooks/useImageMetadataState.test.tsx
git add app/components/ImageMetadata/hooks tests/components/ImageMetadata/hooks app/components/ImageMetadata/ImageMetadataModal.tsx
git commit -m "refactor(image-metadata): extract useImageMetadataState hook

Lifts updateState + collection diff memos + handleCollectionToggle out of the
ImageMetadataModal orchestrator. Pure structural move — smoke tests stay green.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 3 — Extract `useImageMetadataSubmit` hook

**Why:** ~170 LoC of async submit/delete/remove handlers + saving/error state live inline. The three-branch routing in `handleSubmit` (single-GIF / bulk-image / single-image) is the densest logic in the file and most needs isolation testing.

**Files:**
- Create: `app/components/ImageMetadata/hooks/useImageMetadataSubmit.ts`
- Create: `tests/components/ImageMetadata/hooks/useImageMetadataSubmit.test.tsx`
- Modify: `app/components/ImageMetadata/ImageMetadataModal.tsx`

- [ ] **Step 1 — Hook test (failing first).** Mock `@/app/lib/api/content` (`updateImages`, `updateGif`, `deleteImages`, `deleteGif`) and assert: `handleSubmit` early-returns to `onClose` when `!hasChanges`; routes to `updateGif` for single GIF; routes to `updateImages` with bulk diff for `isBulkEdit`; routes to `updateImages` with single-edit diff otherwise; `handleDelete` shows confirm + calls `deleteImages` on confirm; `handleRemoveFromCollection` builds the right diff. Test file structure mirrors Task 2's test file.

- [ ] **Step 2 — Implement.** Hook signature:

```ts
export interface UseImageMetadataSubmitParams {
  selectedImages: EditableContent[];
  selectedImageIds: number[];
  updateState: ImageUpdateState;
  hasChanges: boolean;
  originalCollectionIds: Set<number>;
  availableFilmTypes: ContentFilmTypeModel[];
  currentCollectionId?: number;
  onClose: () => void;
  onSaveSuccess?: (response: ContentImageUpdateResponse) => void;
  onGifSaveSuccess?: (gif: ContentGifModel) => void;
  onDeleteSuccess?: (deletedIds: number[]) => void;
  onRemoveFromCollectionSuccess?: (removedImageIds: number[]) => void;
}

export interface UseImageMetadataSubmitResult {
  saving: boolean;
  error: string | null;
  handleSubmit: (e: SubmitEvent<HTMLFormElement>) => Promise<void>;
  handleCancel: () => void;
  handleDelete: () => Promise<void>;
  handleRemoveFromCollection: () => Promise<void>;
}
```

Lift lines 215–216 (`saving`/`error` state) + 285–471 (the four handlers) verbatim. The `handleCancel` `window.confirm` and `handleDelete`/`handleRemoveFromCollection` confirmation prompts move with them — they're orchestration concerns, not view concerns.

- [ ] **Step 3 — Wire into the orchestrator.** Replace lines 215–216 + 285–471 with:

```tsx
const { saving, error, handleSubmit, handleCancel, handleDelete, handleRemoveFromCollection } =
  useImageMetadataSubmit({
    selectedImages,
    selectedImageIds,
    updateState,
    hasChanges,
    originalCollectionIds,
    availableFilmTypes,
    currentCollectionId,
    onClose,
    onSaveSuccess,
    onGifSaveSuccess,
    onDeleteSuccess,
    onRemoveFromCollectionSuccess,
  });
```

- [ ] **Step 4 — Verify + commit:**

```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ImageMetadata
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
# format/lint as in Task 2 Step 6, then:
git commit -m "refactor(image-metadata): extract useImageMetadataSubmit hook

Lifts handleSubmit/handleDelete/handleRemoveFromCollection/handleCancel plus the
saving/error state out of ImageMetadataModal. The single-GIF / bulk-image / single-
image routing in handleSubmit is now unit-testable in isolation.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

**After Tasks 2+3:** the orchestrator is down to ~360 LoC (1099 − 60 state − 170 handlers − ~510 of soon-to-extract JSX still inline = the running tally).

---

## Task 4 — Extract `<MediaPreview>` subcomponent

**Files:**
- Create: `app/components/ImageMetadata/sections/MediaPreview.tsx`
- Create: `tests/components/ImageMetadata/sections/MediaPreview.test.tsx`
- Modify: `app/components/ImageMetadata/ImageMetadataModal.tsx` (replace lines 477–506 with `<MediaPreview … />`); move the `renderSinglePreview` helper into the new file as a local function.

- [ ] **Step 1 — Component test (failing first).** Assert: renders a `<video>` for a single GIF; renders an `<img>` (alt-text-equal-to-title) for a single image; renders N thumbnails in the bulk grid; returns `null` when `previewImage` is undefined. Use `data-testid="media-preview-bulk-grid"` on the bulk wrapper so the count assertion is robust.

- [ ] **Step 2 — Implement.** Props: `{ isBulkEdit: boolean; selectedImages: EditableContent[]; selectedImageIds: number[]; previewImage: EditableContent; }`. The component reuses the existing SCSS classes (`.imageSection`, `.bulkEditGrid`, `.bulkEditThumb`, `.bulkEditThumbImg`, `.previewMedia`) by importing from `'../ImageMetadataModal.module.scss'` — those rules stay in place (still used by the orchestrator's outer layout).

- [ ] **Step 3 — Wire + verify + commit.**

---

## Task 5 — Extract `<EssentialInfoSection>` + migrate inputs onto `<Field>` primitives

**Files:**
- Create: `app/components/ImageMetadata/sections/EssentialInfoSection.tsx`
- Create: `tests/components/ImageMetadata/sections/EssentialInfoSection.test.tsx`
- Modify: `app/components/ImageMetadata/ImageMetadataModal.tsx`

- [ ] **Step 1 — Map inputs onto Field primitives.** Per the verified inventory of `app/components/ui/Field/`: `<Input>`, `<Textarea>`, `<Select>`, `<Checkbox>`, `<FormError>` are exported from `app/components/ui/Field/`. Mapping:

| Current | Replacement |
|---|---|
| `<input type="text" value={updateState.title}>` | `<Input label="Title" value={updateState.title ?? ''} onChange={…}>` |
| `<textarea value={updateState.caption}>` | `<Textarea label="Caption" disabled={isGif} value={updateState.caption ?? ''} onChange={…}>` |
| `<input type="text" value={updateState.alt}>` | `<Input label="Alt Text (Accessibility)" …>` |
| `<input type="text" value={updateState.author}>` | `<Input label="Author" …>` |
| `<select value={updateState.rating}>` (5 stars) | `<Select label="Rating" options={[…]} …>` |
| Visibility checkbox `<input type="checkbox">` | `<Checkbox label="Collection Visibility" …>` |
| Locations `<Dropdown<LocationModel>>` | **stays** (already a primitive) |

**Verification preflight:** before writing the test, confirm the Field primitives expose the exact props above. Run:

```bash
grep -n "export\|interface\|type " app/components/ui/Field/Input.tsx app/components/ui/Field/Textarea.tsx app/components/ui/Field/Select.tsx app/components/ui/Field/Checkbox.tsx
```

If a prop name differs (e.g. `<Select>` takes `options: { value: string; label: string }[]` vs `children: <option>…</option>`), adjust the mapping table inline rather than guessing.

- [ ] **Step 2 — Test (failing first).** Assert: heading "Essential Information" present; Title input round-trips a change through `onChange`; Caption is disabled when `isGif`; Rating select shows 1–5 + "No rating"; Locations Dropdown receives the `availableLocations` it was given; Collection Visibility checkbox is rendered only when `currentCollectionId` is provided.

- [ ] **Step 3 — Implement, wire, verify, commit.**

**Carry-over from Task 4 onwards:** the 2 inline `style={isGif ? { opacity: 0.4, pointerEvents: 'none' } : undefined}` blocks (lines 538, 690) are replaced with `.sectionDisabled` SCSS class on the section's root `<div>`, keyed off an `isDisabled?: boolean` prop. Add the rule to `ImageMetadataModal.module.scss` (or, cleaner: each section gets its own `.module.scss` co-located in `sections/` — TBD per task author, but be consistent across Tasks 5/6/7).

---

## Task 6 — Extract `<CameraSettingsSection>`

**Files:** mirror Task 5's structure under `sections/CameraSettingsSection.{tsx,test.tsx}`.

The section contains: Camera Dropdown (with the most complex `onAddNew` in the file — optimistic update + async createCamera + swap real id), Lens Dropdown, ISO/F-Stop 2-col, Shutter/Focal 2-col, B&W/Film checkboxes, and the conditional Film Stock + Film Format 2-col block when `updateState.isFilm`. Pass `updateState`, `updateStateField`, and the relevant `available*` arrays as props. Apply the `.sectionDisabled` class when `isGif`.

Test assertions: Camera Dropdown receives `availableCameras`; Film section only renders when `updateState.isFilm`; ISO/F-Stop/Shutter/Focal round-trip; the optimistic create flow can be left for later coverage (it has integration-test surface) — the section test only asserts the dropdown wiring.

---

## Task 7 — Extract `<TagsPeopleSection>`

Smallest extraction — just two `<Dropdown>`s. Same pattern. Section test asserts each Dropdown is wired with its `available*` array and emits the right `updateStateField` call on change.

---

## Task 8 — Extract `<MetadataActionRow>` + migrate the 4 raw `*Button` classes onto `<Button>`

**Why:** This is the only task with a **visible behavior delta** (button styling switches from bespoke SCSS to the primitive's tokens — should look identical because the variants map cleanly, but warrants browser verification).

**Files:**
- Create: `app/components/ImageMetadata/sections/MetadataActionRow.tsx`
- Create: `tests/components/ImageMetadata/sections/MetadataActionRow.test.tsx`
- Modify: `app/components/ImageMetadata/ImageMetadataModal.tsx` (replace lines 1028–1088)
- Modify: `app/components/ImageMetadata/ImageMetadataModal.module.scss` (delete `.deleteButton`, `.removeButton`, `.cancelButton`, `.saveButton`, `.loadingLabel`; keep `.buttonRow`, `.buttonRowLeft`, `.buttonRowRight`)

- [ ] **Step 1 — Component test (failing first).** Asserts: Delete button uses variant `danger` (assertion: `btn.className` contains the Button primitive's `danger` class — use `toHaveClass(expect.stringContaining('danger'))`); Save button is `primary`; Cancel is `ghost`; Remove button is visible only when `currentCollectionId` is provided; `loading={saving}` propagates to all four buttons (assert `aria-busy="true"` on each); Save button is disabled when `!hasChanges`.

- [ ] **Step 2 — Implement.** Props:

```ts
interface MetadataActionRowProps {
  isBulkEdit: boolean;
  selectedCount: number;
  saving: boolean;
  hasChanges: boolean;
  showRemove: boolean;
  onDelete: () => void;
  onRemove: () => void;
  onCancel: () => void;
}
```

`onSubmit` stays bound to the `<form onSubmit>` in the orchestrator; the Save button is `<Button type="submit" variant="primary" loading={saving} disabled={!hasChanges}>` so it triggers the form's native submit.

- [ ] **Step 3 — Delete the migrated SCSS rules.** Grep first to make sure nothing else in the tree references them:

```bash
grep -rn "deleteButton\|removeButton\|cancelButton\|saveButton\|loadingLabel" app/components/ImageMetadata
```

Expected after the JSX migration: matches only inside `ImageMetadataModal.module.scss` itself. Then delete those 5 rule blocks. Verify post-delete file size shrinks materially (target: −80 to −120 LoC in the .scss).

- [ ] **Step 4 — Verify + browser-check.** Beyond the test suite, this task warrants `npm run dev` on :3001 and a manual click-through of the modal action row in single + bulk + GIF modes. The Button primitive's hover/focus rings should match what was there before, but verify.

- [ ] **Step 5 — Commit:**

```bash
git commit -m "refactor(image-metadata): adopt <Button> for action row, delete raw button classes

Delete/Remove/Cancel/Save now use the canonical Button primitive (danger/danger/
ghost/primary variants, loading prop). Drops .deleteButton/.removeButton/.cancelButton/
.saveButton/.loadingLabel from ImageMetadataModal.module.scss. The 4 button classes
PR #158 missed in its action-button migration sweep are now consolidated.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 9 — Final cleanup + line-count gate

- [ ] **Step 1 — Confirm the orchestrator is ≤220 LoC:**

```bash
wc -l app/components/ImageMetadata/ImageMetadataModal.tsx
```

Target: ≤220. If higher, the extraction left dead code behind — `grep -n` for the section helpers in the orchestrator and confirm only the wiring + the `<Modal>` shell remain.

- [ ] **Step 2 — Confirm the SCSS shrunk:** target `wc -l ImageMetadataModal.module.scss` from 599 → ≤500 (the 5 deleted rules + their internals).

- [ ] **Step 3 — Full tree green:**

```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write 'app/components/ImageMetadata/**/*.{ts,tsx,scss}' 'tests/components/ImageMetadata/**/*.{ts,tsx}'
/opt/homebrew/bin/node node_modules/.bin/eslint --fix 'app/components/ImageMetadata/**/*.{ts,tsx}'
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/ImageMetadata/**/*.scss'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest
```

Expected: 72 suites + the new ImageMetadata suites all green (target: 8 smoke + 5 state-hook + ~6 submit-hook + 4 MediaPreview + 6 EssentialInfoSection + 5 CameraSettingsSection + 3 TagsPeopleSection + 6 MetadataActionRow ≈ **43 new tests**); 80 suites total (was 72); 0 → ~43 tests for ImageMetadata surface.

- [ ] **Step 4 — Browser verification on `:3001`:** single-image edit, bulk-edit, single-GIF edit, Delete with cancel, Delete with confirm, Save with no changes, Save with changes, Cancel with unsaved changes (confirm prompt), Remove-from-collection. All should behave identically to pre-refactor.

---

## Verification (run after each task)

```bash
cd /Users/themancalledzac/Code/edens.zac
/opt/homebrew/bin/node node_modules/.bin/prettier --write <touched files>
/opt/homebrew/bin/node node_modules/.bin/eslint --fix <touched .ts/.tsx>
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix <touched .scss>
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest
```

Smoke tests from Task 1 stay green at every step — that's the rolling regression gate. The pre-existing `.next/types/validator.ts` errors for removed routes (collectionType, metadata, search) are noise; ignore unless they change.

---

## Suggested commit sequence

1. `test(image-metadata): smoke tests for the modal orchestrator` (Task 1)
2. `refactor(image-metadata): extract useImageMetadataState hook` (Task 2)
3. `refactor(image-metadata): extract useImageMetadataSubmit hook` (Task 3)
4. `refactor(image-metadata): extract MediaPreview subcomponent` (Task 4)
5. `refactor(image-metadata): extract EssentialInfoSection onto Field primitives` (Task 5)
6. `refactor(image-metadata): extract CameraSettingsSection` (Task 6)
7. `refactor(image-metadata): extract TagsPeopleSection` (Task 7)
8. `refactor(image-metadata): adopt <Button> for action row, delete raw button classes` (Task 8)
9. *(optional rollup)* `chore(image-metadata): tidy after decomposition` if Task 9 surfaces follow-ups

Each commit passes `tsc --noEmit` + `jest` + `stylelint` independently. **Tasks 2 and 3 are sequential** (Task 3 depends on `updateState` from Task 2's hook). **Tasks 4–8 are mutually independent** and could be parallelized via Agent Teams if the user opts in — one subagent per subcomponent, with `tests/components/ImageMetadata/` as the shared test directory and the orchestrator file as the coordination point. Without Agent Teams, run them sequentially in the order above (top-of-file → bottom-of-file matches reading order in code review).

---

## Spec-coverage checklist

Maps each plan task to the architectural concern it addresses.

| Concern | Task | Status |
|---|---|---|
| Orchestrator is 1099 LoC and unreadable | Tasks 2–8 (extraction) | ✅ planned |
| No component tests exist for the modal | Task 1 (smoke) + Tasks 2–8 (per-piece) | ✅ planned |
| Three-branch submit routing is untested | Task 3 (hook + tests) | ✅ planned |
| Edit-state + diff memos are inline noise | Task 2 (hook + tests) | ✅ planned |
| `renderSinglePreview` is a free function in the modal file | Task 4 (moves into MediaPreview) | ✅ planned |
| Inline `style={isGif ? {…} : undefined}` (2 occurrences) | Tasks 5/6 (`.sectionDisabled` class) | ✅ planned |
| 4 raw `*Button` classes that PR #158's primitive migration missed | Task 8 (adopt `<Button>`, delete SCSS) | ✅ planned |
| Naming smell — `ImageMetadataModal` / `selectedImageIds` should drop the "Image" prefix | **Out of scope** | 📋 own MR after this lands (per mempalace `user-2373731890`) |
| `force-dynamic` on `app/page.tsx` blocked on backend | **Out of scope** | ⛔ blocked, chapter 002 |
| LCP / blur placeholder / GIF poster / will-change | **Out of scope** | 🗓 deferred to end of refactor phases per user direction |

**Plan tasks not in any concern:** none — every task maps to an observed concern from reading the file + mempalace history.

**Spec items not covered:** none for this MR's scope.

---

## Dead-code & latent-bug register (address inline during the relevant task)

- **Comment drift** on `ImageMetadataModal.tsx:139–145`: the docstring says "Left side: Image preview (~50% width). Right side: Metadata form (~50% width)." — that was true pre-`<Modal variant="sheet">`; the actual layout is now a vertical sheet on most viewports. Tighten or remove the comment in Task 4 when MediaPreview is extracted.
- **Possibly dead `convertLocationsToModels` import** after Task 2 lifts `buildInitialState` into the hook — verify with `grep` before deleting the import.
- **`updateImages` returning `null`** is treated as a silent no-op (`response !== null` check at line 368). Not a bug to fix here, but worth a Task 3 hook test that asserts `onSaveSuccess` is **not** called when the API returns `null`, so the contract is locked.

---

## Files referenced

- **New:** `app/components/ImageMetadata/hooks/useImageMetadataState.ts`, `app/components/ImageMetadata/hooks/useImageMetadataSubmit.ts`, `app/components/ImageMetadata/sections/{MediaPreview,EssentialInfoSection,CameraSettingsSection,TagsPeopleSection,MetadataActionRow}.tsx`, and a `tests/components/ImageMetadata/*` mirror.
- **Modified:** `app/components/ImageMetadata/ImageMetadataModal.tsx` (1099 → ≤220 LoC), `app/components/ImageMetadata/ImageMetadataModal.module.scss` (599 → ≤500 LoC).
- **Not touched:** `app/components/ImageMetadata/imageMetadataUtils.ts`, `ManageClient.tsx`, any `ui/` primitive.

---

## Execution Handoff

**Plan complete. Branch `0159-image-metadata-modal-decomposition` is created off `0152-token-collapse-a11y`** (because `ImageMetadataModal.module.scss` depends on the new `--scrim-light-*` / `--duration-base` / `--focus-ring` tokens introduced on that branch).

**Pre-flight state:** the working tree carries one uncommitted change from the prior turn — the orphan-token cleanup in `app/styles/globals.css` (12 dead color tokens deleted). It belongs on `0152` semantically (it was the post-ship cleanup for that branch). Recommend cherry-moving it to `0152` before starting Task 1, OR landing it as the first commit on `0159` if `0152` is already submitted and not safely amendable. **Default plan:** move to `0152` so this branch starts clean from a pure-refactor baseline.

**Execution options:**
1. **Subagent-Driven (recommended)** — `superpowers:subagent-driven-development`. Fresh subagent per task. Tasks 4–8 can fan out in parallel after Tasks 1–3 sequence.
2. **Inline Execution** — `superpowers:executing-plans`. Single thread, all 9 tasks back-to-back with checkpoints.
3. **Hybrid** — Tasks 1, 2, 3 inline (sequential, dependency chain); Tasks 4–8 dispatched in parallel via Agent Teams; Task 9 inline.

Which approach — and shall I start with **Task 1 (smoke tests)** now?
