# 006 · Thin-Component Extraction (Phase 2) — Critical Code Review

_Date: 2026-06-06 · Reviewer pass over branch `0176-thin-component-extraction` (PR #179) vs `main` · Chapter [006 · Code Health](../../006-code-health.md) · reviews [the Phase-2 refactor](006-thin-component-extraction.md) against [the Phase-1 audit](006-thin-component-audit-report.md)._

> `docs/superpowers/` is gitignored — this report is local-only by convention, like its sibling plans.

## Verdict

**This refactor is high quality and ships as-is.** All 7 commits / 27 files are genuinely behavior-preserving: every extracted helper body is a verbatim move of the original inline logic, every one of the 5 self-flagged deviations checks out as a true no-op (verified line-by-line against `git show main:`), `tsc --noEmit` is clean, eslint is clean on all 15 changed source files, and the new tests (261 util unit tests + 39 characterization/existing-component tests across the touched suites) are green. The "existing tests stay green unchanged" rule holds in substance: the three test files marked `M` (`EssentialInfoSection`, `GalleryFilter`, `contentFilter`) are **purely additive** — zero removed/changed lines, only appended `describe`/`it` blocks. Type safety is preserved or improved (named return types replace inline anonymous types; no `any`, no unsound casts). Findings below are all **low / nit / verified-correct** — there is **no behavior bug and nothing blocking**. The only actionable items are test-coverage hardening and pre-existing cosmetic debt the audit already deferred.

### Summary table

| ID | Severity | Category | File | Title | Status |
|---|---|---|---|---|---|
| L1 | low | test-gap | `tests/components/Content/boxRendererUtils.test.ts` | No test for `isReorderMode: undefined` (the actual deviation #4 input) | [x] FIXED |
| L2 | low | test-gap | `tests/utils/contentFilter.test.ts` | No test locks the `String(img.rating ?? 0)` wrapper contract | [x] FIXED (cheap unit test; heavy component render intentionally skipped) |
| N1 | nit | over-extraction | `app/components/ui/Dropdown/dropdownUtils.ts:103` | `isFieldVisible` is a one-line ternary (borderline trivial) | [ ] |
| N2 | nit | naming | `app/components/Content/CollectionContentRenderer.tsx:59` | `_hasSlug` underscore name still misleading (pre-existing, audit-flagged) | [ ] |
| N3 | nit | style-defer | `app/components/Content/CollectionContentRenderer.tsx` | Per-render inline `style={{}}` objects (pre-existing, defer to inline-style plan) | [ ] |
| V1 | ✅ verified | behavior-drift | `app/utils/contentFilter.ts:288` | Deviation #1 — `hasValueVariance` `.filter(Boolean)` + `String()` rating wrapper | [x] |
| V2 | ✅ verified | behavior-drift | `app/components/FullScreenModal/fullScreenModalUtils.ts:30` | Deviation #2 — double-guard `!isGif && !isGifBlock` | [x] |
| V3 | ✅ verified | behavior-drift | `app/components/Content/collectionContentRendererUtils.ts:78` | Deviation #3 — `getClickEligibility` extracts predicates only | [x] |
| V4 | ✅ verified | behavior-drift | `app/components/Content/boxRendererUtils.ts:33` | Deviation #4 — `!!isReorderMode` coercion | [x] |
| V5 | ✅ verified | behavior-drift | `app/utils/contentFilter.ts:206` (call site) | Deviation #5 — full criteria (incl. `lenses`) → `syncToUrl` | [x] |

---

## Findings

### [L1] No test for `isReorderMode: undefined` (the actual deviation-#4 input)
- **Severity:** low
- **Category:** test-gap
- **Location:** `tests/components/Content/boxRendererUtils.test.ts:8-18`
- **Finding:** Deviation #4 changes `isReorderMode && …` to `!!isReorderMode && …`. The real-world divergent input is `isReorderMode === undefined` (the prop is `isReorderMode?: boolean`, defaulted to `false` only in `CollectionContentRenderer`, not in `BoxRenderer`). The "when not in reorder mode" test passes `isReorderMode: false`, not `undefined` — so the one input that produced `undefined` in the original and `false` now is not exercised.
- **Why it matters:** Cosmetic for behavior (both falsy; the flags are only read when `isReorderMode` is truthy, so the change is unobservable — see V4), but the characterization suite should lock the exact deviation input so a future change can't silently regress it.
- **Recommended fix:** Add one case:
  ```ts
  it('treats undefined reorder mode as inactive (coerced to false)', () => {
    const flags = computeReorderFlags(7, { pickedUpImageId: 7, reorderMoves: [{ imageId: 7, toIndex: 0 }] });
    expect(flags.isPickedUp).toBe(false);
    expect(flags.hasMoved).toBe(false);
  });
  ```
- **How to verify (for the next agent):** `git show main:app/components/Content/BoxRenderer.tsx | sed -n '92,96p'` shows the original `isReorderMode && …` with `isReorderMode?: boolean` (no default in `BoxRenderer`). Add the test, run `/opt/homebrew/bin/node node_modules/.bin/jest tests/components/Content/boxRendererUtils.test.ts --no-coverage`; expect green.
- **Fixable now?:** yes (safe mechanical — test-only addition)
- [x] **Status:** FIXED — added `it('treats undefined reorder mode as inactive (the !!isReorderMode coercion)')` to the "when not in reorder mode" block (omits `isReorderMode` so it defaults to `undefined`, the exact deviation-#4 input). jest green (162 passed across the two touched suites), tsc/eslint clean.

### [L2] No characterization test locks the `String(img.rating ?? 0)` call-site wrapper
- **Severity:** low
- **Category:** test-gap
- **Location:** `app/components/ContentCollection/CollectionPageClient.tsx:153-156` (call site) · `tests/components/ContentCollection/CollectionPage.test.tsx` (the only component test, stubs out the filter logic)
- **Finding:** Deviation #1's correctness depends on the **call site** passing `String(img.rating ?? 0)` so that rating `0` (falsy) survives the helper's baked-in `.filter(Boolean)`. The helper's unit tests (`contentFilter.test.ts:270-273`) lock this *as called with the String wrapper*, but nothing locks the call site itself: `CollectionPage.test.tsx` stubs `ContentBlockWithFullScreen` and only asserts the `<h1>`, never exercising `hasRatingVariance`/`showHighlyRated`. If someone later "simplifies" the call site to `img => img.rating`, rating-0 would be dropped and the "Highly Rated" control would disappear on an all-0-vs-some-rated collection — no test would catch it.
- **Why it matters:** The deviation is correct today, but the regression surface lives at the un-tested call site, not in the (well-tested) helper. This is the single thinnest spot in an otherwise well-guarded change.
- **Recommended fix:** Either (a) a small `renderHook`/component characterization that renders `CollectionPageClient` with a mix of rating-0 and rating-5 images and asserts the filter bar surfaces the Highly Rated control, or (b) cheaper: add an inline-comment-anchored unit test that documents the contract by asserting `hasValueVariance([rating0, rating5], img => img.rating)` returns `false` (proving the wrapper is load-bearing — the existing test at :270 already does the positive case with the wrapper; add the negative case *without* the wrapper to show why it's needed).
- **How to verify (for the next agent):** `git show main:app/components/ContentCollection/CollectionPageClient.tsx | sed -n '209,217p'` shows the original `new Set(allImages.map(img => img.rating ?? 0))` (numbers, no filter). Confirm the new helper at `app/utils/contentFilter.ts:288` bakes in `.filter(Boolean)`. Then confirm `tests/components/ContentCollection/CollectionPage.test.tsx` does not render real content (it stubs `ContentBlockWithFullScreen`).
- **Fixable now?:** yes (test-only) — or **defer-to-other-plan** (a `006-collectionpageclient-characterization` follow-up) if a full component render is preferred.
- [x] **Status:** FIXED (option b — cheap). Added the negative case to the `hasValueVariance` block in `tests/utils/contentFilter.test.ts`: `hasValueVariance([rating5, rating0], img => img.rating)` returns `false`, documenting that the raw-number selector drops rating-0 and proving the call-site `String()` wrapper is load-bearing. **Option (a) — a full `CollectionPageClient` render characterization — was deliberately NOT done:** the existing `CollectionPage.test.tsx` stubs `CollectionPageClient` to `() => null` because the real client pulls the heavy fullscreen/filter/observer pipeline that can't run cleanly under jsdom; a real-render guard would fight that established pattern to protect an already-correct, already-commented (`CollectionPageClient.tsx:151-152`) deviation. Not worth the weight under the "minimize code" directive.

### [N1] `isFieldVisible` is a borderline-trivial one-line helper
- **Severity:** nit
- **Category:** over-extraction
- **Location:** `app/components/ui/Dropdown/dropdownUtils.ts:103-105`
- **Finding:** `isFieldVisible` is a single-expression ternary (`field.showWhen ? field.showWhen(formData) : true`). The project's no-trivial-helper rule (`ai_main.md`, restated in the audit) says single-expression logic isn't extracted unless it has 3+ call sites or a real domain concept.
- **Why it matters:** Minimal — the audit pre-justified it ("3+ sites: validate + process + render") and it IS reused by `findMissingRequiredFields` and `processAddNewFormData`. It earns its keep as the shared predicate behind the "hidden fields are skipped" rule. Recording only so the next agent doesn't re-litigate it. `getKey` (:31) and `itemExistsInDatabase` (:40) are similarly borderline but likewise justified by call-site count and family cohesion.
- **Recommended fix:** None. Keep as-is — it is correctly within the rule via the 3-call-site exception.
- **How to verify (for the next agent):** `grep -n 'isFieldVisible' app/components/ui/Dropdown/dropdownUtils.ts` → used at :104 (self in `findMissingRequiredFields`), :116, :139, :161 = 3+ real sites. Rule satisfied.
- **Fixable now?:** needs-judgment (no change recommended)
- [ ] **Status:** open

### [N2] `_hasSlug` underscore name remains misleading
- **Severity:** nit
- **Category:** naming
- **Location:** `app/components/Content/CollectionContentRenderer.tsx:59` (destructure), read as boolean at :102/:111 and as a route segment at :523 (`href={`/${_hasSlug}`}`)
- **Finding:** The leading underscore signals "intentionally unused," but `_hasSlug` is load-bearing — it's threaded into `getClickEligibility` and interpolated into an href. Pre-existing; the audit already flagged it (`006-thin-component-audit-report.md:221`) and explicitly deferred it to "its own cleanup." This refactor neither introduced nor worsened it (it carried `_hasSlug` through to the new helper's `hasSlug` param, which is correctly named — the misnomer is only on the component-side destructure).
- **Why it matters:** Readability only. Not a regression.
- **Recommended fix:** Rename the prop `_hasSlug` → `hasSlug` in `CollectionContentRenderer` and at its `CollectionContentRendererProps` source (and the BoxRenderer pass-through). Out of scope for the behavior-preserving sweep; do under its own trivial-cleanup commit.
- **How to verify (for the next agent):** `grep -rn 'hasSlug' app/types/ContentRenderer.ts app/components/Content/` to find every site before renaming; `tsc --noEmit` after.
- **Fixable now?:** defer-to-other-plan (own cleanup commit; touches the shared `ContentRenderer` type)
- [ ] **Status:** open

### [N3] Per-render inline `style={{}}` objects in `CollectionContentRenderer`
- **Severity:** nit
- **Category:** style-defer
- **Location:** `app/components/Content/CollectionContentRenderer.tsx` (inline `style={{ width, height }}` recomputed per render at multiple JSX sites, e.g. :195-198)
- **Finding:** Recomputed object literals in the render path. Pre-existing; audit flagged it (`006-thin-component-audit-report.md:222`) and routed it to `006-inline-jsx-config-cross-file.md` / the inline-style→SCSS rule, **not** this plan.
- **Why it matters:** Marginal re-render cost / a separate code-quality axis. Untouched by this refactor.
- **Recommended fix:** Address under the inline-style plan, not here.
- **How to verify (for the next agent):** `grep -n 'style={{' app/components/Content/CollectionContentRenderer.tsx`.
- **Fixable now?:** defer-to-other-plan (`006-inline-jsx-config-cross-file.md`)
- [ ] **Status:** open

---

## Verified-correct (the 5 self-flagged deviations — do NOT re-investigate)

### [V1] Deviation #1 — `hasValueVariance` `.filter(Boolean)` + rating `String()` wrapper ✅
- **Location:** helper `app/utils/contentFilter.ts:288-294`; call sites `CollectionPageClient.tsx:153-156` (rating) and `:236-239` (date).
- **Evidence:** Original `hasRatingVariance` = `new Set(allImages.map(img => img.rating ?? 0))` — **no** `.filter(Boolean)`, so rating `0` (a number) is a distinct Set member. Original `hasDateVariance` = `new Set(allImages.map(img => img.captureDate).filter(Boolean))` — **had** `.filter(Boolean)`. The unified helper bakes in `.filter(Boolean)`. The rating call site compensates with `String(img.rating ?? 0)`: `String(0) === "0"` is truthy, so it survives `.filter(Boolean)` and remains distinct — identical Set cardinality to the original (`{0,4}` ≅ `{"0","4"}`, both size 2; all-zero → size 1 → `false` in both). The date call site passes `img.captureDate` directly, replicating the original's falsy-drop exactly.
- **Test guard:** `tests/utils/contentFilter.test.ts:270-273` ("counts a rating of 0 as a distinct value when stringified", with a regression comment) and `:276-281` (date falsy-drop). Correct and behavior-locking. (Call-site coverage gap noted in L2.)
- **Verdict:** behavior-identical.

### [V2] Deviation #2 — FullScreenModal double-guard `!isGif && !isGifBlock(currentImage)` ✅
- **Location:** `app/components/FullScreenModal/fullScreenModalUtils.ts:30` and `:46`.
- **Evidence:** At the call site `isGif = isGifBlock(currentImage)` (`FullScreenModal.tsx:93`), so the passed `isGif` boolean and `isGifBlock(currentImage)` can never disagree. When `isGif === false`: `!isGif === true` AND `!isGifBlock(currentImage) === true` → reads `currentImage.locations`/`.captureDate` (identical to original `!isGif ? … `). When `isGif === true`: `!isGif === false` short-circuits to the collection fallback (identical). The extra `&& !isGifBlock(...)` exists purely so TS narrows `currentImage` to the non-GIF union member before the field read — a runtime-redundant, behavior-neutral guard.
- **Test guard:** `tests/components/FullScreenModal/fullScreenModalUtils.test.ts` (GIF fallback at :91/:133, empty-array fallback, undefined collection, null captureDate) + `FullScreenModal.metadata.test.tsx` (rendered-component characterization asserting image-beats-collection precedence and GIF fallback in the DOM).
- **Verdict:** behavior-identical.

### [V3] Deviation #3 — `getClickEligibility` extracts only the two predicates ✅
- **Location:** helper `app/components/Content/collectionContentRendererUtils.ts:78-98`; `handleClick` imperative early returns retained at `CollectionContentRenderer.tsx:109-111`.
- **Evidence:** `isSlugNav` and `hasClickHandler` bodies are byte-identical to the original (only `_hasSlug` → `hasSlug` param rename). The three `handleClick` early returns (`TEXT`, `isReorderMode`, `_hasSlug && !onImageClick`) are present in the same order, not moved into the helper. Nothing dropped or reordered. The empty-string-slug nuance (`hasSlug !== undefined && !onImageClick` makes `hasClickHandler` true while `!!hasSlug` keeps `isSlugNav` false) is preserved and explicitly tested.
- **Test guard:** `tests/components/Content/collectionContentRendererUtils.test.ts:82-150` covers all click branches incl. the empty-string-slug edge (:143); `CollectionContentRenderer.characterization.test.tsx` guards the TEXT/Related render branches.
- **Verdict:** behavior-identical.

### [V4] Deviation #4 — BoxRenderer `!!isReorderMode` coercion ✅
- **Location:** `app/components/Content/boxRendererUtils.ts:33-34`.
- **Evidence:** Original `isPickedUp = isReorderMode && …` returns `undefined` when `isReorderMode` is `undefined`; new `!!isReorderMode && …` returns `false`. Unobservable because: (a) `CollectionContentRendererProps` destructures `isPickedUp = false` / `hasMoved = false` (default-false), and (b) the consuming reorder overlays at `CollectionContentRenderer.tsx:336` and `:561` are gated by `{isReorderMode && …}`, so `isPickedUp`/`hasMoved` are only ever read when `isReorderMode` is truthy. The `isFirstInOrder`/`isLastInOrder` math (`orderIndex === (reorderDisplayOrder?.length ?? 0) - 1`) is byte-identical, preserving the empty/undefined-order "isLast === true" quirk.
- **Test guard:** `tests/components/Content/boxRendererUtils.test.ts` covers the not-reorder short-circuit (with `false`), the `indexOf === -1` edge, and the empty/undefined-order `isLast` quirk. (The `undefined` input itself is the L1 gap.)
- **Verdict:** behavior-identical.

### [V5] Deviation #5 — `handleFilterChange` passes full criteria (incl. `lenses`) to `syncToUrl` ✅
- **Location:** `CollectionPageClient.tsx:206` (`syncToUrl(buildCollectionCriteria(next))`); `buildCollectionCriteria` at `contentFilter.ts:206` includes `lenses`/`lensMatchMode`.
- **Evidence:** `git show main:app/utils/contentFilter.ts` → `serializeFilterToParams` emits only `rating | people | location | tag | camera | q | from | to | isFilm | bw | collection`. There is **no** `lens`/`lenses` key, and no match-mode keys (`tagMatchMode` etc.) either — both were always ignored. So passing the full criteria object (with `lenses` + match modes) produces a byte-identical URLSearchParams to the original hand-trimmed object. The original's omission of `lenses` from `syncToUrl` was cosmetic, not load-bearing. Same reasoning applies to `LocationPageClient.tsx:84` (`buildLocationCriteria` has no lens keys at all).
- **Test guard:** `buildCollectionCriteria` / `buildLocationCriteria` round-trip tests in `contentFilter.test.ts`; `serializeFilterToParams` already covered by pre-existing tests.
- **Verdict:** behavior-identical.

---

## Verified clean (checked and found solid)

- **All 6 helper-body extractions are verbatim moves** — diffed each `*Utils.ts` against `git show main:<component>`: `dropdownUtils` (10 helpers), `boxRendererUtils.computeReorderFlags`, `collectionContentRendererUtils` (`toCollectionDimensions`/`resolveValidDimensions`/`getClickEligibility`), `essentialInfoUtils` (toggle + visibility), `fullScreenModalUtils` (3 resolvers), `filterToolbarUtils` + `GalleryFilter` additions, and the 9 `contentFilter` helpers. No off-by-one, no `??`↔`||` drift, no Set/array semantics change, no dropped guard.
- **`logger.error` side effect kept in the component** (`CollectionContentRenderer.tsx:476-487`), before the pure `resolveValidDimensions` call — exactly as the plan required (pure helper, side effect stays put). NaN-recovery ladder is byte-identical.
- **`EssentialInfoSection` guard ordering preserved** — `if (currentCollectionId == null) return;` stays in the component wrapper (`:62-ish`), so `updateStateField` is never called for a null id; the helper's internal null-guard is harmless dead-defense for isolated testability. APPEND/UPDATE branches byte-identical, incl. the `name: undefined` edge.
- **Type safety preserved or improved** — `toCollectionDimensions` param changed from inline `NonNullable<ReturnType<typeof useCollectionFilter>>['filterOptions']` to the explicit `CollectionInfoOptions` (the exact same type — `filterOptions: CollectionInfoOptions` in the context). `filmFilterFromIsFilm` returns `FilmFilter` ≡ original `FilterState['filmFilter']`. `essentialInfoUtils` returns named `ChildCollection[]` replacing an inline anonymous array type. No `any`, no `as unknown as`, generics correct (`T extends MetadataItem`).
- **`ARRAY_FILTER_KEYS` single-sourced** in `GalleryFilter.ts` (byte-identical to the deleted local `ARRAY_KEYS`), now used at both `FilterToolbar` sites; the new `GalleryFilter.test.ts:36` even asserts it matches the array fields of `INITIAL_FILTER_STATE`.
- **"Existing tests unchanged" rule holds** — `git diff main -- tests/utils/contentFilter.test.ts | grep '^-'` = 0 removed lines; same for `EssentialInfoSection.test.tsx` and `GalleryFilter.test.ts`. All three are append-only.
- **Toolchain green** — `tsc --noEmit` exit 0; `eslint` exit 0 on all 15 changed source files; `jest` 261/261 new util tests + 39/39 characterization+existing component tests pass (full suite reported green by lead).
- **Plan adherence** — every touched component now reads `hooks → helper calls (in useMemo/useCallback wrappers) → early returns → JSX` with no multi-line derivation inline. Helpers are co-located (or consolidated into the same-domain `contentFilter.ts`, as the audit explicitly directed for the filter pages). `'use client'` correctly omitted from every `*Utils.ts`.

## Resolution (2026-06-06 follow-up pass)

1. **L1 — DONE.** `isReorderMode: undefined` test case added (test-only, locks deviation #4's real input).
2. **L2 — DONE (cheap version).** Negative `hasValueVariance(…, img => img.rating)` case added to lock the `String()` wrapper contract for deviation #1. The heavy `CollectionPageClient` render characterization was deliberately skipped (see L2 finding for rationale — it fights the deliberate stub pattern to guard an already-correct, already-commented deviation).
3. **N2 — deferred** to its own trivial-cleanup commit (rename `_hasSlug` → `hasSlug` across the shared `ContentRenderer` type). Out of scope for the behavior-preserving sweep.
4. **N3 — deferred** to `006-inline-jsx-config-cross-file.md` (inline-style plan).
5. **N1 — no action** (recorded so it isn't re-litigated; `isFieldVisible` is justified by 3 internal call sites).

**Source minimization audit (per the "minimize code" directive):** all 21 extracted helpers have ≥1 production call site — **0 dead exports**. Single-call-site helpers are expected and correct here (the value is testability + thin components, not reuse; several have additional internal reuse within their `*Utils.ts`). The +2,687/−423 diff is justified: ~1,778 added lines are net-new test coverage on logic that was previously inline and untested (8 of 11 test files are brand-new), and the source is roughly net-neutral (logic relocated, not duplicated). **No removable source bloat found.**

Verification: `jest` 162/162 green on the two touched suites; `tsc --noEmit` exit 0; `eslint` exit 0; `prettier` clean. None of these blocked the merge.
