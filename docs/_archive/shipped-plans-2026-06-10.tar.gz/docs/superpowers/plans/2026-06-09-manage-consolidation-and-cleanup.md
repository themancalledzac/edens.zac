# Manage Consolidation & Dead-Code Removal Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Remove the duplicated/dead code that bloats branch `0179-mobile-first-admin` — delete the 2,027-line `ManageClient` (a verbatim copy of the new edit brain), park the public `?manage=1` edit entry so it is unreachable in production, drop the branch's markdown docs, and land the remaining review fixes — so the branch is safe to merge.

**Architecture:** The new in-place edit surface (`useCollectionEdit` + `CollectionPageClient` + `edit/` sections) becomes the **single, parked** owner of collection-edit logic. `ManageClient` is deleted; its only live responsibility — the no-slug "create collection" flow — moves to a small `CreateCollectionForm`. `?manage=1` stays in the codebase but is gated to local-dev only (`isLocalEnvironment()`), so production can never enter edit mode. Test coverage that lived only in `ManageClient` tests (bulk-remove) is ported to the hook before its source is deleted.

**Tech Stack:** Next.js App Router (Server + Client Components), TypeScript (strict, no `any`), Jest + Testing Library, SCSS modules with surface-aware tokens. Run commands with the Homebrew node binary (`npm`/`npx` are not on PATH).

**Verification commands (used throughout):**
```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest <path>
/opt/homebrew/bin/node node_modules/.bin/eslint <files>
/opt/homebrew/bin/node node_modules/.bin/stylelint <scss>
/opt/homebrew/bin/node node_modules/.bin/prettier --write <files>
```

**Decisions locked (from review Q&A 2026-06-09):**
- **Consolidation:** delete `ManageClient`, extract a minimal `CreateCollectionForm`.
- **Docs:** none of the branch's markdown belongs in this MR — remove all 17 files + 2 archives.
- **`?manage=1`:** keep the mechanism in code, gate it OFF in production. Implemented as an `isLocalEnvironment()` gate (NOT literal commented-out code, which rots, isn't type-checked, and is a smell you've flagged before). It stays usable for local-dev testing and revives cleanly later by wiring a real admin gate at the same chokepoint. **If you want it off even in local dev**, change the gate in Task 1 to `const editMode = false` — one-line difference, noted in that task.

---

## File Structure

| File | Responsibility | Action |
|---|---|---|
| `app/[slug]/page.tsx` | Public collection route; computes `editMode` from `?manage=1` | **Modify** — gate `editMode` behind `isLocalEnvironment()` |
| `tests/app/slug-page.manage.test.tsx` | Tests the `?manage=1` entry | **Modify** — assert parked-in-prod + works-in-local |
| `docs/000-009*.md`, `docs/0148/0167/0171/0172*.md`, `docs/previous-work.md`, `docs/_archive/*.tar.gz` | Branch authoring artifacts | **Delete** |
| `app/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.tsx` | Minimal "create new collection" form | **Create** |
| `app/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.module.scss` | Styles for the create form | **Create** |
| `tests/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.test.tsx` | Tests the create form | **Create** |
| `app/(admin)/collection/manage/[[...slug]]/page.tsx` | Manage route: redirect for slug, render create for no-slug | **Modify** — render `CreateCollectionForm` |
| `tests/components/ContentCollection/useCollectionEdit.bulkRemove.test.tsx` | Ports bulk-remove coverage to the hook | **Create** |
| `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx` | Old duplicate edit/create page | **Delete** (2,027 lines) |
| `app/(admin)/collection/manage/[[...slug]]/ManageClient.module.scss` | Old page styles | **Delete** |
| `tests/(admin)/collection/manage/[[...slug]]/ManageClient.bulkRemove.test.tsx` | Old component bulk-remove test | **Delete** (after port) |
| `tests/(admin)/collection/manage/[[...slug]]/ManageClient.galleryAccess.test.tsx` | Old component gallery-access test | **Delete** (after coverage confirm) |
| `app/components/ContentCollection/edit/collectionEditUtils.ts` | Shared edit utils | **Modify** — remove now-orphaned `getDisplayedCoverImage` |
| `tests/(admin)/collection/manage/[[...slug]]/manageUtils.test.ts` | Tests the shared utils | **Modify** — drop the `getDisplayedCoverImage` block |
| `tests/components/ContentCollection/useCollectionEdit.test.tsx` | Hook tests | **Modify** — M-7 act() cleanup |

---

## Task 1: Park `?manage=1` behind a production gate

**Files:**
- Modify: `app/[slug]/page.tsx`
- Modify: `tests/app/slug-page.manage.test.tsx`

- [ ] **Step 1: Update the failing test first (parked-in-prod + works-in-local)**

Replace the body of `tests/app/slug-page.manage.test.tsx` with:

```tsx
import { render } from '@testing-library/react';

import CollectionPage from '@/app/[slug]/page';
import CollectionPageWrapper from '@/app/lib/components/CollectionPageWrapper';
import { requireAdmin } from '@/app/utils/admin';

jest.mock('@/app/lib/components/CollectionPageWrapper', () => ({
  __esModule: true,
  default: jest.fn(() => null),
}));

jest.mock('@/app/utils/admin', () => ({
  requireAdmin: jest.fn(async () => {}),
}));

const mockWrapper = CollectionPageWrapper as unknown as jest.Mock;
const mockRequireAdmin = requireAdmin as jest.MockedFunction<typeof requireAdmin>;

async function renderPage(slug: string, manage?: string) {
  const element = await CollectionPage({
    params: Promise.resolve({ slug }),
    searchParams: Promise.resolve(manage === undefined ? {} : { manage }),
  });
  render(element);
}

describe('app/[slug]/page.tsx — ?manage=1 entry (parked to local dev)', () => {
  const originalEnv = process.env.NEXT_PUBLIC_ENV;

  beforeEach(() => {
    jest.clearAllMocks();
    mockRequireAdmin.mockImplementation(async () => {});
  });

  afterEach(() => {
    process.env.NEXT_PUBLIC_ENV = originalEnv;
  });

  it('passes editMode=false and does NOT call requireAdmin with no ?manage param', async () => {
    process.env.NEXT_PUBLIC_ENV = 'local';
    await renderPage('film');

    expect(mockWrapper).toHaveBeenCalledTimes(1);
    expect(mockWrapper.mock.calls[0][0]).toMatchObject({ slug: 'film', editMode: false });
    expect(mockRequireAdmin).not.toHaveBeenCalled();
  });

  it('passes editMode=true and calls requireAdmin when ?manage=1 in local dev', async () => {
    process.env.NEXT_PUBLIC_ENV = 'local';
    await renderPage('film', '1');

    expect(mockWrapper).toHaveBeenCalledTimes(1);
    expect(mockWrapper.mock.calls[0][0]).toMatchObject({ slug: 'film', editMode: true });
    expect(mockRequireAdmin).toHaveBeenCalledTimes(1);
  });

  it('parks ?manage=1 in production: editMode=false, requireAdmin NOT called', async () => {
    process.env.NEXT_PUBLIC_ENV = 'production';
    await renderPage('film', '1');

    expect(mockWrapper.mock.calls[0][0]).toMatchObject({ slug: 'film', editMode: false });
    expect(mockRequireAdmin).not.toHaveBeenCalled();
  });

  it('treats any non-"1" manage value as non-edit', async () => {
    process.env.NEXT_PUBLIC_ENV = 'local';
    await renderPage('film', 'true');

    expect(mockWrapper.mock.calls[0][0]).toMatchObject({ slug: 'film', editMode: false });
    expect(mockRequireAdmin).not.toHaveBeenCalled();
  });
});
```

> Note: Jest sets `NODE_ENV='test'`, so `isLocalEnvironment()` is driven purely by `NEXT_PUBLIC_ENV` here — `'local'` enables, `'production'` parks.

- [ ] **Step 2: Run the test to verify it fails**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest tests/app/slug-page.manage.test.tsx`
Expected: FAIL — the "parks ?manage=1 in production" test fails because `page.tsx` still sets `editMode=true` regardless of env.

- [ ] **Step 3: Gate `editMode` in the page**

In `app/[slug]/page.tsx`, add the import (alphabetically within the `@/app/utils/*` group):

```tsx
import { isLocalEnvironment } from '@/app/utils/environment';
```

Extend the `CollectionPage` JSDoc and change the `editMode` line:

```tsx
/**
 * Route handler for individual collections by slug (e.g. /film, /portfolio-work).
 * Renders via the shared CollectionPageWrapper.
 *
 * `?manage=1` enters the in-place edit surface. It is a local-dev-only affordance,
 * parked until a real admin auth gate exists, so it is hard-disabled outside local
 * dev — production/preview never enter edit mode. Revive by wiring real auth here.
 */
export default async function CollectionPage({ params, searchParams }: CollectionPageProps) {
  const { slug } = await params;

  if (!slug) {
    notFound();
  }

  if (STATIC_FILES.includes(slug.toLowerCase())) {
    notFound();
  }

  const editMode = (await searchParams)?.manage === '1' && isLocalEnvironment();

  if (editMode) {
    await requireAdmin();
  }

  return <CollectionPageWrapper slug={slug} editMode={editMode} />;
}
```

> **To fully park even in local dev** (your "commented out" phrasing taken literally), use `const editMode = false;` here instead and delete the now-unused `manage`/`searchParams` read. Default above keeps local-dev testing alive, which matches "short-term local dev testing strategy."

- [ ] **Step 4: Run the test to verify it passes**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest tests/app/slug-page.manage.test.tsx`
Expected: PASS (4 tests).

- [ ] **Step 5: Type-check, lint, commit**

```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/[slug]/page.tsx tests/app/slug-page.manage.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint 'app/[slug]/page.tsx' tests/app/slug-page.manage.test.tsx
git add 'app/[slug]/page.tsx' tests/app/slug-page.manage.test.tsx
git commit -m "$(cat <<'EOF'
feat(collection): park ?manage=1 edit entry to local dev only

The in-place edit surface is a local-dev testing affordance with no real admin
gate yet, and it sits on the public /[slug] route. Gate editMode behind
isLocalEnvironment() so production/preview can never enter edit mode (and the
client-gallery password gate can never be bypassed via ?manage=1). The whole
edit mechanism stays in the codebase; revive by wiring real auth at this
chokepoint.

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 2: Remove the branch's markdown docs

**Files:**
- Delete: `docs/000-summary.md`, `docs/001-design-review.md`, `docs/002-performance.md`, `docs/003-client-gallery-security.md`, `docs/004-content-discovery.md`, `docs/005-layout.md`, `docs/006-code-health.md`, `docs/007-security-hardening.md`, `docs/008-collection-admin.md`, `docs/009-backend-and-vision.md`, `docs/0148-fullscreen-modal-fix-spec.md`, `docs/0167-refactor-wave-handoff.md`, `docs/0171-next-batch-handoff.md`, `docs/0172-batch-execution-handoff.md`, `docs/previous-work.md`, `docs/_archive/shipped-docs-2026-06-01.tar.gz`, `docs/_archive/todo-archive-2026-06-01.tar.gz`

- [ ] **Step 1: Confirm these are exactly the branch-added docs**

Run: `git diff --name-status origin/main HEAD -- docs/`
Expected: 17 lines, all status `A` (added), matching the list above. If the set differs, delete only the `A` entries.

- [ ] **Step 2: Remove them**

```bash
git rm docs/000-summary.md docs/001-design-review.md docs/002-performance.md \
  docs/003-client-gallery-security.md docs/004-content-discovery.md docs/005-layout.md \
  docs/006-code-health.md docs/007-security-hardening.md docs/008-collection-admin.md \
  docs/009-backend-and-vision.md docs/0148-fullscreen-modal-fix-spec.md \
  docs/0167-refactor-wave-handoff.md docs/0171-next-batch-handoff.md \
  docs/0172-batch-execution-handoff.md docs/previous-work.md \
  docs/_archive/shipped-docs-2026-06-01.tar.gz docs/_archive/todo-archive-2026-06-01.tar.gz
```

- [ ] **Step 3: Verify no source references the deleted docs**

Run: `grep -rnE '00[0-9]-|0148-|016[0-9]-|017[0-9]-|previous-work|shipped-docs|todo-archive' app tests --include='*.ts' --include='*.tsx' | grep -i 'docs/' || echo "no references"`
Expected: `no references`.

- [ ] **Step 4: Commit**

```bash
git commit -m "$(cat <<'EOF'
chore(docs): drop branch authoring artifacts from the MR

Design notes, handoffs, and archive tarballs added on this branch are local
authoring artifacts, not product. Remove all 17 files (+2 archives) so the MR
diff reflects only code.

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 3: Create the minimal `CreateCollectionForm`

**Files:**
- Create: `app/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.tsx`
- Create: `app/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.module.scss`
- Test: `tests/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.test.tsx`

- [ ] **Step 1: Write the failing test**

Create `tests/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.test.tsx`:

```tsx
import { fireEvent, render, screen, waitFor } from '@testing-library/react';

import CreateCollectionForm from '@/app/(admin)/collection/manage/[[...slug]]/CreateCollectionForm';
import { createCollection } from '@/app/lib/api/collections';

jest.mock('next/navigation', () => ({
  useRouter: () => ({ replace: mockReplace }),
}));
const mockReplace = jest.fn();

jest.mock('@/app/lib/api/collections');
jest.mock('@/app/components/ContentCollection/edit/collectionEditUtils', () => ({
  revalidateCollectionCache: jest.fn().mockResolvedValue(undefined),
}));

const mockCreate = createCollection as jest.MockedFunction<typeof createCollection>;

describe('CreateCollectionForm', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockReplace.mockReset();
  });

  it('blocks submit and shows an error when the title is blank', async () => {
    render(<CreateCollectionForm />);
    fireEvent.submit(screen.getByRole('button', { name: /create collection/i }).closest('form')!);

    expect(await screen.findByText(/title is required/i)).toBeInTheDocument();
    expect(mockCreate).not.toHaveBeenCalled();
  });

  it('creates the collection and redirects into ?manage=1 on success', async () => {
    mockCreate.mockResolvedValue({
      collection: { id: 5, slug: 'film-pack-002' },
    } as unknown as Awaited<ReturnType<typeof createCollection>>);

    render(<CreateCollectionForm />);
    fireEvent.change(screen.getByLabelText(/title/i), { target: { value: 'Film Pack 002' } });
    fireEvent.click(screen.getByRole('button', { name: /create collection/i }));

    await waitFor(() => {
      expect(mockCreate).toHaveBeenCalledWith(
        expect.objectContaining({ title: 'Film Pack 002' })
      );
    });
    expect(mockReplace).toHaveBeenCalledWith('/film-pack-002?manage=1');
  });

  it('surfaces an API error and does not redirect', async () => {
    mockCreate.mockRejectedValue(new Error('boom'));

    render(<CreateCollectionForm />);
    fireEvent.change(screen.getByLabelText(/title/i), { target: { value: 'X' } });
    fireEvent.click(screen.getByRole('button', { name: /create collection/i }));

    expect(await screen.findByText(/failed to create collection/i)).toBeInTheDocument();
    expect(mockReplace).not.toHaveBeenCalled();
  });
});
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest CreateCollectionForm.test`
Expected: FAIL — `CreateCollectionForm` does not exist.

- [ ] **Step 3: Write the component**

Create `app/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.tsx`:

```tsx
'use client';

import { useRouter } from 'next/navigation';
import { type FormEvent, useState } from 'react';

import { revalidateCollectionCache } from '@/app/components/ContentCollection/edit/collectionEditUtils';
import { Button } from '@/app/components/ui/Button/Button';
import { Field } from '@/app/components/ui/Field/Field';
import { Input } from '@/app/components/ui/Field/Input';
import { Select } from '@/app/components/ui/Field/Select';
import { createCollection } from '@/app/lib/api/collections';
import {
  ASSIGNABLE_COLLECTION_TYPES,
  COLLECTION_TYPE_LABELS,
  type CollectionCreateRequest,
  CollectionType,
} from '@/app/types/Collection';
import { handleApiError } from '@/app/utils/apiUtils';

import styles from './CreateCollectionForm.module.scss';

/**
 * Minimal "create a new collection" form — the only surviving responsibility of the
 * old manage route. On success it redirects into the in-place edit surface (`?manage=1`).
 */
export function CreateCollectionForm() {
  const router = useRouter();
  const [createData, setCreateData] = useState<CollectionCreateRequest>({
    type: CollectionType.PORTFOLIO,
    title: '',
  });
  const [error, setError] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);

  const handleCreate = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!createData.title.trim()) {
      setError('Title is required');
      return;
    }

    try {
      setIsCreating(true);
      setError(null);

      const response = await createCollection(createData);
      if (response !== null) {
        await revalidateCollectionCache(response.collection.slug);
        router.replace(`/${response.collection.slug}?manage=1`);
      }
    } catch (error_) {
      setError(handleApiError(error_, 'Failed to create collection'));
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <div className={styles.createContainer}>
      <h2 className={styles.createHeading}>Create New Collection</h2>

      {error && <div className={styles.errorMessage}>{error}</div>}

      <form onSubmit={handleCreate}>
        <div className={styles.formGroup}>
          <Field label="Collection Type *" htmlFor="create-type">
            <Select
              id="create-type"
              value={createData.type}
              onChange={e => setCreateData(prev => ({ ...prev, type: e.target.value as CollectionType }))}
              required
            >
              {ASSIGNABLE_COLLECTION_TYPES.map(type => (
                <option key={type} value={type}>
                  {COLLECTION_TYPE_LABELS[type]}
                </option>
              ))}
            </Select>
          </Field>
        </div>

        <div className={styles.formGroup}>
          <Field label="Title *" htmlFor="create-title">
            <Input
              id="create-title"
              value={createData.title}
              onChange={e => setCreateData(prev => ({ ...prev, title: e.target.value }))}
              required
              placeholder="e.g., Film Pack 002"
            />
          </Field>
        </div>

        <Button type="submit" disabled={isCreating}>
          {isCreating ? 'Creating...' : 'Create Collection'}
        </Button>
      </form>
    </div>
  );
}

export default CreateCollectionForm;
```

Create `app/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.module.scss`:

```scss
.createContainer {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
  max-width: 32rem;
  margin: 0 auto;
  padding: var(--space-6) var(--space-3);
}

.createHeading {
  margin: 0;
  font-size: var(--text-lg);
  font-weight: bold;
  color: var(--color-fg);
}

.formGroup {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

.errorMessage {
  padding: var(--space-2);
  border-radius: var(--radius-1);
  background-color: var(--color-danger-surface, transparent);
  color: var(--color-danger);
  font-size: var(--text-sm);
}
```

> Confirm the `Button` import path matches the codebase — `app/components/ui/Button/Button`. If `--color-danger-surface`/`--text-lg` are not defined tokens, run stylelint (Step 5) and replace with the nearest defined token it flags.

- [ ] **Step 4: Run the test to verify it passes**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest CreateCollectionForm.test`
Expected: PASS (3 tests).

- [ ] **Step 5: Type-check, lint, commit**

```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/prettier --write 'app/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.tsx' 'app/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.module.scss' 'tests/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.test.tsx'
/opt/homebrew/bin/node node_modules/.bin/eslint 'app/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.tsx' 'tests/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.test.tsx'
/opt/homebrew/bin/node node_modules/.bin/stylelint 'app/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.module.scss'
git add 'app/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.tsx' 'app/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.module.scss' 'tests/(admin)/collection/manage/[[...slug]]/CreateCollectionForm.test.tsx'
git commit -m "$(cat <<'EOF'
feat(admin): add minimal CreateCollectionForm for the create flow

Extracts the only live responsibility of the 2,027-line ManageClient — creating
a new collection (type + title) and redirecting into ?manage=1 — into a focused
~110-line component, ahead of deleting ManageClient.

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 4: Point the manage route at `CreateCollectionForm`

**Files:**
- Modify: `app/(admin)/collection/manage/[[...slug]]/page.tsx`

- [ ] **Step 1: Update the redirect-page test expectation (if present)**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest ManageCollectionPage.redirect.test`
Expected: PASS as-is (it asserts the slug→redirect and the no-slug render). If it asserts `ManageClient` specifically for the no-slug branch, update that assertion to `CreateCollectionForm` in the next step.

- [ ] **Step 2: Swap the no-slug renderer**

In `app/(admin)/collection/manage/[[...slug]]/page.tsx`, replace the `ManageClient` import and the no-slug render:

```tsx
import { redirect } from 'next/navigation';

import CreateCollectionForm from './CreateCollectionForm';

interface ManageCollectionPageProps {
  params: Promise<{
    slug?: string[];
  }>;
}

export const dynamic = 'force-dynamic';

export default async function ManageCollectionPage({ params }: ManageCollectionPageProps) {
  const { slug: slugArray } = await params;
  const slug = slugArray?.[0];

  if (slug) {
    redirect(`/${slug}?manage=1`);
  }

  return <CreateCollectionForm />;
}
```

- [ ] **Step 3: Verify**

Run: `/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit && /opt/homebrew/bin/node node_modules/.bin/jest ManageCollectionPage.redirect.test`
Expected: tsc clean; redirect test PASS.

- [ ] **Step 4: Commit**

```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write 'app/(admin)/collection/manage/[[...slug]]/page.tsx'
git add 'app/(admin)/collection/manage/[[...slug]]/page.tsx'
git commit -m "$(cat <<'EOF'
refactor(admin): render CreateCollectionForm for the no-slug manage route

The manage route now redirects per-slug into ?manage=1 and renders the small
create form for the create flow — ManageClient is no longer referenced.

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 5: Port bulk-remove coverage to the hook (before deleting its test)

**Context:** `handleBulkRemove` exists in `useCollectionEdit` but is covered ONLY by `ManageClient.bulkRemove.test`. Port the behavior to a hook test so deleting the component test loses no coverage. Selection is driven through the hook's `bottomBarCells` (`enterSelect` → `All` cell sets all ids → `Remove` cell calls `handleBulkRemove`).

**Files:**
- Create: `tests/components/ContentCollection/useCollectionEdit.bulkRemove.test.tsx`

- [ ] **Step 1: Read the source contract**

Read `app/components/ContentCollection/edit/useCollectionEdit.tsx` `handleBulkRemove` (currently ~lines 859-894) and the select-mode `bottomBarCells` (`all`, `remove` keys). Confirm: Remove builds per-image `buildImageUpdateDiff({id, collections: trimmed}, img, filmTypes)` where `trimmed` drops `currentCollectionId`, calls `updateImages(diffs)`, then `handleDeleteSuccess`; and `deleteImages` is NEVER called.

- [ ] **Step 2: Write the test**

Create `tests/components/ContentCollection/useCollectionEdit.bulkRemove.test.tsx`. Use the same mock scaffolding as `useCollectionEdit.handlers.test.tsx` (copy its `jest.mock` blocks + `makeCollection`/`makeResponse`/`renderEdit` helpers), then:

```tsx
describe('useCollectionEdit — bulk remove from collection', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    mockStorageGetFull.mockReturnValue(null);
    mockGetCollectionUpdateMetadata.mockResolvedValue(makeResponse());
    mockGetMetadata.mockResolvedValue(makeMetadata());
    mockUpdateImages.mockResolvedValue([{ id: 11 }] as never);
    jest.spyOn(window, 'confirm').mockReturnValue(true);
  });

  function collectionWithImages() {
    return makeCollection({
      id: 42,
      content: [
        { id: 11, contentType: 'IMAGE', orderIndex: 0, imageUrl: 'a.jpg', locations: [], collections: [{ collectionId: 42, name: 'C', visible: true }] },
        { id: 12, contentType: 'IMAGE', orderIndex: 1, imageUrl: 'b.jpg', locations: [], collections: [{ collectionId: 42, name: 'C', visible: true }] },
      ] as never,
    });
  }

  it('removes selected images from THIS collection (updateImages with remove), never hard-deletes', async () => {
    const collection = collectionWithImages();
    const { result } = renderEdit({ enabled: true, collection });
    await waitFor(() => expect(result.current.currentState).not.toBeNull());

    // enter select mode, select all, then Remove
    act(() => result.current.enterSelect());
    const all = result.current.bottomBarCells.find(c => c.key === 'all');
    act(() => all?.onClick?.());

    const remove = result.current.bottomBarCells.find(c => c.key === 'remove');
    await act(async () => {
      remove?.onClick?.();
      await Promise.resolve();
    });

    await waitFor(() => expect(mockUpdateImages).toHaveBeenCalledTimes(1));
    const diffs = mockUpdateImages.mock.calls[0][0];
    expect(diffs.map((d: { id: number }) => d.id).sort()).toEqual([11, 12]);
    // each diff removes collection 42 from the image's memberships
    for (const d of diffs as Array<{ collections?: { remove?: number[] } }>) {
      expect(d.collections?.remove ?? []).toContain(42);
    }
  });

  it('aborts the remove when the user cancels the confirm', async () => {
    (window.confirm as jest.Mock).mockReturnValue(false);
    const collection = collectionWithImages();
    const { result } = renderEdit({ enabled: true, collection });
    await waitFor(() => expect(result.current.currentState).not.toBeNull());

    act(() => result.current.enterSelect());
    act(() => result.current.bottomBarCells.find(c => c.key === 'all')?.onClick?.());
    await act(async () => {
      result.current.bottomBarCells.find(c => c.key === 'remove')?.onClick?.();
      await Promise.resolve();
    });

    expect(mockUpdateImages).not.toHaveBeenCalled();
  });
});
```

> If `buildImageUpdateDiff` produces `collections.remove` differently than asserted, read `app/components/Metadata/metadataUtils.ts` `buildImageUpdateDiff` and adjust the assertion to match its real output shape (the existing `ManageClient.bulkRemove.test` is the reference for the exact expectation — mirror it).

- [ ] **Step 3: Run to verify pass**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest useCollectionEdit.bulkRemove.test`
Expected: PASS (2 tests). If assertions need shape tweaks, fix against the `ManageClient.bulkRemove.test` reference until green.

- [ ] **Step 4: Commit**

```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write tests/components/ContentCollection/useCollectionEdit.bulkRemove.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint tests/components/ContentCollection/useCollectionEdit.bulkRemove.test.tsx
git add tests/components/ContentCollection/useCollectionEdit.bulkRemove.test.tsx
git commit -m "$(cat <<'EOF'
test(collection-edit): port bulk-remove coverage to the hook

handleBulkRemove was covered only by ManageClient.bulkRemove.test; drive it
through useCollectionEdit's select-mode bar cells so deleting the component test
loses no coverage.

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 6: Confirm gallery-access coverage, then delete ManageClient + redundant tests

**Context:** `ManageClient.galleryAccess.test` renders `<ManageClient>` and checks the gallery-access section (visibility per type, Clear-Password button, save with/without email, <4-char rejection). That UI now lives in `InfoTab`; the hook's `handleSaveAccess` is unit-tested in `useCollectionEdit.handlers.test`. Confirm the *rendering* of the gallery-access section is covered by `CollectionEditSheet.test`/InfoTab before deleting the component test; port any unique case.

**Files:**
- Delete: `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx`
- Delete: `app/(admin)/collection/manage/[[...slug]]/ManageClient.module.scss`
- Delete: `tests/(admin)/collection/manage/[[...slug]]/ManageClient.bulkRemove.test.tsx`
- Delete: `tests/(admin)/collection/manage/[[...slug]]/ManageClient.galleryAccess.test.tsx`
- Possibly Modify: `tests/components/ContentCollection/CollectionEditSheet.test.tsx` (port unique gallery-access cases)

- [ ] **Step 1: Audit gallery-access coverage in the new surface**

Run: `grep -niE 'gallery access|clear password|isPasswordProtected|handleSaveAccess|handleClearPassword|recipient' tests/components/ContentCollection/CollectionEditSheet.test.tsx`
- If the section's render rules (shown for CLIENT_GALLERY/parent; Clear-Password visibility) are already asserted → proceed to Step 2.
- If NOT → add the missing cases to `CollectionEditSheet.test.tsx` by rendering `<CollectionEditSheet edit={...} />` with a CLIENT_GALLERY `currentState` and asserting the "Gallery Access" heading appears, the Clear-Password button shows only when `isPasswordProtected`, and the <4-char rejection sets a status (mirror the deleted test's `it` cases). Run that file green before continuing.

- [ ] **Step 2: Confirm ManageClient has no remaining importers**

Run: `grep -rn "ManageClient" app tests --include='*.ts' --include='*.tsx' | grep -vE 'ManageClient\.(module\.scss|tsx)|ManageClient\.(bulkRemove|galleryAccess)\.test'`
Expected: empty (Task 4 removed the page import). If anything prints, fix it before deleting.

- [ ] **Step 3: Delete the files**

```bash
git rm 'app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx' \
       'app/(admin)/collection/manage/[[...slug]]/ManageClient.module.scss' \
       'tests/(admin)/collection/manage/[[...slug]]/ManageClient.bulkRemove.test.tsx' \
       'tests/(admin)/collection/manage/[[...slug]]/ManageClient.galleryAccess.test.tsx'
```

- [ ] **Step 4: Type-check + run the affected test dirs**

```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest tests/'(admin)' tests/components/ContentCollection
```
Expected: tsc clean; all remaining suites green. tsc surfaces any symbol that only ManageClient imported (resolved in Task 7).

- [ ] **Step 5: Commit**

```bash
git add -A
git commit -m "$(cat <<'EOF'
refactor(admin): delete ManageClient — useCollectionEdit is the single edit brain

ManageClient duplicated useCollectionEdit's entire edit brain (22 verbatim
handlers) and, since the per-slug route now redirects into ?manage=1, only
served the create flow — now handled by CreateCollectionForm. Removes ~2,000
lines of duplicated source plus the component tests whose behavior is covered by
the hook tests (bulk-remove ported in Task 5; gallery-access render confirmed in
CollectionEditSheet.test).

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 7: Sweep exports orphaned by the ManageClient deletion

**Context:** `getDisplayedCoverImage` was used by `ManageClient` and by `useCollectionEdit` (the latter removed earlier this branch). After Task 6 it is referenced only by `manageUtils.test.ts`. Remove it and any other newly-orphaned export.

**Files:**
- Modify: `app/components/ContentCollection/edit/collectionEditUtils.ts`
- Modify: `tests/(admin)/collection/manage/[[...slug]]/manageUtils.test.ts`

- [ ] **Step 1: Re-confirm the orphan set**

Run: `grep -rn 'getDisplayedCoverImage' app tests`
Expected: only `collectionEditUtils.ts` (definition) and `manageUtils.test.ts` (import + describe). Then check siblings that were only reached via ManageClient:
Run: `for s in findImageBlockById validateCoverImageSelection handleSingleImageEdit handleCollectionNavigation; do echo "== $s =="; grep -rn "$s" app | grep -v 'collectionEditUtils.ts'; done`
- Keep any symbol still referenced by `app/` code (e.g. `handleSingleImageEdit`/`handleCollectionNavigation` are used by `useImageClickHandler`; `findImageBlockById`/`validateCoverImageSelection` are used internally by `handleCoverImageSelection`). Only remove symbols with ZERO `app/` references besides their own file. Per this branch, that set is exactly `{ getDisplayedCoverImage }` — but run the check and extend the deletion if more are orphaned.

- [ ] **Step 2: Remove `getDisplayedCoverImage` from the util**

In `app/components/ContentCollection/edit/collectionEditUtils.ts`, delete the `getDisplayedCoverImage` function and its JSDoc block. If `findImageBlockById` is now used only inside this file, leave it (still referenced by `handleCoverImageSelection`/`validateCoverImageSelection`).

- [ ] **Step 3: Remove its tests from `manageUtils.test.ts`**

Remove `getDisplayedCoverImage` from the import list, and delete the entire `describe('getDisplayedCoverImage', () => { ... })` block.

- [ ] **Step 4: Verify**

```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest manageUtils.test
/opt/homebrew/bin/node node_modules/.bin/eslint app/components/ContentCollection/edit/collectionEditUtils.ts 'tests/(admin)/collection/manage/[[...slug]]/manageUtils.test.ts'
```
Expected: tsc clean; manageUtils suite green; eslint clean (no unused imports).

- [ ] **Step 5: Commit**

```bash
git add app/components/ContentCollection/edit/collectionEditUtils.ts 'tests/(admin)/collection/manage/[[...slug]]/manageUtils.test.ts'
git commit -m "$(cat <<'EOF'
refactor(collection-edit): remove getDisplayedCoverImage orphaned by ManageClient

With ManageClient gone and useCollectionEdit reading collection.coverImage
directly, getDisplayedCoverImage has no app callers. Remove it and its tests.

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 8: Fix the M-7 act() warnings in the hook test

**Context:** `enabled: true` tests fire two async effects (data-load + getMetadata); `waitFor` gates on one, the other lands after the test → benign `act()` warning. Flush both inside each such test.

**Files:**
- Modify: `tests/components/ContentCollection/useCollectionEdit.test.tsx`

- [ ] **Step 1: Add a settle helper and use it in `enabled: true` tests**

After the `renderEdit` helper, add:

```tsx
async function flushEffects() {
  // drain the data-load + getMetadata promise chains inside act
  await act(async () => {
    await new Promise(resolve => setTimeout(resolve, 0));
  });
}
```

In every test that calls `renderEdit({ enabled: true })`, add `await flushEffects();` as the final line of the test body (after the existing assertions). This applies to the tests currently at: "performs the cache-first metadata fetch", "uses cached full response", "populates allCollections", the two locations tests, the tags test, and the two C1 handleUpdate tests.

- [ ] **Step 2: Run and confirm zero warnings**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ContentCollection/useCollectionEdit.test.tsx 2>&1 | grep -c 'not wrapped in act'`
Expected: `0`. And the suite stays green.

> If a residual warning remains, the offending test still has an un-flushed update — add `await flushEffects()` to it too. Do NOT silence by mutating product code.

- [ ] **Step 3: Commit**

```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write tests/components/ContentCollection/useCollectionEdit.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint tests/components/ContentCollection/useCollectionEdit.test.tsx
git add tests/components/ContentCollection/useCollectionEdit.test.tsx
git commit -m "$(cat <<'EOF'
test(collection-edit): flush async effects to clear act() warnings

enabled:true tests fire two async effects; waitFor gated on one, leaving the
other to update outside act. Drain both with a per-test macrotask flush.

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>
EOF
)"
```

---

## Task 9: Final verification — suite, lint, and diff delta

**Files:** none (verification only)

- [ ] **Step 1: Full type-check + suite + lint**

```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest
/opt/homebrew/bin/node node_modules/.bin/stylelint 'app/**/*.scss'
```
Expected: tsc exit 0; all suites green (no orphaned references; bulk-remove + gallery-access coverage intact); stylelint clean.

- [ ] **Step 2: Confirm the dead-code goal is met**

```bash
echo "ManageClient gone:"; test ! -f 'app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx' && echo OK
echo "no ?manage edit in prod path (gated):"; grep -n 'isLocalEnvironment' 'app/[slug]/page.tsx'
echo "no getDisplayedCoverImage app refs:"; grep -rn 'getDisplayedCoverImage' app || echo "OK none"
echo "branch docs gone:"; git ls-files docs/ | grep -E '00[0-9]-|0148-|previous-work|_archive' || echo "OK none"
```
Expected: each line confirms removal.

- [ ] **Step 3: Measure the diff reduction**

Run: `git diff --shortstat origin/main HEAD`
Expected: net additions dropped sharply from ~+6,900. Rough target after this plan: removed ≈ ManageClient (2,027) + docs (1,529) + ManageClient tests (654) + getDisplayedCoverImage (~30) − new (CreateCollectionForm ~150 + ported/added tests ~120) ≈ **−3,900 net**, landing the branch around **+3,000 net**. Record the actual number.

- [ ] **Step 4: Push**

```bash
git push
```
(Sandbox note: if the push fails on `known_hosts` "Operation not permitted", retry with the sandbox disabled for that one command.)

---

## Self-Review

**Spec coverage** (review findings + locked decisions → task):

| Requirement (spec) | Task |
|---|---|
| `?manage=1` unreachable in production, mechanism kept (Decision 3) | Task 1 |
| Remove all branch docs (Decision 2) | Task 2 |
| Delete ManageClient duplication, minimal create form (Decision 1) | Tasks 3, 4, 6 |
| No coverage lost when deleting component tests | Tasks 5, 6 (port + confirm) |
| Remove code orphaned by the deletion | Task 7 |
| M-7 act() warning (outstanding fix) | Task 8 |
| Prove the net line reduction (the motivation) | Task 9 |

**Not in this plan (by decision):**
- Hardening `requireAdmin()` to real auth — superseded by Decision 3 (parked in prod via the env gate); revive alongside `?manage=1` later.
- Relocating/renaming `manageUtils.test.ts` → `collectionEditUtils.test.ts` and moving `useCollectionRetype.test.tsx` out of the manage dir — pure tidiness, no dead code; left as optional follow-up to keep this MR focused.

**Dead-code flags addressed:** ManageClient (2,027), its two component tests (654), `getDisplayedCoverImage` (+tests), branch docs (1,529 + archives). The `edit/` hooks and `collectionEditUtils` remainder stay — they are the *parked* (not dead) edit system the user is preserving.

**Type/name consistency:** `CreateCollectionForm` (default + named export) used in Tasks 3/4; `isLocalEnvironment` (existing util) in Task 1; `flushEffects` defined once in Task 8. `CollectionCreateRequest = { type, title }` matches the form state.

---

## Parallelization / Agent-Teams note

Three tracks are independent and could run in parallel (e.g. `/agent-teams`): **Task 1 (park)**, **Task 2 (docs)**, **Task 8 (M-7)**. The core chain is sequential and must stay ordered: **3 → 4 → 5 → 6 → 7** (create form must exist before the route swap and the ManageClient delete; bulk-remove port + gallery-access confirm must precede the delete; orphan sweep follows it). Given the sequential chain dominates and the parallel tasks are small, **subagent-driven sequential execution is recommended** over a full team.
