# 001 · FilterChip + FilterToolbar
_Chapter [001 · Design System Unification](../../001-design-review.md) · plan_

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Collapse the two divergent filter bars (`CollectionFilterBar` borderless dropdowns + density slider vs `LocationFilterBar` bordered pills + film/digital colors), the 6 chip implementations, and the two divergent filter-state types (`GalleryFilterState` + `CollectionFilterState`) into ONE canonical set: a token-driven `<FilterChip>` primitive, a config-driven `<FilterToolbar>` built on `CollectionFilterBar`'s dropdown + 3-state availability model, and one unified `FilterState`. Along the way: unify the two divergent `cycleDateSort` cycle orders into one helper, replace `LocationFilterBar`'s hand-rolled `toggleTag`/`togglePerson` with the exported `toggleArrayFilter`, remove the dead `selectedCollectionIds`, render the film toggle as a neutral tri-state (dropping the saturated green/pink chip tokens), then **delete `app/components/LocationFilterBar/`**.

**Architecture:** New `app/components/ui/FilterChip/` and `app/components/ui/FilterToolbar/` house the canonical primitives. `FilterChip` is a pure, presentational `<button>` (no `'use client'` needed — it has no hooks; its parent toolbar is the client boundary). `FilterToolbar` is `'use client'` (it owns dropdown open/close state via `useClickOutside`, the existing hook). Both are token-driven SCSS Modules using bare `var(--token)`. The unified `FilterState` lives in `app/types/GalleryFilter.ts` with optional dimension arrays so a collection page (cameras/lenses/lensTypes/locations) and a location page (film/tags/people) can share one shape. The two existing call sites (`CollectionContentRenderer` via `CollectionFilterContext`, and `LocationPageClient` directly) re-point onto the unified components, then the per-feature CSS (`.filterBar*` in `ContentComponent.module.scss`, all of `LocationFilterBar.module.scss`) is deleted.

**Tech Stack:** Next.js 16 App Router, React 19, TypeScript (strict, no `any`), SCSS Modules with CSS custom properties (bare `var(--token)`, no `@use` partial), Jest + React Testing Library (tests mirror `app/` under `tests/`). `next/jest` maps CSS-module class names to identity strings, so `styles.foo === 'foo'` inside components; in tests assert class presence with `expect(el.className).toMatch(/foo/)`.

> **Spec:** This plan implements **Task 1.3** of the master plan [`001-design-system-unification.md`](001-design-system-unification.md) ("`<FilterChip>` + `<FilterToolbar>` → promote to its own sub-plan"), which in turn implements [`../../001-design-review.md`](../../001-design-review.md) **§2** (taxonomy / filter IA), **§6a rank-3** (the canonical `<FilterToolbar>` + `<FilterChip>`), and **§5** (the High-severity "two divergent filter bars + filter state never URL-driven" row). Section references like *(review §6a-3)* point to the design review.
> **Predecessors / prerequisites:** This plan **depends on Phase 0 + Task 1.1** of the master plan (the painted dark-safe surface + alias-token layer in `globals.css`, and the `<Button>` primitive). Those MUST land first — see *Prerequisite* below. URL-syncing the filter state (review §5 "wired to nothing") is explicitly **Phase 3** of the master plan, NOT this plan; this plan keeps the existing in-memory `useState` ownership and only unifies the *shape* and the *UI*.
> **Status:** Plan only. No code written yet.

---

## Prerequisite (must be green before Task 1)

This plan builds on two master-plan deliverables. Confirm both are merged before starting:

- **Phase 0** ([`001-design-system-unification.md`](001-design-system-unification.md), Tasks 0.1–0.3): the painted page surface (`html,body{ background:var(--color-bg); color:var(--color-fg) }`) + the alias-token layer in `app/styles/globals.css` (`--text-primary`, `--border-color`, `--color-accent`, etc. declared as non-breaking aliases). `FilterChip.module.scss` and `FilterToolbar.module.scss` below use these tokens (`--color-fg`, `--color-bg`, `--color-border`, `--color-accent`) and would silently fall back to hex without Phase 0.
- **Task 1.1** (Button primitive): not imported by FilterChip/FilterToolbar, but its `app/components/ui/` directory + `tests/components/ui/` directory and the `--focus-ring`/`--color-accent` focus conventions are established there. If Task 1.1 has not landed, create the directories as part of Task 1 Step 1.

**Verify the prerequisite:**

Run:
```bash
grep -n "background-color: var(--color-bg)" app/styles/globals.css
grep -n -- "--color-accent:" app/styles/globals.css
```
Expected output: both greps return at least one match (the painted `body` background and the `--color-accent` alias). If either is empty, land Phase 0 first.

---

## File-structure map

**New (created by this plan):**

```
app/components/ui/
  FilterChip/     FilterChip.tsx       FilterChip.module.scss
  FilterToolbar/  FilterToolbar.tsx    FilterToolbar.module.scss

tests/components/ui/
  FilterChip.test.tsx
  FilterToolbar.test.tsx
```

**Modified:**

```
app/types/GalleryFilter.ts                                  (merge two state types into one FilterState + one cycleDateSort + one toggleArrayFilter; remove dead selectedCollectionIds)
app/components/ContentCollection/CollectionFilterContext.tsx (retype to FilterState)
app/components/Content/CollectionContentRenderer.tsx         (render <FilterToolbar> instead of <CollectionFilterBar>; toggleArrayFilter import moves)
app/components/ContentCollection/CollectionPageClient.tsx    (FilterState instead of CollectionFilterState)
app/components/LocationPage/LocationPageClient.tsx           (FilterState + <FilterToolbar>; drop selectedCollectionIds criteria)
app/components/Content/ContentComponent.module.scss          (delete the .filterBar* block, lines ~516–729)
app/styles/globals.css                                       (delete the 6 --color-chip-film/digital-* tokens, lines ~27–32)
tests/components/ContentCollection/CollectionFilterBar.test.tsx (relocate to FilterToolbar.test.tsx coverage; delete original)
```

**Deleted (after migration):**

```
app/components/ContentCollection/CollectionFilterBar.tsx
app/components/LocationFilterBar/LocationFilterBar.tsx
app/components/LocationFilterBar/LocationFilterBar.module.scss   (whole directory)
```

---

## Task 1 — `<FilterChip>` primitive (test-first)

**Why:** Six chip implementations exist for the same "toggle a facet" concept — `CollectionFilterBar`'s `.filterBarItem` (toggle), `.filterBarChip`/`.filterBarChipActive`/`.filterBarChipUnavailable` (dropdown chip with 3-state availability), and `LocationFilterBar`'s `.chip`/`.chipActive`/`.chipFilm`/`.chipDigital` (bordered pills with count badges + saturated film/digital color). One `<FilterChip>` with `active`, `count`, `tone`, `state`, `onToggle` replaces them all *(review §6a-3, §3 "6 chip variants")*.

**Files:**
- Create: `app/components/ui/FilterChip/FilterChip.tsx`
- Create: `app/components/ui/FilterChip/FilterChip.module.scss`
- Test: `tests/components/ui/FilterChip.test.tsx`

- [ ] **Step 1 — Ensure the `ui` directories exist** (idempotent; no-op if Task 1.1 already created them):

Run:
```bash
mkdir -p app/components/ui/FilterChip tests/components/ui
```
Expected output: no output (directories created or already present; exit 0).

- [ ] **Step 2 — Write the failing test** `tests/components/ui/FilterChip.test.tsx`:

```tsx
import { fireEvent, render, screen } from '@testing-library/react';

import { FilterChip } from '@/app/components/ui/FilterChip/FilterChip';

describe('FilterChip', () => {
  it('renders the label as a real button with type="button"', () => {
    render(<FilterChip label="Portland" onToggle={jest.fn()} />);
    const chip = screen.getByRole('button', { name: /portland/i });
    expect(chip).toBeInTheDocument();
    expect(chip).toHaveAttribute('type', 'button');
  });

  it('renders the count when provided', () => {
    render(<FilterChip label="Film" count={12} onToggle={jest.fn()} />);
    expect(screen.getByText('12')).toBeInTheDocument();
  });

  it('omits the count node when count is undefined', () => {
    render(<FilterChip label="Tags" onToggle={jest.fn()} />);
    // The accessible name is just the label — no trailing number.
    const chip = screen.getByRole('button', { name: 'Tags' });
    expect(chip.textContent).toBe('Tags');
  });

  it('reflects active state via aria-pressed and an active class', () => {
    render(<FilterChip label="Film" active onToggle={jest.fn()} />);
    const chip = screen.getByRole('button', { name: /film/i });
    expect(chip).toHaveAttribute('aria-pressed', 'true');
    expect(chip.className).toMatch(/active/);
  });

  it('is aria-pressed="false" when not active', () => {
    render(<FilterChip label="Film" onToggle={jest.fn()} />);
    expect(screen.getByRole('button', { name: /film/i })).toHaveAttribute('aria-pressed', 'false');
  });

  it('is disabled and carries an unavailable class when state="unavailable"', () => {
    render(<FilterChip label="Telephoto" state="unavailable" onToggle={jest.fn()} />);
    const chip = screen.getByRole('button', { name: /telephoto/i });
    expect(chip).toBeDisabled();
    expect(chip.className).toMatch(/unavailable/);
  });

  it('applies a tone class for film/digital tones', () => {
    render(<FilterChip label="Film" tone="film" active onToggle={jest.fn()} />);
    expect(screen.getByRole('button', { name: /film/i }).className).toMatch(/film/);
  });

  it('fires onToggle on click when available', () => {
    const onToggle = jest.fn();
    render(<FilterChip label="Tags" onToggle={onToggle} />);
    fireEvent.click(screen.getByRole('button', { name: 'Tags' }));
    expect(onToggle).toHaveBeenCalledTimes(1);
  });

  it('does not fire onToggle when unavailable (disabled button swallows the click)', () => {
    const onToggle = jest.fn();
    render(<FilterChip label="Tags" state="unavailable" onToggle={onToggle} />);
    fireEvent.click(screen.getByRole('button', { name: 'Tags' }));
    expect(onToggle).not.toHaveBeenCalled();
  });
});
```

- [ ] **Step 3 — Run it; verify it fails:**

Run:
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/FilterChip.test.tsx
```
Expected output: FAIL — `Cannot find module '@/app/components/ui/FilterChip/FilterChip'`.

- [ ] **Step 4 — Implement `app/components/ui/FilterChip/FilterChip.tsx`** (pure presentational button — no hooks, so no `'use client'`):

```tsx
import styles from './FilterChip.module.scss';

export type FilterChipTone = 'neutral' | 'film' | 'digital';
export type FilterChipState = 'available' | 'unavailable';

export interface FilterChipProps {
  /** Visible chip text (e.g. a tag, person, camera, or "Film"). */
  label: string;
  /** Optional contextual result count rendered as a muted badge. */
  count?: number;
  /** Whether this facet is currently selected. Drives aria-pressed + the active style. */
  active?: boolean;
  /** Visual tone. 'film'/'digital' are neutral tri-state tints, not the old saturated colors. */
  tone?: FilterChipTone;
  /** 'unavailable' greys out and disables the chip (3-state availability model). */
  state?: FilterChipState;
  /** Called when the chip is activated (click). Not called while unavailable. */
  onToggle: () => void;
}

/**
 * Canonical filter chip. Replaces the 6 ad-hoc chip implementations across
 * CollectionFilterBar (.filterBarItem / .filterBarChip*) and LocationFilterBar
 * (.chip / .chipActive / .chipFilm / .chipDigital). A real <button> with
 * aria-pressed; 'unavailable' state renders it disabled.
 */
export function FilterChip({
  label,
  count,
  active = false,
  tone = 'neutral',
  state = 'available',
  onToggle,
}: FilterChipProps) {
  const unavailable = state === 'unavailable';
  const classes = [
    styles.chip,
    active ? styles.active : null,
    tone !== 'neutral' ? styles[tone] : null,
    unavailable ? styles.unavailable : null,
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <button
      type="button"
      className={classes}
      aria-pressed={active}
      disabled={unavailable}
      onClick={onToggle}
    >
      {label}
      {count !== undefined && (
        <span className={styles.count} aria-hidden="true">
          {count}
        </span>
      )}
    </button>
  );
}
```

- [ ] **Step 5 — Implement `app/components/ui/FilterChip/FilterChip.module.scss`** (tokens only; film/digital are neutral tri-state tints via opacity/border, NOT the saturated green/pink):

```scss
.chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: var(--space-1) var(--space-3);
  font: inherit;
  font-size: var(--text-sm);
  font-weight: 500;
  line-height: 1.4;
  letter-spacing: 0.02em;
  white-space: nowrap;
  color: var(--color-fg);
  background-color: transparent;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-1);
  cursor: pointer;
  opacity: 0.7;
  transition: background-color 0.15s ease, border-color 0.15s ease, opacity 0.15s ease;

  &:hover:not(:disabled) {
    border-color: var(--color-fg);
    opacity: 1;
  }

  &:focus-visible {
    outline: 2px solid var(--color-accent);
    outline-offset: 2px;
  }
}

.active {
  color: var(--color-bg);
  background-color: var(--color-fg);
  border-color: var(--color-fg);
  opacity: 1;
  font-weight: 600;

  &:hover:not(:disabled) {
    opacity: 0.85;
  }
}

/* Film/digital tri-state: a neutral emphasis (heavier border), NOT saturated color. */
.film {
  border-style: dashed;
}

.digital {
  border-style: dotted;
}

.unavailable {
  opacity: 0.25;
  cursor: not-allowed;

  &:hover {
    border-color: var(--color-border);
    opacity: 0.25;
  }
}

.count {
  font-size: var(--text-xs);
  font-weight: 400;
  opacity: 0.6;
}
```

- [ ] **Step 6 — Run the test; verify it passes:**

Run:
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/FilterChip.test.tsx
```
Expected output: PASS — 9 tests passed.

- [ ] **Step 7 — Format, lint, type-check:**

Run:
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write 'app/components/ui/FilterChip/FilterChip.tsx' 'tests/components/ui/FilterChip.test.tsx'
/opt/homebrew/bin/node node_modules/.bin/eslint --fix 'app/components/ui/FilterChip/FilterChip.tsx' 'tests/components/ui/FilterChip.test.tsx'
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/ui/FilterChip/FilterChip.module.scss'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
```
Expected output: prettier rewrites/leaves files unchanged; eslint exits 0 with no errors; stylelint exits 0; `tsc` prints nothing and exits 0.

- [ ] **Step 8 — Commit:**

Run:
```bash
git add app/components/ui/FilterChip tests/components/ui/FilterChip.test.tsx
git commit -m "feat(ui): add canonical FilterChip primitive

Real <button> with aria-pressed, optional count badge, neutral/film/digital
tone, and a 3-state availability model (unavailable -> disabled). Replaces the
6 ad-hoc chip variants across CollectionFilterBar and LocationFilterBar.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```
Expected output: one commit created; `tsc --noEmit` and the FilterChip test were green at commit time.

---

## Task 2 — Unify the filter-state types + helpers

**Why:** `GalleryFilterState` (location pages: `dateSortDirection` + `highlyRatedOnly` + `filmFilter` + dead `selectedCollectionIds` + `selectedTags` + `selectedPeople`) and `CollectionFilterState` (collection pages: tags/people/cameras/lenses/locations/lensTypes + `highlyRatedOnly` + `dateSortDirection`) are the same concept with divergent fields. `cycleDateSort` exists twice with **different** cycle orders (collection: `off→asc→desc→off`; location: `off→desc→asc→off`). `LocationFilterBar` re-implements `toggleTag`/`togglePerson` instead of the exported `toggleArrayFilter`. `selectedCollectionIds` is dead — only ever the frozen empty array, read by a `.length > 0` branch in `LocationPageClient` that is never true *(review §2, §6a-3)*.

**Files:**
- Modify: `app/types/GalleryFilter.ts`
- Test: `tests/types/GalleryFilter.test.ts` (new — covers the merged helpers)

- [ ] **Step 1 — Write the failing test** `tests/types/GalleryFilter.test.ts`:

```ts
import {
  cycleDateSort,
  type FilterState,
  INITIAL_FILTER_STATE,
  toggleArrayFilter,
} from '@/app/types/GalleryFilter';

describe('FilterState helpers', () => {
  it('INITIAL_FILTER_STATE has every dimension empty and sorts/toggles off', () => {
    expect(INITIAL_FILTER_STATE.dateSortDirection).toBe('off');
    expect(INITIAL_FILTER_STATE.highlyRatedOnly).toBe(false);
    expect(INITIAL_FILTER_STATE.filmFilter).toBe('off');
    expect(INITIAL_FILTER_STATE.selectedTags).toEqual([]);
    expect(INITIAL_FILTER_STATE.selectedPeople).toEqual([]);
    expect(INITIAL_FILTER_STATE.selectedCameras).toEqual([]);
    expect(INITIAL_FILTER_STATE.selectedLenses).toEqual([]);
    expect(INITIAL_FILTER_STATE.selectedLensTypes).toEqual([]);
    expect(INITIAL_FILTER_STATE.selectedLocations).toEqual([]);
  });

  it('has no selectedCollectionIds field (dead field removed)', () => {
    expect('selectedCollectionIds' in INITIAL_FILTER_STATE).toBe(false);
  });

  it('cycleDateSort uses one canonical order: off -> asc -> desc -> off', () => {
    expect(cycleDateSort('off')).toBe('asc');
    expect(cycleDateSort('asc')).toBe('desc');
    expect(cycleDateSort('desc')).toBe('off');
  });

  it('toggleArrayFilter adds a value not present', () => {
    const state: FilterState = { ...INITIAL_FILTER_STATE };
    const updates: Partial<FilterState>[] = [];
    toggleArrayFilter(state, u => updates.push(u), 'selectedTags', 'sunset');
    expect(updates).toEqual([{ selectedTags: ['sunset'] }]);
  });

  it('toggleArrayFilter removes a value already present', () => {
    const state: FilterState = { ...INITIAL_FILTER_STATE, selectedPeople: ['Ana', 'Bo'] };
    const updates: Partial<FilterState>[] = [];
    toggleArrayFilter(state, u => updates.push(u), 'selectedPeople', 'Ana');
    expect(updates).toEqual([{ selectedPeople: ['Bo'] }]);
  });
});
```

- [ ] **Step 2 — Run it; verify it fails:**

Run:
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/types/GalleryFilter.test.ts
```
Expected output: FAIL — `cycleDateSort`/`INITIAL_FILTER_STATE`/`FilterState`/`toggleArrayFilter` are not exported from `@/app/types/GalleryFilter`.

- [ ] **Step 3 — Replace the entire contents of `app/types/GalleryFilter.ts`** with the unified shape + helpers. This collapses both interfaces into one `FilterState` (every dimension optional-presence via empty arrays), one `cycleDateSort`, and lifts `toggleArrayFilter` (previously exported from `CollectionFilterBar.tsx`) into the type module so both the toolbar and `CollectionContentRenderer` import it from one place:

```ts
/**
 * Unified filter state for every gallery view (collection detail pages,
 * location/tag/people taxonomy pages, parent pages). One shape with all
 * dimensions present-as-empty-arrays; a given page wires only the dimensions
 * it surfaces. Replaces the former GalleryFilterState + CollectionFilterState.
 *
 * All fields are URL-serializable (see app/utils/contentFilter.ts
 * parseFilterFromParams / serializeFilterToParams) so the state can later be
 * synced to search params (master plan Phase 3 — not this plan).
 */
export type DateSortDirection = 'asc' | 'desc' | 'off';

/** 'film' = film only, 'digital' = digital only, 'off' = no film/digital filter. */
export type FilmFilter = 'film' | 'digital' | 'off';

export type LensType = 'wide' | 'normal' | 'telephoto';

export interface FilterState {
  dateSortDirection: DateSortDirection;
  highlyRatedOnly: boolean;
  filmFilter: FilmFilter;
  readonly selectedTags: readonly string[];
  readonly selectedPeople: readonly string[];
  readonly selectedCameras: readonly string[];
  readonly selectedLenses: readonly string[];
  readonly selectedLocations: readonly string[];
  readonly selectedLensTypes: readonly LensType[];
}

export const INITIAL_FILTER_STATE: FilterState = Object.freeze({
  dateSortDirection: 'off' as const,
  highlyRatedOnly: false,
  filmFilter: 'off' as const,
  selectedTags: Object.freeze([] as readonly string[]),
  selectedPeople: Object.freeze([] as readonly string[]),
  selectedCameras: Object.freeze([] as readonly string[]),
  selectedLenses: Object.freeze([] as readonly string[]),
  selectedLocations: Object.freeze([] as readonly string[]),
  selectedLensTypes: Object.freeze([] as readonly LensType[]),
});

/** Keys of FilterState whose value is a readonly string-or-LensType array. */
export type ArrayFilterKey =
  | 'selectedTags'
  | 'selectedPeople'
  | 'selectedCameras'
  | 'selectedLenses'
  | 'selectedLocations'
  | 'selectedLensTypes';

/**
 * The single canonical date-sort cycle: off -> asc -> desc -> off.
 * (Collapses the two divergent orders that previously lived in
 * CollectionFilterBar and LocationFilterBar.)
 */
export function cycleDateSort(current: DateSortDirection): DateSortDirection {
  const next: Record<DateSortDirection, DateSortDirection> = {
    off: 'asc',
    asc: 'desc',
    desc: 'off',
  };
  return next[current];
}

/**
 * Toggle a value in one of the array dimensions and emit a Partial update.
 * Lifted out of CollectionFilterBar so the toolbar AND tag-click handlers in
 * CollectionContentRenderer share one implementation (replaces the hand-rolled
 * toggleTag / togglePerson in LocationFilterBar).
 */
export function toggleArrayFilter(
  state: FilterState,
  onChange: (update: Partial<FilterState>) => void,
  key: ArrayFilterKey,
  value: string
): void {
  const current = state[key] as readonly string[];
  const next = current.includes(value) ? current.filter(v => v !== value) : [...current, value];
  onChange({ [key]: next });
}
```

- [ ] **Step 4 — Run the new test; verify it passes:**

Run:
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/types/GalleryFilter.test.ts
```
Expected output: PASS — 5 tests passed.

- [ ] **Step 5 — Surface every downstream breakage** (this is expected — fixed in Tasks 3–4):

Run:
```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
```
Expected output: errors referencing `GalleryFilterState`, `CollectionFilterState`, `INITIAL_GALLERY_FILTER_STATE`, `INITIAL_COLLECTION_FILTER_STATE`, and `selectedCollectionIds` in `CollectionFilterBar.tsx`, `LocationFilterBar.tsx`, `CollectionFilterContext.tsx`, `CollectionPageClient.tsx`, `LocationPageClient.tsx`, `CollectionContentRenderer.tsx`. Record the file list — Tasks 3 and 4 clear all of them. **Do not commit yet** (the tree does not type-check on its own until Task 4 lands; commit at the end of Task 4).

---

## Task 3 — `<FilterToolbar>` (test-first, config-driven)

**Why:** Two filter bars render the same facets differently. `CollectionFilterBar` has the better model (borderless toggle items, dropdown panels, the 3-state availability grey-out, the density slider). `LocationFilterBar` adds count badges + a film toggle but loses availability and re-implements toggling. One config-driven `<FilterToolbar>` adopts `CollectionFilterBar`'s dropdown + availability base, folds in `LocationFilterBar`'s count badges + film tri-state, and includes the density slider — driven by a `dimensions` config that says which facets to show *(review §6a-3, §7 "one persistent/sticky FilterToolbar … works identically on collection and taxonomy pages")*.

**Files:**
- Create: `app/components/ui/FilterToolbar/FilterToolbar.tsx`
- Create: `app/components/ui/FilterToolbar/FilterToolbar.module.scss`
- Test: `tests/components/ui/FilterToolbar.test.tsx`

- [ ] **Step 1 — Write the failing test** `tests/components/ui/FilterToolbar.test.tsx`:

```tsx
import { fireEvent, render, screen } from '@testing-library/react';
import { type ComponentProps } from 'react';

import { FilterToolbar } from '@/app/components/ui/FilterToolbar/FilterToolbar';
import { INITIAL_FILTER_STATE } from '@/app/types/GalleryFilter';

type Props = ComponentProps<typeof FilterToolbar>;

function renderToolbar(overrides: Partial<Props> = {}) {
  const onFilterChange = jest.fn();
  const onDensityChange = jest.fn();
  const props: Props = {
    filterState: INITIAL_FILTER_STATE,
    onFilterChange,
    dimensions: {},
    showDateSort: false,
    showHighlyRated: false,
    showFilm: false,
    ...overrides,
  };
  render(<FilterToolbar {...props} />);
  return { onFilterChange, onDensityChange };
}

describe('FilterToolbar', () => {
  it('renders a date-sort toggle that cycles off -> asc on click', () => {
    const { onFilterChange } = renderToolbar({ showDateSort: true });
    fireEvent.click(screen.getByRole('button', { name: /date/i }));
    expect(onFilterChange).toHaveBeenCalledWith({ dateSortDirection: 'asc' });
  });

  it('renders a highly-rated toggle with its count badge', () => {
    const { onFilterChange } = renderToolbar({
      showHighlyRated: true,
      counts: { highlyRated: 7 },
    });
    expect(screen.getByText('7')).toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: /highly rated/i }));
    expect(onFilterChange).toHaveBeenCalledWith({ highlyRatedOnly: true });
  });

  it('renders a film tri-state toggle that cycles off -> film', () => {
    const { onFilterChange } = renderToolbar({ showFilm: true });
    fireEvent.click(screen.getByRole('button', { name: /film/i }));
    expect(onFilterChange).toHaveBeenCalledWith({ filmFilter: 'film' });
  });

  it('opens a dimension dropdown and toggles a value via FilterChip', () => {
    const { onFilterChange } = renderToolbar({
      dimensions: { selectedTags: { label: 'Tags', options: ['sunset', 'forest'] } },
    });
    fireEvent.click(screen.getByRole('button', { name: 'Tags' }));
    fireEvent.click(screen.getByRole('button', { name: 'sunset' }));
    expect(onFilterChange).toHaveBeenCalledWith({ selectedTags: ['sunset'] });
  });

  it('greys out + disables an option absent from filteredAvailable', () => {
    renderToolbar({
      dimensions: { selectedTags: { label: 'Tags', options: ['sunset', 'forest'] } },
      filteredAvailable: { selectedTags: ['sunset'] },
    });
    fireEvent.click(screen.getByRole('button', { name: 'Tags' }));
    expect(screen.getByRole('button', { name: 'forest' })).toBeDisabled();
    expect(screen.getByRole('button', { name: 'sunset' })).not.toBeDisabled();
  });

  it('renders the density slider when onDensityChange is provided', () => {
    const onDensityChange = jest.fn();
    renderToolbar({ density: 4, onDensityChange });
    const slider = screen.getByLabelText('Row density') as HTMLInputElement;
    expect(slider.getAttribute('type')).toBe('range');
    expect(slider.value).toBe('4');
    fireEvent.change(slider, { target: { value: '8' } });
    expect(onDensityChange).toHaveBeenCalledWith(8);
  });

  it('omits the density slider when onDensityChange is not provided', () => {
    renderToolbar({});
    expect(screen.queryByLabelText('Row density')).toBeNull();
  });

  it('renders a reset button only when a filter is active', () => {
    const { rerender } = (() => {
      const onFilterChange = jest.fn();
      const view = render(
        <FilterToolbar
          filterState={INITIAL_FILTER_STATE}
          onFilterChange={onFilterChange}
          dimensions={{}}
          showDateSort
        />
      );
      return { ...view, onFilterChange };
    })();
    expect(screen.queryByRole('button', { name: /reset all filters/i })).toBeNull();
    rerender(
      <FilterToolbar
        filterState={{ ...INITIAL_FILTER_STATE, highlyRatedOnly: true }}
        onFilterChange={jest.fn()}
        dimensions={{}}
        showHighlyRated
      />
    );
    expect(screen.getByRole('button', { name: /reset all filters/i })).toBeInTheDocument();
  });
});
```

- [ ] **Step 2 — Run it; verify it fails:**

Run:
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/FilterToolbar.test.tsx
```
Expected output: FAIL — `Cannot find module '@/app/components/ui/FilterToolbar/FilterToolbar'`.

- [ ] **Step 3 — Implement `app/components/ui/FilterToolbar/FilterToolbar.tsx`** (`'use client'` — owns dropdown open/close via the existing `useClickOutside` hook; renders `FilterChip`s + native range slider). Note the density slider renders only when `onDensityChange` is supplied; film renders as a neutral tri-state chip (tone driven, no saturated color):

```tsx
'use client';

import { useCallback, useRef, useState } from 'react';

import { FilterChip } from '@/app/components/ui/FilterChip/FilterChip';
import { useClickOutside } from '@/app/hooks/useClickOutside';
import {
  type ArrayFilterKey,
  cycleDateSort,
  type FilmFilter,
  type FilterState,
  INITIAL_FILTER_STATE,
  toggleArrayFilter,
} from '@/app/types/GalleryFilter';

import styles from './FilterToolbar.module.scss';

/** One filterable dimension: which state key it writes, its dropdown label, its options, and optional value->label/count maps. */
export interface ToolbarDimension {
  label: string;
  options: readonly string[];
  /** Optional display labels for option values (e.g. lens-type 'wide' -> 'Wide'). */
  optionLabels?: Record<string, string>;
  /** Optional per-option contextual counts. */
  counts?: Record<string, number>;
}

/** Aggregate counts for the standalone toggles. */
export interface ToolbarCounts {
  highlyRated?: number;
  film?: number;
  digital?: number;
}

export interface FilterToolbarProps {
  filterState: FilterState;
  onFilterChange: (update: Partial<FilterState>) => void;
  /** Which array dimensions to surface as dropdowns, keyed by the FilterState array key. */
  dimensions: Partial<Record<ArrayFilterKey, ToolbarDimension>>;
  /** Subset of options still reachable under current filters; absent options render unavailable. null/undefined = all available. */
  filteredAvailable?: Partial<Record<ArrayFilterKey, readonly string[]>> | null;
  /** Aggregate counts for the highly-rated / film / digital toggles. */
  counts?: ToolbarCounts;
  showDateSort?: boolean;
  showHighlyRated?: boolean;
  showFilm?: boolean;
  /** When provided, renders the row-density slider (1-10). */
  density?: number;
  onDensityChange?: (value: number) => void;
}

const ARRAY_KEYS: readonly ArrayFilterKey[] = [
  'selectedTags',
  'selectedPeople',
  'selectedCameras',
  'selectedLenses',
  'selectedLocations',
  'selectedLensTypes',
];

const DATE_LABELS: Record<FilterState['dateSortDirection'], string> = {
  asc: 'Date ↑',
  desc: 'Date ↓',
  off: 'Date',
};

/**
 * Canonical, config-driven filter toolbar. Adopts CollectionFilterBar's
 * dropdown + 3-state availability model as the base, folds in
 * LocationFilterBar's count badges + film toggle (rendered as a neutral
 * tri-state, not saturated green/pink), and includes the density slider.
 * Replaces both filter bars.
 */
export function FilterToolbar({
  filterState,
  onFilterChange,
  dimensions,
  filteredAvailable,
  counts,
  showDateSort = false,
  showHighlyRated = false,
  showFilm = false,
  density,
  onDensityChange,
}: FilterToolbarProps) {
  const [openDropdown, setOpenDropdown] = useState<ArrayFilterKey | null>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const closeAll = useCallback(() => setOpenDropdown(null), []);
  useClickOutside(barRef, openDropdown !== null, closeAll);

  const toggleOpen = (key: ArrayFilterKey) =>
    setOpenDropdown(prev => (prev === key ? null : key));

  const isAvailable = (key: ArrayFilterKey, value: string): boolean => {
    const avail = filteredAvailable?.[key];
    if (!avail) return true;
    return avail.includes(value);
  };

  const cycleFilm = () => {
    const next: Record<FilmFilter, FilmFilter> = { off: 'film', film: 'digital', digital: 'off' };
    onFilterChange({ filmFilter: next[filterState.filmFilter] });
  };

  const hasActiveFilters =
    filterState.dateSortDirection !== 'off' ||
    filterState.highlyRatedOnly ||
    filterState.filmFilter !== 'off' ||
    ARRAY_KEYS.some(k => (filterState[k] as readonly string[]).length > 0);

  const resetAll = () => {
    onFilterChange({ ...INITIAL_FILTER_STATE });
    closeAll();
  };

  return (
    <div ref={barRef} className={styles.toolbar}>
      {showDateSort && (
        <FilterChip
          label={DATE_LABELS[filterState.dateSortDirection]}
          active={filterState.dateSortDirection !== 'off'}
          onToggle={() => onFilterChange({ dateSortDirection: cycleDateSort(filterState.dateSortDirection) })}
        />
      )}

      {showHighlyRated && (
        <FilterChip
          label="Highly Rated"
          count={counts?.highlyRated}
          active={filterState.highlyRatedOnly}
          onToggle={() => onFilterChange({ highlyRatedOnly: !filterState.highlyRatedOnly })}
        />
      )}

      {showFilm && (
        <FilterChip
          label={filterState.filmFilter === 'digital' ? 'Digital' : 'Film'}
          count={
            filterState.filmFilter === 'film'
              ? counts?.film
              : filterState.filmFilter === 'digital'
                ? counts?.digital
                : undefined
          }
          tone={filterState.filmFilter === 'digital' ? 'digital' : 'film'}
          active={filterState.filmFilter !== 'off'}
          onToggle={cycleFilm}
        />
      )}

      {ARRAY_KEYS.map(key => {
        const dim = dimensions[key];
        if (!dim || dim.options.length === 0) return null;
        const selected = filterState[key] as readonly string[];
        const isOpen = openDropdown === key;
        return (
          <div key={key} className={styles.dropdown}>
            <button
              type="button"
              aria-haspopup="true"
              aria-expanded={isOpen}
              className={`${styles.dropdownTrigger} ${selected.length > 0 ? styles.dropdownTriggerActive : ''}`}
              onClick={() => toggleOpen(key)}
            >
              {dim.label}
              <span className={styles.chevron} aria-hidden="true">
                {isOpen ? '▴' : '▾'}
              </span>
            </button>
            {isOpen && (
              <div className={styles.panel}>
                {dim.options.map(option => {
                  const isSelected = selected.includes(option);
                  const available = isSelected || isAvailable(key, option);
                  return (
                    <FilterChip
                      key={`${key}-${option}`}
                      label={dim.optionLabels?.[option] ?? option}
                      count={dim.counts?.[option]}
                      active={isSelected}
                      state={available ? 'available' : 'unavailable'}
                      onToggle={() => {
                        toggleArrayFilter(filterState, onFilterChange, key, option);
                        closeAll();
                      }}
                    />
                  );
                })}
              </div>
            )}
          </div>
        );
      })}

      {hasActiveFilters && (
        <button
          type="button"
          className={styles.reset}
          onClick={resetAll}
          aria-label="Reset all filters"
        >
          {'×'}
        </button>
      )}

      {onDensityChange && density !== undefined && (
        <label className={styles.slider}>
          {/* aria-hidden: the range input already announces its value natively. */}
          <span className={styles.sliderLabel} aria-hidden="true">
            Density {density}
          </span>
          <input
            type="range"
            min={1}
            max={10}
            step={1}
            value={density}
            onChange={e => onDensityChange(Number(e.target.value))}
            aria-label="Row density"
          />
        </label>
      )}
    </div>
  );
}
```

- [ ] **Step 4 — Implement `app/components/ui/FilterToolbar/FilterToolbar.module.scss`** (tokens only; mirrors the proven `.filterBar*` layout that is being deleted, but token-driven and dark-safe):

```scss
.toolbar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px;
  margin-top: auto;
  padding: var(--space-2) var(--space-3) var(--space-1);
  border-top: 1px solid var(--color-border);

  @media (width >= 768px) {
    padding: var(--space-2) 0 var(--space-1);
  }
}

.dropdown {
  position: relative;
}

.dropdownTrigger {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 5px 10px;
  font: inherit;
  font-size: var(--text-sm);
  font-weight: 500;
  line-height: 1.4;
  letter-spacing: 0.02em;
  white-space: nowrap;
  color: var(--color-fg);
  background-color: transparent;
  border: none;
  border-radius: var(--radius-1);
  cursor: pointer;
  opacity: 0.5;
  transition: background-color 0.15s ease, opacity 0.15s ease;

  &:hover {
    background-color: var(--color-overlay-soft);
    opacity: 0.8;
  }

  &:focus-visible {
    outline: 2px solid var(--color-accent);
    outline-offset: 2px;
  }
}

.dropdownTriggerActive {
  opacity: 1;
  font-weight: 600;
  background-color: var(--color-overlay-soft);
}

.chevron {
  font-size: 0.55rem;
  line-height: 1;
  opacity: 0.5;
}

.panel {
  position: absolute;
  top: calc(100% + 4px);
  left: 0;
  z-index: var(--z-dropdown);
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-1);
  min-width: 160px;
  max-width: 320px;
  padding: 8px 10px;
  background-color: var(--color-bg);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-1);
  box-shadow: 0 4px 12px var(--color-overlay-soft);
}

.reset {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  margin-left: auto;
  padding: 2px 8px;
  font: inherit;
  font-size: var(--text-sm);
  line-height: 1.4;
  color: var(--color-fg);
  background-color: transparent;
  border: none;
  border-radius: var(--radius-1);
  cursor: pointer;
  opacity: 0.35;
  transition: opacity 0.15s ease, background-color 0.15s ease;

  &:hover {
    opacity: 0.7;
    background-color: var(--color-overlay-soft);
  }

  &:focus-visible {
    outline: 2px solid var(--color-accent);
    outline-offset: 2px;
  }
}

.slider {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 5px 10px;
  font-size: var(--text-sm);
  font-weight: 500;
  line-height: 1.4;
  letter-spacing: 0.02em;
  white-space: nowrap;
  color: var(--color-fg);
  opacity: 0.75;

  input[type='range'] {
    width: 96px;
    height: 1rem;
    margin: 0;
    vertical-align: middle;
    cursor: pointer;
    accent-color: var(--color-fg);

    &:focus-visible {
      outline: 2px solid var(--color-accent);
      outline-offset: 2px;
    }
  }
}

.sliderLabel {
  opacity: 0.55;
  font-weight: 400;
  font-variant-numeric: tabular-nums;
}
```

- [ ] **Step 5 — Run the test; verify it passes:**

Run:
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/FilterToolbar.test.tsx
```
Expected output: PASS — 8 tests passed.

- [ ] **Step 6 — Confirm `--color-overlay-soft` is declared** (used by the toolbar SCSS; the master plan's Button SCSS also relies on it). If it is not in `globals.css`, the toolbar still functions but the hover/shadow tints fall back to `initial`:

Run:
```bash
grep -n -- "--color-overlay-soft" app/styles/globals.css
```
Expected output: at least one match. If empty, add `--color-overlay-soft: rgb(0 0 0 / 5%);` to the `:root` block in `globals.css` as part of this step (matches the literal that `.filterBarItem:hover` used).

- [ ] **Step 7 — Format, lint, type-check** (`tsc` still reports the Task 2 downstream errors — those clear in Task 4; this step only confirms the new files themselves are clean):

Run:
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write 'app/components/ui/FilterToolbar/FilterToolbar.tsx' 'tests/components/ui/FilterToolbar.test.tsx'
/opt/homebrew/bin/node node_modules/.bin/eslint --fix 'app/components/ui/FilterToolbar/FilterToolbar.tsx' 'tests/components/ui/FilterToolbar.test.tsx'
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/ui/FilterToolbar/FilterToolbar.module.scss'
```
Expected output: prettier/eslint/stylelint each exit 0 with no errors on the new files. (Skip `tsc` here — run it after Task 4 when the migration completes the tree.)

*(No commit in Task 3 — the repo does not type-check until Task 4 re-points the call sites. Tasks 2+3+4 land as one commit at the end of Task 4.)*

---

## Task 4 — Migrate call sites + delete the old bars

**Why:** Re-point both consumers (`CollectionContentRenderer` via `CollectionFilterContext`, and `LocationPageClient` directly) onto `<FilterToolbar>` + the unified `FilterState`, then delete `CollectionFilterBar.tsx`, the whole `LocationFilterBar/` directory, the `.filterBar*` SCSS block, and the saturated chip tokens. This is what makes the consolidation real *(review §6c step 5 "migrate call sites … delete each per-feature block as it converts")*.

**Files:**
- Modify: `app/components/ContentCollection/CollectionFilterContext.tsx`
- Modify: `app/components/Content/CollectionContentRenderer.tsx`
- Modify: `app/components/ContentCollection/CollectionPageClient.tsx`
- Modify: `app/components/LocationPage/LocationPageClient.tsx`
- Modify: `app/components/Content/ContentComponent.module.scss`
- Modify: `app/styles/globals.css`
- Delete: `app/components/ContentCollection/CollectionFilterBar.tsx`
- Delete: `app/components/LocationFilterBar/LocationFilterBar.tsx` + `LocationFilterBar.module.scss`
- Delete: `tests/components/ContentCollection/CollectionFilterBar.test.tsx`

- [ ] **Step 1 — Retype `CollectionFilterContext.tsx`** to the unified `FilterState`. Replace the two type imports and every `CollectionFilterState` reference. The `CollectionInfoOptions` / `FilteredAvailableOptions` / `DimensionData` shapes stay (the collection page still computes per-dimension `filterable` + availability) — only the state type changes:

Change the import (top of file):
```tsx
import { type FilterState, type LensType } from '@/app/types/GalleryFilter';
```
Then replace both occurrences of `CollectionFilterState` in the `CollectionFilterContextValue` interface with `FilterState`:
```tsx
interface CollectionFilterContextValue {
  filterState: FilterState;
  filterOptions: CollectionInfoOptions;
  filteredAvailable: FilteredAvailableOptions;
  onFilterChange: (update: Partial<FilterState>) => void;
  density: number;
  onDensityChange: (value: number) => void;
}
```

- [ ] **Step 2 — Rewrite `CollectionContentRenderer.tsx`'s filter-bar render + tag-click import.** The file currently imports `toggleArrayFilter` from `CollectionFilterBar` (line ~13 area) and renders `<CollectionFilterBar … />` (lines ~273–282). Re-point both:

Replace the `toggleArrayFilter` import so it comes from the type module, and import the toolbar:
```tsx
import { FilterToolbar, type ToolbarDimension } from '@/app/components/ui/FilterToolbar/FilterToolbar';
import { type ArrayFilterKey, toggleArrayFilter } from '@/app/types/GalleryFilter';
```
(Remove the old `import CollectionFilterBar, { … } from '@/app/components/ContentCollection/CollectionFilterBar';` line and any `toggleArrayFilter` import that pointed at it.)

Replace the `{collectionFilter && ( <CollectionFilterBar … /> )}` block with a toolbar that maps `CollectionInfoOptions` → the toolbar's `dimensions` config. Add this helper just above the component's return (or inline in the render where `collectionFilter` is consumed):
```tsx
function toCollectionDimensions(
  options: NonNullable<ReturnType<typeof useCollectionFilter>>['filterOptions']
): Partial<Record<ArrayFilterKey, ToolbarDimension>> {
  const dims: Partial<Record<ArrayFilterKey, ToolbarDimension>> = {};
  if (options.people.filterable && options.people.values.length > 0) {
    dims.selectedPeople = { label: 'People', options: options.people.values };
  }
  if (options.tags.filterable && options.tags.values.length > 0) {
    dims.selectedTags = { label: 'Tags', options: options.tags.values };
  }
  if (options.cameras.filterable && options.cameras.values.length > 0) {
    dims.selectedCameras = { label: 'Camera', options: options.cameras.values };
  }
  if (options.locations.filterable && options.locations.values.length > 0) {
    dims.selectedLocations = { label: 'Location', options: options.locations.values };
  }
  const lensOptions = [...options.lensTypes.values, ...options.lenses.values];
  if (
    (options.lenses.filterable && options.lenses.values.length > 0) ||
    (options.lensTypes.filterable && options.lensTypes.values.length > 0)
  ) {
    // Lens dropdown is split (types then names) in the old bar; the toolbar
    // surfaces lens NAMES as one dropdown. Lens-type chips are folded in via
    // optionLabels when present.
    dims.selectedLenses = {
      label: 'Lens',
      options: options.lenses.values,
    };
    if (options.lensTypes.values.length > 0) {
      dims.selectedLensTypes = {
        label: 'Lens type',
        options: options.lensTypes.values,
        optionLabels: { wide: 'Wide', normal: 'Normal', telephoto: 'Telephoto' },
      };
    }
  }
  void lensOptions;
  return dims;
}
```
Then render:
```tsx
{collectionFilter && (
  <FilterToolbar
    filterState={collectionFilter.filterState}
    onFilterChange={collectionFilter.onFilterChange}
    dimensions={toCollectionDimensions(collectionFilter.filterOptions)}
    filteredAvailable={
      collectionFilter.filteredAvailable
        ? {
            selectedTags: collectionFilter.filteredAvailable.tags,
            selectedPeople: collectionFilter.filteredAvailable.people,
            selectedCameras: collectionFilter.filteredAvailable.cameras,
            selectedLenses: collectionFilter.filteredAvailable.lenses,
            selectedLensTypes: collectionFilter.filteredAvailable.lensTypes,
            selectedLocations: collectionFilter.filteredAvailable.locations,
          }
        : null
    }
    showDateSort
    showHighlyRated={collectionFilter.filterOptions.showHighlyRated}
    density={collectionFilter.density}
    onDensityChange={collectionFilter.onDensityChange}
  />
)}
```
The existing tag-click handler (`handleTagClick`) already calls `toggleArrayFilter(collectionFilter.filterState, collectionFilter.onFilterChange, 'selectedTags', tagName)` — it now resolves to the import from `@/app/types/GalleryFilter`; no behavior change. Leave the inline info-chip rendering for non-filterable single-value dimensions (cameras/lenses) as-is if present; the toolbar's `dimensions` config already excludes non-filterable dims by checking `.filterable`.

- [ ] **Step 3 — Update `CollectionPageClient.tsx`** to use the unified type. Change the import and the `useState`:

Replace:
```tsx
import {
  type CollectionFilterState,
  INITIAL_COLLECTION_FILTER_STATE,
  type LensType,
} from '@/app/types/GalleryFilter';
```
with:
```tsx
import { type FilterState, INITIAL_FILTER_STATE, type LensType } from '@/app/types/GalleryFilter';
```
Replace `useState<CollectionFilterState>(INITIAL_COLLECTION_FILTER_STATE)` with `useState<FilterState>(INITIAL_FILTER_STATE)`, and the `handleFilterChange` signature `(update: Partial<CollectionFilterState>)` with `(update: Partial<FilterState>)`. All the `criteria`/`hasActiveFilters` memo bodies reference fields that still exist on `FilterState` (`highlyRatedOnly`, `selectedTags`, `selectedPeople`, `selectedCameras`, `selectedLenses`, `selectedLocations`, `selectedLensTypes`, `dateSortDirection`) — no body changes needed. `filmFilter` is simply left at `'off'` for collection pages (the toolbar's `showFilm` defaults to false there).

- [ ] **Step 4 — Update `LocationPageClient.tsx`** to use `FilterState` + `<FilterToolbar>`, and drop the dead `selectedCollectionIds` criteria branch. Replace imports:
```tsx
import { FilterToolbar } from '@/app/components/ui/FilterToolbar/FilterToolbar';
import { type FilterState, INITIAL_FILTER_STATE } from '@/app/types/GalleryFilter';
```
(Remove the `LocationFilterBar` import and the `GalleryFilterState`/`INITIAL_GALLERY_FILTER_STATE` import.)

Change the state hook + handler:
```tsx
const [filterState, setFilterState] = useState<FilterState>(INITIAL_FILTER_STATE);
// ...
const handleFilterChange = useCallback((update: Partial<FilterState>) => {
  setFilterState(prev => ({ ...prev, ...update }));
}, []);
```
Remove the dead `selectedCollectionIds` branch from `criteria` (it can never fire — the field no longer exists):
```tsx
const criteria = useMemo(
  () => ({
    ...(filterState.highlyRatedOnly ? { minRating: 4 } : {}),
    ...(filterState.filmFilter === 'film' ? { isFilm: true as const } : {}),
    ...(filterState.filmFilter === 'digital' ? { isFilm: false as const } : {}),
    ...(filterState.selectedTags.length > 0 ? { tags: filterState.selectedTags } : {}),
    ...(filterState.selectedPeople.length > 0 ? { people: filterState.selectedPeople } : {}),
  }),
  [filterState]
);
```
Replace the `<LocationFilterBar … />` render with `<FilterToolbar … />`, mapping `availableOptions` (a `ContentFilterOptions`: flat `tags: string[]`, `people: string[]`) + `filterCounts` into the toolbar config. Preserve the original visibility rules (`showTagRow = tags.length > 0`, `showPeopleRow = people.length >= 2`):
```tsx
<FilterToolbar
  filterState={filterState}
  onFilterChange={handleFilterChange}
  dimensions={{
    ...(availableOptions.tags.length > 0
      ? { selectedTags: { label: 'Tags', options: availableOptions.tags, counts: filterCounts.tags } }
      : {}),
    ...(availableOptions.people.length >= 2
      ? {
          selectedPeople: {
            label: 'People',
            options: availableOptions.people,
            counts: filterCounts.people,
          },
        }
      : {}),
  }}
  counts={{
    highlyRated: filterCounts.highlyRated,
    film: filterCounts.film,
    digital: filterCounts.digital,
  }}
  showDateSort
  showHighlyRated
  showFilm
/>
```

- [ ] **Step 5 — Delete the old bars + their styles + the stale test:**

Run:
```bash
git rm app/components/ContentCollection/CollectionFilterBar.tsx \
       app/components/LocationFilterBar/LocationFilterBar.tsx \
       app/components/LocationFilterBar/LocationFilterBar.module.scss \
       tests/components/ContentCollection/CollectionFilterBar.test.tsx
```
Expected output: four `rm '…'` lines; the empty `app/components/LocationFilterBar/` directory is removed by git.

- [ ] **Step 6 — Delete the `.filterBar*` SCSS block** from `app/components/Content/ContentComponent.module.scss` (the block from `/* ── Filter bar … ── */` `.filterBar` through `.filterBarReset`, lines ~516–729) — every class in it (`filterBar`, `filterBarItem`, `filterBarItemActive`, `filterBarInfo`, `filterBarInfoLabel`, `filterBarSlider`, `filterBarSliderLabel`, `filterBarChevron`, `filterBarDropdown`, `filterBarPanel`, `filterBarPanelDivider`, `filterBarChip`, `filterBarChipActive`, `filterBarChipUnavailable`, `filterBarReset`) is now dead. **Keep** the `&:has(.filterBar)` rule at line ~56 only if it still matches a live class; since `.filterBar` is deleted, update that selector to target the new toolbar wrapper or remove the `:has` branch. Verify no other module references these classes (Step 8 grep covers this).

- [ ] **Step 7 — Delete the saturated chip tokens** from `app/styles/globals.css` (lines ~27–32):

Remove these six lines:
```css
  --color-chip-film-bg: #e8f5e9;
  --color-chip-film-border: #4caf50;
  --color-chip-film-text: #1b5e20;
  --color-chip-digital-bg: #fce4ec;
  --color-chip-digital-border: #e91e63;
  --color-chip-digital-text: #880e4f;
```

- [ ] **Step 8 — Prove nothing dangling remains:**

Run:
```bash
grep -rn "CollectionFilterBar\|LocationFilterBar\|GalleryFilterState\|CollectionFilterState\|INITIAL_GALLERY_FILTER_STATE\|INITIAL_COLLECTION_FILTER_STATE\|selectedCollectionIds\|filterBarChip\|filterBarItem\|color-chip-film\|color-chip-digital" app tests --include='*.tsx' --include='*.ts' --include='*.scss' --include='*.css'; echo "exit: $?"
```
Expected output: no matches; `exit: 1`. (If `&:has(.filterBar)` was kept in Step 6, the only allowed match is that one selector — re-point or remove it so grep is clean.)

- [ ] **Step 9 — Full format / lint / type-check / test pass:**

Run:
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write 'app/components/ContentCollection/CollectionFilterContext.tsx' 'app/components/Content/CollectionContentRenderer.tsx' 'app/components/ContentCollection/CollectionPageClient.tsx' 'app/components/LocationPage/LocationPageClient.tsx' 'app/types/GalleryFilter.ts'
/opt/homebrew/bin/node node_modules/.bin/eslint --fix 'app/components/ContentCollection/CollectionFilterContext.tsx' 'app/components/Content/CollectionContentRenderer.tsx' 'app/components/ContentCollection/CollectionPageClient.tsx' 'app/components/LocationPage/LocationPageClient.tsx' 'app/types/GalleryFilter.ts'
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/Content/ContentComponent.module.scss' 'app/styles/globals.css'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest
```
Expected output: prettier/eslint/stylelint exit 0; `tsc --noEmit` prints nothing (all Task 2 downstream errors cleared); full jest run is green (the deleted `CollectionFilterBar.test.tsx` is gone, the new `FilterChip` / `FilterToolbar` / `GalleryFilter` tests pass, and existing suites — including `CollectionContentRenderer.test.tsx` — stay green).

- [ ] **Step 10 — Commit (Tasks 2 + 3 + 4 as one atomic, type-checking commit):**

Run:
```bash
git add app/components/ui/FilterToolbar tests/components/ui/FilterToolbar.test.tsx \
        tests/types/GalleryFilter.test.ts app/types/GalleryFilter.ts \
        app/components/ContentCollection/CollectionFilterContext.tsx \
        app/components/Content/CollectionContentRenderer.tsx \
        app/components/ContentCollection/CollectionPageClient.tsx \
        app/components/LocationPage/LocationPageClient.tsx \
        app/components/Content/ContentComponent.module.scss \
        app/styles/globals.css
git commit -m "refactor(filters): unify two filter bars + 6 chips into FilterToolbar + FilterChip

Merges GalleryFilterState + CollectionFilterState into one FilterState (drops
dead selectedCollectionIds), unifies the two divergent cycleDateSort orders
into one helper, and lifts toggleArrayFilter into the type module. Adds the
config-driven FilterToolbar (CollectionFilterBar's dropdown + 3-state
availability base, folding in LocationFilterBar's count badges + a neutral
film tri-state). Deletes CollectionFilterBar, LocationFilterBar, the .filterBar*
SCSS, and the saturated chip tokens.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```
Expected output: one commit; the staged `git rm`s from Step 5 are included automatically (already staged). `tsc --noEmit` + full `jest` were green at commit time.

---

## Verification (run after each task; full pass before any PR)

```bash
cd /Users/themancalledzac/Code/edens.zac
# Format -> lint -> type-check -> test (project pipeline, per CLAUDE.md; npm/npx not on PATH)
/opt/homebrew/bin/node node_modules/.bin/prettier --write <touched files>
/opt/homebrew/bin/node node_modules/.bin/eslint --fix <touched .ts/.tsx>
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix '<touched .scss/.css>'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest
```

**Visual (dev server :3001 — user keeps :3000):**
- **Collection page:** open a multi-tag collection → the filter toolbar renders inside the metadata block; the date toggle cycles `off → ↑ → ↓ → off`; a dimension dropdown opens, chips toggle, unavailable chips are greyed/disabled; the density slider retunes rows live; the reset `×` appears only when a filter is active.
- **Location page (`/location/[slug]`):** Date / Highly Rated / Film toggles render with count badges; Film cycles `off → Film → Digital → off` and shows a **neutral** chip (dashed/dotted border), not the old green/pink; Tags + People dropdowns toggle facets; results update.
- **Dark mode:** in an OS-dark-mode browser the toolbar, dropdown panel, and chips are all readable (tokens, not the old `var(--text-primary, #333)` literals).
- **No regressions:** tag chips in the collection metadata block still toggle the filter (they route through the same `toggleArrayFilter`).

---

## Suggested commit sequence

1. `feat(ui): add canonical FilterChip primitive` — Task 1 (independent; green on its own).
2. `refactor(filters): unify two filter bars + 6 chips into FilterToolbar + FilterChip` — Tasks 2 + 3 + 4 as **one atomic commit** (the state-type merge breaks the tree until the call sites migrate, so they ship together).

Each commit passes `tsc --noEmit` + the relevant `jest` run independently. The Task-1 commit is fully self-contained; the second commit is the migration cut-over.

---

## Self-review: spec-coverage checklist

Maps every in-scope spec item (master-plan Task 1.3 + design-review §2/§5/§6a-3) to a task. Gaps flagged explicitly.

| Spec item (source) | Plan task | Status |
|--------------------|-----------|--------|
| Create `FilterChip.tsx` + `.module.scss`; props `{label,count?,active?,tone?,state?,onToggle}`; real `<button>` + `aria-pressed`; unavailable → disabled (master 1.3) | Task 1 | ✅ |
| FilterChip test: renders label+count, active class, disabled when unavailable, onToggle fires (master 1.3) | Task 1 Step 2 (9 tests) | ✅ |
| Create config-driven `FilterToolbar` built on CollectionFilterBar's dropdown + 3-state availability base (master 1.3, review §6a-3) | Task 3 | ✅ |
| Fold in LocationFilterBar's count badges + film toggle; render film as neutral tri-state (drop green/pink) (master 1.3, review §7) | Task 3 (tone classes) + Task 4 Step 7 (delete tokens) | ✅ |
| Include the density Slider (native `input[type=range]`, `aria-label`) (master 1.3) | Task 3 (slider, `aria-label="Row density"`) | ✅ |
| Merge `GalleryFilterState` + `CollectionFilterState` into ONE `FilterState` (optional dimension arrays) (master 1.3) | Task 2 | ✅ |
| REMOVE dead `selectedCollectionIds` (master 1.3) | Task 2 (type) + Task 4 Step 4 (criteria branch) | ✅ |
| Unify the TWO divergent `cycleDateSort` orders into one helper (master 1.3, review §3) | Task 2 (`cycleDateSort`, off→asc→desc→off) | ✅ |
| Replace LocationFilterBar's local `toggleTag`/`togglePerson` with exported `toggleArrayFilter` (master 1.3) | Task 2 (lifted to type module) + Task 4 Step 4 | ✅ |
| DELETE `app/components/LocationFilterBar/` after migration (master 1.3) | Task 4 Step 5 | ✅ |
| Point `CollectionPageClient` + `LocationPageClient` at unified FilterToolbar + FilterState (master 1.3 migration) | Task 4 Steps 3–4 | ✅ |
| Delete the `.filterBar*` and `.chip*` SCSS (master 1.3 migration) | Task 4 Steps 5–6 (`.chip*` via LocationFilterBar.module.scss delete; `.filterBar*` block) | ✅ |
| Two filter bars + 6 chip variants collapsed to one set (review §2, §3 catalog, §6a-3) | Tasks 1–4 | ✅ |
| §5 High — filter state never URL-driven (wire `parse/serializeFilterToParams`) | **Out of scope — master-plan Phase 3** | 📋 deferred (stated in header) |

**Out-of-scope (stated, not hidden):**
- **URL-syncing** the filter state (review §5 "tested filter-URL helpers wired to nothing") is master-plan **Phase 3** ([`001-ia-and-ux.md`](001-ia-and-ux.md)). This plan keeps the existing in-memory `useState` ownership in both page clients and only unifies the state *shape* + UI. The unified `FilterState` is deliberately kept URL-serializable (matches `ContentFilterCriteria` field names) so Phase 3 is a clean follow-on.
- **Sticky/persistent toolbar** (review §7) is a layout/IA decision for Phase 3, not this consolidation.

**Dead-code handling (per writing-plans rule 5):**
- `selectedCollectionIds` (dead field + its never-true `LocationPageClient` criteria branch) — **removed** in Tasks 2 + 4.
- Saturated `--color-chip-film-*` / `--color-chip-digital-*` tokens — **deleted** in Task 4 Step 7 (replaced by neutral tone borders).
- The entire `.filterBar*` SCSS block + `LocationFilterBar.module.scss` `.chip*` rules — **deleted** in Task 4 Steps 5–6.
- The `&:has(.filterBar)` selector in `ContentComponent.module.scss:56` — **flagged** in Task 4 Step 6 to re-point or remove (it references a deleted class).
- `lensOptions`/`void lensOptions` in the Task 4 Step 2 helper is a deliberate no-op kept only to document the lens-types-then-names split decision; **remove it** if the reviewer prefers — it is not load-bearing.

**Placeholder scan:** every code step contains complete, paste-ready code; every run step has an exact command + expected output; exact file paths throughout. No TBD / "implement later" / "similar to above".

**Type consistency:** `FilterState`, `DateSortDirection`, `FilmFilter`, `LensType`, `ArrayFilterKey`, `cycleDateSort`, `toggleArrayFilter`, `INITIAL_FILTER_STATE` are defined once in `app/types/GalleryFilter.ts` (Task 2) and referenced consistently by `FilterToolbar` (Task 3) and all four migrated call sites (Task 4). `FilterChipProps` / `FilterChipTone` / `FilterChipState` (Task 1) and `FilterToolbarProps` / `ToolbarDimension` / `ToolbarCounts` (Task 3) are each introduced once.

---

## Files referenced
- **New:** `app/components/ui/FilterChip/{FilterChip.tsx,FilterChip.module.scss}`, `app/components/ui/FilterToolbar/{FilterToolbar.tsx,FilterToolbar.module.scss}`, `tests/components/ui/{FilterChip,FilterToolbar}.test.tsx`, `tests/types/GalleryFilter.test.ts`
- **Modified:** `app/types/GalleryFilter.ts`, `app/components/ContentCollection/CollectionFilterContext.tsx`, `app/components/Content/CollectionContentRenderer.tsx`, `app/components/ContentCollection/CollectionPageClient.tsx`, `app/components/LocationPage/LocationPageClient.tsx`, `app/components/Content/ContentComponent.module.scss`, `app/styles/globals.css`
- **Deleted:** `app/components/ContentCollection/CollectionFilterBar.tsx`, `app/components/LocationFilterBar/LocationFilterBar.tsx`, `app/components/LocationFilterBar/LocationFilterBar.module.scss`, `tests/components/ContentCollection/CollectionFilterBar.test.tsx`
