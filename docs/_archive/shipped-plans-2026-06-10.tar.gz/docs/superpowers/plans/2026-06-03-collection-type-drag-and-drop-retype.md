# Collection-Type Drag-and-Drop Retype Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** On the admin manage page, let an admin drag a collection row in the `CollectionListSelector` accordion and drop it on a different type's section header to instantly (optimistically) reassign that collection's type, persisted via the existing `PUT /api/admin/collections/{id}`.

**Architecture:** Controlled selector emits `onChangeType(collection, targetType)`; `ManageClient` owns the optimistic `setAllCollections` update + the PUT via a colocated `useCollectionRetype` hook. The optimistic update re-buckets the row through the selector's existing `groupsByType` memo — no refetch/reload. On non-success the move reverts and an error banner shows.

**Tech Stack:** Next.js (App Router, RSC where possible — these are existing `'use client'` files), TypeScript (strict, no `any`), native HTML5 drag-and-drop (no library), Jest + React Testing Library. Tests run with `/opt/homebrew/bin/node node_modules/.bin/jest`.

> **Working-tree note:** `ManageClient.tsx`, `CollectionListSelector.tsx`, `CollectionListSelector.module.scss`, `ManageClient.module.scss`, `globals.css` and a `tagUtils`/`TagsSelector` set already have UNCOMMITTED changes from prior in-progress work. Commit strategy (which hunks land in which commit) is resolved with the user before committing — see the git investigation step. Code content below is independent of that.

---

### Task 1: `ASSIGNABLE_COLLECTION_TYPES` constant

**Files:**
- Modify: `app/types/Collection.ts` (after `COLLECTION_TYPE_ORDER`, ~line 32)
- Test: `tests/components/CollectionListSelector.test.tsx` (add a `describe` next to the existing `COLLECTION_TYPE_ORDER` block)

- [ ] **Step 1: Write the failing test**

```tsx
// add the import to the existing top-of-file import from '@/app/types/Collection'
// import { ASSIGNABLE_COLLECTION_TYPES, COLLECTION_TYPE_ORDER, type CollectionListModel } from '@/app/types/Collection';

describe('ASSIGNABLE_COLLECTION_TYPES', () => {
  it('lists the 5 user-assignable types, excluding HOME and MISC', () => {
    expect(ASSIGNABLE_COLLECTION_TYPES).toEqual([
      'PORTFOLIO',
      'ART_GALLERY',
      'BLOG',
      'CLIENT_GALLERY',
      'PARENT',
    ]);
  });
});
```

- [ ] **Step 2: Run test, verify it fails**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest tests/components/CollectionListSelector.test.tsx -t "ASSIGNABLE_COLLECTION_TYPES"`
Expected: FAIL (`ASSIGNABLE_COLLECTION_TYPES` is not exported).

- [ ] **Step 3: Implement the constant**

```ts
// in app/types/Collection.ts, immediately after the COLLECTION_TYPE_ORDER array:

/**
 * Collection types an admin can assign to a collection — the set the create/update
 * form selects offer and the valid drag-and-drop retype drop targets. Excludes
 * HOME (pinned singleton) and MISC (catch-all for unknown/missing types).
 */
export const ASSIGNABLE_COLLECTION_TYPES: CollectionType[] = [
  CollectionType.PORTFOLIO,
  CollectionType.ART_GALLERY,
  CollectionType.BLOG,
  CollectionType.CLIENT_GALLERY,
  CollectionType.PARENT,
];
```

- [ ] **Step 4: Run test, verify it passes**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest tests/components/CollectionListSelector.test.tsx -t "ASSIGNABLE_COLLECTION_TYPES"`
Expected: PASS.

- [ ] **Step 5: Commit** (per resolved strategy)

---

### Task 2: `useCollectionRetype` hook

**Files:**
- Create: `app/(admin)/collection/manage/[[...slug]]/useCollectionRetype.ts`
- Test: `tests/(admin)/collection/manage/[[...slug]]/useCollectionRetype.test.tsx`

- [ ] **Step 1: Write the failing test**

```tsx
import { act, renderHook } from '@testing-library/react';

import { useCollectionRetype } from '@/app/(admin)/collection/manage/[[...slug]]/useCollectionRetype';
import { updateCollection } from '@/app/lib/api/collections';
import { type CollectionListModel, CollectionType } from '@/app/types/Collection';

jest.mock('@/app/lib/api/collections', () => ({ updateCollection: jest.fn() }));
const mockUpdateCollection = updateCollection as jest.MockedFunction<typeof updateCollection>;

const dragged: CollectionListModel = { id: 7, name: 'Hidden Lake', slug: 'hidden-lake', type: 'BLOG' };

function setup() {
  let collections: CollectionListModel[] = [dragged];
  const setAllCollections = jest.fn((updater: unknown) => {
    collections = typeof updater === 'function' ? updater(collections) : (updater as CollectionListModel[]);
  });
  const setError = jest.fn();
  const { result } = renderHook(() =>
    useCollectionRetype({ setAllCollections: setAllCollections as never, setError })
  );
  return { result, setAllCollections, setError, getCollections: () => collections };
}

describe('useCollectionRetype', () => {
  beforeEach(() => jest.clearAllMocks());

  it('optimistically moves the collection then PUTs the new type', async () => {
    mockUpdateCollection.mockResolvedValue({ collection: { id: 7 } } as never);
    const { result, getCollections } = setup();
    await act(async () => {
      await result.current.handleChangeType(dragged, CollectionType.PORTFOLIO);
    });
    expect(getCollections()).toEqual([{ ...dragged, type: 'PORTFOLIO' }]);
    expect(mockUpdateCollection).toHaveBeenCalledWith(7, { id: 7, type: 'PORTFOLIO' });
  });

  it('reverts and sets an error when the PUT returns null', async () => {
    mockUpdateCollection.mockResolvedValue(null);
    const { result, getCollections, setError } = setup();
    await act(async () => {
      await result.current.handleChangeType(dragged, CollectionType.PORTFOLIO);
    });
    expect(getCollections()).toEqual([dragged]);
    expect(setError).toHaveBeenLastCalledWith('Failed to move "Hidden Lake" to Portfolio');
  });

  it('reverts and sets an error when the PUT throws', async () => {
    mockUpdateCollection.mockRejectedValue(new Error('network'));
    const { result, getCollections, setError } = setup();
    await act(async () => {
      await result.current.handleChangeType(dragged, CollectionType.PORTFOLIO);
    });
    expect(getCollections()).toEqual([dragged]);
    expect(setError).toHaveBeenCalled();
  });

  it('is a no-op (no PUT, no state change) when dropped on its current type', async () => {
    const { result, setAllCollections } = setup();
    await act(async () => {
      await result.current.handleChangeType(dragged, CollectionType.BLOG);
    });
    expect(mockUpdateCollection).not.toHaveBeenCalled();
    expect(setAllCollections).not.toHaveBeenCalled();
  });
});
```

- [ ] **Step 2: Run test, verify it fails**

Run: `/opt/homebrew/bin/node "node_modules/.bin/jest" "tests/(admin)/collection/manage/[[...slug]]/useCollectionRetype.test.tsx"`
Expected: FAIL (module does not exist). If `renderHook` is not exported by this RTL version, fall back to a tiny harness component — verify with `grep renderHook node_modules/@testing-library/react/dist/index.js`.

- [ ] **Step 3: Implement the hook**

```ts
'use client';

import { type Dispatch, type SetStateAction, useCallback } from 'react';

import { updateCollection } from '@/app/lib/api/collections';
import { type CollectionListModel, type CollectionType } from '@/app/types/Collection';
import { handleApiError } from '@/app/utils/apiUtils';
import { humanizeConstantCase } from '@/app/utils/stringUtils';

interface UseCollectionRetypeParams {
  setAllCollections: Dispatch<SetStateAction<CollectionListModel[]>>;
  setError: Dispatch<SetStateAction<string | null>>;
}

/**
 * Drag-and-drop collection retype. Optimistically moves the dragged collection to
 * its new type in `allCollections` (which re-buckets it in the manage-page
 * accordion), then persists via PUT /api/admin/collections/{id}. On any
 * non-success the optimistic move is reverted and an error is surfaced.
 *
 * The PUT response describes the DRAGGED collection (not the manage-page
 * collection being edited), so it is intentionally ignored beyond success/failure
 * — it must never be written into `currentState`.
 */
export function useCollectionRetype({ setAllCollections, setError }: UseCollectionRetypeParams) {
  const handleChangeType = useCallback(
    async (collection: CollectionListModel, targetType: CollectionType) => {
      const previousType = collection.type;
      if (previousType === targetType) return; // no-op: already this type

      const setType = (type: CollectionType | string | undefined) =>
        setAllCollections(prev => prev.map(c => (c.id === collection.id ? { ...c, type } : c)));

      setType(targetType); // optimistic move
      setError(null);

      const failureMessage = `Failed to move "${collection.name}" to ${humanizeConstantCase(targetType)}`;
      try {
        const response = await updateCollection(collection.id, {
          id: collection.id,
          type: targetType,
        });
        if (response === null) {
          setType(previousType);
          setError(failureMessage);
        }
      } catch (error) {
        setType(previousType);
        setError(handleApiError(error, failureMessage));
      }
    },
    [setAllCollections, setError]
  );

  return { handleChangeType };
}
```

- [ ] **Step 4: Run test, verify it passes**

Run: `/opt/homebrew/bin/node "node_modules/.bin/jest" "tests/(admin)/collection/manage/[[...slug]]/useCollectionRetype.test.tsx"`
Expected: PASS (4 tests).

- [ ] **Step 5: Commit** (per resolved strategy)

---

### Task 3: `CollectionListSelector` drag-and-drop

**Files:**
- Modify: `app/components/CollectionListSelector/CollectionListSelector.tsx`
- Test: `tests/components/CollectionListSelector.test.tsx`

- [ ] **Step 1: Write the failing tests** (append to the test file)

```tsx
describe('drag-and-drop retype', () => {
  const rows: CollectionListModel[] = [
    { id: 1, name: 'Home', type: 'HOME' },
    { id: 2, name: 'P1', type: 'PORTFOLIO' },
    { id: 3, name: 'B1', type: 'BLOG', collectionDate: '2025-01-01' },
    { id: 6, name: 'M1', type: 'MISC' },
  ];

  function renderWithRetype(onChangeType = jest.fn(), extra: Record<string, unknown> = {}) {
    render(
      <CollectionListSelector
        allCollections={rows}
        savedCollectionIds={new Set()}
        pendingAddIds={new Set()}
        pendingRemoveIds={new Set()}
        onToggle={jest.fn()}
        siblingSavedIds={new Set()}
        siblingPendingAddIds={new Set()}
        siblingPendingRemoveIds={new Set()}
        onToggleSibling={jest.fn()}
        parentSavedIds={new Set()}
        parentPendingAddIds={new Set()}
        parentPendingRemoveIds={new Set()}
        onToggleParent={jest.fn()}
        onChangeType={onChangeType}
        {...extra}
      />
    );
    return { onChangeType };
  }

  it('fires onChangeType when a row is dropped on a different assignable header', () => {
    const { onChangeType } = renderWithRetype();
    fireEvent.click(screen.getByText('Blog')); // expand BLOG to reach B1
    const row = screen.getByText('B1').closest('[role="group"]')!;
    fireEvent.dragStart(row);
    fireEvent.drop(screen.getByText('Portfolio'));
    expect(onChangeType).toHaveBeenCalledTimes(1);
    expect(onChangeType).toHaveBeenCalledWith(expect.objectContaining({ id: 3, name: 'B1' }), 'PORTFOLIO');
  });

  it('does not fire onChangeType when dropped on the type it already has', () => {
    const { onChangeType } = renderWithRetype();
    fireEvent.click(screen.getByText('Blog'));
    const row = screen.getByText('B1').closest('[role="group"]')!;
    fireEvent.dragStart(row);
    fireEvent.drop(screen.getByText('Blog'));
    expect(onChangeType).not.toHaveBeenCalled();
  });

  it('does not treat MISC headers as drop targets', () => {
    const { onChangeType } = renderWithRetype();
    fireEvent.click(screen.getByText('Blog'));
    const row = screen.getByText('B1').closest('[role="group"]')!;
    fireEvent.dragStart(row);
    fireEvent.drop(screen.getByText('Misc'));
    expect(onChangeType).not.toHaveBeenCalled();
  });

  it('marks assignable rows draggable but never the HOME row', () => {
    renderWithRetype();
    const homeRow = screen.getByText('Home').closest('[role="group"]')!;
    expect(homeRow).not.toHaveAttribute('draggable', 'true');
    fireEvent.click(screen.getByText('Portfolio'));
    const p1Row = screen.getByText('P1').closest('[role="group"]')!;
    expect(p1Row).toHaveAttribute('draggable', 'true');
  });

  it('does not make the current ("you are here") row draggable', () => {
    renderWithRetype(jest.fn(), { currentCollectionId: 2 }); // P1 auto-expands PORTFOLIO
    const p1Row = screen.getByText('P1').closest('[role="group"]')!;
    expect(p1Row).not.toHaveAttribute('draggable', 'true');
  });

  it('does nothing when onChangeType is absent (no drag wiring)', () => {
    // Sanity: the existing 3-column helper renders without onChangeType and rows aren't draggable.
    render(
      <CollectionListSelector
        allCollections={rows}
        savedCollectionIds={new Set()}
        pendingAddIds={new Set()}
        pendingRemoveIds={new Set()}
        onToggle={jest.fn()}
        siblingSavedIds={new Set()}
        siblingPendingAddIds={new Set()}
        siblingPendingRemoveIds={new Set()}
        onToggleSibling={jest.fn()}
        parentSavedIds={new Set()}
        parentPendingAddIds={new Set()}
        parentPendingRemoveIds={new Set()}
        onToggleParent={jest.fn()}
      />
    );
    fireEvent.click(screen.getByText('Portfolio'));
    expect(screen.getByText('P1').closest('[role="group"]')!).not.toHaveAttribute('draggable', 'true');
  });
});
```

- [ ] **Step 2: Run tests, verify they fail**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest tests/components/CollectionListSelector.test.tsx -t "drag-and-drop retype"`
Expected: FAIL (rows not draggable; `onChangeType` not a prop).

- [ ] **Step 3: Implement the selector changes**

3a. Imports — update the react import and the Collection types import:

```ts
import { type DragEvent, type ReactNode, useCallback, useEffect, useMemo, useRef, useState } from 'react';

import { Button } from '@/app/components/ui/Button/Button';
import {
  ASSIGNABLE_COLLECTION_TYPES,
  COLLECTION_TYPE_ORDER,
  type CollectionListModel,
  CollectionType,
} from '@/app/types/Collection';
```

3b. Props — add to `CollectionListSelectorProps` (after `onToggleParent`):

```ts
  /**
   * Drag-and-drop retype. When provided AND the selector is in accordion mode,
   * rows become draggable and the assignable type-headers become drop targets;
   * dropping a row on a different assignable type fires this with the new type.
   */
  onChangeType?: (collection: CollectionListModel, targetType: CollectionType) => void;
```

3c. Destructure `onChangeType` in the component parameter list (after `onToggleParent`).

3d. Drag state + `dragEnabled` — add right after `const accordionMode = siblingMode || parentMode;`:

```ts
  // Drag-and-drop retype state. `draggedRef` is the source of truth for a drop
  // (set on dragstart, read on drop); `draggedId` dims the dragged row;
  // `dragOverType` highlights the assignable header under the pointer.
  const draggedRef = useRef<CollectionListModel | null>(null);
  const [draggedId, setDraggedId] = useState<number | null>(null);
  const [dragOverType, setDragOverType] = useState<CollectionType | null>(null);
  const dragEnabled = accordionMode && !!onChangeType;

  const handleRowDragStart = useCallback(
    (collection: CollectionListModel) => (e: DragEvent<HTMLDivElement>) => {
      draggedRef.current = collection;
      setDraggedId(collection.id);
      if (e.dataTransfer) {
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', String(collection.id));
      }
    },
    []
  );

  const handleRowDragEnd = useCallback(() => {
    draggedRef.current = null;
    setDraggedId(null);
    setDragOverType(null);
  }, []);

  const handleHeaderDragOver = useCallback(
    (type: CollectionType) => (e: DragEvent<HTMLButtonElement>) => {
      if (!draggedRef.current) return;
      e.preventDefault(); // allow drop
      if (e.dataTransfer) e.dataTransfer.dropEffect = 'move';
      setDragOverType(type);
    },
    []
  );

  const handleHeaderDragLeave = useCallback(
    (type: CollectionType) => (e: DragEvent<HTMLButtonElement>) => {
      if (e.currentTarget.contains(e.relatedTarget as Node | null)) return; // child still inside
      setDragOverType(prev => (prev === type ? null : prev));
    },
    []
  );

  const handleHeaderDrop = useCallback(
    (type: CollectionType) => (e: DragEvent<HTMLButtonElement>) => {
      e.preventDefault();
      const dragged = draggedRef.current;
      draggedRef.current = null;
      setDraggedId(null);
      setDragOverType(null);
      if (dragged && dragged.type !== type) onChangeType?.(dragged, type);
    },
    [onChangeType]
  );
```

3e. Draggable rows — in `renderRow`, inside the `if (siblingMode || parentMode) {` block, after `isActivelyParent`/reason locals, add:

```ts
      const isHome = collection.type === CollectionType.HOME;
      const rowDraggable = dragEnabled && !isCurrent && !isHome;
```

Then change the row `<div>` opening tag to:

```tsx
        <div
          key={collection.id}
          className={`${styles.row} ${styles.rowSibling} ${expanded ? styles.expandedRow : ''} ${isCurrent ? styles.currentRow : ''} ${rowDraggable ? styles.draggable : ''} ${draggedId === collection.id ? styles.dragging : ''}`}
          role="group"
          aria-label={collection.name}
          draggable={rowDraggable || undefined}
          onDragStart={rowDraggable ? handleRowDragStart(collection) : undefined}
          onDragEnd={rowDraggable ? handleRowDragEnd : undefined}
        >
```

3f. Header drop targets — in the accordion header `.map(t => {...})` (the `COLLECTION_TYPE_ORDER.filter(t => t !== CollectionType.HOME).map`), add the drop-target locals and wire the header button:

```tsx
        {COLLECTION_TYPE_ORDER.filter(t => t !== CollectionType.HOME).map(t => {
          const rows = groupsByType.get(t) ?? [];
          const isExpanded = expandedType === t;
          const isDropTarget = dragEnabled && ASSIGNABLE_COLLECTION_TYPES.includes(t);
          const isDragOver = isDropTarget && dragOverType === t;
          return (
            <div key={t}>
              <button
                type="button"
                className={`${styles.typeHeaderRow} ${isExpanded ? styles['typeHeaderRow--expanded'] : ''} ${isDragOver ? styles['typeHeaderRow--dropTarget'] : ''}`}
                onClick={() => setExpandedType(isExpanded ? null : t)}
                aria-expanded={isExpanded}
                onDragOver={isDropTarget ? handleHeaderDragOver(t) : undefined}
                onDragEnter={isDropTarget ? handleHeaderDragOver(t) : undefined}
                onDragLeave={isDropTarget ? handleHeaderDragLeave(t) : undefined}
                onDrop={isDropTarget ? handleHeaderDrop(t) : undefined}
              >
                <span className={styles.typeHeaderChevron}>{isExpanded ? '▾' : '▸'}</span>
                <span className={styles.typeHeaderLabel}>{humanizeConstantCase(t)}</span>
                <span className={styles.typeHeaderCount}>({rows.length})</span>
              </button>
              {isExpanded && rows.map(c => renderRow(c, true))}
            </div>
          );
        })}
```

- [ ] **Step 4: Run tests, verify they pass**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest tests/components/CollectionListSelector.test.tsx`
Expected: PASS (existing suite + the new `drag-and-drop retype` block).

- [ ] **Step 5: Commit** (per resolved strategy — paired with Task 4 SCSS)

---

### Task 4: SCSS drag/drop affordances

**Files:**
- Modify: `app/components/CollectionListSelector/CollectionListSelector.module.scss` (append at end)

- [ ] **Step 1: Add styles**

```scss
// Drag-and-drop retype affordances (accordion mode). Draggable rows show a grab
// cursor; the row being dragged dims; the assignable type-header under the
// pointer highlights as a drop target.
.draggable {
  cursor: grab;

  &:active {
    cursor: grabbing;
  }
}

.dragging {
  opacity: 0.4;
}

.typeHeaderRow--dropTarget {
  background: var(--sel-elev-hover);
  outline: 2px dashed var(--sel-accent-child);
  outline-offset: -2px;
}
```

- [ ] **Step 2: Stylelint**

Run: `/opt/homebrew/bin/node node_modules/.bin/stylelint --fix app/components/CollectionListSelector/CollectionListSelector.module.scss`
Expected: no errors.

- [ ] **Step 3: Commit** (with Task 3)

---

### Task 5: Wire `useCollectionRetype` into `ManageClient`

**Files:**
- Modify: `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx`

- [ ] **Step 1: Add the import** (in the local `./` import block, alphabetical — before `useContentReordering`)

```ts
import { useCollectionRetype } from './useCollectionRetype';
```

- [ ] **Step 2: Call the hook** — after the `getMetadata()` effect that sets `allCollections` (~line 155):

```ts
  const { handleChangeType } = useCollectionRetype({ setAllCollections, setError });
```

- [ ] **Step 3: Pass the prop** — add to the `<CollectionListSelector …>` usage (after `onToggleParent={handleParentToggle}`):

```tsx
                          onChangeType={handleChangeType}
```

- [ ] **Step 4: Type-check**

Run: `/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit`
Expected: no errors.

- [ ] **Step 5: Commit** (per resolved strategy)

---

### Task 6: Full verification

- [ ] **Step 1: Prettier** the changed files

Run: `/opt/homebrew/bin/node node_modules/.bin/prettier --write app/types/Collection.ts app/components/CollectionListSelector/CollectionListSelector.tsx app/components/CollectionListSelector/CollectionListSelector.module.scss "app/(admin)/collection/manage/[[...slug]]/useCollectionRetype.ts" "app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx" tests/components/CollectionListSelector.test.tsx "tests/(admin)/collection/manage/[[...slug]]/useCollectionRetype.test.tsx"`

- [ ] **Step 2: ESLint --fix** the same TS/TSX files (not the scss).

- [ ] **Step 3: Stylelint --fix** the scss.

- [ ] **Step 4: tsc --noEmit** — expect clean.

- [ ] **Step 5: Full jest** — `/opt/homebrew/bin/node node_modules/.bin/jest` — expect green.

- [ ] **Step 6: Browser verify** (preview on port 3001): manage page → drag a collection row onto another type header → row moves, network shows `PUT /api/admin/collections/{id}` with `{ type }`; success leaves it moved; forced failure reverts + banner.

- [ ] **Step 7: Final commit** (per resolved strategy).

---

## Spec coverage checklist

| Spec requirement | Task |
| --- | --- |
| Drag row → drop on different type header retypes | Task 3 (selector) + Task 5 (wire) |
| Instant optimistic move, revert on non-success | Task 2 (hook) |
| 5 assignable types only as drop targets | Task 1 (constant) + Task 3 (`isDropTarget`) |
| Current row inert (not draggable) | Task 3 (`rowDraggable` excludes `isCurrent`) |
| HOME rows not draggable; MISC not a target | Task 3 (`isHome`, `ASSIGNABLE_COLLECTION_TYPES`) |
| Header-only drop zones | Task 3 (handlers only on headers) |
| PUT response not written to `currentState` | Task 2 (response ignored beyond success) |
| Drag/drop visual affordances | Task 4 (SCSS) |
| Tests for hook + selector | Tasks 2, 3 |

**Not in spec, intentionally excluded:** touch/mobile drag, keyboard retype for non-current rows, DRYing the form `<select>`s, re-bucket animation. (All listed "Out of scope" in the spec.)
