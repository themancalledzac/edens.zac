# 006 · Camera Optimistic-Create Race + Silent Failure

_Chapter [006 · Code Health](../../006-code-health.md) · plan · branch `0161-camera-create-race`_

> ✅ **SHIPPED — [PR #162](https://github.com/themancalledzac/edens.zac/pull/162) (merged 2026-06-03, fix `f5c3a64`).** Implemented **Option B (guard-the-swap + surface-the-failure)**, frontend-only — the eager `createCamera` call was kept (it correctly persists the `isFilm`/`defaultFilmFormat` fields the name-only save-time diff drops). `useImageMetadataState` gained a guarded `replaceOptimisticCamera(optimisticName, replacement)` (no-op unless `prev.camera?.id===0 && name matches`), used for both the success id-swap and the failure revert; `CameraSettingsSection.onAddNew` snapshots `previousCamera`, optimistic-sets, swaps on resolve (or returns on 204), and on `.catch` reverts + shows an inline `role="alert"` error. The deferred-create *unification* (Option A) was **not** taken — it needs a cross-repo backend change. The plan below is preserved as the design record.

> **For agentic workers:** REQUIRED SUB-SKILL: `superpowers:test-driven-development`. Small MR (~2–3 files, 1 commit). Surfaced by the 0159 full-MR critical review (2026-06-02). **Pre-existing bug — NOT introduced by 0159;** the logic lived verbatim in the pre-decomposition monolith (`ImageMetadataModal.tsx` at `b7ed03a`) and was only *relocated* into `CameraSettingsSection.tsx` by the extraction. It was intentionally kept out of 0159 scope to preserve per-MR discipline.

**Goal:** Remove the optimistic camera-create race and its silent failure in `app/components/ImageMetadata/sections/CameraSettingsSection.tsx` (`onAddNew`, ~lines 124–160), preferably by unifying the camera "add new" path onto the **deferred-create** pattern the lens / film-stock / location pickers already use.

---

## The problem

When the user adds a brand-new camera via the Camera dropdown's "add new" form, `onAddNew`:

1. Builds an `optimisticCamera` with `id: 0` and writes it into `updateState` immediately (via `computeCameraSelectionUpdate`).
2. Fires `createCamera(...)` fire-and-forget (`void createCamera(...)`).
3. On resolve, **unconditionally** swaps the camera with the server-assigned id via `updateStateField({ camera: { id: created.id, ... } })`.
4. On reject, only `console.error`s.

Two latent defects:

### Defect 1 — Stale-write race (correctness)
Between step 1 and step 3, the create promise is in flight. If the user changes the camera selection (picks a different camera, clears it, or toggles film) in that window, the step-3 `.then` **overwrites their newer choice** with the just-created camera. `updateStateField` does a blind `{ ...prev, ...updates }` set with no check that `updateState.camera` is still the optimistic placeholder. Low probability (the create RTT is short), but it is a real lost-update.

### Defect 2 — Silent failure (project anti-pattern)
The `.catch` only logs to console. On failure the user keeps a phantom `{ id: 0 }` camera that *looks* selected but was never persisted as a standalone entity, with zero UI feedback. (It may self-heal on save — `buildCameraDiff` emits `{ newValue: name }` for an `id: 0` camera, so the image-update endpoint re-creates it — but that is incidental, not designed, and masks the failure entirely.)

### The smell that points at the fix
Camera is the **only** "add new" picker that eagerly persists. Lens (`CameraSettingsSection.tsx` ~177–179), film stock (~280–287), and location (`EssentialInfoSection.tsx` ~116–121) all just set `{ id: 0, name }` locally and let the **save-time `newValue` path** create the entity server-side. The eager `createCamera` call is what *creates* the race surface in the first place.

---

## Recommended fix — unify camera onto the deferred-create pattern

Make camera behave like lens/film/location: set the optimistic `{ id: 0 }` camera locally and stop calling `createCamera` in `onAddNew`. Let `buildCameraDiff`'s existing `newValue` path persist it at save time (it already handles `id <= 0`).

This **deletes both defects at once** — there is no in-flight promise to race, and no fire-and-forget call to fail silently.

**Files:**
- Modify `app/components/ImageMetadata/sections/CameraSettingsSection.tsx` — strip the `void createCamera(...).then(...).catch(...)` block from the Camera `onAddNew`; keep only the `computeCameraSelectionUpdate(optimisticCamera, updateState)` local write. Remove the now-unused `createCamera` import.
- Verify the backend `newValue` camera-create path on image update carries `isFilm` + `defaultFilmFormat` (the eager path passed these; confirm the update DTO does too — see `buildCameraDiff` in `imageMetadataUtils.ts:428` and the `ContentImageUpdateRequest.camera` shape). **If the update endpoint cannot create a film camera with its format, this unification is blocked** and we fall back to the "minimal fix" below.

**Tests:** add `CameraSettingsSection.test.tsx` cases — adding a new camera writes an `{ id: 0 }` camera into state and does NOT call `createCamera`; adding a film camera auto-toggles `isFilm` and seeds `filmFormat`.

**LoC:** ~−30. **Risk:** LOW-MEDIUM (depends on the backend `newValue`-create capability check above).

---

## Fallback — minimal fix (if eager create must stay)

If a standalone camera id is genuinely required before save (e.g. the backend can't create a film camera via the image-update `newValue` path), keep `createCamera` but make it safe:

1. **Guard the swap:** only apply the real-id swap if the current selection is still the optimistic one. Requires `updateStateField` to accept an updater function, or a dedicated `swapOptimisticCamera(name, realId)` handler that reads `prev` inside `setUpdateState`:
   ```ts
   // only swap if the user hasn't changed the camera since
   setUpdateState(prev =>
     prev.camera?.id === 0 && prev.camera.name === optimisticName
       ? { ...prev, camera: { id: createdId, name, isFilm, defaultFilmFormat } }
       : prev
   );
   ```
2. **Surface the failure:** on `.catch`, set a user-visible error (or revert the optimistic camera) instead of only `console.error`.

**Risk:** LOW, but leaves two code paths for "add new" where one would do.

---

## Out of scope
- The broader "drop the `Image` prefix" rename (own MR, chapter 006).
- Any change to `computeCameraSelectionUpdate` semantics (the film auto-toggle is correct and unit-tested).
