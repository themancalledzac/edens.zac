# 001 · Design System Unification
_Chapter [001 · Design System Unification](../../001-design-review.md) · plan_

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Collapse the site's many divergent UI standards (≈30–38 button classes, 5 modal shells, 2 filter bars, 6 chip variants, 3 badge definitions, 3 color-token families) into one unified set of canonical "Main Design Elements" on one painted, dark‑safe page surface — fixing the foundation contrast bug along the way.

**Architecture:** New `app/components/ui/` houses token‑driven primitives (Button, IconButton, CloseButton, Modal, FilterChip/FilterToolbar, Dropdown, NavLink/Tile, Badge, Field set, StatusPage). Each primitive ships test‑first, then existing call sites migrate onto it and the per‑feature CSS is deleted. A non‑breaking token‑alias layer is declared first so nothing regresses; the color layer is collapsed last. Server‑Component‑friendly where possible (no needless `'use client'`).

**Tech Stack:** Next.js 16 App Router, React 19, TypeScript (strict, no `any`), SCSS Modules with CSS custom properties (bare `var(--token)`, no `@use` partial), Jest + React Testing Library (tests mirror `app/` under `tests/`).

> **Spec:** This plan is the implementation of [`../../001-design-review.md`](../../001-design-review.md) (the full design review — the spec). Section references like *(review §6a)* point there.
> **Predecessors / related plans:** [`006-cleanup-and-refactor.md`](006-cleanup-and-refactor.md) (introduced the `StatusBanner` / `useApiSubmit` reuse instinct this plan generalizes), the v3-promotion layout-cleanup work (layout unification — the same "many→one" pattern at the algorithm layer).
> **Status:** ✅ **All phases shipped & merged to `main` (PRs [#152](https://github.com/themancalledzac/edens.zac/pull/152) → [#160](https://github.com/themancalledzac/edens.zac/pull/160), 2026-06-03).** Phase 0 foundation (#152) → buttons (#153) → modal/filter/dropdown (#154/#155) → nav & shell (#156) → admin-route gating (#157) → IA & UX (#158) → token collapse & a11y (#159) → ImageMetadataModal decomposition (#160). Two carve-outs were intentionally deferred and now live in [006 · Code Health](../../006-code-health.md): the `@custom-media` breakpoint bridge (Phase 4 Task 5 — postcss/Next 16 conflict) and the gap-rule + `rgb()` syntax sweeps (Phase 4 Tasks 6d/6e). See the **Shipped panel** in each sub-plan for landed-commit detail. **The design-system unification is complete.**

---

## How to use this plan (Scope Check)

The review spans several **independent subsystems**. Per the writing‑plans Scope Check, this is a **master plan**, decomposed by phase:

- **Phase 0 (Foundation)** and **Phase 1 · Task 1.1 (Button)** are written to full bite‑sized TDD detail with complete, correct code — **execute these directly.**
- **Phase 1 · Tasks 1.2–1.4** (Modal, FilterChip, Dropdown) are specified to interface + canonical‑test + migration‑target level. Each is large enough to be **promoted to its own dated sub‑plan** via `superpowers:writing-plans`, using Task 1.1 as the bite‑sized template.
- **Phases 2–4** are scoped task definitions (files, interfaces, acceptance criteria, exact call‑site lists). Each **becomes its own sub‑plan** before execution.

This is decomposition, not deferral — every item has concrete files and acceptance criteria. The phases are largely independent (a primitive doesn't depend on another primitive; IA doesn't depend on the token collapse), so they **parallelize well across agents / Agent Teams** — see *Execution Handoff*.

### Sub-plans (generated — each is a complete bite-sized TDD doc)

The 📋 items below are realized as standalone executable plans:

| Phase / item | Sub-plan file | Tasks | Status |
|--------------|---------------|-------|--------|
| 0 Foundation (canvas paint, alias layer, dead-nav) | (this file, Task 0) | — | ✅ shipped (PR #152, `0145`) |
| 1.1 Button + IconButton + CloseButton | (this file, Task 1.1) | 8 | ✅ shipped (PR #153, `0146`) |
| 1.2 Modal | [`001-modal-primitive.md`](001-modal-primitive.md) | 6 | ✅ shipped (PR #154/#155, `0147`/`0148`) |
| 1.3 FilterChip + FilterToolbar | [`001-filter-toolbar-and-chip.md`](001-filter-toolbar-and-chip.md) | 4 | ✅ shipped (PR #154, `0147`) |
| 1.4 Dropdown | [`001-dropdown-primitive.md`](001-dropdown-primitive.md) | 7 | ✅ shipped (PR #154, `0147`) |
| 2 Nav + Shell (Tile, PageShell, StatusPage, Badge, Field, MetadataList) | [`001-nav-and-shell.md`](001-nav-and-shell.md) | 6 | ✅ shipped (PR #156, `0149`) + admin gating (PR #157, `0150`) |
| 3 IA + UX | [`001-ia-and-ux.md`](001-ia-and-ux.md) | 6 | ✅ shipped (PR #158, `0151`) |
| 4 Token collapse + a11y | [`001-token-collapse-and-a11y.md`](001-token-collapse-and-a11y.md) | 6 | ✅ shipped (PR #159, `0152`); Task 5 (`@custom-media`) + 6d/6e (gap-rule/`rgb()`) deferred → [006](../../006-code-health.md) |
| **5 ImageMetadataModal decomposition (final consumer migration)** | [`001-image-metadata-modal-decomposition.md`](001-image-metadata-modal-decomposition.md) | 9 | ✅ shipped (PR #160, `0159`) — 1099 → 203 LoC; closed the unification by migrating the last big consumer + deleting the 4 raw button classes |

**Dependency order:** Phase 0 → Button (Task 1.1) → {Modal, FilterChip, Dropdown} in parallel → Nav+Shell → IA+UX → Token-collapse+a11y (last; it deletes the Task 0.1 alias block). Within a phase, tasks are mostly parallel.

**Corrections the sub-plan authors found in the live source** (refining the review): `/metadata` is **fully public** today (not in the `proxy.ts` matcher) — Nav+Shell Task 6 moves it under `(admin)` *and* adds the matcher. Taxonomy/person pages **already render an `h1`** name — the review's "shows only N photos" was stale, so IA Task 6 is scoped as regression-hardening, not a re-fix. `UnifiedMetadataSelector` is a **default export** with `simpleChips` used by **zero** call sites (clean to generalize).

---

## File-structure map

**New (created by this plan):**

```
app/components/ui/
  Button/        Button.tsx          Button.module.scss
  IconButton/    IconButton.tsx      IconButton.module.scss
  CloseButton/   CloseButton.tsx     (composes IconButton; no own SCSS)
  Modal/         Modal.tsx           Modal.module.scss        (Phase 1.2 → sub-plan)
  FilterChip/    FilterChip.tsx      FilterChip.module.scss   (Phase 1.3 → sub-plan)
  FilterToolbar/ FilterToolbar.tsx   FilterToolbar.module.scss(Phase 1.3 → sub-plan)
  Dropdown/      Dropdown.tsx        Dropdown.module.scss     (Phase 1.4: promoted from UnifiedMetadataSelector)
  Badge/         (Phase 2: promote BadgeOverlay)
  Field/         (Phase 2: Input/Select/Textarea/Checkbox/FormError)
  NavLink/  Tile/  PageShell/  CollectionHeader/  StatusPage/  (Phase 2 → sub-plan)

tests/components/ui/   (mirrors the above: Button.test.tsx, Modal.test.tsx, …)
```

**Modified (foundation, Phase 0):** `app/styles/globals.css` (token alias layer + paint the canvas), `app/components/SiteHeader/SiteHeader.module.scss` (token + scrim), `app/components/FullScreenModal/FullScreenModal.tsx` (remove `FsDebug`), delete `app/components/FullScreenModal/FsDebug.tsx`, `app/components/MenuDropdown/MenuDropdown.tsx` (kill 404 Blogs link + duplicate "Create"), `app/(admin)/admin/adminTiles.ts` (Blogs href), `app/components/About/About.tsx` + `app/components/ContactForm/ContactForm.tsx` (drop dead `onBack`).

---

## Phase 0 — Foundation (execute first; smallest diff, highest leverage)

Fixes the critical dark‑mode invisibility (review §1.1, §5), kills the shippable debug tool, and removes the 404 nav link. No new dependencies.

### Task 0.1 — Paint the canvas + declare the token‑alias layer

**Why:** `globals.css` defines `--color-bg`/`--color-fg` + `color-scheme:light` but never binds them to `html`/`body` (verified live: `html`/`body` background = `rgba(0,0,0,0)`, text = black). Under OS dark mode the 404 page, `/metadata`, the SiteHeader title, and admin headings render invisible. Separately, ~15 tokens are referenced but undeclared and silently fall back to hex (review §1.3) — the admin UI is un‑themeable. Declaring them as aliases is non‑breaking and makes the token layer real.

**Files:**
- Modify: `app/styles/globals.css` (`:root` block + the `body` rule at ~lines 159–167)
- Modify: `app/components/SiteHeader/SiteHeader.module.scss:49,92`

- [ ] **Step 1 — Add the alias + new tokens inside `:root`** (append just before the closing `}` of the `:root`/`html` block in `globals.css`, after the existing `--color-border-dark` line):

```css
  /* ── Compatibility aliases: map the previously-undeclared "shadow namespace"
     onto real tokens so silent hex fallbacks stop winning. Non-breaking.
     These are the migration seam; Phase 4 renames usages onto the semantic
     roles and then deletes this block. ── */
  --text-primary: var(--color-text-primary);     /* was silently #333 */
  --text-secondary: var(--color-text-secondary); /* was silently #666 */
  --text-muted: var(--color-text-muted);         /* was silently #999 */
  --text-base: var(--text-md);                    /* font-size, ManageClient */
  --border-color: var(--color-border);            /* was silently #ddd */
  --color-bg-subtle: var(--color-bg-light);
  --color-bg-muted: var(--color-bg-medium);
  --surface-secondary: var(--color-bg-light);
  --color-accent: var(--color-blue);              /* selection/link accent */
  --radius-sm: var(--radius-1);
  --color-warning: #f4b400;                        /* RatingStars; net-new token */
  --color-overlay-light-80: rgb(255, 255, 255, 0.8); /* gap in the 05..90 ramp */
```

- [ ] **Step 2 — Paint the canvas.** Modify the `body` rule (currently `padding/margin/font-family/overflow-x`) to add background + color:

```css
body {
  padding: 0;
  margin: 0;
  font-family: var(--font-sans), serif;
  background-color: var(--color-bg);
  color: var(--color-fg);

  /* No body perspective/transform-style: it makes <body> the containing block for
     position:fixed overlays and breaks the fullscreen modal on iOS. Parallax is JS-driven. */
  overflow-x: clip;
}
```

- [ ] **Step 3 — Make the header title token‑driven + legible over imagery.** In `SiteHeader.module.scss`, replace the two `color: black;` declarations (the `.title span` ~line 49 and `.menu` ~line 92) with:

```scss
  color: var(--color-fg);
  text-shadow: 0 1px 3px var(--color-overlay-strong); /* scrim for legibility over photos */
```

- [ ] **Step 4 — Verify (browser, not jest — CSS foundation isn't unit-testable).** Start the preview server and assert the computed canvas + visibility:

Run:
```bash
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/styles/globals.css' 'app/components/SiteHeader/SiteHeader.module.scss'
```
Then with the dev server on :3001, in DevTools console:
```js
getComputedStyle(document.body).backgroundColor   // expect rgb(255, 255, 255), NOT rgba(0,0,0,0)
getComputedStyle(document.body).color             // expect rgb(17, 17, 17)
```
Expected: visit `/this-route-does-not-exist` in an OS‑dark‑mode browser → the "404 — Not Found" text is **readable** (was invisible). Visit `/metadata` → tag/person names readable.

- [ ] **Step 5 — Commit:**
```bash
git add app/styles/globals.css app/components/SiteHeader/SiteHeader.module.scss
git commit -m "fix(foundation): paint page surface from tokens + declare alias layer

Binds --color-bg/--color-fg to html,body so OS dark mode no longer renders
black-on-black (404, /metadata, header title, admin headings). Declares the
~15 previously-undeclared tokens as non-breaking aliases onto real tokens.

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

### Task 0.2 — Delete the shippable `FsDebug` diagnostic (dead code)

**Why:** `FsDebug.tsx` is self‑documented as TEMPORARY but is still imported and renders behind `?fsdebug=1` in production — it injects global `!important` outlines + a magenta bar (review §5, viewer‑primitives). The bug it diagnosed (landscape white strip, branch 0142) is fixed.

**Files:**
- Delete: `app/components/FullScreenModal/FsDebug.tsx`
- Modify: `app/components/FullScreenModal/FullScreenModal.tsx` (remove import ~line 13, the `?fsdebug=1` read ~lines 87–89, and the `<FsDebug … />` render ~line 292)

- [ ] **Step 1 — Run the existing fullscreen tests to capture the green baseline:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/FullScreenModal 2>/dev/null || /opt/homebrew/bin/node node_modules/.bin/jest -t FullScreen
```
Expected: PASS (record the count).

- [ ] **Step 2 — Delete the file and remove its three usages** in `FullScreenModal.tsx`: the `import FsDebug …` line, the `const fsDebug = … window.location.search …` block, and the `{… && <FsDebug … />}` render. Also remove the now‑unused `window.location.search` read if nothing else uses it.

- [ ] **Step 3 — Verify nothing references it:**
```bash
grep -rn "FsDebug\|fsdebug" app/ ; echo "exit: $?"
```
Expected: no matches (grep exit 1).

- [ ] **Step 4 — Type-check + tests:**
```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest -t FullScreen
```
Expected: tsc clean; same tests PASS.

- [ ] **Step 5 — Commit:**
```bash
git add -A app/components/FullScreenModal/
git commit -m "chore(fullscreen): remove temporary FsDebug diagnostic (?fsdebug=1)

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

### Task 0.3 — Fix the dead "Blogs" nav link + duplicate "Create" + dead `onBack`

**Why:** The only public nav links "Blogs" → `/all-blogs`, which 404s (review §5, ux‑flows). The local menu renders "Create" twice (two handlers → same `/collection/manage` route). `About`/`ContactForm` carry an unused `onBack` prop.

**Files:**
- Modify: `app/components/MenuDropdown/MenuDropdown.tsx` (Blogs item ~80–83; duplicate Create ~213–224 vs ~250–260)
- Modify: `app/(admin)/admin/adminTiles.ts:19` (Blogs href)
- Modify: `app/components/About/About.tsx:16`, `app/components/ContactForm/ContactForm.tsx:16` (remove `onBack`), and the two call sites in `MenuDropdown.tsx` that pass it

- [ ] **Step 1 — Decide Blogs:** the route does not exist. Until a `/all-blogs` listing ships (tracked in Phase 3 IA), **remove** the Blogs menu item and the `adminTiles.ts` Blogs tile. (Do NOT leave a 404 in the only public nav.)

- [ ] **Step 2 — Remove the duplicate "Create":** delete the second handler/item (`handleNavigation.manage` + its `<…>Create</…>` block); keep the single `handleNavigation.create` entry.

- [ ] **Step 3 — Drop the dead `onBack`:** remove the `onBack`/`_onBack` param from `About.tsx` and `ContactForm.tsx` interfaces and stop passing `handleBackToMenu` to them in `MenuDropdown.tsx`. (Back into the menu is handled by the dropdown's own close; the prop was never wired.)

- [ ] **Step 4 — Verify:**
```bash
grep -rn "all-blogs" app/ ; echo "exit: $?"        # expect no matches
grep -rn "onBack" app/components/About app/components/ContactForm ; echo "exit: $?"  # expect no matches
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ContactForm.test.tsx
```
Expected: no `all-blogs`/`onBack` matches; tsc clean; ContactForm tests PASS.

- [ ] **Step 5 — Commit:**
```bash
git add app/components/MenuDropdown/MenuDropdown.tsx app/\(admin\)/admin/adminTiles.ts app/components/About/About.tsx app/components/ContactForm/ContactForm.tsx
git commit -m "fix(nav): remove dead /all-blogs link, duplicate Create item, dead onBack prop

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

### Task 0.4 (optional hardening) — Freeze the shadow namespace

**Why:** prevent undeclared `var()` references from regrowing after Task 0.1.

- [ ] **Step 1 — Add the csstools plugin** (real package): `npm i -D stylelint-value-no-unknown-custom-properties`. **Step 2 —** in `.stylelintrc` add to `plugins` and enable `"csstools/value-no-unknown-custom-properties": [true, { "importFrom": ["app/styles/globals.css"] }]`. **Step 3 —** run `stylelint '**/*.scss'`; every reported undeclared token must be declared in `globals.css` (Task 0.1 covers the known set) or renamed. If the team prefers no new dev‑dep, Task 0.1's alias block already removes the runtime symptom — this task only guards regressions.

---

## Phase 1 — Core primitives (highest consolidation leverage)

### Task 1.1 — `<Button>` (+ `<IconButton>` + `<CloseButton>`)  ← the bite-sized template

**Why:** ~30–38 ad‑hoc `*Button` classes + 4 divergent close buttons across ImageMetadataModal, TextBlockCreateModal, Comments, ClientGalleryGate/Download, CollectionListSelector, ErrorBoundary, SiteHeader, MenuDropdown, ManageClient (review §3 catalog, §6a‑rank‑2). One component with `variant`/`size` props replaces them all.

> **Button primitive (supersedes the old "shared button module" idea).** An earlier todo (019, now absorbed here) proposed a pure-SCSS fix: an `app/styles/_buttons.scss` mixin partial + variant classes that the per-feature modules would `@use`/`composes`. **That approach is superseded by this React `<Button>`/`<IconButton>`/`<CloseButton>` primitive** — a component owns the variant/size/loading logic *and* the markup, so call sites delete their bespoke `*Button` JSX, not just their CSS. The 019 inventory still scopes the migration: **~26–38 button classes across 8 SCSS modules** — `ImageMetadataModal.module.scss` (11, the worst — 3 sizing tiers), `TextBlockCreateModal.module.scss` (4), `ManageClient.module.scss` (3, already token-based), `ReorderOverlay.module.scss` (2 icon-circles), and one each in `fullscreen-image.module.scss` (circle close, byte-identical to ImageMetadata's), `CollectionListSelector.module.scss`, `ContactForm.module.scss` (outlier 60px), `MenuDropdown.module.scss` (icon-ghost). 019's variant taxonomy maps cleanly onto this primitive's props: `primary` (save/confirm), `secondary`/`ghost` (cancel), `danger` (delete/clear), `accent`/`action` (the blue/`--color-secondary` submit buttons), `icon-circle`→`<IconButton round overlay>`, `icon-ghost`→`<IconButton square ghost>`. 019 also flagged that the **modal context uses raw `rgba()` literals** (hardcoded blue-500 / red-600) instead of tokens — that rgba→token cleanup is **owned by [`001-token-collapse-and-a11y.md`](001-token-collapse-and-a11y.md)** (the `--color-accent`/`--color-danger` collapse), not this task; here, the new `Button.module.scss` is token-only from the start so migrated call sites stop emitting raw rgba.

**Files:**
- Create: `app/components/ui/Button/Button.tsx`
- Create: `app/components/ui/Button/Button.module.scss`
- Test: `tests/components/ui/Button.test.tsx`

- [ ] **Step 1 — Write the failing test** `tests/components/ui/Button.test.tsx`:

```tsx
import { fireEvent, render, screen } from '@testing-library/react';

import { Button } from '@/app/components/ui/Button/Button';

describe('Button', () => {
  it('renders children and defaults to type="button"', () => {
    render(<Button>Save</Button>);
    const btn = screen.getByRole('button', { name: 'Save' });
    expect(btn).toBeInTheDocument();
    expect(btn).toHaveAttribute('type', 'button');
  });

  it('applies variant and size classes', () => {
    render(
      <Button variant="danger" size="sm">
        Delete
      </Button>
    );
    const btn = screen.getByRole('button', { name: 'Delete' });
    expect(btn.className).toMatch(/danger/);
    expect(btn.className).toMatch(/sm/);
  });

  it('is disabled and aria-busy while loading', () => {
    render(<Button loading>Saving</Button>);
    const btn = screen.getByRole('button', { name: /saving/i });
    expect(btn).toBeDisabled();
    expect(btn).toHaveAttribute('aria-busy', 'true');
  });

  it('forwards onClick', () => {
    const onClick = jest.fn();
    render(<Button onClick={onClick}>Go</Button>);
    fireEvent.click(screen.getByRole('button', { name: 'Go' }));
    expect(onClick).toHaveBeenCalledTimes(1);
  });
});
```

- [ ] **Step 2 — Run it; verify it fails:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/Button.test.tsx
```
Expected: FAIL — `Cannot find module '@/app/components/ui/Button/Button'`.

- [ ] **Step 3 — Implement `app/components/ui/Button/Button.tsx`** (Server‑Component‑friendly — no hooks, so no `'use client'`):

```tsx
import { type ButtonHTMLAttributes, type ReactNode } from 'react';

import { LoadingSpinner } from '@/app/components/LoadingSpinner/LoadingSpinner';

import styles from './Button.module.scss';

export type ButtonVariant = 'primary' | 'secondary' | 'danger' | 'ghost';
export type ButtonSize = 'sm' | 'md';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  leftIcon?: ReactNode;
}

/**
 * Canonical action button. Replaces the ~30 per-feature *Button classes.
 * Variant drives color; size drives padding/height; loading shows a spinner
 * and disables the control. Forwards all native button attributes.
 */
export function Button({
  variant = 'primary',
  size = 'md',
  loading = false,
  leftIcon,
  type = 'button',
  disabled,
  className,
  children,
  ...rest
}: ButtonProps) {
  const spinnerColor = variant === 'primary' || variant === 'danger' ? 'white' : 'dark';
  const classes = [styles.button, styles[variant], styles[size], className]
    .filter(Boolean)
    .join(' ');

  return (
    <button
      type={type}
      className={classes}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      {...rest}
    >
      {loading ? <LoadingSpinner size="small" color={spinnerColor} /> : leftIcon}
      <span className={styles.label}>{children}</span>
    </button>
  );
}
```

- [ ] **Step 4 — Implement `app/components/ui/Button/Button.module.scss`** (tokens only; no literals):

```scss
.button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
  border: 1px solid transparent;
  border-radius: var(--radius-1);
  font: inherit;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.2s ease, color 0.2s ease, border-color 0.2s ease;

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  &:focus-visible {
    outline: 2px solid var(--color-accent);
    outline-offset: 2px;
  }
}

/* sizes */
.sm {
  padding: var(--space-1) var(--space-3);
  font-size: var(--text-sm);
}
.md {
  padding: var(--space-2) var(--space-5);
  font-size: var(--text-md);
}

/* variants */
.primary {
  background-color: var(--color-fg);
  color: var(--color-bg);

  &:hover:not(:disabled) {
    background-color: var(--color-primary-dark);
  }
}
.secondary {
  background-color: var(--color-bg);
  color: var(--color-fg);
  border-color: var(--color-border);

  &:hover:not(:disabled) {
    background-color: var(--color-bg-light);
  }
}
.danger {
  background-color: var(--color-danger);
  color: var(--color-white);

  &:hover:not(:disabled) {
    filter: brightness(0.92);
  }
}
.ghost {
  background-color: transparent;
  color: var(--color-fg);

  &:hover:not(:disabled) {
    background-color: var(--color-overlay-soft);
  }
}

.label {
  display: inline-block;
}
```

- [ ] **Step 5 — Run the test; verify it passes:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/Button.test.tsx
```
Expected: PASS (4 tests).

- [ ] **Step 6 — Add `IconButton` + `CloseButton`.** Create `app/components/ui/IconButton/IconButton.tsx` (same prop pattern, `round|square` + `overlay|ghost` variants, `aria-label` **required** via typed prop) and `app/components/ui/CloseButton/CloseButton.tsx` (composes `IconButton`, single `✕` glyph, `aria-label="Close"` default). Add `tests/components/ui/IconButton.test.tsx` asserting `aria-label` is required and the role is button. *(Write these test‑first using the same 5‑step rhythm.)*

- [ ] **Step 7 — Lint + type-check + commit:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/components/ui/**/*.{ts,tsx,scss} tests/components/ui/*.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/components/ui/**/*.{ts,tsx}
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/ui/**/*.scss'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
git add app/components/ui tests/components/ui
git commit -m "feat(ui): add canonical Button, IconButton, CloseButton primitives

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

- [ ] **Step 8 — Migrate call sites (incremental; one commit per file).** Replace each bespoke button with `<Button variant size>` and delete the dead SCSS rule. Migration targets (from the review's catalog):

| File | Class(es) → variant |
|------|---------------------|
| `app/components/ClientGalleryGate/ClientGalleryGate.module.scss` `.gateButton` | `primary` |
| `app/components/ClientGalleryDownload/ClientGalleryDownload.module.scss` `.downloadButton`, `.pickerButton` | `primary` / `secondary` |
| `app/components/ClientGalleryDownload/ImageDownloadOverlay.module.scss` `.formatButton` | `IconButton` overlay |
| `app/components/ImageMetadata/ImageMetadataModal.module.scss` `.saveButton/.cancelButton/.deleteButton/.removeButton` | `primary`/`ghost`/`danger`/`danger` |
| `app/components/TextBlockCreateModal/TextBlockCreateModal.module.scss` `.submitButton/.cancelButton` | `primary`/`ghost` |
| `app/(admin)/comments/Comments.module.scss` `.replyButton/.deleteButton/.loadMore` | `secondary`/`danger`/`ghost` |
| `app/components/CollectionListSelector/CollectionListSelector.module.scss` `.addButton` | `secondary` |
| `app/components/Admin/AllImagesClient.module.scss` `.retry` | `secondary` |
| `app/components/ErrorBoundary/ErrorBoundary.module.scss` `.retryButton`; `app/error.tsx` retry | `primary` |
| `app/(admin)/collection/manage/[[...slug]]/ManageClient.module.scss` (8 button classes) | per intent |
| close buttons: `fullscreen-image.module.scss:395`, `ImageMetadataModal.module.scss:347`, `TextBlockCreateModal.module.scss:61`, `MenuDropdown` `CircleX` | `CloseButton` |

**Acceptance:** `grep -rn "Button {" app --include=*.scss` trends toward zero bespoke button rules; each migrated component's tests stay green.

### Task 1.2 — `<Modal>`  → promote to its own sub-plan

**Why:** 5 modal shells re‑solve portal/backdrop/Esc/scroll‑lock/focus independently; only `FullScreenModal` does it correctly via `createPortal` (review §6a‑rank‑1). `ImageMetadataModal` uses the `position:absolute + inset:0 + 100vh + top:scrollPosition` footgun.

**Files:** Create `app/components/ui/Modal/Modal.tsx` + `.module.scss`; test `tests/components/ui/Modal.test.tsx`.

**Interface (lock this in the sub-plan):**
```tsx
export interface ModalProps {
  open: boolean;
  onClose: () => void;
  variant?: 'overlay' | 'sheet' | 'fullscreen';
  labelledBy?: string;          // id of the heading → aria-labelledby
  children: React.ReactNode;
}
```
**Owns:** `createPortal(document.body)`, backdrop (tokenized scrim), `Escape` close, **focus trap + focus return**, `useBodyScrollLock` (the existing hook), `role="dialog"` + `aria-modal`.

**Canonical test:** opens → focus moves to first focusable; `Escape` calls `onClose`; `Tab` cycles within the dialog (focus trap); on close, focus returns to the previously‑focused element; backdrop click calls `onClose`.

**Migration targets:** `FullScreenModal` (content becomes children; keep its image/EXIF panel), `ImageMetadataModal` (removes the `100vh`/`scrollPosition` hack), `TextBlockCreateModal`, `MenuDropdown` (variant `sheet`), `ClientGalleryGate` (variant `overlay` card). Fold `MenuDropdown`'s hand‑rolled click‑outside/Esc/scroll‑lock onto the existing `useClickOutside` + the Modal.

**→ Promoted:** [`001-modal-primitive.md`](001-modal-primitive.md) (via writing-plans, using Task 1.1's TDD rhythm).

### Task 1.3 — `<FilterChip>` + `<FilterToolbar>`  → promote to its own sub-plan

**Why:** two filter bars (`CollectionFilterBar` borderless dropdowns + slider vs `LocationFilterBar` bordered pills + film/digital colors) and 6 chip variants for the same "toggle a facet" concept; `cycleDateSort` exists twice with different cycle orders; `toggleTag/togglePerson` re‑implement the exported `toggleArrayFilter` (review §2 taxonomy, §6a‑rank‑3).

**Interface:**
```tsx
export interface FilterChipProps {
  label: string;
  count?: number;
  active?: boolean;
  tone?: 'neutral' | 'film' | 'digital';
  state?: 'available' | 'unavailable';
  onToggle: () => void;
}
```
**FilterToolbar:** config‑driven (which dimensions to show) wrapping `FilterChip`s + the density `<Slider>`; adopt `CollectionFilterBar`'s dropdown + 3‑state availability model as the base, fold in `LocationFilterBar`'s count badges + film toggle, then **delete `LocationFilterBar`**. Unify the two `cycleDateSort` orders into one. Reconsider the saturated green/pink film/digital tokens against the monochrome aesthetic (render film as a neutral tri‑state).

**Migration targets:** `app/components/ContentCollection/CollectionFilterBar.tsx`, `app/components/LocationFilterBar/LocationFilterBar.tsx`; the `.filterBarChip*` (ContentComponent.module.scss) and `.chip*` (LocationFilterBar.module.scss) styles deleted. Merge `GalleryFilterState` + `CollectionFilterState` into one `FilterState` (remove dead `selectedCollectionIds`). **→ Promote to its own sub-plan.**

### Task 1.4 — `<Dropdown<T>>`  → promote `UnifiedMetadataSelector`

**Why:** `UnifiedMetadataSelector` is already a correct generic `Dropdown<T>` (review §3 best). It just borrows `ImageMetadataModal.module.scss` class names, so it isn't portable.

**Steps (sub-plan):** move `app/components/ImageMetadata/UnifiedMetadataSelector.tsx` → `app/components/ui/Dropdown/Dropdown.tsx`; extract its styles into `app/components/ui/Dropdown/Dropdown.module.scss` (copy the `cameraDropdown*`/`chip*` rules it uses out of `ImageMetadataModal.module.scss`); generalize the `simpleChips` boolean into a `variant` prop; keep its `useClickOutsideMultiple` usage. Re‑point existing imports. Then `MenuDropdown` and the filter dropdowns can adopt one keyboard/positioning implementation. **→ Promote to its own sub-plan.**

---

## Phase 2 — Navigation, shell & remaining primitives  *(own sub-plan: [`001-nav-and-shell.md`](001-nav-and-shell.md))*

Scoped tasks (each: files + acceptance):

- **`<NavLink>` / `<Tile>`** — always a real `next/link` `<a>`. Migrate `CollectionContentRenderer.tsx:531` tile navigation off `div onClick`+`router.push` to `<Link href>` (keep the parallax image + overlay + Badge composed inside). Reserve `onClick` for fullscreen‑open only. **Acceptance:** home/collection tiles are middle‑clickable, open‑in‑new‑tab, crawlable; tile is keyboard‑activatable. *(review §1.4, §5)*
- **`<PageShell>` + `<CollectionHeader>`** — one `container/main/SiteHeader/pageHeader` scaffold (+ breadcrumb slot) replacing the 8 copy‑pasted page modules; hosts the dark‑safe surface and the "up to parent / View all work" affordance. **Acceptance:** `MetadataPage/TaxonomyPage/ContentCollectionPage/LocationPage/admin page/Comments/ManageClient` all compose it; the duplicated `.container/.main/.pageHeader` SCSS is removed. *(review §2, §3 dup catalog)*
- **`<StatusPage>`** — token‑driven 404/error/empty shell on the painted surface (reuse `ErrorBoundary`'s readable pattern); `not-found.tsx`/`error.tsx` adopt it; `error.tsx` gains a home link + `type="button"` on retry. *(review §5)*
- **`<Badge>`** — promote `BadgeOverlay`; move the duplicated `.dateBadge`/`.cardTypeBadge` rules out of `globals.css:211` **and** `ContentComponent.module.scss:160` into one component; add `tone` + `position` props; **map `CollectionType` → curated public labels** (or suppress) so `PARENT`/`PORTFOLIO` never reach visitors. *(review §1.5, §5)*
- **Form set** `<Field>/<Input>/<Select>/<Textarea>/<Checkbox>/<FormError>` — one SCSS source replacing the parallel form scaffolding in `ImageMetadataModal`, `TextBlockCreateModal`, `ContactForm`, `UnifiedMetadataSelector`; `ContactForm` gains real `<label htmlFor>` + `role="status"`/`aria-live`. *(review §5 a11y)*
- **Metadata lists** — collapse `Metadata{Tag,Person,Location}List` into one generic `MetadataList<T>`; move `/metadata` under `(admin)` with real auth (it's unguarded CRUD today). *(review §3, §5)*

---

## Phase 3 — Information architecture & UX  *(own sub-plan: [`001-ia-and-ux.md`](001-ia-and-ux.md))*

- **Public taxonomy directory** — repurpose the `/metadata` data into a public "Explore" index (tags/people/locations as `NavLink`s) and/or add index routes `/tag`, `/location`, `/people`; link from the menu + footer. *(review §5, §8 — `/people` has zero entry points today)*
- **Deep‑linkable fullscreen** — sync the open image to the URL (`?image=<id>`) + `history.pushState` so links reopen to an image and Back **closes the modal** instead of exiting the collection. Add a `3 / 12` counter. *(review §2, §8)*
- **Wire the existing filter‑URL helpers** — `contentFilter.ts:493/567` (`parse/serializeFilterToParams`) are fully tested but imported by no page; wire into the gallery clients via `useSearchParams` + `router.replace`. Shareable/back‑correct filtered views. *(review §5)*
- **Skeleton / blur‑up** — eager‑render the first BoxTree row(s) + add `next/image placeholder="blur"`/skeletons sized to the rows; kills blank‑on‑load. *(review §1, §2, §8)*
- **Footer + breadcrumb** — persistent text links (About/Contact/IG/GitHub) + "Browse all work" linking the existing public `/all-collections`; breadcrumb/parent affordance on deep pages. *(review §2, §8)*
- **Reachable taxonomy titles** — taxonomy/person pages show the entity **name** (today a person page reads only "2 photos"). *(review §2)*

---

## Phase 4 — Color-token collapse + a11y polish  *(own sub-plan: [`001-token-collapse-and-a11y.md`](001-token-collapse-and-a11y.md))*

- **One semantic taxonomy** — migrate the three color families + the alias block onto: `--color-surface / -surface-raised / -on-surface / -on-surface-muted / -border / -accent (+ -on-accent) / -danger / -success` + a single `--scrim-dark-{10..90}` / `--scrim-light-{10..90}` scale (replacing the 9 fixed `--color-overlay-light-*` steps + ~30 inline `rgb(0 0 0 / x%)`); then **delete** the legacy `--color-text-*` / `--color-bg-light/medium/dark` family and the Task 0.1 alias block. Split the `--color-primary` near‑black/blue collision into `--color-primary` + `--color-accent` (fixes the latent ReorderOverlay selection‑outline bug). Collapse `--color-danger`'s 4 fallback values to one. *(review §6b)*
- **Motion + breakpoints** — add `--duration-fast/base/slow` + `--ease-standard` (replace ~40 magic numbers); add a `@custom-media` bridge so the existing `--breakpoint-*` tokens are usable and migrate the 97 hardcoded `768px` queries; delete `page.module.scss`'s competing `$bp/@mixin up()`. *(review §5, SCSS report)*
- **a11y sweep** — one `--focus-ring` + ban bare `outline:none` (~7 modules); real `h1` per collection/home (titles are `div.textOverlay` today); `prefers-reduced-motion` guard on parallax; fix the gap‑rule violation (per‑image `padding` → row `gap`); standardize `rgb()` slash syntax via stylelint. *(review §5)*
- **Backend track (cross-repo signal):** plaintext client‑gallery password is stored + rendered (`ManageClient.tsx:1444`; backend `gallery_password VARCHAR`). Out of FE scope — hand off to `edens.zac.backend` (hash/encrypt; stop rendering plaintext). *Flagged here so it isn't lost.*

---

## Dead-code & latent-bug register (address as encountered)

- `app/components/FullScreenModal/FsDebug.tsx` — delete (Task 0.2). ✅ in plan
- Duplicate "Create" in `MenuDropdown` — remove (Task 0.3). ✅
- Dead `onBack` in `About`/`ContactForm` — remove (Task 0.3). ✅
- `useCollectionData.tsx` — admin‑only; confirm it is not on any public path before relying on it.
- `.dateBadge` defined twice (`globals.css` + `ContentComponent.module.scss`) — collapse (Phase 2 Badge).
- `@keyframes gateSpinnerRotate` — duplicate of `LoadingSpinner`'s `spin`; remove (Phase 4).
- **Latent bug:** `ReorderOverlay.module.scss` uses `var(--color-primary, #3b82f6)` expecting blue, but `--color-primary` is near‑black `#212226` → the selection outline is near‑black, not blue. Fix when `--color-accent` lands (Phase 4).
- **Latent bug:** `--color-warning` undeclared → `RatingStars` always uses literal `#f4b400`. Declared in Task 0.1.

---

## Verification (run after each task; full pass before any PR)

```bash
cd /Users/themancalledzac/Code/edens.zac
# Format → lint → type-check → test (project pipeline, per CLAUDE.md; npm/npx not on PATH)
/opt/homebrew/bin/node node_modules/.bin/prettier --write <touched files>
/opt/homebrew/bin/node node_modules/.bin/eslint --fix <touched .ts/.tsx>
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix '<touched .scss>'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest
```
**Visual (dev server :3001 — user keeps :3000):** Phase 0 → 404 + `/metadata` readable in OS dark mode; header title readable over imagery. Phase 1 → migrated buttons/modals look and behave identically; focus‑visible ring present; modal traps + returns focus. Phase 2 → tiles open in new tab / middle‑click; 404 has chrome + home link. Phase 3 → filtered URL is shareable, Back closes fullscreen, no blank‑on‑load.

---

## Suggested commit sequence (Phase 0 + 1.1)

1. `fix(foundation): paint page surface from tokens + declare alias layer` (Task 0.1)
2. `chore(fullscreen): remove temporary FsDebug diagnostic` (Task 0.2)
3. `fix(nav): remove dead /all-blogs link, duplicate Create item, dead onBack prop` (Task 0.3)
4. *(optional)* `build(stylelint): guard against undeclared custom properties` (Task 0.4)
5. `feat(ui): add canonical Button, IconButton, CloseButton primitives` (Task 1.1 steps 1–7)
6. `refactor(<feature>): adopt <Button> primitive` — **one commit per migrated file** (Task 1.1 step 8)

Each commit passes `tsc --noEmit` + `jest` independently.

---

## Self-review: spec-coverage checklist

Maps every design‑review section/finding to a task. Gaps flagged explicitly.

| Review section / finding | Plan task | Status |
|--------------------------|-----------|--------|
| §1.1 / §5 — no page background; dark‑mode invisible text (404, /metadata, header, admin) | Task 0.1 | ✅ Phase 0 |
| §1.2 / §1.4 / §5 — tiles are non‑link `div onClick` | Phase 2 (NavLink/Tile) | 📋 sub-plan |
| §1.3 / §5 — shadow namespace (~15 undeclared tokens) | Task 0.1 (alias) + Phase 4 (collapse) | ✅ / 📋 |
| §5 — FsDebug shippable; dead Blogs link; duplicate Create; dead onBack | Tasks 0.2, 0.3 | ✅ Phase 0 |
| §3 / §6a‑2 / §5 — ~30–38 button classes + 4 close buttons | Task 1.1 | ✅ template |
| §6a‑1 / §5 — 5 modal shells, no focus trap | Task 1.2 | 📋 sub-plan |
| §2 / §6a‑3 — 2 filter bars + 6 chips; filter state not URL‑driven | Task 1.3 + Phase 3 | 📋 sub-plan |
| §3 best / §6a‑4 — promote UnifiedMetadataSelector → Dropdown | Task 1.4 | 📋 sub-plan |
| §3 dup / §6a‑6 — 8 copy‑pasted page scaffolds | Phase 2 (PageShell) | 📋 sub-plan |
| §5 — 404/error chrome‑less + invisible | Phase 2 (StatusPage) | 📋 sub-plan |
| §1.5 / §5 — public CollectionType badge; 3 badge defs | Phase 2 (Badge) | 📋 sub-plan |
| §5 — ContactForm labels; form scaffolding dup | Phase 2 (Form set) | 📋 sub-plan |
| §5 — /metadata unguarded CRUD; 3 near‑identical lists | Phase 2 (MetadataList + auth) | 📋 sub-plan |
| §5 / §8 — taxonomy pages orphaned (/people no entry) | Phase 3 (directory) | 📋 sub-plan |
| §2 / §8 — fullscreen not deep‑linkable; Back exits collection | Phase 3 | 📋 sub-plan |
| §5 — tested filter‑URL helpers wired to nothing | Phase 3 | 📋 sub-plan |
| §1 / §2 / §8 — blank‑on‑load | Phase 3 (skeleton) | 📋 sub-plan |
| §2 / §8 — no footer/breadcrumb; missing "Browse all work" | Phase 3 | 📋 sub-plan |
| §6b — color‑token collapse; motion + breakpoint tokens | Phase 4 | 📋 sub-plan |
| §5 — outline:none / focus ring / headings / reduced‑motion / gap rule | Phase 4 | 📋 sub-plan |
| §5 / §7 — plaintext gallery password | Phase 4 register (backend hand‑off) | ⚠ cross‑repo |
| §4 wins (BoxTree, single pipeline, ContactForm, RatingStars, token scales) | **Preserve — no task** | ✅ keep |
| §7 "better idea": intentional dark theme; persistent nav; sticky FilterToolbar | Phase 4 (theme) / Phase 2 (nav) / Task 1.3 | 📋 + decision |

**Deferred by design (not gaps):** the §7 strategic *decisions* (commit to light vs intentional‑dark theme; replace hamburger‑only nav) need a product call before Phase 4/2 execution — surfaced in *Execution Handoff*. Client‑gallery favorites/print‑select (§8) is a future feature, intentionally out of scope.

**Placeholder scan:** Phase 0 + Task 1.1 contain complete code, exact paths, and exact commands (no TBDs). Phases 1.2–4 are scoped task definitions with concrete files/interfaces/acceptance — each must be expanded to bite‑sized via `writing-plans` before execution (stated, not hidden).

**Type consistency:** `ButtonVariant`/`ButtonSize` in Task 1.1 are reused by the migration table; `ModalProps`/`FilterChipProps`/`FilterState` names are introduced once and referenced consistently across phases.

---

## Files referenced
- **New:** `app/components/ui/{Button,IconButton,CloseButton,Modal,FilterChip,FilterToolbar,Dropdown,Badge,Field,NavLink,Tile,PageShell,CollectionHeader,StatusPage}/…`, `tests/components/ui/*.test.tsx`
- **Modified (Phase 0):** `app/styles/globals.css`, `app/components/SiteHeader/SiteHeader.module.scss`, `app/components/FullScreenModal/FullScreenModal.tsx` (+ delete `FsDebug.tsx`), `app/components/MenuDropdown/MenuDropdown.tsx`, `app/(admin)/admin/adminTiles.ts`, `app/components/About/About.tsx`, `app/components/ContactForm/ContactForm.tsx`
- **Migrated (Phase 1+):** the button/modal/chip/badge/form/page‑shell call sites listed per task.

---

## Execution Handoff

**Plan complete and saved to [`001-design-system-unification.md`](001-design-system-unification.md) (chapter [001 · Design System Unification](../../001-design-review.md)).**

This master plan parallelizes well: **Phase 0 is sequential‑first** (everything builds on the painted surface + alias layer), then **Phase 1 primitives are mutually independent** and **Phases 2–4 are independent subsystems** — a strong fit for Agent Teams / multi‑agent execution (one agent per primitive or per phase).

Two product **decisions** gate Phase 2/4 and are worth settling first: (a) commit to a clean **light** theme or an intentional **dark** theme (the review's "better idea" — galleries shine on dark); (b) keep hamburger‑only nav or add a **persistent nav + footer**.

**Execution options:**
1. **Subagent‑Driven (recommended)** — REQUIRED SUB‑SKILL `superpowers:subagent-driven-development`: fresh subagent per task + two‑stage review. Best for Phase 0 → 1.1 right now.
2. **Inline Execution** — REQUIRED SUB‑SKILL `superpowers:executing-plans`: batch with checkpoints.
3. **Promote a sub‑plan** — pick a 📋 item (Modal / FilterChip / IA / token‑collapse) and I'll expand it to full bite‑sized TDD via `writing-plans`.

Which approach — and shall I start with **Phase 0** now?
