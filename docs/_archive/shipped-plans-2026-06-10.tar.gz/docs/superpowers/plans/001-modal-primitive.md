# 001 · Modal Primitive
_Chapter [001 · Design System Unification](../../001-design-review.md) · plan_

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking. Each task is bite-sized and ends in a green commit; do not batch tasks.

**Goal:** Build one canonical `<Modal>` primitive (`app/components/ui/Modal/`) that owns the portal, the tokenized backdrop scrim, Escape-to-close, a focus trap with focus-return-to-trigger, the existing `useBodyScrollLock` hook, and the `role="dialog"` / `aria-modal` / `aria-labelledby` semantics — then migrate the site's 5 divergent modal shells onto it. This eliminates the `position:absolute + inset:0 + 100vh + top:scrollPosition` footgun in `ImageMetadataModal`, the three independently hand-rolled dismissal effects in `MenuDropdown`, and the per-shell backdrop/portal re-implementations.

**Architecture:** `Modal` is a single `'use client'` component (it uses `useEffect`/`useRef` and `createPortal`). It renders `createPortal(<backdrop><dialog>…</dialog></backdrop>, document.body)` only while `open`. The dialog `<div>` gets `role="dialog"`, `aria-modal="true"`, and `aria-labelledby={labelledBy}`. On open it records `document.activeElement` as the return target, moves focus to the first focusable descendant, and installs a `keydown` handler that (a) calls `onClose` on `Escape` and (b) traps `Tab`/`Shift+Tab` within the dialog. On close (unmount or `open` → `false`) it returns focus to the recorded element. Backdrop (but not dialog) clicks call `onClose`. `useBodyScrollLock(open)` is called unconditionally with the `open` flag (the hook is ref-counted and no-ops when `false`). The three `variant` values map to SCSS classes that control layout only (`overlay` = centered card, `sheet` = full-bleed panel, `fullscreen` = edge-to-edge) — behavior is identical across variants. The modal's own close control composes the `<CloseButton>` primitive (prerequisite below). Migrations move each shell's *content* into `<Modal>` children and delete the shell's portal/backdrop/Esc/scroll-lock/positioning code.

**Tech Stack:** Next.js 16 App Router, React 19 (named imports only — no `import React`), TypeScript (strict, no `any`), SCSS Modules with CSS custom properties (bare `var(--token)`, no `@use` partial), Jest + React Testing Library (tests mirror `app/` under `tests/`; `next/jest` maps `*.module.scss` so `styles.foo === 'foo'` in tests). `npm`/`npx` are not on PATH — use the Homebrew node binary directly.

> **Spec:** This plan implements **rank 1** of the "Main Design Elements" in [`../../001-design-review.md`](../../001-design-review.md) — §6a row 1 (`<Modal>` collapses 5 modal shells + the `position:absolute+100vh` footgun + duplicated dismissal effects), §5 "No focus trap / focus return in any modal or the dropdown", and §3's modal/close-button duplication catalog.
> **Parent plan:** This is the promoted sub-plan for **Task 1.2** of [`001-design-system-unification.md`](001-design-system-unification.md). It follows that plan's Task 1.1 (`<Button>`) bite-sized TDD format exactly.
> **Status:** ✅ Shipped on branch `0148-design-modal-migration`. Tasks 1–4 + 6 landed (Modal primitive + ClientGalleryGate / TextBlockCreateModal / ImageMetadataModal / FullScreenModal). **Task 5 (MenuDropdown) was migrated then reverted (`174f5fb`)** — it's a popover, not a blocking modal, so it keeps its own `useBodyScrollLock` + `useClickOutside`. See **Post-migration fixes** below.

---

## Post-migration fixes (branch `0148`) — scroll restore + single backdrop

The migration shipped, then surfaced two regressions in the fullscreen viewer (fixed in `ca8e8ad`; comment-cleanup follow-up in `09847a1`):

1. **Jump-to-top on close.** Running `<Modal>`'s `useBodyScrollLock(open)` alongside the viewer's own `useBodyScrollLock(isOpen)` exposed a latent bug in the hook: it ref-counted lockers at module level but stored the captured scroll offset in a **per-instance `useRef`**. With two concurrent lockers only the first captured the real offset; whichever cleanup drove the count to 0 restored *its* ref (often `0`) → the page jumped to the top.
   - **Fix:** hoist the offset to a module-level variable in `useBodyScrollLock.ts` so concurrent lockers share one capture/restore, **and** remove the now-redundant `useBodyScrollLock` from `useFullScreenImage` + `useImageMetadataEditor` so `<Modal>` is the sole locker. Added `tests/hooks/useBodyScrollLock.test.tsx` (single / concurrent / nested lockers).
2. **No translucent backdrop.** The Modal `.backdrop` scrim (`0.7`) stacked with the viewer wrapper's own `0.9` ≈ opaque. **Fix:** transparent `.imageFullScreenWrapper`; a single `0.9` scrim on the Modal `.fullscreen` variant.
3. **Esc dedup:** `<Modal>` owns Esc; the viewer hook keeps only arrows / swipe / wheel.

**Verified in-browser (:3001):** scroll → open → close returns to the exact position; faint page visible behind the scrim; Esc closes. The same latent double-lock would have hit `ImageMetadataModal` too — resolved by the same change.

> **Learning:** when a primitive (`<Modal>`) absorbs a concern (scroll lock), the per-feature implementations must be *removed*, not left to run in parallel — and any shared module-level hook must keep all of its coordinated state at module level, not split count-vs-value across scopes.

---

## Prerequisites (must land before Task 1 of this plan)

This plan assumes the following are already on the branch (they are earlier tasks in the parent master plan):

- **Phase 0 — painted surface + alias-token layer** (master plan Task 0.1): `html, body { background: var(--color-bg); color: var(--color-fg); }` is bound, and the previously-undeclared "shadow namespace" tokens (`--text-primary`, `--border-color`, `--color-accent`, `--radius-sm`, …) are declared as non-breaking aliases in `app/styles/globals.css`. The Modal SCSS below references existing tokens only (`--color-overlay-strong`, `--z-modal`, `--space-*`, `--radius-*`, `--color-bg`, `--color-fg`, `--color-border`) — all already declared in `globals.css`.
- **Button / IconButton / CloseButton primitives** (master plan Task 1.1): `app/components/ui/Button/Button.tsx`, `app/components/ui/IconButton/IconButton.tsx`, and `app/components/ui/CloseButton/CloseButton.tsx` exist. `CloseButton` renders a `<button type="button">` with an `aria-label` (default `"Close"`) and an `onClick` prop, composing `IconButton`. **The Modal's close control composes `<CloseButton>`** — migration tasks below replace each shell's bespoke `✕`/`CircleX` button with `<CloseButton onClick={onClose} />`.

If a migration task reaches a shell before `CloseButton` exists, stop and land Task 1.1 first.

---

## File-structure map

**New (created by this plan):**

```
app/components/ui/Modal/
  Modal.tsx            (the primitive — 'use client')
  Modal.module.scss    (backdrop + 3 variant layouts; tokens only)

tests/components/ui/
  Modal.test.tsx       (focus-in, Escape, backdrop click, Tab cycle, focus-return)
```

**Modified (migrations):**

```
app/components/FullScreenModal/FullScreenModal.tsx        (content/EXIF panel → Modal children; keep image render)
app/components/ImageMetadata/ImageMetadataModal.tsx        (remove scrollPosition top + outer wrapper → Modal children)
app/components/ImageMetadata/ImageMetadataModal.module.scss (delete .metadataModalWrapper position hack)
app/components/TextBlockCreateModal/TextBlockCreateModal.tsx        (content → Modal children)
app/components/TextBlockCreateModal/TextBlockCreateModal.module.scss (delete .modalWrapper backdrop)
app/components/MenuDropdown/MenuDropdown.tsx               (variant='sheet'; drop hand-rolled click-outside/Esc/scroll-lock)
app/components/ClientGalleryGate/ClientGalleryGate.tsx     (variant='overlay' card → Modal children)
```

Each migration also removes the `scrollPosition` prop from the modals that took it (`ImageMetadataModal`, `TextBlockCreateModal`) and updates their call sites in `ManageClient` / wherever they are mounted — see each task's **Files**.

---

## Task 1 — Build the canonical `<Modal>` primitive

**Why:** 5 modal shells (`FullScreenModal`, `ImageMetadataModal`, `TextBlockCreateModal`, `MenuDropdown`, `ClientGalleryGate`) each re-solve portal/backdrop/Escape/scroll-lock/focus independently. Only `FullScreenModal` uses `createPortal`; `ImageMetadataModal` uses the `position:absolute + inset:0 + width:100vw + height:100vh + style={{ top: scrollPosition }}` footgun; none implement a focus trap or focus return (review §5, §6a-rank-1).

**Files:**
- Create: `app/components/ui/Modal/Modal.tsx`
- Create: `app/components/ui/Modal/Modal.module.scss`
- Test: `tests/components/ui/Modal.test.tsx`

- [ ] **Step 1 — Write the failing test** `tests/components/ui/Modal.test.tsx`. It mounts real focusable `<button>`s as children, opens via a `rerender`, and uses fake DOM focusable elements to assert focus-in, Escape, backdrop click, Tab cycling, and focus-return:

```tsx
import { fireEvent, render, screen } from '@testing-library/react';

import { Modal } from '@/app/components/ui/Modal/Modal';

/**
 * The Modal owns dismissal + focus management. These tests assert the behavioral
 * contract the 5 shells will delegate to it: focus moves in on open, Escape and
 * backdrop click call onClose, Tab cycles within the dialog, and focus returns to
 * the previously-focused element on close. Children are real focusable buttons so
 * the focus trap has something to cycle through.
 */
function Harness({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  return (
    <>
      <button type="button" data-testid="trigger">
        Open
      </button>
      <Modal open={open} onClose={onClose} labelledBy="dialog-title">
        <h2 id="dialog-title">Title</h2>
        <button type="button" data-testid="first">
          First
        </button>
        <button type="button" data-testid="last">
          Last
        </button>
      </Modal>
    </>
  );
}

describe('Modal', () => {
  it('renders nothing while closed', () => {
    render(<Harness open={false} onClose={jest.fn()} />);
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });

  it('renders a labelled dialog with aria-modal when open', () => {
    render(<Harness open onClose={jest.fn()} />);
    const dialog = screen.getByRole('dialog');
    expect(dialog).toHaveAttribute('aria-modal', 'true');
    expect(dialog).toHaveAttribute('aria-labelledby', 'dialog-title');
  });

  it('moves focus to the first focusable child on open', () => {
    const { rerender } = render(<Harness open={false} onClose={jest.fn()} />);
    const trigger = screen.getByTestId('trigger');
    trigger.focus();
    expect(trigger).toHaveFocus();

    rerender(<Harness open onClose={jest.fn()} />);
    expect(screen.getByTestId('first')).toHaveFocus();
  });

  it('calls onClose when Escape is pressed', () => {
    const onClose = jest.fn();
    render(<Harness open onClose={onClose} />);
    fireEvent.keyDown(screen.getByRole('dialog'), { key: 'Escape' });
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it('calls onClose when the backdrop is clicked but not when the dialog is clicked', () => {
    const onClose = jest.fn();
    render(<Harness open onClose={onClose} />);
    const dialog = screen.getByRole('dialog');

    fireEvent.click(dialog);
    expect(onClose).not.toHaveBeenCalled();

    // The dialog's parent is the backdrop.
    fireEvent.click(dialog.parentElement as HTMLElement);
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it('traps Tab within the dialog (last → first) and Shift+Tab (first → last)', () => {
    render(<Harness open onClose={jest.fn()} />);
    const first = screen.getByTestId('first');
    const last = screen.getByTestId('last');

    last.focus();
    fireEvent.keyDown(screen.getByRole('dialog'), { key: 'Tab' });
    expect(first).toHaveFocus();

    first.focus();
    fireEvent.keyDown(screen.getByRole('dialog'), { key: 'Tab', shiftKey: true });
    expect(last).toHaveFocus();
  });

  it('returns focus to the previously-focused element on close', () => {
    const { rerender } = render(<Harness open={false} onClose={jest.fn()} />);
    const trigger = screen.getByTestId('trigger');
    trigger.focus();

    rerender(<Harness open onClose={jest.fn()} />);
    expect(screen.getByTestId('first')).toHaveFocus();

    rerender(<Harness open={false} onClose={jest.fn()} />);
    expect(trigger).toHaveFocus();
  });
});
```

- [ ] **Step 2 — Run it; verify it fails:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/Modal.test.tsx
```
Expected output: FAIL — `Cannot find module '@/app/components/ui/Modal/Modal' from 'tests/components/ui/Modal.test.tsx'`.

- [ ] **Step 3 — Implement `app/components/ui/Modal/Modal.tsx`** (`'use client'` — it uses hooks + `createPortal`):

```tsx
'use client';

import { type ReactNode, useCallback, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';

import { useBodyScrollLock } from '@/app/hooks/useBodyScrollLock';

import styles from './Modal.module.scss';

export type ModalVariant = 'overlay' | 'sheet' | 'fullscreen';

export interface ModalProps {
  open: boolean;
  onClose: () => void;
  variant?: ModalVariant;
  /** id of the heading inside `children` → wired to aria-labelledby. */
  labelledBy?: string;
  children: ReactNode;
}

/** Elements the focus trap treats as tabbable. */
const FOCUSABLE_SELECTOR =
  'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';

/**
 * Canonical modal. Owns the portal, the backdrop scrim, Escape-to-close, a focus
 * trap with focus-return, body scroll lock, and dialog ARIA. Replaces the 5
 * per-feature modal shells (review §6a-rank-1). Variants change layout only —
 * the dismissal + focus behavior is identical across all three.
 */
export function Modal({ open, onClose, variant = 'overlay', labelledBy, children }: ModalProps) {
  const dialogRef = useRef<HTMLDivElement>(null);
  const previouslyFocusedRef = useRef<HTMLElement | null>(null);

  // Ref-counted; no-ops when `open` is false. Locks the page behind the modal.
  useBodyScrollLock(open);

  const getFocusable = useCallback((): HTMLElement[] => {
    const node = dialogRef.current;
    if (!node) return [];
    return [...node.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)];
  }, []);

  // On open: record the trigger and move focus to the first focusable child.
  // On close/unmount: return focus to the recorded trigger.
  useEffect(() => {
    if (!open) return;

    previouslyFocusedRef.current =
      document.activeElement instanceof HTMLElement ? document.activeElement : null;

    const focusable = getFocusable();
    (focusable[0] ?? dialogRef.current)?.focus();

    return () => {
      previouslyFocusedRef.current?.focus();
    };
  }, [open, getFocusable]);

  const handleKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    if (event.key === 'Escape') {
      event.stopPropagation();
      onClose();
      return;
    }

    if (event.key !== 'Tab') return;

    const focusable = getFocusable();
    if (focusable.length === 0) {
      event.preventDefault();
      return;
    }

    const first = focusable[0]!;
    const last = focusable[focusable.length - 1]!;
    const active = document.activeElement;

    if (event.shiftKey) {
      if (active === first || !dialogRef.current?.contains(active)) {
        event.preventDefault();
        last.focus();
      }
    } else if (active === last) {
      event.preventDefault();
      first.focus();
    }
  };

  if (!open || typeof document === 'undefined') return null;

  return createPortal(
    <div
      className={`${styles.backdrop} ${styles[variant]}`}
      onClick={event => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div
        ref={dialogRef}
        className={styles.dialog}
        role="dialog"
        aria-modal="true"
        aria-labelledby={labelledBy}
        tabIndex={-1}
        onKeyDown={handleKeyDown}
      >
        {children}
      </div>
    </div>,
    document.body
  );
}
```

- [ ] **Step 4 — Implement `app/components/ui/Modal/Modal.module.scss`** (tokens only; variants are layout-only):

```scss
.backdrop {
  position: fixed;
  inset: 0;
  z-index: var(--z-modal);
  display: flex;
  background-color: var(--color-overlay-strong);
  overscroll-behavior: none;

  /* Reset transforms inherited from any parallax/perspective ancestor so the
     portal'd dialog positions against the viewport, not a transformed parent. */
  transform: none;
  perspective: none;
}

.dialog {
  &:focus {
    outline: none;
  }

  &:focus-visible {
    outline: 2px solid var(--color-accent);
    outline-offset: 2px;
  }
}

/* ── Variants (layout only; behavior is identical) ── */

/* overlay: centered card with breathing room (ClientGalleryGate, TextBlockCreateModal). */
.overlay {
  align-items: center;
  justify-content: center;
  padding: var(--space-5);

  .dialog {
    width: 100%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
    background-color: var(--color-bg);
    color: var(--color-fg);
    border-radius: var(--radius-2);
    box-shadow: 0 20px 60px var(--color-overlay-strong);
  }
}

/* sheet: full-bleed scrolling panel (MenuDropdown nav, ImageMetadataModal editor). */
.sheet {
  .dialog {
    width: 100%;
    height: 100%;
    overflow-y: auto;
    background-color: var(--color-bg);
    color: var(--color-fg);
  }
}

/* fullscreen: edge-to-edge, transparent dialog over the scrim (FullScreenModal viewer). */
.fullscreen {
  .dialog {
    width: 100%;
    height: 100%;
  }
}
```

- [ ] **Step 5 — Run the test; verify it passes:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ui/Modal.test.tsx
```
Expected output: PASS (7 tests).

- [ ] **Step 6 — Lint + type-check:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/components/ui/Modal/Modal.tsx app/components/ui/Modal/Modal.module.scss tests/components/ui/Modal.test.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/components/ui/Modal/Modal.tsx tests/components/ui/Modal.test.tsx
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/ui/Modal/Modal.module.scss'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
```
Expected output: prettier rewrites (or no-ops); eslint exits 0; stylelint exits 0; tsc prints nothing and exits 0.

- [ ] **Step 7 — Commit:**
```bash
git add app/components/ui/Modal tests/components/ui/Modal.test.tsx
git commit -m "feat(ui): add canonical Modal primitive (portal, focus trap, scroll lock)

One <Modal variant=overlay|sheet|fullscreen> owning createPortal(document.body),
a tokenized backdrop scrim, Escape-to-close, a Tab focus trap with focus return
to the trigger, useBodyScrollLock, and role=dialog/aria-modal/aria-labelledby.
Replaces the 5 hand-rolled modal shells (review §6a-rank-1, §5).

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 2 — Migrate `ClientGalleryGate` onto `<Modal variant="overlay">`

**Why:** the simplest shell — a centered card with no dismissal logic of its own — so it validates the `overlay` variant before the harder migrations. Today the card sits in a plain `.gateContainer` with no portal, scrim, focus management, or scroll lock.

**Files:**
- Modify: `app/components/ClientGalleryGate/ClientGalleryGate.tsx`
- Test: `tests/components/ClientGalleryGate.test.tsx` (existing — must stay green; the gate's `role="dialog"` is now provided by `<Modal>`)

- [ ] **Step 1 — Capture the green baseline:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ClientGalleryGate.test.tsx
```
Expected output: PASS (record the count).

- [ ] **Step 2 — Wrap both render branches in `<Modal>`.** The gate is always shown when mounted (the wrapper unmounts it on unlock), so `open` is always `true` and `onClose` is a no-op (there is no dismiss affordance — the only exit is a successful unlock that unmounts the component). Add the import and wrap each returned card.

Add to the imports block:
```tsx
import { Modal } from '@/app/components/ui/Modal/Modal';
```

Replace the `unlocking` branch (currently `return (<div className={styles.gateContainer}>…</div>)`) with:
```tsx
  if (submitState === 'unlocking') {
    return (
      <Modal open onClose={() => {}} variant="overlay" labelledBy="gate-title">
        <div className={styles.gateCard}>
          <h1 id="gate-title" className={styles.gateTitle}>
            {collection.title}
          </h1>
          <p className={styles.gateSubtitle}>Client Gallery</p>
          <p className={styles.gateLoading} role="status" aria-live="polite">
            <span className={styles.gateSpinner} aria-hidden="true" />
            Loading gallery…
          </p>
        </div>
      </Modal>
    );
  }
```

Replace the main `return (<div className={styles.gateContainer}>…</div>)` with:
```tsx
  return (
    <Modal open onClose={() => {}} variant="overlay" labelledBy="gate-title">
      <div className={styles.gateCard}>
        <h1 id="gate-title" className={styles.gateTitle}>
          {collection.title}
        </h1>
        <p className={styles.gateSubtitle}>Client Gallery</p>

        <form onSubmit={handleSubmit} className={styles.gateForm}>
          <label htmlFor="gallery-password" className={styles.gateLabel}>
            Enter the password to view this gallery
          </label>
          <input
            id="gallery-password"
            type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            className={styles.gateInput}
            placeholder="Gallery password"
            autoFocus
            autoComplete="off"
            disabled={isVerifying}
          />
          {error && <p className={styles.gateError}>{error}</p>}
          <button type="submit" className={styles.gateButton} disabled={isVerifying}>
            {isVerifying ? 'Verifying...' : 'Enter Gallery'}
          </button>
        </form>
      </div>
    </Modal>
  );
```

Note: the heading went from `<h1 className={styles.gateTitle}>` to additionally carry `id="gate-title"` so `<Modal labelledBy>` can reference it. The `.gateContainer` wrapper is gone (the backdrop is now the Modal's). Leave `.gateContainer` in the SCSS for now — Phase 4 of the master plan owns dead-CSS removal; deleting it here is out of scope.

- [ ] **Step 3 — Verify tests + types.** The existing test asserts the title, subtitle, form, and error states render; those are unchanged. If a test queried `.gateContainer` directly it must be re-pointed at `screen.getByRole('dialog')`:
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ClientGalleryGate.test.tsx
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
```
Expected output: same test count PASS; tsc clean.

- [ ] **Step 4 — Lint + commit:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/components/ClientGalleryGate/ClientGalleryGate.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/components/ClientGalleryGate/ClientGalleryGate.tsx
git add app/components/ClientGalleryGate/ClientGalleryGate.tsx
git commit -m "refactor(client-gallery): mount gate card in <Modal variant=overlay>

Gate now gets the portal, scrim, focus trap, and scroll lock from <Modal>
instead of a bare .gateContainer div (review §6a-rank-1).

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 3 — Migrate `TextBlockCreateModal` onto `<Modal variant="overlay">`

**Why:** a second independent backdrop + portal-less centered card + a third bespoke close-button style (review §3). It also threads a `scrollPosition` prop only to drive a manual `top` offset that the Modal makes unnecessary.

**Files:**
- Modify: `app/components/TextBlockCreateModal/TextBlockCreateModal.tsx`
- Modify: `app/components/TextBlockCreateModal/TextBlockCreateModal.module.scss` (delete `.modalWrapper`)
- Modify: the mount site that passes `scrollPosition` (find with grep in Step 1)

- [ ] **Step 1 — Find the call site + capture baseline.** The component takes `scrollPosition` and is rendered somewhere in the manage flow:
```bash
grep -rn "TextBlockCreateModal" app/ ; echo "exit: $?"
/opt/homebrew/bin/node node_modules/.bin/jest -t "TextBlock" 2>/dev/null; echo "jest exit: $?"
```
Expected output: at least the component file + one mount site (likely `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx`). Record the mount site path for Step 4.

- [ ] **Step 2 — Replace the wrapper with `<Modal>` and drop `scrollPosition`.** Edit `TextBlockCreateModal.tsx`.

Update imports (add `Modal` + `CloseButton`):
```tsx
'use client';

import { type SubmitEvent, useState } from 'react';

import { LoadingSpinner } from '@/app/components/LoadingSpinner/LoadingSpinner';
import { CloseButton } from '@/app/components/ui/CloseButton/CloseButton';
import { Modal } from '@/app/components/ui/Modal/Modal';

import styles from './TextBlockCreateModal.module.scss';
```

Update the props interface (remove `scrollPosition`):
```tsx
interface TextBlockCreateModalProps {
  onClose: () => void;
  onSubmit: (data: {
    content: string;
    format: 'plain' | 'markdown' | 'html';
    align: 'left' | 'center' | 'right';
  }) => Promise<void>;
}
```

Update the signature (remove `scrollPosition`):
```tsx
export default function TextBlockCreateModal({ onClose, onSubmit }: TextBlockCreateModalProps) {
```

Replace the entire `return (…)` block (the outer `.modalWrapper` div with its backdrop-click handler, the `.modalContent` div, and the bespoke `.closeButton`) with a `<Modal>` whose children are the existing header/form. The backdrop click is now the Modal's; the close glyph becomes `<CloseButton>`:
```tsx
  return (
    <Modal open onClose={handleCancel} variant="overlay" labelledBy="text-block-modal-title">
      <div className={styles.modalContent}>
        <div className={styles.modalHeader}>
          <h2 id="text-block-modal-title" className={styles.heading}>
            Create New Text Block
          </h2>
          <CloseButton onClick={handleCancel} aria-label="Close modal" />
        </div>

        {error && <div className={styles.errorMessage}>{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className={styles.formGroup}>
            <label className={styles.formLabel}>Text Content *</label>
            <textarea
              value={content}
              onChange={e => setContent(e.target.value)}
              className={styles.formTextarea}
              placeholder="Enter text content for the new block..."
              rows={8}
              required
              autoFocus
            />
          </div>

          <div className={styles.formRow}>
            <div className={styles.formGroup}>
              <label className={styles.formLabel}>Format</label>
              <select
                value={format}
                onChange={e => setFormat(e.target.value as 'plain' | 'markdown' | 'html')}
                className={styles.formSelect}
              >
                <option value="plain">Plain Text</option>
                <option value="markdown">Markdown</option>
                <option value="html">HTML</option>
              </select>
            </div>

            <div className={styles.formGroup}>
              <label className={styles.formLabel}>Alignment</label>
              <select
                value={align}
                onChange={e => setAlign(e.target.value as 'left' | 'center' | 'right')}
                className={styles.formSelect}
              >
                <option value="left">Left</option>
                <option value="center">Center</option>
                <option value="right">Right</option>
              </select>
            </div>
          </div>

          <div className={styles.formActions}>
            <button
              type="button"
              onClick={handleCancel}
              className={styles.cancelButton}
              disabled={saving}
            >
              Cancel
            </button>
            <button
              type="submit"
              className={styles.submitButton}
              disabled={saving || !content.trim()}
            >
              {saving ? (
                <>
                  <LoadingSpinner size="small" color="white" />
                  <span style={{ marginLeft: '8px' }}>Creating...</span>
                </>
              ) : (
                'Create Text Block'
              )}
            </button>
          </div>
        </form>
      </div>
    </Modal>
  );
```

- [ ] **Step 3 — Delete the dead backdrop SCSS.** In `TextBlockCreateModal.module.scss`, delete the entire `.modalWrapper { … }` rule (the `position: fixed; inset: 0; … background-color: rgb(0,0,0,0.85); z-index: var(--z-fullscreen); … !important resets` block at the top). Also delete the `.closeButton { … }` rule — the glyph is now `<CloseButton>`. Keep `.modalContent`, `.modalHeader`, `.heading`, `.errorMessage`, `.formGroup`, `.formRow`, `.formLabel`, `.formTextarea`, `.formSelect`, `.formActions`, `.cancelButton`, `.submitButton` (still used as children styles). The `.modalContent` background/padding/border-radius now sits inside the Modal's `overlay` dialog — leave them; the Modal's `.dialog` is transparent-bordered and `.modalContent` provides the card chrome.

- [ ] **Step 4 — Drop `scrollPosition` at the mount site.** In the file from Step 1 (e.g. `ManageClient.tsx`), remove the `scrollPosition={…}` prop from the `<TextBlockCreateModal …>` usage. If `scrollPosition` was computed solely for this modal (and also for `ImageMetadataModal`, migrated in Task 4), leave the computation until Task 4 removes the last consumer.

- [ ] **Step 5 — Verify:**
```bash
grep -rn "scrollPosition" app/components/TextBlockCreateModal ; echo "exit: $?"   # expect no matches in the component
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest -t "TextBlock" 2>/dev/null; echo "jest exit: $?"
```
Expected output: no `scrollPosition` in the component; tsc clean; any TextBlock tests PASS (or "no tests found" → exit 1, acceptable if none exist).

- [ ] **Step 6 — Lint + commit:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/components/TextBlockCreateModal/TextBlockCreateModal.tsx app/components/TextBlockCreateModal/TextBlockCreateModal.module.scss
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/components/TextBlockCreateModal/TextBlockCreateModal.tsx
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/TextBlockCreateModal/TextBlockCreateModal.module.scss'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
git add app/components/TextBlockCreateModal
git commit -m "refactor(text-block): adopt <Modal variant=overlay> + <CloseButton>

Drops the bespoke backdrop/.modalWrapper, the scrollPosition prop, and the
third close-button style in favor of the canonical Modal (review §6a-rank-1, §3).

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```
(Add the modified mount-site file to `git add` as well, e.g. `git add app/\(admin\)/collection/manage/\[\[...slug\]\]/ManageClient.tsx`.)

---

## Task 4 — Migrate `ImageMetadataModal` onto `<Modal variant="sheet">` (remove the `position:absolute + 100vh + top:scrollPosition` footgun)

**Why:** this is the headline fix of §6a-rank-1. The modal renders an outer `<div className={styles.metadataModalWrapper} style={{ top: scrollPosition }}>` that is `position: absolute; inset: 0; width: 100vw; height: 100vh;` with `!important` transform/perspective resets — a fragile substitute for a portal. The `scrollPosition` prop exists only to push that absolutely-positioned wrapper down to the current scroll offset. `<Modal>` (portal + `position:fixed` backdrop + `useBodyScrollLock`) makes all of it unnecessary.

**Files:**
- Modify: `app/components/ImageMetadata/ImageMetadataModal.tsx`
- Modify: `app/components/ImageMetadata/ImageMetadataModal.module.scss` (delete the `.metadataModalWrapper` positioning hack)
- Modify: the mount site passing `scrollPosition` (same `ManageClient.tsx` from Task 3 Step 1)

- [ ] **Step 1 — Capture the baseline:**
```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ImageMetadata 2>/dev/null; echo "jest exit: $?"
```
Expected output: PASS (record count), or "no tests" → exit 1 (acceptable; rely on tsc + visual).

- [ ] **Step 2 — Remove the `scrollPosition` prop + add Modal/CloseButton imports.**

In the imports block, add:
```tsx
import { CloseButton } from '@/app/components/ui/CloseButton/CloseButton';
import { Modal } from '@/app/components/ui/Modal/Modal';
```

In `interface ImageMetadataModalProps`, delete this line (currently the first member):
```tsx
  scrollPosition: number;
```

In the `export default function ImageMetadataModal({ … })` destructure, delete `scrollPosition,` (first destructured name).

- [ ] **Step 3 — Replace the outer wrapper with `<Modal>`.** The current outer element is:
```tsx
    <div
      className={styles.metadataModalWrapper}
      style={{
        top: `${scrollPosition}px`,
      }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="metadata-modal-title"
    >
```
Replace that opening tag with:
```tsx
    <Modal
      open
      onClose={handleCancel}
      variant="sheet"
      labelledBy="metadata-modal-title"
    >
```
The `role`/`aria-modal`/`aria-labelledby` move onto the Modal's dialog (`labelledBy` already points at the existing `id="metadata-modal-title"` `<h2>`). Then replace the matching closing `</div>` of that wrapper (the last line before the function's closing `}` — currently after the `{/* Close Button */}` block) with `</Modal>`.

- [ ] **Step 4 — Replace the bespoke close button with `<CloseButton>`.** The current trailing close button is:
```tsx
      {/* Close Button */}
      <button
        className={styles.closeButton}
        onClick={handleCancel}
        aria-label="Close metadata editor"
        disabled={saving}
      >
        <span aria-hidden="true">&#10005;</span>
      </button>
```
Replace it with:
```tsx
      {/* Close Button */}
      <CloseButton onClick={handleCancel} aria-label="Close metadata editor" disabled={saving} />
```
Keep its position as the last child inside `<Modal>` (after the metadata `</div>` section, before `</Modal>`).

- [ ] **Step 5 — Delete the positioning hack from `ImageMetadataModal.module.scss`.** Delete this entire rule (lines ~4–27, the `.metadataModalWrapper` block):
```scss
.metadataModalWrapper {
  position: absolute;
  inset: 0;
  width: 100vw;
  height: 100vh;
  display: flex;
  flex-direction: row;
  background-color: rgb(0, 0, 0, 0.95);
  z-index: var(--z-fullscreen);
  overflow: hidden;

  /* Reset inherited styles */
  margin: 0 !important;
  padding: 0 !important;
  transform: none !important;
  perspective: none !important;

  /* Prevent scrolling interactions */
  overscroll-behavior: none;

  @media (width <= 1024px) {
    flex-direction: column;
  }
}
```
The two-column split-screen layout (`flex-direction: row`, and `column` under 1024px) now belongs on the dialog's inner content, not the deleted wrapper. Add a new wrapping `<div className={styles.metadataLayout}>` immediately inside `<Modal>` around the existing `.imageSection` + `.metadataSection` (the close button stays a sibling, outside `.metadataLayout`, so it floats over the corner as before), and add this rule to the SCSS where `.metadataModalWrapper` was:
```scss
.metadataLayout {
  display: flex;
  flex-direction: row;
  width: 100%;
  height: 100%;
  background-color: rgb(0, 0, 0, 0.95);
  overflow: hidden;
  overscroll-behavior: none;

  @media (width <= 1024px) {
    flex-direction: column;
  }
}
```
Also delete the `.closeButton { … }` rule in this SCSS (now provided by `<CloseButton>`); confirm with Step 7's grep. The JSX structure inside `<Modal>` becomes:
```tsx
    <Modal open onClose={handleCancel} variant="sheet" labelledBy="metadata-modal-title">
      <div className={styles.metadataLayout}>
        {/* Image Section - Left Side */}
        <div className={styles.imageSection}>
          {/* …unchanged… */}
        </div>

        {/* Metadata Section - Right Side */}
        <div className={styles.metadataSection}>
          {/* …unchanged… */}
        </div>
      </div>

      {/* Close Button */}
      <CloseButton onClick={handleCancel} aria-label="Close metadata editor" disabled={saving} />
    </Modal>
```

- [ ] **Step 6 — Drop `scrollPosition` at the mount site.** In `ManageClient.tsx`, remove `scrollPosition={…}` from the `<ImageMetadataModal …>` usage. If nothing else now reads the scroll-position value (Task 3 removed the other consumer), also delete its computation/state. Verify with:
```bash
grep -rn "scrollPosition" app/ ; echo "exit: $?"
```
Expected output: no remaining `scrollPosition` references tied to these two modals (any unrelated hits, e.g. in `FullScreenModal`'s `FullScreenState.scrollPosition`, are separate and out of scope here).

- [ ] **Step 7 — Verify:**
```bash
grep -n "metadataModalWrapper\|\.closeButton" app/components/ImageMetadata/ImageMetadataModal.module.scss ; echo "exit: $?"
grep -n "metadataModalWrapper\|styles.closeButton" app/components/ImageMetadata/ImageMetadataModal.tsx ; echo "exit: $?"
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ImageMetadata 2>/dev/null; echo "jest exit: $?"
```
Expected output: no `metadataModalWrapper` / `.closeButton` matches (grep exit 1); tsc clean; ImageMetadata tests PASS (or none).

- [ ] **Step 8 — Lint + commit:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/components/ImageMetadata/ImageMetadataModal.tsx app/components/ImageMetadata/ImageMetadataModal.module.scss
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/components/ImageMetadata/ImageMetadataModal.tsx
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/ImageMetadata/ImageMetadataModal.module.scss'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
git add app/components/ImageMetadata/ImageMetadataModal.tsx app/components/ImageMetadata/ImageMetadataModal.module.scss
git commit -m "refactor(image-metadata): adopt <Modal variant=sheet>, remove 100vh footgun

Deletes .metadataModalWrapper (position:absolute + inset:0 + 100vw/100vh +
top:scrollPosition + !important resets) and the scrollPosition prop; the modal
now uses the portal + fixed backdrop + scroll lock from <Modal> and a
<CloseButton> (review §6a-rank-1, §3).

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```
(Add the modified `ManageClient.tsx` to `git add` as well.)

---

## Task 5 — Migrate `MenuDropdown` onto `<Modal variant="sheet">` (fold hand-rolled click-outside / Esc / scroll-lock onto `useClickOutside` + `Modal`)

**Why:** `MenuDropdown` re-implements three dismissal concerns: a `mousedown` click-outside effect (desktop-only), a `keydown` Escape effect, and `useBodyScrollLock(isOpen)` — exactly the duplication §6a-rank-1 and §3 call out. `<Modal>` already owns Escape + scroll lock; `useClickOutside` (existing) owns the desktop click-outside. Note the dropdown's intentional **desktop-only** click-outside: on mobile it must NOT close on outside tap. We preserve that by gating `useClickOutside` on `isDesktop`.

**Files:**
- Modify: `app/components/MenuDropdown/MenuDropdown.tsx`
- Test: any existing MenuDropdown test must stay green (grep in Step 1)

- [ ] **Step 1 — Baseline + check for tests:**
```bash
grep -rln "MenuDropdown" tests/ ; echo "exit: $?"
/opt/homebrew/bin/node node_modules/.bin/jest -t "MenuDropdown" 2>/dev/null; echo "jest exit: $?"
```
Expected output: record whether a test exists; if so it must stay green.

- [ ] **Step 2 — Swap the dismissal effects + outer markup.** Edit `MenuDropdown.tsx`.

Update imports — add `Modal`, `useClickOutside`, drop the now-unused `useBodyScrollLock` import; keep `useEffect`, `useRef`, `useState`, `useTransition`. New import block:
```tsx
'use client';

import { CircleX } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useEffect, useRef, useState, useTransition } from 'react';

import { About } from '@/app/components/About/About';
import { ContactForm } from '@/app/components/ContactForm/ContactForm';
import GitHubIcon from '@/app/components/Icons/GitHubIcon';
import InstagramIcon from '@/app/components/Icons/InstagramIcon';
import { Modal } from '@/app/components/ui/Modal/Modal';
import { BREAKPOINTS } from '@/app/constants';
import { useClickOutside } from '@/app/hooks/useClickOutside';
import { clearCacheAction } from '@/app/lib/actions/clearCache';
import { collectionStorage } from '@/app/lib/storage/collectionStorage';
import { isLocalEnvironment } from '@/app/utils/environment';

import styles from './MenuDropdown.module.scss';
```

Delete the hand-rolled **click-outside `useEffect`** (the `handleClickOutside` block, ~lines 115–130), the **Escape `useEffect`** (the `handleKeyDown` block, ~lines 133–145), and the `useBodyScrollLock(isOpen);` call (~line 147). Replace them with a desktop-gated `useClickOutside` plus a tracked desktop flag (the dropdown closes on outside click only on desktop — mobile keeps it open). Add this near the other hooks, after `const dropdownRef = useRef<HTMLDivElement>(null);`:
```tsx
  // Desktop-only outside-click dismissal — mirrors the previous hand-rolled effect
  // (mobile intentionally does NOT close on an outside tap). The Modal owns Escape
  // and scroll-lock, so only the click-outside concern remains here.
  const [isDesktop, setIsDesktop] = useState(false);
  useEffect(() => {
    const check = () => setIsDesktop(window.innerWidth >= BREAKPOINTS.mobile);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  useClickOutside(dropdownRef, isOpen && isDesktop, onClose);
```
Keep the "Reset forms when dropdown closes" and "Preload About image on open" effects — they are not dismissal logic.

- [ ] **Step 3 — Wrap the panel in `<Modal variant="sheet">` and remove the `if (!isOpen) return null` early return** (the Modal's `open` prop now controls mounting). Change the early return line:
```tsx
  if (!isOpen) return null;

  return (
    <div className={styles.dropdown} ref={dropdownRef}>
```
to:
```tsx
  return (
    <Modal open={isOpen} onClose={onClose} variant="sheet">
      <div className={styles.dropdown} ref={dropdownRef}>
```
and change the final closing `</div>` of the dropdown root (the last line before the function's closing `}`) to:
```tsx
      </div>
    </Modal>
  );
```
The `ref={dropdownRef}` stays on the inner `.dropdown` div so `useClickOutside` measures clicks against the panel (the Modal's backdrop is outside it; a desktop backdrop click therefore registers as "outside" and closes — matching the old behavior). The `CircleX` close button (`.dropdownCloseButtonWrapper_button`) stays as-is for this task; converting it to `<CloseButton>` is deferred to the Button/CloseButton migration table in the parent plan (Task 1.1 Step 8) to keep this commit focused on dismissal-logic consolidation.

- [ ] **Step 4 — Verify the hand-rolled dismissal logic is gone:**
```bash
grep -n "useBodyScrollLock\|addEventListener('keydown'\|addEventListener('mousedown'" app/components/MenuDropdown/MenuDropdown.tsx ; echo "exit: $?"
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest -t "MenuDropdown" 2>/dev/null; echo "jest exit: $?"
```
Expected output: no `useBodyScrollLock` / manual `keydown` / `mousedown` listeners in the file (grep exit 1); tsc clean; MenuDropdown tests PASS (or none).

- [ ] **Step 5 — Lint + commit:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/components/MenuDropdown/MenuDropdown.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/components/MenuDropdown/MenuDropdown.tsx
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
git add app/components/MenuDropdown/MenuDropdown.tsx
git commit -m "refactor(menu): adopt <Modal variant=sheet>, fold dismissal onto useClickOutside

Removes MenuDropdown's three hand-rolled dismissal effects (mousedown
click-outside, keydown Escape, useBodyScrollLock) in favor of <Modal>
(portal + Escape + scroll lock) plus a desktop-gated useClickOutside that
preserves the mobile no-outside-tap behavior (review §6a-rank-1, §3).

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Task 6 — Migrate `FullScreenModal` onto `<Modal variant="fullscreen">` (content/EXIF panel becomes children; keep the image render)

**Why:** `FullScreenModal` is the one shell that already does `createPortal(modalContent, document.body)` correctly — but it duplicates the portal + the dialog ARIA + the `fullscreen-open` body-class management that `<Modal>` now centralizes. Folding it onto `<Modal variant="fullscreen">` removes that duplication and gives the viewer a real focus trap + focus return for free. **The image / GIF rendering stays exactly as-is** — only the portal/dialog wrapper is replaced.

**Files:**
- Modify: `app/components/FullScreenModal/FullScreenModal.tsx`
- Test: any existing FullScreen test must stay green (grep in Step 1)

> **Sequencing note:** this task assumes Task 0.2 of the parent plan (delete `FsDebug`) has landed, so there is no `{fsdebug && <FsDebug />}` render or `FsDebug` import to carry. If `FsDebug` is still present, remove it as part of this task (delete the import on line 19, the `const fsdebug = …` block on lines 101–103, and the `{fsdebug && <FsDebug />}` render on line 306) — that is the same change Task 0.2 makes.

- [ ] **Step 1 — Baseline:**
```bash
grep -rln "FullScreen" tests/ ; echo "exit: $?"
/opt/homebrew/bin/node node_modules/.bin/jest -t "FullScreen" 2>/dev/null; echo "jest exit: $?"
```
Expected output: record whether a test exists; if so it must stay green.

- [ ] **Step 2 — Replace the portal + dialog wrapper with `<Modal>`.** `FullScreenModal` currently builds `modalContent` and ends with `if (typeof document !== 'undefined') return createPortal(modalContent, document.body); return null;`. The `<Modal>` now owns the portal and the `role="dialog"`/`aria-modal`/`aria-label` semantics.

Update imports — add `Modal`, drop the now-unused `createPortal`:
```tsx
import { Modal } from '@/app/components/ui/Modal/Modal';
```
and remove `import { createPortal } from 'react-dom';`.

The component keeps the existing early returns (`if (!fullScreenState) return null;` and `if (!currentImage) return null;`) and all the derived values. The `useEffect` that toggles `document.body.classList.add('fullscreen-open')` **stays** — it drives the iOS dark-canvas fix in `globals.css` (`html:has(body.fullscreen-open)`), which is independent of scroll-lock; the Modal's `useBodyScrollLock` handles scroll, this class handles the canvas paint. (See `globals.css` comment: "intentionally scoped to fullscreen-open, NOT scroll-locked".)

Change the `modalContent` opening element from:
```tsx
  const modalContent = (
    <div
      ref={modalRef}
      className={styles.imageFullScreenWrapper}
      role="dialog"
      aria-modal="true"
      aria-label="Image viewer"
    >
```
to a fragment-free inner wrapper (the dialog ARIA now lives on the Modal's dialog; `modalRef` stays on the inner wrapper because callers measure swipe geometry against it):
```tsx
  const modalContent = (
    <div ref={modalRef} className={styles.imageFullScreenWrapper}>
```
Keep the entire inner body (`.overlayContainer`, the `<Image>`/`<video>` render, the `.metadataOverlay`/`.metadataContent` panel, the prev/next nav buttons, and the close button) **unchanged**.

Then replace the trailing `if (typeof document !== 'undefined') { return createPortal(modalContent, document.body); } return null;` with:
```tsx
  return (
    <Modal
      open
      onClose={hideImage}
      variant="fullscreen"
      labelledBy={currentImage.title ? 'fullscreen-title' : undefined}
    >
      {modalContent}
    </Modal>
  );
```
`open` is always `true` here because the function already returned `null` above when `fullScreenState`/`currentImage` is absent. `onClose={hideImage}` wires Escape + backdrop click to the existing close handler (`hideImage` already accepts an optional event). For `labelledBy`, the metadata title is conditional — if you want the dialog labelled by the photo title, add `id="fullscreen-title"` to the existing `.metadataTitle` div (`<div id="fullscreen-title" className={styles.metadataTitle}>{currentImage.title}</div>`); if not, pass `labelledBy={undefined}` and keep the previous `aria-label="Image viewer"` by setting it on the inner wrapper instead. **Choose the title-id approach** (better semantics) and add the `id`.

> **Backdrop-click vs swipe:** the existing inner `.overlayContainer` has its own `onClick={handleOverlayClick}` that calls `hideImage()` unless `isSwiping.current`. The Modal's backdrop is *behind/around* `modalContent`; in the `fullscreen` variant the dialog fills the viewport so the Modal backdrop is not reachable by a normal tap — the existing overlay-click handler continues to own tap-to-close (and its swipe guard). This is intended: keep `handleOverlayClick` as-is so swipe-to-navigate is not misread as a close.

- [ ] **Step 3 — Verify:**
```bash
grep -n "createPortal\|aria-modal" app/components/FullScreenModal/FullScreenModal.tsx ; echo "exit: $?"
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest -t "FullScreen" 2>/dev/null; echo "jest exit: $?"
```
Expected output: no `createPortal`/`aria-modal` left in the file (the Modal owns both) — grep exit 1; tsc clean; FullScreen tests PASS (or none).

- [ ] **Step 4 — Lint + commit:**
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/components/FullScreenModal/FullScreenModal.tsx
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/components/FullScreenModal/FullScreenModal.tsx
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
git add app/components/FullScreenModal/FullScreenModal.tsx
git commit -m "refactor(fullscreen): adopt <Modal variant=fullscreen>; keep image render

Replaces the hand-rolled createPortal + dialog ARIA wrapper with <Modal>, which
adds a focus trap + focus return the viewer lacked. The image/GIF render, swipe
overlay, nav buttons, EXIF panel, and the fullscreen-open body class (iOS canvas
fix) are unchanged (review §6a-rank-1, §5).

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Verification (full pass before any PR)

Run the project pipeline (per `CLAUDE.md`; `npm`/`npx` not on PATH):
```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write 'app/components/ui/Modal/**/*' 'app/components/{FullScreenModal,ImageMetadata,TextBlockCreateModal,MenuDropdown,ClientGalleryGate}/**/*.{ts,tsx,scss}' 'tests/components/ui/Modal.test.tsx'
/opt/homebrew/bin/node node_modules/.bin/eslint --fix 'app/components/ui/Modal/**/*.{ts,tsx}' 'app/components/{FullScreenModal,ImageMetadata,TextBlockCreateModal,MenuDropdown,ClientGalleryGate}/**/*.{ts,tsx}'
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix 'app/components/ui/Modal/Modal.module.scss' 'app/components/{ImageMetadata,TextBlockCreateModal}/**/*.scss'
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest
```
Expected: prettier/eslint/stylelint exit 0; tsc prints nothing; the full jest suite is green (the new `Modal.test.tsx` adds 7 tests; all migrated-component tests stay at their prior counts).

**Grep gates (every migration removed its hand-rolled shell):**
```bash
grep -rn "metadataModalWrapper" app/ ; echo "exit: $?"        # expect none (Task 4)
grep -rn "scrollPosition" app/components/ImageMetadata app/components/TextBlockCreateModal ; echo "exit: $?"  # expect none
grep -n "createPortal" app/components/FullScreenModal/FullScreenModal.tsx ; echo "exit: $?"  # expect none (Task 6)
grep -n "useBodyScrollLock" app/components/MenuDropdown/MenuDropdown.tsx ; echo "exit: $?"   # expect none (Task 5)
```

**Visual (dev server :3001 — user keeps :3000):**
- ImageMetadataModal: open from manage, scroll the page first, reopen — the editor covers the viewport with no top-offset gap (the `scrollPosition` bug is gone); Escape closes it; focus is trapped inside; closing returns focus to the trigger.
- TextBlockCreateModal: opens centered; backdrop click and Escape both close; the close glyph is the shared `<CloseButton>`.
- MenuDropdown: opens as a sheet; Escape closes; desktop outside-click closes; **mobile outside-tap does NOT close** (regression check); page behind is scroll-locked.
- ClientGalleryGate: the gate card is centered on the scrim; the verifying/unlocking states still render; focus lands in the password field on open.
- FullScreenModal: image/GIF render unchanged; swipe-to-navigate still works (not misread as close); Escape closes; arrows + EXIF panel unchanged; on iOS the dark canvas fix still holds (no white strip).

---

## Suggested commit sequence

1. `feat(ui): add canonical Modal primitive (portal, focus trap, scroll lock)` — Task 1
2. `refactor(client-gallery): mount gate card in <Modal variant=overlay>` — Task 2
3. `refactor(text-block): adopt <Modal variant=overlay> + <CloseButton>` — Task 3
4. `refactor(image-metadata): adopt <Modal variant=sheet>, remove 100vh footgun` — Task 4
5. `refactor(menu): adopt <Modal variant=sheet>, fold dismissal onto useClickOutside` — Task 5
6. `refactor(fullscreen): adopt <Modal variant=fullscreen>; keep image render` — Task 6

Each commit passes `tsc --noEmit` + `jest` independently. Tasks 2–6 are mutually independent given Task 1 — they parallelize across agents (one shell per agent).

---

## Self-review: spec-coverage checklist

| Design-review finding | Plan task | Status |
|-----------------------|-----------|--------|
| §6a-rank-1 — one `<Modal variant=overlay\|sheet\|fullscreen>` owning portal, backdrop, Esc, focus trap + return, `useBodyScrollLock` | Task 1 | ✅ built test-first |
| §6a-rank-1 / §3 — collapse 5 modal shells | Tasks 2–6 (gate, text-block, image-metadata, menu, fullscreen) | ✅ one task each |
| §3 / §5 — `ImageMetadataModal` `position:absolute + inset:0 + 100vh + top:scrollPosition` footgun | Task 4 (deletes `.metadataModalWrapper` + `scrollPosition`) | ✅ exact lines shown |
| §5 — "No focus trap / focus return in any modal or the dropdown" | Task 1 (trap + return) inherited by Tasks 2–6 | ✅ |
| §3 / §6a-rank-1 — `MenuDropdown` re-implements click-outside / Esc / scroll-lock | Task 5 (folds onto `useClickOutside` + `Modal`) | ✅ desktop-only behavior preserved |
| §3 — `FullScreenModal` correct-but-duplicated portal/dialog wrapper | Task 6 (image render kept; portal/ARIA delegated) | ✅ |
| §3 — third/fourth bespoke close-button styles (TextBlock ghost glyph, ImageMetadata `✕`) | Tasks 3 & 4 (replace with `<CloseButton>`) | ✅ |
| §6a-rank-2 — `<CloseButton>` primitive the Modal close composes | **Prerequisite** (parent plan Task 1.1) | ⛓ stated, not built here |
| §1.1 / Phase 0 — painted surface + alias tokens (`--color-accent`, `--radius-sm`, etc. used by Modal SCSS) | **Prerequisite** (parent plan Task 0.1) | ⛓ stated, not built here |
| `MenuDropdown` `CircleX` → `<CloseButton>` conversion | **Deferred** to parent Task 1.1 Step 8 migration table (kept this task focused on dismissal logic) | 🔻 out of scope, flagged |
| `.gateContainer` dead CSS after Task 2; `@keyframes gateSpinnerRotate` dup | **Deferred** to parent Phase 4 (dead-CSS sweep) | 🔻 out of scope, flagged |

**Placeholder scan:** every code step is complete fenced code against verified signatures (`ModalProps`, `useBodyScrollLock(enabled)`, `useClickOutside(ref, isOpen, onClose)`, `LoadingSpinner`, the real prop interfaces of all 5 shells); every run step has an exact command + expected output; no TBD / "implement later" / "similar to above".

**Type consistency:** `ModalProps` / `ModalVariant` are declared once in Task 1 and referenced by every migration. `variant` values (`overlay` / `sheet` / `fullscreen`) map 1:1 to the SCSS classes and to the per-shell choices in Tasks 2–6.
