# Related / Sibling Collections — Mutual Association + Metadata-Block Links

**Status:** Approved design (brainstormed 2026-05-31)
**Date:** 2026-05-31
**Branch:** `0143-sibling-collections` (proposed — not yet created; current working branch is the unrelated `0142-mobile-landscape-fullscreen-padding`)
**Scope:** Cross-repo — spans `edens.zac` (frontend, this repo) and `edens.zac.backend` (backend, sibling repo)
**Companion spec:** A condensed backend companion may be filed at `edens.zac.backend/docs/superpowers/specs/2026-05-31-sibling-collections-backend.md` during the plan phase. Keep both in sync if revised.

## Problem

A collection (e.g. "Dolomites") may have closely-related *variant* collections — the same subject shot on film vs digital, or two edits of one trip — that today live as entirely separate pages with unique slugs (`dolomites-film`, `dolomites-2025`) and no link between them. A visitor landing on one has no way to discover or hop to the other. The existing grouping mechanisms don't fit this need:

- **Location** grouping (`/location/{slug}`) is automatic and coarse — it groups by *place*, not by curated relatedness.
- **Parent/child** collections (`collection_content` → `ContentCollectionEntity`) are *hierarchical* — they require a PARENT container page and model "contains", not "is a peer of".

We want a lightweight, **curated, mutual** "these collections are siblings" relationship, surfaced as navigable links on the collection page.

## Goal

1. Let the operator **hand-pick sibling collections** for any collection, in the existing Manage page, alongside the existing child-collection picker.
2. Store siblings as a **mutual (symmetric)** relationship: marking B a sibling of A automatically makes A a sibling of B. Set once on either side; both pages link to each other.
3. Render a collection's siblings as **navigable text links in the metadata text block** beside the hero (reusing the existing location/tag link pattern), visibility-filtered so no dead links leak to the public.

## Non-goals

- **No title/slug change.** An earlier brainstorming thread explored decoupling display title from slug and adding a per-collection "variant label"; that direction was **dropped**. This spec does not touch titles, slugs, or the hero overlay.
- **No automatic similarity.** Siblings are 100% curated. We do not derive them from shared location/tags.
- **No directional "see also".** The relationship is always mutual. One-way relations are out of scope.
- **No cover thumbnails (v1).** Siblings render as text links, matching the existing metadata-block style. A richer thumbnail treatment is a backlog item.
- **No reordering / per-sibling visibility metadata.** Unlike children, sibling links carry no `orderIndex` or per-link `visible` flag. Display order is by collection title.

## Decisions locked during brainstorming

| Topic | Choice | Why |
|---|---|---|
| Relationship semantics | Curated, **mutual/symmetric** | User wants to hand-pick variant peers; "sibling" reads as a two-way relation |
| Storage | New `collection_sibling(collection_id, sibling_collection_id)` join, **reciprocal rows** `(A,B)+(B,A)`, composite PK | Mirrors `collection_people`/`collection_locations`; reciprocal rows make "siblings of X" a single-direction read |
| No join entity POJO | Manipulate `collection_sibling` via SQL in a DAO, no `*Entity` class | Matches `collection_people` / `collection_locations` precedent |
| Write semantics | Incremental `newValue` (add) / `remove` (delete) — **not** full DELETE-then-INSERT | Mutual reciprocal rows mean a full reconcile of one side would have to touch unrelated rows on the other side; incremental add/remove of reciprocal pairs is simpler and safe |
| Response DTO | Add `siblings` to **`CollectionModel`** (single field), reuse existing `Records.CollectionList` / `CollectionListModel` | One field serves both the public render and the manage pre-check (manage payload nests a `CollectionModel`); the list shape already exists in both repos |
| Visibility | Public render filtered to **LISTED** siblings (same rule as child collections); admin/manage payload returns **all** siblings | No dead/hidden links leak publicly; operator can still see/edit every link |
| Admin UI | Extend the existing `CollectionListSelector` into a `Collection \| Sibling \| Child` grid: name on the left, two independent toggle columns | User-specified layout; reuses the existing toggle/state machinery |
| Toggle independence | A pair *can* be both sibling and child (not blocked) | Two orthogonal relationships; mutual exclusivity adds rules with no clear benefit |
| Public render style | `Related:` line of text links in the metadata text block | Smallest change; consistent with existing location/tag links |
| Wire shape for the update | Reuse the existing `CollectionUpdate` shape (`newValue`/`remove`) under a new `siblings` key; backend reads only `collectionId` (ignores `orderIndex`/`visible`) | Lets the frontend reuse the existing selector/toggle logic unchanged |

## Architecture

```
ADMIN WRITE (dev profile):
  Manage page (ManageClient.tsx)
    └─ CollectionListSelector  [ Collection | ☐ Sibling | ☐ Child ]
         ├─ Sibling toggle → updateData.siblings  (CollectionUpdate: newValue/remove)
         └─ Child toggle   → updateData.collections (unchanged)
    └─ Save → PUT /api/admin/collections/{id}  body: { siblings, collections, ... }
                 │
                 ▼
         AdminController.updateCollection  (@Profile("dev"))
           └─ CollectionService.updateContent
                ├─ handleCollectionToCollectionUpdates(...)        // children (unchanged)
                └─ handleSiblingUpdates(parentId, siblings)        // NEW
                     ├─ for each newValue.collectionId: INSERT (A,B) + (B,A)
                     └─ for each remove id:             DELETE (A,B) + (B,A)
                        via CollectionSiblingRepository

PUBLIC READ (both envs):
  Collection page → GET /api/read/collections/{slug}
           CollectionControllerProd.getCollectionBySlug
             └─ CollectionService.getCollectionWithPagination
                  └─ CollectionProcessingUtil.convertToModel(...)
                       ├─ populateCollectionsOnContent(model)
                       ├─ populateSiblings(model, visibilityFiltered)   // NEW
                       │     CollectionSiblingRepository.findSiblings(id, listedOnly)
                       └─ filterNonListedChildCollections(model)
                  ▼
           CollectionModel { ..., siblings: List<CollectionList> }
                  ▼
  contentLayout.buildMetadataItems(collection)
     └─ pushes one { type: 'collection', value: name, slug: '/'+slug } per sibling
  CollectionContentRenderer (TEXT branch)
     └─ NEW render branch: 'collection' items → <Link href={slug}>{value}</Link>  ("Related:")
```

## Data model (backend)

### Flyway migration — `V26__collection_sibling.sql`

Next free version is **V26** (highest current is `V25__add_web_url_to_content_gif.sql`). Style matches `V16__locations_many_to_many.sql` / `V22__collection_people.sql` (BEGIN/COMMIT, `ON DELETE CASCADE`, `idx_{table}_{column}` indexes).

```sql
-- V26__collection_sibling
-- Description: Mutual ("sibling") association between collections. Rows are stored
-- reciprocally: a sibling link between A and B is two rows (A,B) and (B,A), so
-- "siblings of X" is a single-direction lookup on collection_id. ON DELETE CASCADE
-- cleans up both directions when either collection is deleted.

BEGIN;

CREATE TABLE collection_sibling (
    collection_id         BIGINT NOT NULL REFERENCES collection(id) ON DELETE CASCADE,
    sibling_collection_id BIGINT NOT NULL REFERENCES collection(id) ON DELETE CASCADE,
    PRIMARY KEY (collection_id, sibling_collection_id),
    CONSTRAINT chk_collection_sibling_not_self CHECK (collection_id <> sibling_collection_id)
);

CREATE INDEX idx_collection_sibling_collection ON collection_sibling(collection_id);
CREATE INDEX idx_collection_sibling_sibling    ON collection_sibling(sibling_collection_id);

COMMIT;
```

`CHECK (collection_id <> sibling_collection_id)` enforces "no collection is its own sibling" at the DB level. No dedicated entity POJO — the table is manipulated directly via SQL (matches `collection_people`).

## Backend changes (`edens.zac.backend`)

### DAO — `CollectionSiblingRepository`

`dao/CollectionSiblingRepository.java`. Extends `BaseDao`, annotated `@Component`, constructor takes `JdbcTemplate` (matches `CollectionPeopleRepository`). Uses `NamedParameterJdbcTemplate` via `BaseDao`.

Methods:

```java
// Reciprocal insert — idempotent via ON CONFLICT DO NOTHING (composite PK)
void addSibling(Long a, Long b);
//   INSERT INTO collection_sibling (collection_id, sibling_collection_id)
//   VALUES (:a,:b), (:b,:a) ON CONFLICT DO NOTHING

// Reciprocal delete
void removeSibling(Long a, Long b);
//   DELETE FROM collection_sibling
//   WHERE (collection_id = :a AND sibling_collection_id = :b)
//      OR (collection_id = :b AND sibling_collection_id = :a)

// Read siblings of one collection, optionally LISTED-only, as CollectionList rows
List<Records.CollectionList> findSiblings(Long collectionId, boolean listedOnly);
//   SELECT c.id, c.title AS name, c.slug, c.type
//   FROM collection_sibling cs
//   JOIN collection c ON c.id = cs.sibling_collection_id
//   WHERE cs.collection_id = :id
//     [AND c.visibility = 'LISTED']      -- appended when listedOnly
//   ORDER BY c.title ASC
```

> Note: `Records.CollectionList` field is `name`; we alias `c.title AS name` to fill it (the frontend `CollectionListModel.name` already carries collection titles this way — confirmed in `GeneralMetadataDTO.collections`).

### DTO changes

- **`CollectionModel.java`** — add `private List<Records.CollectionList> siblings;` near `tags`/`content` (lines ~77-88). Null/empty when none.
- **`CollectionRequests.Update`** (`CollectionRequests.java`, record lines 43-83) — add field `CollectionUpdate siblings`. Reuses the existing `CollectionUpdate(prev, newValue, remove)` record (lines 191-194). For siblings only `newValue` (add) and `remove` are honored; `prev` and the `orderIndex`/`visible` fields of `ChildCollection` are ignored.

### Service — `CollectionService`

- New method `handleSiblingUpdates(Long parentId, CollectionUpdate siblings)`, called from `updateContent(...)` right after `handleCollectionToCollectionUpdates(...)`:
  - For each `remove` id → `collectionSiblingRepository.removeSibling(parentId, id)`.
  - For each `newValue` entry → `collectionSiblingRepository.addSibling(parentId, entry.collectionId())`.
  - Guard: skip any `collectionId` equal to `parentId` (defensive; DB CHECK also blocks it).
  - No-op when `siblings == null` (partial-update friendly, same gate as `collections`).
- Population: add a dedicated `CollectionProcessingUtil.populateSiblings(CollectionModel model, boolean listedOnly)` (a peer of `populateCollectionsOnContent`) that sets `model.setSiblings(collectionSiblingRepository.findSiblings(model.getId(), listedOnly))`, no-op on null model/id. **Do NOT** thread `listedOnly` through `convertToModel` — its 5-arg signature is stubbed in ~8 tests and shared by `reorderContent`/`convertToFullModel`, so changing it would break them (confirmed during plan authoring).
  - Call `populateSiblings(model, true)` on the **public** read path in `CollectionService.getCollectionWithPagination`, between `populateCollectionsOnContent` and `filterNonListedChildCollections` (LISTED-only).
  - Call `populateSiblings(model, false)` on the **admin** manage payload inside `convertToFullModel` (backs `findBySlug` → `getUpdateCollectionData`) so the operator sees every sibling regardless of visibility.

### Controllers

- **No new endpoints.** Sibling writes ride the existing `PUT /api/admin/collections/{id}` (`AdminController`, `@Profile("dev")`, line 112) via the new `siblings` field on `CollectionRequests.Update`. Sibling reads ride the existing `GET /api/read/collections/{slug}` (`CollectionControllerProd`, line 87) and `GET /api/admin/collections/{slug}/update` (`AdminController`, line 140).

## Frontend changes (`edens.zac`)

### Types

- **`app/types/Collection.ts`**
  - `CollectionModel` (lines 160-205): add `siblings?: CollectionListModel[];`.
  - `CollectionUpdateRequest` (lines 134-154): add `siblings?: CollectionUpdate;` (mirrors `collections?: CollectionUpdate` at line 153).
- **`app/types/Content.ts`**
  - `TextBlockItem` (lines 125-130): extend the union to `'date' | 'location' | 'description' | 'text' | 'tag' | 'collection'`.

### Manage UI — `Collection | Sibling | Child` grid

- **`app/components/CollectionListSelector/CollectionListSelector.tsx`** — extend from a single toggle column to **two relationship columns**. Name on the left; then a **Sibling** toggle column and a **Child** toggle column, each with a header. New/changed props:
  - `siblingSelectedIds` / `childSelectedIds` (or two `getCheckboxState`-style state inputs).
  - `onToggleSibling(collection)` / `onToggleChild(collection)`.
  - Column headers `Sibling` and `Child`.
  - **Backward-compatible (confirmed during plan authoring):** `CollectionListSelector` has two consumers — `ManageClient` *and* `ImageMetadataModal`, with 19 existing tests — so the two-column mode is purely additive: the four new sibling props are optional and, when absent, the component renders its current single-column layout unchanged.
- **`app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx`**
  - Add sibling selection state mirroring the existing child state (lines 800-913): `originalSiblingIds` (from `collection.siblings`), `pendingAddSiblingIds`, `pendingRemoveSiblingIds`, and a `handleSiblingToggle` that mutates `updateData.siblings` (`newValue`/`remove`) exactly like `handleCollectionToggle` mutates `updateData.collections`.
  - `originalSiblingIds` derives from `collection.siblings` (the new field) rather than from `collection.content`.
  - Pass both state sets + handlers into the extended `CollectionListSelector` (the same instance used at line ~1618 with `excludeCollectionId={collection.id}`).
- **`app/(admin)/collection/manage/[[...slug]]/manageUtils.ts`**
  - `buildUpdatePayload` (lines 86-88): add a parallel passthrough — `if (formData.siblings !== undefined) payload.siblings = formData.siblings;`.

### Public render — `Related:` links in the metadata block

- **`app/utils/contentLayout.ts`** — `buildMetadataItems` (lines 429-466): after the tags loop, push one item per sibling:
  ```ts
  if (collection.siblings && collection.siblings.length > 0) {
    for (const sib of collection.siblings) {
      if (sib.slug) {
        items.push({ type: 'collection', value: sib.name, slug: `/${sib.slug}` });
      }
    }
  }
  ```
- **`app/components/Content/CollectionContentRenderer.tsx`** — in the TEXT branch (lines 164-268), add a render block for `'collection'` items: a `Related:` label followed by each item as `<Link href={item.slug!} className={cbStyles.metadataSiblingCollection}>{item.value}</Link>`, placed after the description/tags. Existing `find`/`filter` calls key off other type names, so they will not pick up `'collection'` items.
- **`app/components/Content/ContentComponent.module.scss`** — add `.metadataSiblingCollection` (+ a wrapper/label class), styled like `.metadataLocation`. SCSS runs through Stylelint.

### API layer

- **`app/lib/api/collections.ts`** — no signature changes. `getCollectionBySlug` (lines 97-114) and `getCollectionUpdateMetadata` (lines 287-295) automatically carry the new `siblings` field once the backend returns it (responses are typed to `CollectionModel` / `CollectionUpdateResponseDTO`). `updateCollection` (lines 219-224) already forwards the full `CollectionUpdateRequest`, so the new `siblings` key flows through unchanged.

## Testing strategy

**Frontend**
- `tests/(admin)/collection/manage/[[...slug]]/manageUtils.test.ts` — add a `buildUpdatePayload` case asserting `siblings` passes through unchanged (mirror the `collections` case at line 664).
- `tests/utils/contentLayout.test.ts` — add a case (drive via `createHeaderRow`, since `buildMetadataItems` is private) asserting that a collection with `siblings` produces `type: 'collection'` items with `slug` = `/{siblingSlug}` and `value` = name; and that a collection with no siblings produces none.
- New `tests/components/CollectionListSelector/CollectionListSelector.test.tsx` (or extend existing) — two-column render: each row exposes a Sibling toggle and a Child toggle; `onToggleSibling`/`onToggleChild` fire independently; `excludeCollectionId` row is omitted.
- `tests/components/Content/CollectionContentRenderer.test.tsx` (or nearest existing render test) — a `'collection'` item renders an `<a>`/`<Link>` to `item.slug` with the name as text under a `Related:` label.

**Backend**
- `CollectionSiblingRepositoryTest` — mirror `CollectionRepositoryTest` (Mockito + reflection-swapped `NamedParameterJdbcTemplate`). Assert `addSibling` issues the two-row reciprocal INSERT, `removeSibling` issues the bidirectional DELETE, and `findSiblings` appends the `visibility = 'LISTED'` clause only when `listedOnly`.
- `CollectionServiceTest` — `handleSiblingUpdates` calls `addSibling` per `newValue` and `removeSibling` per `remove`, skips self, and is a no-op on null. Assert `convertToModel` populates `siblings` with `listedOnly=true` on the public path.
- `CollectionControllerDevTest` / `CollectionControllerProdTest` — `PUT .../{id}` accepts a body with `siblings`; `GET /{slug}` returns `siblings` in the JSON (prod path LISTED-only).

## Manual verification checklist

1. **Migration:** run the backend; `V26` applies cleanly; `\d collection_sibling` shows the composite PK, both indexes, and the self-check constraint.
2. **Curate (mutual):** in Manage for collection A, tick **Sibling** on B, save. Open Manage for B → A shows as a checked Sibling (reciprocity). Untick on either side, save → both directions cleared.
3. **Child unaffected:** ticking **Child** still creates the child relationship exactly as before; a pair can be both.
4. **Public render:** visit `/{A-slug}` → metadata block shows a `Related:` link to B; clicking it navigates to `/{B-slug}`, whose metadata block links back to A.
5. **Visibility filter:** set B to UNLISTED/HIDDEN → B's link disappears from A's public page, but B still appears in A's Manage Sibling column (admin sees all).
6. **Self-exclusion:** A cannot be added as its own sibling (row excluded by `excludeCollectionId`; DB CHECK as backstop).
7. **Type-check + lint clean:** `tsc --noEmit`, `eslint --fix`, `stylelint --fix` on changed files; backend `mvn verify` passes.

## Dead code surfaced during exploration (address or explicitly defer)

Flagged in files this work touches — the plan should remove or consciously keep each:
- `_chunkSize` param in `createHeaderRow` (`contentLayout.ts:542`) — JSDoc'd "unused, kept for API compatibility". We're editing `contentLayout.ts`; consider removing if no caller passes it.
- `_hasSlug` param in `CollectionContentRenderer` (`CollectionContentRenderer.tsx:55`) — shadows the `hasSlug` prop; we're editing this file's render branch. Rename for clarity if low-risk.
- `_currentState` param in `mergeNewMetadata` (`manageUtils.ts:302`) — explicitly unused. We're editing `manageUtils.ts`.
- `_deletedIds` in `handleDeleteSuccess` (`ManageClient.tsx:769`) — never inspected. We're editing `ManageClient.tsx`.

These are **carry-along cleanups**, not requirements. Default: leave behavior untouched unless the change is trivially safe; note any deferral.

## Out of scope / Backlog

1. **Cover-thumbnail rendering** of siblings instead of text links.
2. **Sibling ordering** (drag-reorder) and per-link visibility — siblings are title-ordered and all-or-nothing for v1.
3. **Automatic/suggested siblings** from shared location/tags (a "you might also like" derived list).
4. **Bulk sibling editing** outside the per-collection Manage page.

## Spec coverage checklist

Mapping the feature request to spec sections:

| Requirement (from brainstorming) | Spec section |
|---|---|
| Determine "sibling/similar/associated" collections | Goal + Data model (`collection_sibling`) |
| Curated, not automatic | Non-goals + Decisions table |
| Mutual (set once, both link) | Decisions table + DAO reciprocal `addSibling`/`removeSibling` |
| Managed in the Manage "collections" component | Frontend → Manage UI (`Collection \| Sibling \| Child` grid) |
| `Collection \| Sibling \| Child` layout, name left | Frontend → Manage UI |
| Sibling column writes new association; Child unchanged | Service `handleSiblingUpdates` + `buildUpdatePayload` passthrough |
| Do we need a DB association column? → join table | Data model (`V26` migration) |
| Surface related collections to navigate to | Public render (`Related:` links) |
| Likely in the metadata text block | `buildMetadataItems` + `CollectionContentRenderer` `'collection'` branch |
| No dead links to hidden collections | Visibility filter (`findSiblings` `listedOnly`) |

**Plan-task → spec-section mapping** (for the writing-plans phase):

| Implementation task | Spec section |
|---|---|
| BE: `V26__collection_sibling.sql` migration | Data model |
| BE: `CollectionSiblingRepository` (add/remove/find) | Backend → DAO |
| BE: `CollectionModel.siblings` + `Update.siblings` DTO fields | Backend → DTO changes |
| BE: `CollectionService.handleSiblingUpdates` + `convertToModel` population | Backend → Service |
| BE tests (repo/service/controller) | Testing strategy |
| FE: type additions (`CollectionModel`, `CollectionUpdateRequest`, `TextBlockItem`) | Frontend → Types |
| FE: extend `CollectionListSelector` to two columns | Frontend → Manage UI |
| FE: `ManageClient` sibling state + `buildUpdatePayload` passthrough | Frontend → Manage UI |
| FE: `buildMetadataItems` + `CollectionContentRenderer` + SCSS | Frontend → Public render |
| FE tests (manageUtils, contentLayout, selector, renderer) | Testing strategy |
| Manual verification | Manual verification checklist |
| Dead-code carry-along review | Dead code surfaced |
```
