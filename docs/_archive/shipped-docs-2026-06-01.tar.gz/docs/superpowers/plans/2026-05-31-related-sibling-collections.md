# Related / Sibling Collections — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a curated, mutual "sibling" association between collections — edited in the admin Manage page and rendered as `Related:` links in the metadata block on the public collection page.

**Architecture:** A new reciprocal `collection_sibling` join table (no entity POJO) with a DAO/service/DTO path mirroring `collection_people`. Siblings are populated onto `CollectionModel` (LISTED-only on public reads, all on admin reads) and rendered via a new `'collection'` `TextBlockItem`. The frontend extends the existing `CollectionListSelector` into a backward-compatible two-column `Sibling | Child` grid.

**Tech Stack:** Backend — Spring Boot, Postgres, Flyway (V26), NamedParameterJdbcTemplate, JUnit 5 / Mockito. Frontend — Next.js App Router, TypeScript, SCSS modules, Jest + React Testing Library.

**Spec:** `docs/superpowers/specs/2026-05-31-related-sibling-collections-design.md`
**Branch:** `0143-sibling-collections` — create fresh from the default branch; do NOT build on the unrelated `0142-mobile-landscape-fullscreen-padding` WIP currently checked out.
**Repos:** Backend tasks (`BE-*`) run in `/Users/themancalledzac/Code/edens.zac.backend`; frontend tasks (`FE-*`) in `/Users/themancalledzac/Code/edens.zac`. Commit in each repo separately.

---

## Execution model & parallelization

Two largely independent tracks, joined only by the `siblings` data contract (already fixed by the spec):

- **Backend track (BE-1 … BE-6):** migration → DAO → DTO → service write → read-path population → controller contract tests.
- **Frontend track (FE-1 … FE-6):** types → payload passthrough → selector → manage wiring → metadata items → public render.

The frontend's *runtime* behavior depends on the backend returning `siblings`, but the FE types (FE-1) are forward-compatible (the UI degrades to empty until the backend ships), so the tracks can be built **in parallel** and integrated last. This is a strong candidate for **Agent Teams** — one worker per track. Run `/agent-teams` to parallelize, or execute BE then FE sequentially.

## Two real-code constraints the executor MUST respect

1. **`CollectionRequests.Update` is a positional Java record (17 → 18 components).** Adding `siblings` shifts every positional `new Update(...)`. Four **test** call sites need a trailing arg (fixed inside BE-4 and BE-6). No `src/main` code constructs it positionally (controllers bind it via `@RequestBody`).
2. **`CollectionListSelector` has two consumers** (`ManageClient` + `ImageMetadataModal`, with 19 existing tests). The two-column extension is **purely additive** — every new prop is optional; absent → the current single-column layout is unchanged.

## One open decision for review

**FE-4 drops `onNavigate`** from the manage-page selector instance (row-click-to-navigate is incompatible with two independent toggle columns). This is spec-aligned (the grid is name + two toggles, no row navigation), but it removes the "click a row → open that collection's manage page" shortcut. If you want navigation kept, the fallback is making the name cell a `<Link>` — a small addition to FE-3. **Confirm your preference before executing FE-3/FE-4.**

## File structure

**Backend (`edens.zac.backend`)**
- Create: `src/main/resources/db/migration/V26__collection_sibling.sql` — reciprocal join table
- Create: `src/main/java/.../dao/CollectionSiblingRepository.java` — `addSibling` / `removeSibling` / `findSiblings`
- Create (test): `src/test/java/.../dao/CollectionSiblingRepositoryTest.java`, `src/test/java/.../services/CollectionProcessingUtilTest.java`
- Modify: `model/CollectionModel.java` (+`siblings`), `model/CollectionRequests.java` (+`siblings` on `Update`)
- Modify: `services/CollectionService.java` (`handleSiblingUpdates` + public-path populate), `services/CollectionProcessingUtil.java` (`populateSiblings` + admin-path populate)
- Modify (test): `CollectionServiceTest`, `CollectionControllerDevTest`, `CollectionControllerProdTest`

**Frontend (`edens.zac`)**
- Modify: `app/types/Collection.ts` (+`siblings` on model & request), `app/types/Content.ts` (+`'collection'` `TextBlockItem`)
- Modify: `app/components/CollectionListSelector/CollectionListSelector.tsx` (+ `.module.scss`) — two-column
- Modify: `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx` (sibling state), `manageUtils.ts` (passthrough)
- Modify: `app/utils/contentLayout.ts` (`buildMetadataItems`), `app/components/Content/CollectionContentRenderer.tsx` (+ `ContentComponent.module.scss`)
- Create (test): `tests/components/Content/CollectionContentRenderer.test.tsx`; extend `tests/components/CollectionListSelector.test.tsx`, `tests/(admin)/collection/manage/[[...slug]]/manageUtils.test.ts`, `tests/utils/contentLayout.test.ts`

---

## Backend Track — Sibling Collections (TDD)

All paths below are absolute under the backend repo `/Users/themancalledzac/Code/edens.zac.backend`. Java package root is `edens.zac.portfolio.backend`. Run a single test with `cd /Users/themancalledzac/Code/edens.zac.backend && ./mvnw -q -Dtest=ClassName test`; full gate with `cd /Users/themancalledzac/Code/edens.zac.backend && ./mvnw -q verify`. Commit in the backend repo with `git commit -m "feat(siblings): <desc>"`.

> **Threading decision (confirmed from real code).** The 5-arg `CollectionProcessingUtil.convertToModel(entity, list, currentPage, pageSize, totalElements)` is stubbed in ~8 places across `CollectionServiceTest` (e.g. `convertToModel(eq(testCollection), any(), anyInt(), anyInt(), anyLong())`) and is also called by `reorderContent` and `convertToFullModel`. Changing its signature would break every one of those stubs and callers. So siblings are **not** populated by mutating `convertToModel`'s signature. Instead BE-5 adds a dedicated `populateSiblings(CollectionModel model, boolean listedOnly)` method (peer of the existing `populateCollectionsOnContent`), called with `listedOnly=true` from the public read path (`CollectionService.getCollectionWithPagination`, between `populateCollectionsOnContent` and `filterNonListedChildCollections`) and `listedOnly=false` from the admin path (`CollectionProcessingUtil.convertToFullModel`, which backs `findBySlug`→`getUpdateCollectionData`). This matches the spec's intent ("after populateCollectionsOnContent, before filterNonListedChildCollections", public=LISTED-only / admin=all) without the signature churn.

---

### Task BE-1: Flyway migration `V26__collection_sibling.sql`

**Files:**
- Create: `/Users/themancalledzac/Code/edens.zac.backend/src/main/resources/db/migration/V26__collection_sibling.sql`
- Test: none (no Spring-boot/Flyway integration test exists — `ApplicationTests` is `@Disabled`, surefire only runs `**/*Test.java` with mocked deps). Verified by applying the migration against the dev Postgres and inspecting the schema.

Steps:

- [ ] **Confirm the next free version.** Highest existing migration is `V25__add_web_url_to_content_gif.sql`. Confirm V26 is free:
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && ls src/main/resources/db/migration/ | grep -E '^V2[0-9]'
  ```
  Expected: lists `V20`…`V25` and no `V26`.

- [ ] **Create the migration file** (style mirrors `V16__locations_many_to_many.sql`: `BEGIN;`/`COMMIT;`, `ON DELETE CASCADE`, `idx_{table}_{column}` indexes; adds the self-reference CHECK from the spec). Write `/Users/themancalledzac/Code/edens.zac.backend/src/main/resources/db/migration/V26__collection_sibling.sql`:
  ```sql
  -- V26__collection_sibling
  -- Description: Mutual ("sibling") association between collections. Rows are stored
  -- reciprocally: a sibling link between A and B is two rows (A,B) and (B,A), so
  -- "siblings of X" is a single-direction lookup on collection_id. ON DELETE CASCADE
  -- cleans up both directions when either collection is deleted.

  BEGIN;

  CREATE TABLE collection_sibling (
      collection_id         BIGINT NOT NULL REFERENCES collection(id) ON DELETE CASCADE,
      sibling_collection_id BIGINT NOT NULL REFERENCES collection(id) ON DELETE CASCADE,
      PRIMARY KEY (collection_id, sibling_collection_id),
      CONSTRAINT chk_collection_sibling_not_self CHECK (collection_id <> sibling_collection_id)
  );

  CREATE INDEX idx_collection_sibling_collection ON collection_sibling(collection_id);
  CREATE INDEX idx_collection_sibling_sibling    ON collection_sibling(sibling_collection_id);

  COMMIT;
  ```

- [ ] **Compile-only safety check** (does not boot Spring, so it never touches the DB — just proves nothing else broke):
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && ./mvnw -q -DskipTests package
  ```
  Expected: `BUILD SUCCESS`.

- [ ] **Apply + verify against the dev Postgres** (the app runs Flyway on startup; use the normal dev run target). Start the app pointed at the dev DB, e.g.:
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && ./mvnw -q spring-boot:run -Dspring-boot.run.profiles=dev
  ```
  Expected in the log: a Flyway line `Migrating schema "public" to version "26 - collection sibling"` and `Successfully applied 1 migration`. Stop the app once it boots.

- [ ] **Inspect the schema** with psql against the same dev database (substitute the dev datasource name from `src/main/resources/application.properties`):
  ```bash
  psql "$DEV_DATABASE_URL" -c '\d collection_sibling'
  ```
  Expected: two `bigint not null` columns `collection_id` / `sibling_collection_id`; `Indexes:` shows the composite PK `collection_sibling_pkey PRIMARY KEY, btree (collection_id, sibling_collection_id)` plus `idx_collection_sibling_collection` and `idx_collection_sibling_sibling`; `Check constraints:` shows `chk_collection_sibling_not_self CHECK (collection_id <> sibling_collection_id)`; `Foreign-key constraints:` shows both FKs `... REFERENCES collection(id) ON DELETE CASCADE`.

- [ ] **Commit:**
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && git add src/main/resources/db/migration/V26__collection_sibling.sql && git commit -m "feat(siblings): add V26 collection_sibling join table"
  ```

---

### Task BE-2: `CollectionSiblingRepository` + `CollectionSiblingRepositoryTest` (TDD)

**Files:**
- Create: `/Users/themancalledzac/Code/edens.zac.backend/src/main/java/edens/zac/portfolio/backend/dao/CollectionSiblingRepository.java`
- Test: `/Users/themancalledzac/Code/edens.zac.backend/src/test/java/edens/zac/portfolio/backend/dao/CollectionSiblingRepositoryTest.java`

Mirrors `CollectionPeopleRepository` (`@Component`, `extends BaseDao`, ctor takes `JdbcTemplate`, uses the inherited `query` / `update` / `createParameterSource` / `namedParameterJdbcTemplate`). The test mirrors `CollectionRepositoryTest` exactly — Mockito `@Mock NamedParameterJdbcTemplate`, reflection-swap into the `BaseDao.namedParameterJdbcTemplate` field, `ArgumentCaptor<String>`/`ArgumentCaptor<MapSqlParameterSource>` to pin SQL + params.

Steps:

- [ ] **Write the failing test first.** Create `/Users/themancalledzac/Code/edens.zac.backend/src/test/java/edens/zac/portfolio/backend/dao/CollectionSiblingRepositoryTest.java` (the reflection swap and captor pattern are copied verbatim from `CollectionRepositoryTest` lines 41-57):
  ```java
  package edens.zac.portfolio.backend.dao;

  import static org.assertj.core.api.Assertions.assertThat;
  import static org.mockito.ArgumentMatchers.any;
  import static org.mockito.ArgumentMatchers.anyString;
  import static org.mockito.Mockito.verify;
  import static org.mockito.Mockito.when;

  import edens.zac.portfolio.backend.model.Records;
  import java.util.List;
  import org.junit.jupiter.api.BeforeEach;
  import org.junit.jupiter.api.Nested;
  import org.junit.jupiter.api.Test;
  import org.junit.jupiter.api.extension.ExtendWith;
  import org.mockito.ArgumentCaptor;
  import org.mockito.Captor;
  import org.mockito.Mock;
  import org.mockito.junit.jupiter.MockitoExtension;
  import org.springframework.jdbc.core.JdbcTemplate;
  import org.springframework.jdbc.core.RowMapper;
  import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
  import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

  @ExtendWith(MockitoExtension.class)
  class CollectionSiblingRepositoryTest {

    @Mock private JdbcTemplate jdbcTemplate;

    @Mock private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Captor private ArgumentCaptor<String> sqlCaptor;

    @Captor private ArgumentCaptor<MapSqlParameterSource> paramsCaptor;

    private CollectionSiblingRepository repository;

    @BeforeEach
    void setUp() {
      repository = new CollectionSiblingRepository(jdbcTemplate);
      setNamedParameterJdbcTemplate(repository, namedParameterJdbcTemplate);
    }

    private void setNamedParameterJdbcTemplate(
        CollectionSiblingRepository repo, NamedParameterJdbcTemplate template) {
      try {
        java.lang.reflect.Field field =
            BaseDao.class.getDeclaredField("namedParameterJdbcTemplate");
        field.setAccessible(true);
        field.set(repo, template);
      } catch (Exception e) {
        throw new RuntimeException("Failed to set mock NamedParameterJdbcTemplate", e);
      }
    }

    @Nested
    class AddSibling {

      @Test
      void addSibling_issuesReciprocalInsertWithOnConflictDoNothing() {
        when(namedParameterJdbcTemplate.update(anyString(), any(MapSqlParameterSource.class)))
            .thenReturn(2);

        repository.addSibling(1L, 2L);

        verify(namedParameterJdbcTemplate).update(sqlCaptor.capture(), paramsCaptor.capture());
        String sql = sqlCaptor.getValue();
        assertThat(sql)
            .containsIgnoringCase(
                "INSERT INTO collection_sibling (collection_id, sibling_collection_id)");
        assertThat(sql).containsIgnoringCase("VALUES (:a, :b), (:b, :a)");
        assertThat(sql).containsIgnoringCase("ON CONFLICT DO NOTHING");

        MapSqlParameterSource params = paramsCaptor.getValue();
        assertThat(params.getValue("a")).isEqualTo(1L);
        assertThat(params.getValue("b")).isEqualTo(2L);
      }
    }

    @Nested
    class RemoveSibling {

      @Test
      void removeSibling_issuesBidirectionalDelete() {
        when(namedParameterJdbcTemplate.update(anyString(), any(MapSqlParameterSource.class)))
            .thenReturn(2);

        repository.removeSibling(3L, 4L);

        verify(namedParameterJdbcTemplate).update(sqlCaptor.capture(), paramsCaptor.capture());
        String sql = sqlCaptor.getValue();
        assertThat(sql).containsIgnoringCase("DELETE FROM collection_sibling");
        assertThat(sql)
            .containsIgnoringCase(
                "(collection_id = :a AND sibling_collection_id = :b)");
        assertThat(sql)
            .containsIgnoringCase(
                "(collection_id = :b AND sibling_collection_id = :a)");

        MapSqlParameterSource params = paramsCaptor.getValue();
        assertThat(params.getValue("a")).isEqualTo(3L);
        assertThat(params.getValue("b")).isEqualTo(4L);
      }
    }

    @Nested
    class FindSiblings {

      @SuppressWarnings("unchecked")
      @Test
      void findSiblings_listedOnlyTrue_appendsVisibilityClause() {
        when(namedParameterJdbcTemplate.query(
                anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
            .thenReturn(List.of());

        List<Records.CollectionList> result = repository.findSiblings(7L, true);

        assertThat(result).isEmpty();
        verify(namedParameterJdbcTemplate)
            .query(sqlCaptor.capture(), paramsCaptor.capture(), any(RowMapper.class));
        String sql = sqlCaptor.getValue();
        assertThat(sql).containsIgnoringCase("SELECT c.id, c.title AS name, c.slug, c.type");
        assertThat(sql).containsIgnoringCase("FROM collection_sibling cs");
        assertThat(sql)
            .containsIgnoringCase("JOIN collection c ON c.id = cs.sibling_collection_id");
        assertThat(sql).containsIgnoringCase("WHERE cs.collection_id = :id");
        assertThat(sql).containsIgnoringCase("AND c.visibility = 'LISTED'");
        assertThat(sql).containsIgnoringCase("ORDER BY c.title ASC");
        assertThat(paramsCaptor.getValue().getValue("id")).isEqualTo(7L);
      }

      @SuppressWarnings("unchecked")
      @Test
      void findSiblings_listedOnlyFalse_omitsVisibilityClause() {
        when(namedParameterJdbcTemplate.query(
                anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
            .thenReturn(List.of());

        repository.findSiblings(8L, false);

        verify(namedParameterJdbcTemplate)
            .query(sqlCaptor.capture(), any(MapSqlParameterSource.class), any(RowMapper.class));
        String sql = sqlCaptor.getValue();
        assertThat(sql).containsIgnoringCase("WHERE cs.collection_id = :id");
        assertThat(sql).doesNotContainIgnoringCase("visibility = 'LISTED'");
        assertThat(sql).containsIgnoringCase("ORDER BY c.title ASC");
      }
    }
  }
  ```

- [ ] **Run the test — expect compile failure** (class does not exist yet), which is the RED step:
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && ./mvnw -q -Dtest=CollectionSiblingRepositoryTest test
  ```
  Expected: `BUILD FAILURE` with a compilation error `cannot find symbol ... CollectionSiblingRepository`.

- [ ] **Implement the repository.** Create `/Users/themancalledzac/Code/edens.zac.backend/src/main/java/edens/zac/portfolio/backend/dao/CollectionSiblingRepository.java`. The `findSiblings` RowMapper builds `Records.CollectionList(id, name, slug, type)` — exact record is `record CollectionList(Long id, String name, String slug, CollectionType type)` (Records.java:69) — aliasing `c.title AS name` and parsing `c.type` via `CollectionType.valueOf`, matching `CollectionRepository.findIdTitleSlugAndType` (CollectionRepository.java:393-403):
  ```java
  package edens.zac.portfolio.backend.dao;

  import edens.zac.portfolio.backend.model.Records;
  import edens.zac.portfolio.backend.types.CollectionType;
  import java.util.List;
  import org.springframework.jdbc.core.JdbcTemplate;
  import org.springframework.jdbc.core.RowMapper;
  import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
  import org.springframework.stereotype.Component;
  import org.springframework.transaction.annotation.Transactional;

  /**
   * Mutual ("sibling") association between collections (mirror of collection_people). Rows are
   * stored reciprocally — a link between A and B is two rows (A,B) and (B,A) — so "siblings of X"
   * is a single-direction lookup on collection_id. No dedicated entity POJO: the join is
   * manipulated directly via SQL, matching collection_people / collection_locations.
   *
   * <p>Reads return {@link Records.CollectionList} DTOs directly (aliasing {@code c.title AS name})
   * so CollectionProcessingUtil can populate {@code CollectionModel.siblings} without an entity.
   */
  @Component
  public class CollectionSiblingRepository extends BaseDao {

    private static final RowMapper<Records.CollectionList> SIBLING_ROW_MAPPER =
        (rs, rowNum) ->
            new Records.CollectionList(
                rs.getLong("id"),
                rs.getString("name"),
                rs.getString("slug"),
                CollectionType.valueOf(rs.getString("type")));

    public CollectionSiblingRepository(JdbcTemplate jdbcTemplate) {
      super(jdbcTemplate);
    }

    /**
     * Reciprocal insert of the pair (a,b) and (b,a). Idempotent via {@code ON CONFLICT DO NOTHING}
     * against the composite PK, so re-adding an existing link is a no-op.
     */
    @Transactional
    public void addSibling(Long a, Long b) {
      String sql =
          """
          INSERT INTO collection_sibling (collection_id, sibling_collection_id)
          VALUES (:a, :b), (:b, :a)
          ON CONFLICT DO NOTHING
          """;
      update(sql, createParameterSource().addValue("a", a).addValue("b", b));
    }

    /** Bidirectional delete: removes both (a,b) and (b,a). */
    @Transactional
    public void removeSibling(Long a, Long b) {
      String sql =
          """
          DELETE FROM collection_sibling
          WHERE (collection_id = :a AND sibling_collection_id = :b)
             OR (collection_id = :b AND sibling_collection_id = :a)
          """;
      update(sql, createParameterSource().addValue("a", a).addValue("b", b));
    }

    /**
     * Siblings of one collection as {@link Records.CollectionList} rows, ordered by title. When
     * {@code listedOnly} is true, only LISTED siblings are returned (public read path); when false,
     * every sibling regardless of visibility is returned (admin manage payload).
     */
    @Transactional(readOnly = true)
    public List<Records.CollectionList> findSiblings(Long collectionId, boolean listedOnly) {
      String sql =
          "SELECT c.id, c.title AS name, c.slug, c.type "
              + "FROM collection_sibling cs "
              + "JOIN collection c ON c.id = cs.sibling_collection_id "
              + "WHERE cs.collection_id = :id "
              + (listedOnly ? "AND c.visibility = 'LISTED' " : "")
              + "ORDER BY c.title ASC";
      MapSqlParameterSource params = createParameterSource().addValue("id", collectionId);
      return query(sql, SIBLING_ROW_MAPPER, params);
    }
  }
  ```

- [ ] **Run the test — expect GREEN:**
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && ./mvnw -q -Dtest=CollectionSiblingRepositoryTest test
  ```
  Expected: `BUILD SUCCESS`, `Tests run: 4, Failures: 0, Errors: 0`.

- [ ] **Commit:**
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && git add src/main/java/edens/zac/portfolio/backend/dao/CollectionSiblingRepository.java src/test/java/edens/zac/portfolio/backend/dao/CollectionSiblingRepositoryTest.java && git commit -m "feat(siblings): add CollectionSiblingRepository with reciprocal add/remove/find"
  ```

---

### Task BE-3: DTO fields — `CollectionModel.siblings` + `CollectionRequests.Update.siblings`

**Files:**
- Modify: `/Users/themancalledzac/Code/edens.zac.backend/src/main/java/edens/zac/portfolio/backend/model/CollectionModel.java:75-77` (add `siblings` near `tags`/`content`)
- Modify: `/Users/themancalledzac/Code/edens.zac.backend/src/main/java/edens/zac/portfolio/backend/model/CollectionRequests.java:79-83` (add `siblings` as the last `Update` field)
- Test: covered transitively by the existing suites that must be updated for the new positional `Update` arg — `CollectionServiceTest`, `CollectionControllerDevTest` (handled in BE-4 / BE-6). No standalone DTO test.

> **CRITICAL RIPPLE — `Update` is a positional record.** `CollectionRequests.Update` currently has **17 components**; every `new CollectionRequests.Update(...)` in the codebase passes 17 positional args. Adding `siblings` makes it **18**. Each call site must get one more trailing `null` (or a value). Known call sites (all in tests): `CollectionServiceTest` lines ~200-218, ~246-263, ~276-293; `CollectionControllerDevTest` lines ~88-105. These are fixed in BE-4 (service test) and BE-6 (controller test). There are no non-test positional constructions in `src/main`.

Steps:

- [ ] **Add the field to `CollectionModel`.** Current `// === Content ===` block (CollectionModel.java:71-77):
  ```java
    // === Content ===

    @Valid private ContentModels.Image coverImage;

    private List<String> tags;

    @Valid private List<ContentModel> content;
  ```
  Insert the siblings field right after `tags` (uses the already-imported `Records` and `List`; `@Data`+`@Builder` generate `getSiblings`/`setSiblings`):
  ```java
    // === Content ===

    @Valid private ContentModels.Image coverImage;

    private List<String> tags;

    /**
     * Sibling collections (mutual association via collection_sibling). LISTED-only on the public
     * read path; all siblings on the admin manage payload. Null/empty when none.
     */
    private List<Records.CollectionList> siblings;

    @Valid private List<ContentModel> content;
  ```

- [ ] **Add the field to `CollectionRequests.Update`.** Current tail of the `Update` record (CollectionRequests.java:79-83):
  ```java
        /**
         * Collection updates using prev/new/remove pattern. Used to manage child collections within
         * this collection (add, remove, update visibility/order of nested collections).
         */
        CollectionUpdate collections) {}
  ```
  Change the `collections` line to end with a comma and append the new `siblings` component (reusing the existing `CollectionUpdate(prev, newValue, remove)` record — only `newValue` + `remove` are honored downstream):
  ```java
        /**
         * Collection updates using prev/new/remove pattern. Used to manage child collections within
         * this collection (add, remove, update visibility/order of nested collections).
         */
        CollectionUpdate collections,
        /**
         * Sibling (mutual) collection updates. Reuses {@link CollectionUpdate}; only {@code newValue}
         * (add) and {@code remove} (delete) are honored, and only each entry's {@code collectionId}
         * is read ({@code orderIndex}/{@code visible}/{@code prev} are ignored — siblings carry no
         * ordering or per-link visibility).
         */
        CollectionUpdate siblings) {}
  ```

- [ ] **Verify compilation of main sources** (tests will fail to compile until BE-4/BE-6 add the trailing `null`; that is expected and resolved there):
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && ./mvnw -q -DskipTests compile
  ```
  Expected: `BUILD SUCCESS`. (Do **not** run `verify` here — test compilation is intentionally broken until BE-4/BE-6.)

- [ ] **Commit** (defer the test fixups to BE-4/BE-6, but note them in the message):
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && git add src/main/java/edens/zac/portfolio/backend/model/CollectionModel.java src/main/java/edens/zac/portfolio/backend/model/CollectionRequests.java && git commit -m "feat(siblings): add siblings to CollectionModel and Update DTO"
  ```

---

### Task BE-4: `CollectionService.handleSiblingUpdates` + `CollectionServiceTest` (TDD)

**Files:**
- Modify: `/Users/themancalledzac/Code/edens.zac.backend/src/main/java/edens/zac/portfolio/backend/services/CollectionService.java:60-72` (inject `CollectionSiblingRepository`), `:484-488` (call site in `updateContent`), and add the new private `handleSiblingUpdates` method
- Modify (test): `/Users/themancalledzac/Code/edens.zac.backend/src/test/java/edens/zac/portfolio/backend/services/CollectionServiceTest.java` (add `@Mock CollectionSiblingRepository`, fix the three positional `Update(...)` constructions to 18 args, add a `HandleSiblingUpdates` nested test class)

`CollectionService` uses `@RequiredArgsConstructor`, so the new repo is just another `private final` field. The service test uses `@InjectMocks` — the new `@Mock` is wired automatically.

Steps:

- [ ] **RED: add the failing service test first.** In `CollectionServiceTest`, add the mock field alongside the others (after line 49 block):
  ```java
    @Mock private edens.zac.portfolio.backend.dao.CollectionSiblingRepository collectionSiblingRepository;
  ```
  Then add a new nested test class (place after the `UpdateContentWithMetadata` class). It exercises `updateContent` directly (which is `public`), driving the new `siblings` field. Note the `Update` constructor now takes **18** positional args (siblings is last):
  ```java
    @Nested
    class HandleSiblingUpdates {

      private CollectionRequests.Update updateWithSiblings(
          Long id, CollectionRequests.CollectionUpdate siblings) {
        return new CollectionRequests.Update(
            id, null, null, null, null, null, null, null, null, null, null, null, null, null,
            null, null, /* collections */ null, /* siblings */ siblings);
      }

      @Test
      void addsEachNewValueAndRemovesEachRemoveId() {
        Long parentId = 1L;
        CollectionRequests.CollectionUpdate siblings =
            new CollectionRequests.CollectionUpdate(
                null,
                List.of(
                    new Records.ChildCollection(20L, null, null, null, null, null),
                    new Records.ChildCollection(21L, null, null, null, null, null)),
                List.of(30L, 31L));

        when(collectionRepository.findById(parentId)).thenReturn(Optional.of(testCollection));
        when(collectionRepository.countContentByCollectionId(parentId)).thenReturn(0L);
        when(collectionRepository.save(any(CollectionEntity.class))).thenReturn(testCollection);
        when(collectionProcessingUtil.convertToBasicModel(any(CollectionEntity.class)))
            .thenReturn(CollectionModel.builder().id(parentId).slug("test-collection").build());

        service.updateContent(parentId, updateWithSiblings(parentId, siblings));

        verify(collectionSiblingRepository).addSibling(parentId, 20L);
        verify(collectionSiblingRepository).addSibling(parentId, 21L);
        verify(collectionSiblingRepository).removeSibling(parentId, 30L);
        verify(collectionSiblingRepository).removeSibling(parentId, 31L);
      }

      @Test
      void skipsSelfReferenceInNewValue() {
        Long parentId = 1L;
        CollectionRequests.CollectionUpdate siblings =
            new CollectionRequests.CollectionUpdate(
                null,
                List.of(new Records.ChildCollection(parentId, null, null, null, null, null)),
                null);

        when(collectionRepository.findById(parentId)).thenReturn(Optional.of(testCollection));
        when(collectionRepository.countContentByCollectionId(parentId)).thenReturn(0L);
        when(collectionRepository.save(any(CollectionEntity.class))).thenReturn(testCollection);
        when(collectionProcessingUtil.convertToBasicModel(any(CollectionEntity.class)))
            .thenReturn(CollectionModel.builder().id(parentId).slug("test-collection").build());

        service.updateContent(parentId, updateWithSiblings(parentId, siblings));

        verify(collectionSiblingRepository, never()).addSibling(eq(parentId), eq(parentId));
      }

      @Test
      void nullSiblings_isNoOp() {
        Long parentId = 1L;

        when(collectionRepository.findById(parentId)).thenReturn(Optional.of(testCollection));
        when(collectionRepository.countContentByCollectionId(parentId)).thenReturn(0L);
        when(collectionRepository.save(any(CollectionEntity.class))).thenReturn(testCollection);
        when(collectionProcessingUtil.convertToBasicModel(any(CollectionEntity.class)))
            .thenReturn(CollectionModel.builder().id(parentId).slug("test-collection").build());

        service.updateContent(parentId, updateWithSiblings(parentId, null));

        verify(collectionSiblingRepository, never()).addSibling(anyLong(), anyLong());
        verify(collectionSiblingRepository, never()).removeSibling(anyLong(), anyLong());
      }
    }
  ```
  (`anyLong`, `eq`, `never`, `verify`, `Records`, `List`, `Optional`, `CollectionModel`, `CollectionEntity` are all already imported in this test file.)

- [ ] **Fix the three existing positional `Update(...)` constructions to 18 args.** They currently pass 17 nulls (`CollectionServiceTest` lines ~201-218, ~246-263, ~276-293). Append one trailing `null` to each so the new `siblings` component is supplied. Example for the first (`updateContentWithMetadata_happyPath_returnsUpdateResponse`):
  ```java
        CollectionRequests.Update updateDTO =
            new CollectionRequests.Update(
                collectionId, null, "Updated Title", null, null, null, null, null, null, null,
                null, null, null, null, null, null, null, null);
  ```
  (16 trailing nulls after `"Updated Title"`-position values → 18 components total: `id`, `type`, `title`, … `collections`, `siblings`.) Apply the same trailing-`null` addition to the other two constructions in lines ~246-263 and ~276-293.

- [ ] **Run the test — expect RED** (method `handleSiblingUpdates` not wired yet; the `addSibling`/`removeSibling` verifies fail):
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && ./mvnw -q -Dtest=CollectionServiceTest test
  ```
  Expected: `BUILD FAILURE` with Mockito "Wanted but not invoked: collectionSiblingRepository.addSibling(...)" on the new tests (existing tests should pass once the 18-arg fixups compile).

- [ ] **Implement in `CollectionService`.** (a) Add the injected field after `collectionPeopleRepository` (CollectionService.java:61):
  ```java
    private final CollectionPeopleRepository collectionPeopleRepository;
    private final edens.zac.portfolio.backend.dao.CollectionSiblingRepository collectionSiblingRepository;
  ```
  (b) Add the `handleSiblingUpdates` call in `updateContent` immediately after the `handleCollectionToCollectionUpdates` block (CollectionService.java:484-488):
  ```java
      // Handle collection updates using prev/new/remove pattern
      // This manages child collections within this parent collection
      if (updateDTO.collections() != null) {
        handleCollectionToCollectionUpdates(entity, updateDTO.collections());
      }

      // Handle sibling (mutual) collection updates — reciprocal add/remove
      handleSiblingUpdates(entity.getId(), updateDTO.siblings());
  ```
  (c) Add the private method (place near `handleCollectionToCollectionUpdates`, e.g. after it ends at line 903):
  ```java
    /**
     * Apply mutual sibling updates for a collection. Each {@code newValue} entry's collectionId is
     * added via a reciprocal INSERT; each {@code remove} id is deleted bidirectionally. Self-links
     * are skipped defensively (the DB CHECK also blocks them). No-op when {@code siblings} is null
     * (partial-update friendly, same gate semantics as {@code collections}).
     */
    private void handleSiblingUpdates(
        Long parentId, CollectionRequests.CollectionUpdate siblings) {
      if (siblings == null) {
        return;
      }
      if (siblings.remove() != null) {
        for (Long siblingId : siblings.remove()) {
          if (siblingId == null || siblingId.equals(parentId)) {
            continue;
          }
          collectionSiblingRepository.removeSibling(parentId, siblingId);
        }
      }
      if (siblings.newValue() != null) {
        for (Records.ChildCollection entry : siblings.newValue()) {
          Long siblingId = entry.collectionId();
          if (siblingId == null || siblingId.equals(parentId)) {
            continue;
          }
          collectionSiblingRepository.addSibling(parentId, siblingId);
        }
      }
      log.info("Applied sibling updates for collection {}", parentId);
    }
  ```

- [ ] **Run the test — expect GREEN:**
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && ./mvnw -q -Dtest=CollectionServiceTest test
  ```
  Expected: `BUILD SUCCESS`, all `CollectionServiceTest` tests pass including the three new `HandleSiblingUpdates` cases.

- [ ] **Commit:**
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && git add src/main/java/edens/zac/portfolio/backend/services/CollectionService.java src/test/java/edens/zac/portfolio/backend/services/CollectionServiceTest.java && git commit -m "feat(siblings): wire handleSiblingUpdates into updateContent"
  ```

---

### Task BE-5: Populate `siblings` in read paths (`populateSiblings` + `listedOnly` threading) + tests

**Files:**
- Modify: `/Users/themancalledzac/Code/edens.zac.backend/src/main/java/edens/zac/portfolio/backend/services/CollectionProcessingUtil.java:45-52` (inject `CollectionSiblingRepository`), add a public `populateSiblings(model, listedOnly)` method, and call it with `listedOnly=false` inside `convertToFullModel` (admin path, :302-315)
- Modify: `/Users/themancalledzac/Code/edens.zac.backend/src/main/java/edens/zac/portfolio/backend/services/CollectionService.java:124-127` (call `populateSiblings(model, true)` on the public read path, between `populateCollectionsOnContent` and `filterNonListedChildCollections`)
- Modify (test): `/Users/themancalledzac/Code/edens.zac.backend/src/test/java/edens/zac/portfolio/backend/services/CollectionServiceTest.java` (assert the public path calls `populateSiblings(model, true)`)

> Rationale recap (see top-of-track note): `convertToModel`'s 5-arg signature is left untouched to avoid breaking ~8 mock stubs; siblings are populated by a sibling-of-`populateCollectionsOnContent` method instead. Public read = `getCollectionWithPagination` (listedOnly=true). Admin manage payload = `getUpdateCollectionData` → `findBySlug` → `convertToFullModel` (listedOnly=false).

Steps:

- [ ] **RED: extend the public-path service test.** In `CollectionServiceTest`, the existing `GetCollectionWithPagination.getCollectionWithPagination_happyPath_returnsPaginatedModel` (lines ~318-336) stubs `convertToModel`. Add an assertion that `populateSiblings` is invoked with `listedOnly=true`. Append to that test body, after the existing `convertToModel` stub:
  ```java
        // existing stub:
        when(collectionProcessingUtil.convertToModel(
                eq(testCollection), any(), anyInt(), anyInt(), anyLong()))
            .thenReturn(model);

        CollectionModel result = service.getCollectionWithPagination(slug, 0, 10);

        assertThat(result).isNotNull();
        assertThat(result.getTitle()).isEqualTo("Test Collection");
        // NEW: public read path populates siblings LISTED-only
        verify(collectionProcessingUtil).populateSiblings(model, true);
  ```
  (`verify` and `eq`/`any` already imported.)

- [ ] **Run — expect RED** (method does not exist on the mock yet → compile failure):
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && ./mvnw -q -Dtest=CollectionServiceTest test
  ```
  Expected: `BUILD FAILURE`, `cannot find symbol ... populateSiblings`.

- [ ] **Implement in `CollectionProcessingUtil`.** (a) Inject the repo after `collectionPeopleRepository` (CollectionProcessingUtil.java:46):
  ```java
    private final CollectionPeopleRepository collectionPeopleRepository;
    private final edens.zac.portfolio.backend.dao.CollectionSiblingRepository collectionSiblingRepository;
  ```
  (b) Add the public method (place right after `populateCollectionsOnContent`, ~line 409):
  ```java
    /**
     * Populate {@code model.siblings} from the collection_sibling join. {@code listedOnly=true} on
     * the public read path (LISTED siblings only — no dead links leak); {@code listedOnly=false} on
     * the admin manage payload (operator sees every sibling regardless of visibility). No-op when
     * the model or its id is null.
     */
    public void populateSiblings(CollectionModel model, boolean listedOnly) {
      if (model == null || model.getId() == null) {
        return;
      }
      model.setSiblings(collectionSiblingRepository.findSiblings(model.getId(), listedOnly));
    }
  ```
  (c) Call it on the **admin** path inside `convertToFullModel` (CollectionProcessingUtil.java:302-315) so `findBySlug`/`getUpdateCollectionData` return all siblings. Current:
  ```java
    public CollectionModel convertToFullModel(CollectionEntity entity) {
      List<CollectionContentEntity> joinEntries =
          collectionRepository.findContentByCollectionIdOrderByOrderIndex(entity.getId());

      if (joinEntries.isEmpty()) {
        CollectionModel model = convertToBasicModel(entity);
        model.setContent(Collections.emptyList());
        return model;
      }

      CollectionModel model = convertToModel(entity, joinEntries, 0, 0, joinEntries.size());
      populateCollectionsOnContent(model);
      return model;
    }
  ```
  Change to populate siblings (all) on both return branches:
  ```java
    public CollectionModel convertToFullModel(CollectionEntity entity) {
      List<CollectionContentEntity> joinEntries =
          collectionRepository.findContentByCollectionIdOrderByOrderIndex(entity.getId());

      if (joinEntries.isEmpty()) {
        CollectionModel model = convertToBasicModel(entity);
        model.setContent(Collections.emptyList());
        populateSiblings(model, false); // admin/manage path: all siblings
        return model;
      }

      CollectionModel model = convertToModel(entity, joinEntries, 0, 0, joinEntries.size());
      populateCollectionsOnContent(model);
      populateSiblings(model, false); // admin/manage path: all siblings
      return model;
    }
  ```

- [ ] **Call it on the public path in `CollectionService.getCollectionWithPagination`** (CollectionService.java:123-128). Current:
  ```java
      // Populate collections on content items
      collectionProcessingUtil.populateCollectionsOnContent(model);

      // Filter out child collection content that references non-LISTED collections
      filterNonListedChildCollections(model);

      return model;
  ```
  Change to insert `populateSiblings(model, true)` between them (LISTED-only on public read):
  ```java
      // Populate collections on content items
      collectionProcessingUtil.populateCollectionsOnContent(model);

      // Populate sibling links (LISTED-only on the public read path)
      collectionProcessingUtil.populateSiblings(model, true);

      // Filter out child collection content that references non-LISTED collections
      filterNonListedChildCollections(model);

      return model;
  ```

- [ ] **Run the service test — expect GREEN:**
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && ./mvnw -q -Dtest=CollectionServiceTest test
  ```
  Expected: `BUILD SUCCESS` — the new `verify(...populateSiblings(model, true))` passes and no other `GetCollectionWithPagination` test regresses (the parent-type tests at lines ~741-806 stub `convertToModel` and run the same path; `populateSiblings` on a mock returns void/no-op, so they stay green).

- [ ] **Add a `CollectionProcessingUtil` unit test for `populateSiblings`** (no existing `CollectionProcessingUtilTest` — create one; this is the focused test for the new branch). Create `/Users/themancalledzac/Code/edens.zac.backend/src/test/java/edens/zac/portfolio/backend/services/CollectionProcessingUtilTest.java`:
  ```java
  package edens.zac.portfolio.backend.services;

  import static org.assertj.core.api.Assertions.assertThat;
  import static org.mockito.Mockito.verify;
  import static org.mockito.Mockito.verifyNoInteractions;
  import static org.mockito.Mockito.when;

  import edens.zac.portfolio.backend.dao.CollectionSiblingRepository;
  import edens.zac.portfolio.backend.model.CollectionModel;
  import edens.zac.portfolio.backend.model.Records;
  import edens.zac.portfolio.backend.types.CollectionType;
  import java.util.List;
  import org.junit.jupiter.api.Test;
  import org.junit.jupiter.api.extension.ExtendWith;
  import org.mockito.InjectMocks;
  import org.mockito.Mock;
  import org.mockito.junit.jupiter.MockitoExtension;

  @ExtendWith(MockitoExtension.class)
  class CollectionProcessingUtilTest {

    @Mock private CollectionSiblingRepository collectionSiblingRepository;

    @InjectMocks private CollectionProcessingUtil util;

    @Test
    void populateSiblings_listedOnlyTrue_setsResultFromRepository() {
      CollectionModel model = CollectionModel.builder().id(5L).build();
      List<Records.CollectionList> siblings =
          List.of(new Records.CollectionList(9L, "Dolomites Film", "dolomites-film",
              CollectionType.PORTFOLIO));
      when(collectionSiblingRepository.findSiblings(5L, true)).thenReturn(siblings);

      util.populateSiblings(model, true);

      assertThat(model.getSiblings()).isEqualTo(siblings);
      verify(collectionSiblingRepository).findSiblings(5L, true);
    }

    @Test
    void populateSiblings_nullModel_isNoOp() {
      util.populateSiblings(null, true);
      verifyNoInteractions(collectionSiblingRepository);
    }

    @Test
    void populateSiblings_nullId_isNoOp() {
      util.populateSiblings(CollectionModel.builder().build(), false);
      verifyNoInteractions(collectionSiblingRepository);
    }
  }
  ```
  > Note: `CollectionProcessingUtil` has 8 `@RequiredArgsConstructor` fields; `@InjectMocks` only needs the `CollectionSiblingRepository` mock for `populateSiblings` (the other fields stay null and are never touched by this method). Run:
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && ./mvnw -q -Dtest=CollectionProcessingUtilTest test
  ```
  Expected: `BUILD SUCCESS`, `Tests run: 3, Failures: 0`.

- [ ] **Commit:**
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && git add src/main/java/edens/zac/portfolio/backend/services/CollectionProcessingUtil.java src/main/java/edens/zac/portfolio/backend/services/CollectionService.java src/test/java/edens/zac/portfolio/backend/services/CollectionServiceTest.java src/test/java/edens/zac/portfolio/backend/services/CollectionProcessingUtilTest.java && git commit -m "feat(siblings): populate siblings on public (LISTED) and admin (all) read paths"
  ```

---

### Task BE-6: Controller-level tests — PUT accepts `siblings`, GET returns `siblings`

**Files:**
- Modify (test): `/Users/themancalledzac/Code/edens.zac.backend/src/test/java/edens/zac/portfolio/backend/controller/dev/CollectionControllerDevTest.java` — fix the existing positional `Update(...)` at lines ~88-105 to 18 args; add a PUT test asserting a JSON body with `siblings` binds and reaches the service
- Modify (test): `/Users/themancalledzac/Code/edens.zac.backend/src/test/java/edens/zac/portfolio/backend/controller/prod/CollectionControllerProdTest.java` — add a GET-by-slug test asserting `siblings` is serialized in the response JSON

Both tests are MockMvc `standaloneSetup` with a mocked `CollectionService` (no DB, no Spring boot). The PUT endpoint under test is `AdminController.updateCollection` (`@PutMapping("/collections/{id}")`, dev profile). The GET is `CollectionControllerProd.getCollectionBySlug` (`@GetMapping("/{slug}")`).

Steps:

- [ ] **Fix the existing 17-arg `Update` in `CollectionControllerDevTest`** (lines ~88-105) to 18 by appending a trailing `null`:
  ```java
      testUpdateDTO =
          new CollectionRequests.Update(
              1L, null, "Updated Test Blog", null, "An updated test blog collection", null, null,
              null, null, null, null, null, null, null, null, null, null, null);
  ```

- [ ] **RED: add the PUT-accepts-siblings test to `CollectionControllerDevTest`.** Sends a raw JSON body containing a `siblings` block to prove Jackson binds the new field onto `Update` and the controller forwards it. Add:
  ```java
    @Test
    @DisplayName("PUT /collections/{id} should accept a siblings block in the body")
    void updateCollection_acceptsSiblings() throws Exception {
      when(collectionService.updateContentWithMetadata(eq(1L), any(CollectionRequests.Update.class)))
          .thenReturn(testCollectionUpdateResponse);

      String body =
          "{\"id\":1,\"siblings\":{\"newValue\":[{\"collectionId\":20}],\"remove\":[30]}}";

      mockMvc
          .perform(
              put("/api/admin/collections/1")
                  .contentType(MediaType.APPLICATION_JSON)
                  .content(body))
          .andExpect(status().isOk());

      org.mockito.ArgumentCaptor<CollectionRequests.Update> captor =
          org.mockito.ArgumentCaptor.forClass(CollectionRequests.Update.class);
      verify(collectionService).updateContentWithMetadata(eq(1L), captor.capture());
      CollectionRequests.Update sent = captor.getValue();
      assertThat(sent.siblings()).isNotNull();
      assertThat(sent.siblings().newValue()).hasSize(1);
      assertThat(sent.siblings().newValue().get(0).collectionId()).isEqualTo(20L);
      assertThat(sent.siblings().remove()).containsExactly(30L);
    }
  ```
  Add the AssertJ import if not present (the file currently uses Hamcrest `jsonPath`; add `import static org.assertj.core.api.Assertions.assertThat;`). `put`, `verify`, `eq`, `any` come from the wildcard `MockMvcRequestBuilders.*` / `Mockito.*` imports already in the file.

- [ ] **RED: add the GET-returns-siblings test to `CollectionControllerProdTest`.** Stub `getCollectionWithPagination` to return a model whose `siblings` is set, and assert the JSON contains them. Add:
  ```java
    @Test
    @DisplayName("GET /{slug} should serialize siblings in the response")
    void getCollectionBySlug_returnsSiblings() throws Exception {
      CollectionModel model =
          CollectionModel.builder()
              .id(1L)
              .type(CollectionType.PORTFOLIO)
              .title("Dolomites")
              .slug("dolomites")
              .visibility(CollectionVisibility.LISTED)
              .siblings(
                  List.of(
                      new Records.CollectionList(
                          2L, "Dolomites Film", "dolomites-film", CollectionType.PORTFOLIO)))
              .build();
      when(collectionService.getCollectionWithPagination(eq("dolomites"), anyInt(), anyInt()))
          .thenReturn(model);

      mockMvc
          .perform(get("/api/read/collections/dolomites"))
          .andExpect(status().isOk())
          .andExpect(jsonPath("$.siblings", hasSize(1)))
          .andExpect(jsonPath("$.siblings[0].slug", is("dolomites-film")))
          .andExpect(jsonPath("$.siblings[0].name", is("Dolomites Film")));
    }
  ```
  (`get`, `jsonPath`, `status`, `hasSize`, `is`, `eq`, `anyInt`, `when`, `Records`, `List` are all already imported in `CollectionControllerProdTest`.)

- [ ] **Run both controller tests — expect GREEN** (these don't need the prod/dev implementation to change; the DTO field from BE-3 + the service wiring from BE-4/BE-5 are sufficient — the controllers forward the body and serialize the model unchanged):
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && ./mvnw -q -Dtest=CollectionControllerDevTest,CollectionControllerProdTest test
  ```
  Expected: `BUILD SUCCESS`, both new tests pass (and the previously-broken `CollectionControllerDevTest` now compiles thanks to the 18-arg fix).

- [ ] **Full gate** — run the entire backend test suite + quality plugins to confirm nothing else regressed (Checkstyle/Spotless/SpotBugs run under `verify`):
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && ./mvnw -q verify
  ```
  Expected: `BUILD SUCCESS`, `Tests run: <N>, Failures: 0, Errors: 0`, no Spotless/Checkstyle/SpotBugs violations. (If Spotless flags formatting, run `./mvnw spotless:apply` then re-verify.)

- [ ] **Commit:**
  ```bash
  cd /Users/themancalledzac/Code/edens.zac.backend && git add src/test/java/edens/zac/portfolio/backend/controller/dev/CollectionControllerDevTest.java src/test/java/edens/zac/portfolio/backend/controller/prod/CollectionControllerProdTest.java && git commit -m "feat(siblings): controller tests for PUT body + GET response"
  ```

---

### Backend track notes

- **mvn vs mvnw:** Use **`./mvnw`**. The wrapper is present and executable (`/Users/themancalledzac/Code/edens.zac.backend/mvnw`, `0755`) with `.mvn/wrapper/maven-wrapper.jar` pinned to Maven **3.8.7** (`distributionUrl=https://repo.maven.apache.org/maven2/.../apache-maven-3.8.7-bin.zip`). I could not capture `./mvnw --version` output in this session because the first invocation tries to download the 3.8.7 distribution from `repo.maven.apache.org`, which is **not in the sandbox network allowlist** — so the wrapper stalled on the download (a sandbox limitation, not a project problem). On the user's normal machine (or once the distro is cached in `~/.m2/wrapper`) `./mvnw` runs fine; that's the canonical command this repo is set up for.
- **Confirmed next migration version:** **V26**. Highest existing is `V25__add_web_url_to_content_gif.sql`; no `V26` exists.
- **`convertToModel` signature found (exact):** `public CollectionModel convertToModel(CollectionEntity entity, List<CollectionContentEntity> collectionContentList, int currentPage, int pageSize, long totalElements)` — `CollectionProcessingUtil.java:209-214`. **It was deliberately NOT modified.** It is stubbed in ~8 places in `CollectionServiceTest` (`convertToModel(eq(...), any(), anyInt(), anyInt(), anyLong())`) and also called by `reorderContent` and `convertToFullModel`; threading `listedOnly` through it would break all those stubs/callers. Siblings are populated via a new `CollectionProcessingUtil.populateSiblings(CollectionModel model, boolean listedOnly)` (peer of `populateCollectionsOnContent`) — called `listedOnly=true` from `CollectionService.getCollectionWithPagination` (public, between `populateCollectionsOnContent` and `filterNonListedChildCollections`) and `listedOnly=false` from `convertToFullModel` (admin manage payload via `findBySlug`→`getUpdateCollectionData`).
- **Biggest real-code surprise — `CollectionRequests.Update` is a 17-component positional record.** Every existing `new CollectionRequests.Update(...)` passes 17 positional args (all in tests). Adding `siblings` makes it **18**, so 4 call sites need a trailing arg: `CollectionServiceTest` (3 constructions) and `CollectionControllerDevTest` (1). These fixups are baked into BE-4 and BE-6. There are **no** positional `Update` constructions in `src/main` (the controllers receive it via `@RequestBody`), so production code needs no change for this.
- **No DB / Spring-boot test harness exists.** The only `@SpringBootTest` (`ApplicationTests`) is `@Disabled`; surefire runs `**/*Test.java` as pure Mockito unit tests, and there are no Testcontainers/H2-Flyway integration tests. Consequence: the V26 migration (BE-1) **cannot** be exercised by `./mvnw verify` — it's verified by booting the app against the dev Postgres and using `psql \d collection_sibling`. Everything else (repo/service/controller) is unit-tested with mocks and runs without a database.
- **DI is free via Lombok.** Both `CollectionService` and `CollectionProcessingUtil` are `@RequiredArgsConstructor`, so adding `private final CollectionSiblingRepository ...` is enough — no constructor edits. The matching test classes use `@InjectMocks`, so a single `@Mock CollectionSiblingRepository` field wires it.
- **`Records.CollectionList` exact shape (for the RowMapper):** `record CollectionList(Long id, String name, String slug, CollectionType type)` (`Records.java:69`). The DAO aliases `c.title AS name` and parses `c.type` with `CollectionType.valueOf(...)`, matching the existing `CollectionRepository.findIdTitleSlugAndType` projection. `Records.ChildCollection.collectionId()` is the accessor used to read add-IDs in `handleSiblingUpdates`.
- **`BaseDao` is package-private (`abstract class BaseDao`)** in package `edens.zac.portfolio.backend.dao`, exposing `protected` `query(...)`, `update(...)`, `createParameterSource()`, and the `namedParameterJdbcTemplate` field — so the new DAO and its test must live in that same `dao` package (the test reflection-swaps `BaseDao.class.getDeclaredField("namedParameterJdbcTemplate")`, identical to `CollectionRepositoryTest`).

---

## FRONTEND TRACK

These tasks implement the frontend half of the sibling-collections feature. They are written to be executed **after** the backend returns the `siblings` field (the types in FE-1 are forward-compatible — the UI degrades gracefully to empty until the backend ships). Each task is independently committable.

**Execution model.** FE-1 → FE-2 → FE-5 are mostly independent type/util edits. FE-3 (selector) is a prerequisite for FE-4 (ManageClient wiring). FE-6 (public render) depends only on FE-1. The four pure-unit tasks (FE-2, FE-5) and the two component tasks (FE-3, FE-6) touch disjoint files and could be parallelized across agents if desired.

> **Critical real-code constraint discovered during exploration:** `CollectionListSelector` has **two** consumers — `ManageClient.tsx` (line 1602) *and* `ImageMetadataModal.tsx` (line 1051). The existing test suite (`tests/components/CollectionListSelector.test.tsx`, 19 tests) drives the single-column contract. Therefore the two-column extension in FE-3 must be **purely additive and backward-compatible**: every new prop is optional, and when the sibling props are absent the component renders **exactly** its current single-column layout. This is enforced by a TDD step in FE-3 that keeps all existing tests green.

---

### Task FE-1: Type additions — `CollectionModel.siblings`, `CollectionUpdateRequest.siblings`, `TextBlockItem` `'collection'`

**Files:**
- Modify: `app/types/Collection.ts:160-205` (`CollectionModel`), `app/types/Collection.ts:134-154` (`CollectionUpdateRequest`)
- Modify: `app/types/Content.ts:125-130` (`TextBlockItem`)
- Test (verification only — type-only change): `tsc --noEmit`

Steps:

- [ ] Add `siblings?: CollectionListModel[];` to `CollectionModel`. The interface already imports nothing extra — `CollectionListModel` is declared in the same file (lines 67-72). Insert the field in the "Content" region near the end of the interface. Current code (the tail of `CollectionModel`):
  ```ts
    /** Admin-only: recipient email addresses. Populated only in admin/manage responses. */
    recipientEmails?: string[];

    // Content
    content?: AnyContentModel[];
  }
  ```
  Change to:
  ```ts
    /** Admin-only: recipient email addresses. Populated only in admin/manage responses. */
    recipientEmails?: string[];

    /**
     * Curated, mutual "sibling" collections (variant peers). Public reads return only
     * LISTED siblings; admin/manage reads return all. Rendered as `Related:` text links
     * in the metadata block. Mirrors backend CollectionModel.siblings (List<CollectionList>).
     */
    siblings?: CollectionListModel[];

    // Content
    content?: AnyContentModel[];
  }
  ```

- [ ] Add `siblings?: CollectionUpdate;` to `CollectionUpdateRequest`, mirroring `collections?: CollectionUpdate` at line 153. Current tail of the interface:
  ```ts
    tags?: TagUpdate;
    people?: PersonUpdate;
    collections?: CollectionUpdate;
  }
  ```
  Change to:
  ```ts
    tags?: TagUpdate;
    people?: PersonUpdate;
    collections?: CollectionUpdate;
    /**
     * Sibling-collection updates (mutual association). Reuses the `CollectionUpdate`
     * wire shape; backend honors only `newValue` (add) and `remove` (delete) — `prev`
     * and the `orderIndex`/`visible` fields of each `ChildCollection` are ignored.
     */
    siblings?: CollectionUpdate;
  }
  ```

- [ ] Extend the `TextBlockItem.type` union with `'collection'` in `app/types/Content.ts`. Current:
  ```ts
  export interface TextBlockItem {
    type: 'date' | 'location' | 'description' | 'text' | 'tag';
    value: string;
    slug?: string; // URL slug for navigation (location and tag items)
    label?: string; // Optional display label (e.g., "Date:", "Location:")
  }
  ```
  Change to:
  ```ts
  export interface TextBlockItem {
    type: 'date' | 'location' | 'description' | 'text' | 'tag' | 'collection';
    value: string;
    slug?: string; // URL slug for navigation (location, tag, and sibling-collection items)
    label?: string; // Optional display label (e.g., "Date:", "Location:")
  }
  ```

- [ ] Type-check. Verifies the additions compile and break nothing (the five existing `item.type === …` consumers in `CollectionContentRenderer.tsx` are `find`/`filter` calls, not an exhaustive `switch`, so a new union member is non-breaking):
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
  ```
  Expected output: no output, exit code 0.

- [ ] Lint the touched type files:
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/eslint --fix app/types/Collection.ts app/types/Content.ts
  ```
  Expected output: no errors (exit 0).

- [ ] Commit:
  ```bash
  git commit -m "feat(siblings): add siblings to Collection types and 'collection' TextBlockItem"
  ```

---

### Task FE-2: `buildUpdatePayload` siblings passthrough (TDD)

**Files:**
- Modify: `app/(admin)/collection/manage/[[...slug]]/manageUtils.ts:86-88` (the `collections` passthrough block in `buildUpdatePayload`)
- Test: `tests/(admin)/collection/manage/[[...slug]]/manageUtils.test.ts` (add case after the `'should include collections when set'` case at line 664-680)

Steps:

- [ ] **RED** — add a failing test mirroring the existing collections case. Insert immediately after the closing `});` of the `'should include collections when set'` test (line 680), inside the `describe('passing cases', …)` block:
  ```ts
  it('should include siblings when set', () => {
    const formData: CollectionUpdateRequest = {
      id: 1,
      siblings: {
        newValue: [{ collectionId: 5, name: 'Sibling Collection' }],
        remove: [9],
      },
    };

    const result = buildUpdatePayload(formData, originalCollection);

    expect(result).toEqual({
      id: 1,
      siblings: {
        newValue: [{ collectionId: 5, name: 'Sibling Collection' }],
        remove: [9],
      },
    });
  });
  ```

- [ ] Run the test — it must FAIL (the field is dropped because `buildUpdatePayload` has no `siblings` passthrough yet):
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/jest "tests/(admin)/collection/manage/[[...slug]]/manageUtils.test.ts" -t "should include siblings when set"
  ```
  Expected output: `1 failed` — `Expected { id: 1, siblings: {…} }, Received { id: 1 }`.

- [ ] **GREEN** — add the passthrough in `buildUpdatePayload`. Current code (lines 86-93):
  ```ts
    if (formData.collections !== undefined) {
      payload.collections = formData.collections;
    }

    if (formData.locations !== undefined) {
      payload.locations = formData.locations;
    }

    return payload;
  ```
  Change to:
  ```ts
    if (formData.collections !== undefined) {
      payload.collections = formData.collections;
    }

    if (formData.siblings !== undefined) {
      payload.siblings = formData.siblings;
    }

    if (formData.locations !== undefined) {
      payload.locations = formData.locations;
    }

    return payload;
  ```
  Also update the `@remarks` JSDoc bullet at line 33 for accuracy. Current:
  ```ts
   * - `coverImageId`, `collections`, and `locations` use presence-check (`!== undefined`) rather
   *   than value-diff because each has its own update semantics.
  ```
  Change to:
  ```ts
   * - `coverImageId`, `collections`, `siblings`, and `locations` use presence-check
   *   (`!== undefined`) rather than value-diff because each has its own update semantics.
  ```

- [ ] Run the new test plus the existing `collections` test — both must pass (proves the passthrough is symmetric and nothing regressed):
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/jest "tests/(admin)/collection/manage/[[...slug]]/manageUtils.test.ts" -t "should include"
  ```
  Expected output: all matched tests pass (includes `should include collections when set`, `should include siblings when set`, `should include coverImageId when set`, etc.).

- [ ] Type-check + lint:
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
  /opt/homebrew/bin/node node_modules/.bin/eslint --fix "app/(admin)/collection/manage/[[...slug]]/manageUtils.ts" "tests/(admin)/collection/manage/[[...slug]]/manageUtils.test.ts"
  ```
  Expected output: no output / no errors (exit 0).

- [ ] Commit:
  ```bash
  git commit -m "feat(siblings): pass siblings through buildUpdatePayload"
  ```

---

### Task FE-3: Extend `CollectionListSelector` to two toggle columns (TDD, backward-compatible)

**Files:**
- Modify: `app/components/CollectionListSelector/CollectionListSelector.tsx` (FULL — props interface + JSX)
- Modify: `app/components/CollectionListSelector/CollectionListSelector.module.scss` (add a second checkbox cell + column headers; keep `.name` left-alignable)
- Test: `tests/components/CollectionListSelector.test.tsx` (add a `describe('two-column sibling mode', …)` block; the existing 19 tests must stay green)

**Design (additive, dual-mode):** The component keeps its current single-column contract when the sibling props are absent. When `siblingProps` are supplied, it renders a header row (`Sibling` | `Child` column labels), then per row: a **Sibling** checkbox, a **Child** checkbox (the existing checkbox, now labeled `Child`), then the name on the **left** of the two columns. The existing `onToggle`/`pendingAddIds`/etc. become the **Child** column (zero behavior change for `ImageMetadataModal`, which never passes sibling props).

Steps:

- [ ] **RED** — add a new test block at the end of `tests/components/CollectionListSelector.test.tsx`, before the final closing `});` of `describe('CollectionListSelector', …)`. It exercises the new two-column API and asserts independence:
  ```ts
  describe('two-column sibling mode', () => {
    const twoColProps = {
      allCollections: mockCollections,
      // Child column (existing props)
      savedCollectionIds: new Set<number>([1]),
      pendingAddIds: new Set<number>(),
      pendingRemoveIds: new Set<number>(),
      onToggle: jest.fn(),
      // Sibling column (new props)
      siblingSavedIds: new Set<number>([2]),
      siblingPendingAddIds: new Set<number>(),
      siblingPendingRemoveIds: new Set<number>(),
      onToggleSibling: jest.fn(),
    };

    beforeEach(() => {
      jest.clearAllMocks();
    });

    it('renders Sibling and Child column headers when sibling props are provided', () => {
      render(<CollectionListSelector {...twoColProps} />);
      expect(screen.getByText('Sibling')).toBeInTheDocument();
      expect(screen.getByText('Child')).toBeInTheDocument();
    });

    it('exposes a Sibling and a Child toggle per collection row', () => {
      render(<CollectionListSelector {...twoColProps} />);
      // Each name yields two distinct toggles, disambiguated by aria-label
      expect(screen.getByLabelText('Toggle sibling Portfolio A')).toBeInTheDocument();
      expect(screen.getByLabelText('Toggle child Portfolio A')).toBeInTheDocument();
    });

    it('fires onToggleSibling (not onToggle) when the Sibling checkbox is clicked', () => {
      const onToggle = jest.fn();
      const onToggleSibling = jest.fn();
      render(
        <CollectionListSelector
          {...twoColProps}
          onToggle={onToggle}
          onToggleSibling={onToggleSibling}
        />
      );
      fireEvent.click(screen.getByLabelText('Toggle sibling Portfolio A'));
      expect(onToggleSibling).toHaveBeenCalledTimes(1);
      expect(onToggleSibling).toHaveBeenCalledWith(mockCollections[0]);
      expect(onToggle).not.toHaveBeenCalled();
    });

    it('fires onToggle (not onToggleSibling) when the Child checkbox is clicked', () => {
      const onToggle = jest.fn();
      const onToggleSibling = jest.fn();
      render(
        <CollectionListSelector
          {...twoColProps}
          onToggle={onToggle}
          onToggleSibling={onToggleSibling}
        />
      );
      fireEvent.click(screen.getByLabelText('Toggle child Portfolio A'));
      expect(onToggle).toHaveBeenCalledTimes(1);
      expect(onToggle).toHaveBeenCalledWith(mockCollections[0]);
      expect(onToggleSibling).not.toHaveBeenCalled();
    });

    it('reflects independent saved state per column (sibling on B, child on A)', () => {
      render(<CollectionListSelector {...twoColProps} />);
      // Child saved on collection 1 (Portfolio A)
      expect(screen.getByLabelText('Toggle child Portfolio A').className).toContain('saved');
      // Sibling saved on collection 2 (Blog B)
      expect(screen.getByLabelText('Toggle sibling Blog B').className).toContain('saved');
      // Cross-check: sibling NOT saved on A, child NOT saved on B
      expect(screen.getByLabelText('Toggle sibling Portfolio A').className).toContain('empty');
      expect(screen.getByLabelText('Toggle child Blog B').className).toContain('empty');
    });

    it('still omits the excludeCollectionId row in two-column mode', () => {
      render(<CollectionListSelector {...twoColProps} excludeCollectionId={2} />);
      expect(screen.getByText('Portfolio A')).toBeInTheDocument();
      expect(screen.queryByText('Blog B')).not.toBeInTheDocument();
    });
  });
  ```

- [ ] Run the new block — it must FAIL (two-column API does not exist; the current single checkbox has `aria-label={`Toggle ${name}`}`, so `Toggle sibling/child …` and the `Sibling`/`Child` headers are not found):
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/jest tests/components/CollectionListSelector.test.tsx -t "two-column sibling mode"
  ```
  Expected output: `6 failed` — `Unable to find an element with the text: Sibling` / `Unable to find a label 'Toggle sibling Portfolio A'`.

- [ ] **GREEN** — rewrite `app/components/CollectionListSelector/CollectionListSelector.tsx` to support both modes. The full new file:
  ```tsx
  'use client';

  import { useCallback, useState } from 'react';

  import type { CollectionListModel } from '@/app/types/Collection';

  import styles from './CollectionListSelector.module.scss';

  type CheckboxState = 'empty' | 'saved' | 'pending-add' | 'pending-remove';

  interface CollectionListSelectorProps {
    allCollections: CollectionListModel[];
    // Primary (Child) column — existing contract
    savedCollectionIds: Set<number>;
    pendingAddIds: Set<number>;
    pendingRemoveIds: Set<number>;
    onToggle: (collection: CollectionListModel) => void;
    onNavigate?: (collection: CollectionListModel) => void;
    onAddNewChild?: () => void;
    label?: string;
    excludeCollectionId?: number;
    // Secondary (Sibling) column — optional. When all four are provided the selector
    // renders a two-column `Sibling | Child` grid; otherwise it stays single-column.
    siblingSavedIds?: Set<number>;
    siblingPendingAddIds?: Set<number>;
    siblingPendingRemoveIds?: Set<number>;
    onToggleSibling?: (collection: CollectionListModel) => void;
  }

  function getCheckboxState(
    collectionId: number,
    savedIds: Set<number>,
    pendingAddIds: Set<number>,
    pendingRemoveIds: Set<number>
  ): CheckboxState {
    if (pendingRemoveIds.has(collectionId)) return 'pending-remove';
    if (pendingAddIds.has(collectionId)) return 'pending-add';
    if (savedIds.has(collectionId)) return 'saved';
    return 'empty';
  }

  export default function CollectionListSelector({
    allCollections,
    savedCollectionIds,
    pendingAddIds,
    pendingRemoveIds,
    onToggle,
    onNavigate,
    onAddNewChild,
    label = 'Collections',
    excludeCollectionId,
    siblingSavedIds,
    siblingPendingAddIds,
    siblingPendingRemoveIds,
    onToggleSibling,
  }: CollectionListSelectorProps) {
    const [hoveredCheckboxId, setHoveredCheckboxId] = useState<number | null>(null);
    const [hoveredSiblingId, setHoveredSiblingId] = useState<number | null>(null);

    // Two-column mode is active only when the full sibling prop-set is supplied.
    const siblingMode =
      !!onToggleSibling &&
      !!siblingSavedIds &&
      !!siblingPendingAddIds &&
      !!siblingPendingRemoveIds;

    const filteredCollections = excludeCollectionId
      ? allCollections.filter(c => c.id !== excludeCollectionId)
      : allCollections;

    const handleChildClick = useCallback(
      (e: React.MouseEvent, collection: CollectionListModel) => {
        e.stopPropagation();
        onToggle(collection);
      },
      [onToggle]
    );

    const handleSiblingClick = useCallback(
      (e: React.MouseEvent, collection: CollectionListModel) => {
        e.stopPropagation();
        onToggleSibling?.(collection);
      },
      [onToggleSibling]
    );

    const handleRowClick = useCallback(
      (collection: CollectionListModel) => {
        if (onNavigate) {
          onNavigate(collection);
        } else if (!siblingMode) {
          // In single-column mode a bare row click toggles the (child) relationship.
          // In two-column mode the row has two independent toggles, so a row click is a no-op.
          onToggle(collection);
        }
      },
      [onNavigate, onToggle, siblingMode]
    );

    return (
      <div className={styles.container}>
        <div className={styles.header}>
          <label className={styles.label}>{label}</label>
          {onAddNewChild && (
            <button type="button" className={styles.addButton} onClick={onAddNewChild}>
              Add New Child
            </button>
          )}
        </div>
        {siblingMode && (
          <div className={styles.columnHeaderRow}>
            <span className={styles.columnHeader}>Sibling</span>
            <span className={styles.columnHeader}>Child</span>
            <span className={styles.columnHeaderName} />
          </div>
        )}
        <div className={styles.list}>
          {filteredCollections.length === 0 && (
            <div className={styles.emptyState}>No collections available</div>
          )}
          {filteredCollections.map(collection => {
            const childState = getCheckboxState(
              collection.id,
              savedCollectionIds,
              pendingAddIds,
              pendingRemoveIds
            );
            const isChildHovered = hoveredCheckboxId === collection.id;
            const isChildSelected = childState === 'saved' || childState === 'pending-add';
            const showChildRemoveIntent = isChildHovered && isChildSelected;

            const siblingState = siblingMode
              ? getCheckboxState(
                  collection.id,
                  siblingSavedIds!,
                  siblingPendingAddIds!,
                  siblingPendingRemoveIds!
                )
              : 'empty';
            const isSiblingHovered = hoveredSiblingId === collection.id;
            const isSiblingSelected =
              siblingState === 'saved' || siblingState === 'pending-add';
            const showSiblingRemoveIntent = isSiblingHovered && isSiblingSelected;

            return (
              <div
                key={collection.id}
                className={`${styles.row} ${onNavigate ? styles.navigable : ''}`}
                role="button"
                tabIndex={0}
                onClick={() => handleRowClick(collection)}
                onKeyDown={e => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    handleRowClick(collection);
                  }
                }}
              >
                {siblingMode && (
                  <button
                    type="button"
                    className={`${styles.checkbox} ${styles[`checkbox--${siblingState}`]} ${showSiblingRemoveIntent ? styles['checkbox--remove-intent'] : ''}`}
                    onClick={e => handleSiblingClick(e, collection)}
                    onMouseEnter={() => setHoveredSiblingId(collection.id)}
                    onMouseLeave={() => setHoveredSiblingId(null)}
                    aria-label={`Toggle sibling ${collection.name}`}
                  />
                )}
                <button
                  type="button"
                  className={`${styles.checkbox} ${styles[`checkbox--${childState}`]} ${showChildRemoveIntent ? styles['checkbox--remove-intent'] : ''}`}
                  onClick={e => handleChildClick(e, collection)}
                  onMouseEnter={() => setHoveredCheckboxId(collection.id)}
                  onMouseLeave={() => setHoveredCheckboxId(null)}
                  aria-label={siblingMode ? `Toggle child ${collection.name}` : `Toggle ${collection.name}`}
                />
                <span className={styles.type}>{collection.type || 'Portfolio'}</span>
                <span className={styles.name}>{collection.name}</span>
              </div>
            );
          })}
        </div>
      </div>
    );
  }
  ```

  > Note the single-column `aria-label` is preserved verbatim (`Toggle ${collection.name}`) so the **existing 19 tests stay green**; only two-column mode uses the `child`/`sibling` prefixes.

- [ ] Add the new SCSS to `app/components/CollectionListSelector/CollectionListSelector.module.scss`. Append after `.header` (after line 13's closing brace) for the column-header row, and keep the existing checkbox/row styles unchanged:
  ```scss
  .columnHeaderRow {
    display: flex;
    align-items: center;
    gap: var(--space-2);
    padding: 0 var(--space-3) var(--space-1);
  }

  .columnHeader {
    width: 16px;
    min-width: 16px;
    font-size: var(--text-xs);
    font-weight: 600;
    color: var(--color-text-muted);
    text-align: center;
    flex-shrink: 0;
  }

  .columnHeaderName {
    flex: 1;
  }
  ```

- [ ] Run the new sibling block AND the full existing suite together (proves both the new contract and zero regression on the single-column consumers):
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/jest tests/components/CollectionListSelector.test.tsx
  ```
  Expected output: all tests pass (19 original + 6 new = 25 passing, `Tests: 25 passed`).

- [ ] Format, lint, SCSS-lint, type-check:
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/prettier --write app/components/CollectionListSelector/CollectionListSelector.tsx app/components/CollectionListSelector/CollectionListSelector.module.scss
  /opt/homebrew/bin/node node_modules/.bin/eslint --fix app/components/CollectionListSelector/CollectionListSelector.tsx tests/components/CollectionListSelector.test.tsx
  /opt/homebrew/bin/node node_modules/.bin/stylelint --fix app/components/CollectionListSelector/CollectionListSelector.module.scss
  /opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
  ```
  Expected output: each command exits 0 with no remaining errors.

- [ ] Commit:
  ```bash
  git commit -m "feat(siblings): extend CollectionListSelector to Sibling|Child two-column grid"
  ```

---

### Task FE-4: `ManageClient` sibling selection state + wiring

**Files:**
- Modify: `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx` — add sibling state region mirroring child state (after lines 800-913), and pass the new props into the `CollectionListSelector` at line 1602-1619
- Test: covered by FE-2 (payload) + FE-3 (selector). ManageClient itself is an integration component already mocked in `tests/(admin)/collection/manage/[[...slug]]/ManageClient.galleryAccess.test.tsx` (which mocks `CollectionListSelector` entirely). Verify via **manual check** + `tsc`; no new unit test (the existing ManageClient test mocks the selector, so it neither breaks nor exercises this wiring).

Steps:

- [ ] Add three `useMemo` derivations + one `useCallback` handler for siblings, mirroring `originalCollectionIds`/`pendingAddIds`/`pendingRemoveIds` (lines 800-822) and `handleCollectionToggle` (lines 866-913). **Key difference:** `originalSiblingIds` derives from `collection.siblings` (the new field, a `CollectionListModel[]`), not from `collection.content`. Insert immediately after the `handleCollectionToggle` `useCallback` ends (line 913):
  ```tsx
    /**
     * Sibling-collection selection state — mirrors the child-collection state above,
     * but `originalSiblingIds` derives from `collection.siblings` (mutual association)
     * rather than from `collection.content` (containment).
     */
    const originalSiblingIds = useMemo(() => {
      const ids = new Set<number>();
      for (const sib of collection?.siblings ?? []) {
        ids.add(sib.id);
      }
      return ids;
    }, [collection?.siblings]);

    const pendingAddSiblingIds = useMemo(() => {
      const ids = new Set<number>();
      for (const sib of updateData.siblings?.newValue ?? []) {
        ids.add(sib.collectionId);
      }
      return ids;
    }, [updateData.siblings?.newValue]);

    const pendingRemoveSiblingIds = useMemo(() => {
      return new Set<number>(updateData.siblings?.remove ?? []);
    }, [updateData.siblings?.remove]);

    /**
     * Handle sibling toggle from CollectionListSelector (Sibling column).
     * Mutates `updateData.siblings` (newValue/remove) exactly like handleCollectionToggle
     * mutates `updateData.collections`.
     */
    const handleSiblingToggle = useCallback(
      (toggledCollection: CollectionListModel) => {
        setUpdateData(prev => {
          const currentRemove = new Set(prev.siblings?.remove || []);
          const currentNewValue = prev.siblings?.newValue || [];
          const isSaved = originalSiblingIds.has(toggledCollection.id);

          let newRemove: number[];
          if (!isSaved) {
            newRemove = [...currentRemove];
          } else if (currentRemove.has(toggledCollection.id)) {
            newRemove = [...currentRemove].filter(id => id !== toggledCollection.id);
          } else {
            newRemove = [...currentRemove, toggledCollection.id];
          }

          let newNewValue: typeof currentNewValue;
          if (isSaved) {
            newNewValue = [...currentNewValue];
          } else if (currentNewValue.some(c => c.collectionId === toggledCollection.id)) {
            newNewValue = currentNewValue.filter(c => c.collectionId !== toggledCollection.id);
          } else {
            newNewValue = [
              ...currentNewValue,
              { collectionId: toggledCollection.id, name: toggledCollection.name },
            ];
          }

          const hasChanges = newRemove.length > 0 || newNewValue.length > 0;
          return {
            ...prev,
            siblings: hasChanges
              ? {
                  ...prev.siblings,
                  remove: newRemove.length > 0 ? newRemove : undefined,
                  newValue: newNewValue.length > 0 ? newNewValue : undefined,
                }
              : undefined,
          };
        });
      },
      [originalSiblingIds]
    );
  ```
  > The sibling `newValue` entry intentionally omits `visible`/`orderIndex` (unlike child toggling at lines 893-895) because siblings carry no per-link order/visibility — the backend ignores those fields for siblings, and the spec specifies a bare `{ collectionId, name }`.

- [ ] Pass the four new props into the `CollectionListSelector` instance at line 1602. Current usage:
  ```tsx
                          <CollectionListSelector
                            allCollections={allCollections}
                            savedCollectionIds={originalCollectionIds}
                            pendingAddIds={pendingAddIds}
                            pendingRemoveIds={pendingRemoveIds}
                            onToggle={handleCollectionToggle}
                            onNavigate={col => {
                              if (col.slug) {
                                router.push(`/collection/manage/${col.slug}`);
                              } else {
                                console.error('Cannot navigate to collection: missing slug', col);
                                setError(`Cannot navigate to collection "${col.name}": missing slug`);
                              }
                            }}
                            onAddNewChild={handleAddNewChild}
                            label="Collections"
                            excludeCollectionId={collection.id}
                          />
  ```
  Change to (add the four sibling props; **remove `onNavigate`** here — in two-column mode the row click is a no-op so navigation-on-row-click no longer applies, and the selector now needs the row to host two independent toggles rather than a navigate-on-click. The "Add New Child" button is retained):
  ```tsx
                          <CollectionListSelector
                            allCollections={allCollections}
                            savedCollectionIds={originalCollectionIds}
                            pendingAddIds={pendingAddIds}
                            pendingRemoveIds={pendingRemoveIds}
                            onToggle={handleCollectionToggle}
                            siblingSavedIds={originalSiblingIds}
                            siblingPendingAddIds={pendingAddSiblingIds}
                            siblingPendingRemoveIds={pendingRemoveSiblingIds}
                            onToggleSibling={handleSiblingToggle}
                            onAddNewChild={handleAddNewChild}
                            label="Collections"
                            excludeCollectionId={collection.id}
                          />
  ```
  > **Decision to confirm with reviewer:** dropping `onNavigate` removes the "click row → open that collection's manage page" shortcut. This is the cleanest reconciliation of "two independent toggle columns" with the existing single-toggle-row affordance (you cannot both navigate-on-row-click and host two toggles). If preserving navigation matters, an alternative is a dedicated name-cell link — flag during plan review. The spec's grid layout (name on the left, two toggle columns) does not call for row-click navigation, so removing it is spec-aligned.

- [ ] Confirm `CollectionListModel` and the hooks are already imported in `ManageClient.tsx` (they are — `CollectionListModel` is used by `handleCollectionToggle` at line 867; `useMemo`/`useCallback` are already in use). No new imports needed. Verify:
  ```bash
  grep -n "CollectionListModel\|useMemo\|useCallback" "app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx" | head -5
  ```
  Expected output: shows existing imports of `CollectionListModel` and `useMemo`/`useCallback` (no edit required).

- [ ] Type-check + run the existing ManageClient test (it mocks the selector, so it must remain green and proves the wiring compiles in context):
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
  /opt/homebrew/bin/node node_modules/.bin/jest "tests/(admin)/collection/manage/[[...slug]]/ManageClient.galleryAccess.test.tsx"
  ```
  Expected output: `tsc` exits 0 with no output; the test file passes (`Tests: N passed`).

- [ ] Lint:
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/eslint --fix "app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx"
  ```
  Expected output: no errors (exit 0).

- [ ] **Manual verification** (dev profile, against a backend returning `siblings`): open `/collection/manage/<slug>`, confirm the collections panel shows `Sibling` + `Child` headers; tick a Sibling on collection B, Save; reopen B's manage page and confirm A appears as a checked Sibling (reciprocity, backend-driven). Ticking Child still behaves as before. Per the project's preview-port convention, use port 3001 for the preview server (the user keeps 3000).

- [ ] Commit:
  ```bash
  git commit -m "feat(siblings): wire sibling selection state into ManageClient selector"
  ```

---

### Task FE-5: `buildMetadataItems` emits sibling items (TDD via `createHeaderRow`)

**Files:**
- Modify: `app/utils/contentLayout.ts:429-466` (`buildMetadataItems` — push sibling items after the tags loop)
- Test: `tests/utils/contentLayout.test.ts` (add cases to the `describe('createHeaderRow', …)` block at line 938 — `buildMetadataItems` is private, so assert via the metadata text block the header row produces)

> **Why drive through `createHeaderRow`:** `buildMetadataItems` is not exported. The existing tests already reach its output through `createHeaderRow(...).items[1].content.items` (see line 968-976). The default `createCollectionModel(1)` fixture has a date + 1 location + description and **no siblings**, so its metadata block has exactly 3 items (asserted at line 976) — adding sibling emission must NOT change that count, which the first new test guards.

Steps:

- [ ] **RED** — add two tests inside the `describe('Normal cases with full metadata', …)` group (after the `'should create header row with metadata block with all metadata items'` test ends at ~line 977), still within the outer `describe('createHeaderRow', () => { const componentWidth = 800; const chunkSize = 4; …`:
  ```ts
    it('should append a collection item per sibling after the tags', () => {
      const collection = createCollectionModel(1, {
        siblings: [
          { id: 50, name: 'Dolomites Film', slug: 'dolomites-film' },
          { id: 51, name: 'Dolomites 2025', slug: 'dolomites-2025' },
        ],
      });
      const result = asSingleRow(createHeaderRow(collection, componentWidth, chunkSize));
      const metadataBlock = result?.items[1]?.content as ContentTextModel;

      const collectionItems = metadataBlock.items.filter(item => item.type === 'collection');
      expect(collectionItems).toHaveLength(2);
      expect(collectionItems[0]).toEqual({
        type: 'collection',
        value: 'Dolomites Film',
        slug: '/dolomites-film',
      });
      expect(collectionItems[1]).toEqual({
        type: 'collection',
        value: 'Dolomites 2025',
        slug: '/dolomites-2025',
      });
    });

    it('should emit no collection items when the collection has no siblings', () => {
      const collection = createCollectionModel(1); // fixture has no siblings
      const result = asSingleRow(createHeaderRow(collection, componentWidth, chunkSize));
      const metadataBlock = result?.items[1]?.content as ContentTextModel;

      expect(metadataBlock.items.filter(item => item.type === 'collection')).toHaveLength(0);
      // Sanity: existing date+location+description count is unchanged
      expect(metadataBlock.items).toHaveLength(3);
    });

    it('should skip siblings that have no slug', () => {
      const collection = createCollectionModel(1, {
        siblings: [
          { id: 60, name: 'Has Slug', slug: 'has-slug' },
          { id: 61, name: 'No Slug' }, // slug undefined → skipped
        ],
      });
      const result = asSingleRow(createHeaderRow(collection, componentWidth, chunkSize));
      const metadataBlock = result?.items[1]?.content as ContentTextModel;

      const collectionItems = metadataBlock.items.filter(item => item.type === 'collection');
      expect(collectionItems).toHaveLength(1);
      expect(collectionItems[0]?.value).toBe('Has Slug');
      expect(collectionItems[0]?.slug).toBe('/has-slug');
    });
  ```

- [ ] Run them — they must FAIL (no sibling emission yet; `collection` items length is 0):
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/jest tests/utils/contentLayout.test.ts -t "sibling"
  ```
  Expected output: `2 failed` (the two sibling-emitting tests; the "no siblings" test already passes). E.g. `expect(received).toHaveLength(2) // Received length: 0`.

- [ ] **GREEN** — add the sibling loop to `buildMetadataItems`, after the tags loop. Current tail (lines 456-466):
  ```ts
    if (collection.tags && collection.tags.length > 0) {
      for (const tag of collection.tags) {
        items.push({
          type: 'tag',
          value: tag,
        });
      }
    }

    return items;
  }
  ```
  Change to:
  ```ts
    if (collection.tags && collection.tags.length > 0) {
      for (const tag of collection.tags) {
        items.push({
          type: 'tag',
          value: tag,
        });
      }
    }

    if (collection.siblings && collection.siblings.length > 0) {
      for (const sib of collection.siblings) {
        if (sib.slug) {
          items.push({ type: 'collection', value: sib.name, slug: `/${sib.slug}` });
        }
      }
    }

    return items;
  }
  ```
  Also update the function's JSDoc (line 427) for accuracy:
  ```ts
  /**
   * Build metadata items array from collection fields (date, location, description, tags, siblings).
   */
  ```

- [ ] Re-run the sibling tests + the existing full-metadata group (proves emission works and the 3-item count for the default fixture is intact):
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/jest tests/utils/contentLayout.test.ts -t "createHeaderRow"
  ```
  Expected output: all `createHeaderRow` tests pass, including `should create header row with metadata block with all metadata items` (still 3 items) and the three new sibling tests.

- [ ] Run the full contentLayout suite to be safe:
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/jest tests/utils/contentLayout.test.ts
  ```
  Expected output: `Tests: <all> passed`.

- [ ] Type-check + lint:
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
  /opt/homebrew/bin/node node_modules/.bin/eslint --fix app/utils/contentLayout.ts tests/utils/contentLayout.test.ts
  ```
  Expected output: exit 0, no errors.

- [ ] Commit:
  ```bash
  git commit -m "feat(siblings): emit collection metadata items for siblings in buildMetadataItems"
  ```

---

### Task FE-6: `CollectionContentRenderer` `'collection'` render branch + SCSS (TDD)

**Files:**
- Modify: `app/components/Content/CollectionContentRenderer.tsx:164-268` (TEXT branch — add a `Related:` block for `'collection'` items)
- Modify: `app/components/Content/ContentComponent.module.scss` (add `.metadataSiblingsContainer`, `.metadataSiblingsRow`, `.metadataSiblingLabel`, `.metadataSiblingCollection` — the link styled like `.metadataLocation` at lines 422-434)
- Create: `tests/components/Content/CollectionContentRenderer.test.tsx` (new — the `tests/components/Content/` dir currently has no renderer test; React Testing Library is the project convention)

Steps:

- [ ] **RED** — create `tests/components/Content/CollectionContentRenderer.test.tsx`. Mock `next/navigation` (the component calls `useRouter`) and the parallax hook; render the TEXT branch with a `'collection'` item and assert the `Related:` label + an `<a>` to the sibling slug. (Pattern mirrors the existing `tests/components/CollectionListSelector.test.tsx` — `@testing-library/jest-dom` + `render`/`screen`. `next/link` renders a real `<a href>` under jsdom, so `getByRole('link')` works.)
  ```tsx
  import '@testing-library/jest-dom';

  import { render, screen } from '@testing-library/react';

  import CollectionContentRenderer from '@/app/components/Content/CollectionContentRenderer';
  import type { TextBlockItem } from '@/app/types/Content';

  // next/navigation: component calls useRouter()
  jest.mock('next/navigation', () => ({
    useRouter: () => ({ push: jest.fn() }),
  }));

  // Parallax hook returns a ref; stub to a no-op ref
  jest.mock('@/app/hooks/useParallax', () => ({
    useParallax: () => ({ current: null }),
  }));

  // CollectionFilterContext: TEXT branch reads useCollectionFilter(); default to no filter bar
  jest.mock('@/app/components/ContentCollection/CollectionFilterContext', () => ({
    useCollectionFilter: () => null,
  }));

  const baseProps = {
    contentId: -2,
    className: 'imageSingle',
    width: 400,
    height: 300,
    isMobile: false,
    imageUrl: '',
    imageWidth: 0,
    imageHeight: 0,
    alt: '',
    enableParallax: false,
    contentType: 'TEXT' as const,
  };

  describe('CollectionContentRenderer — TEXT branch sibling collections', () => {
    it('renders a Related: label and a link per collection item', () => {
      const textItems: TextBlockItem[] = [
        { type: 'collection', value: 'Dolomites Film', slug: '/dolomites-film' },
        { type: 'collection', value: 'Dolomites 2025', slug: '/dolomites-2025' },
      ];
      render(<CollectionContentRenderer {...baseProps} textItems={textItems} />);

      expect(screen.getByText('Related:')).toBeInTheDocument();

      const filmLink = screen.getByRole('link', { name: 'Dolomites Film' });
      expect(filmLink).toHaveAttribute('href', '/dolomites-film');

      const link2025 = screen.getByRole('link', { name: 'Dolomites 2025' });
      expect(link2025).toHaveAttribute('href', '/dolomites-2025');
    });

    it('renders no Related: label when there are no collection items', () => {
      const textItems: TextBlockItem[] = [
        { type: 'description', value: 'Just a description' },
      ];
      render(<CollectionContentRenderer {...baseProps} textItems={textItems} />);

      expect(screen.queryByText('Related:')).not.toBeInTheDocument();
    });
  });
  ```

- [ ] Run it — it must FAIL (no `'collection'` render block exists; `Related:` and the links are not found):
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/jest tests/components/Content/CollectionContentRenderer.test.tsx
  ```
  Expected output: `1 failed` for the first test — `Unable to find an element with the text: Related:`.

- [ ] **GREEN** — add a `collectionItems` derivation and a render block in the TEXT branch. In the block of `find`/`filter` calls (lines 169-173), add one line. Current:
  ```ts
      const dateItem = textItems.find(item => item.type === 'date');
      const locationItem = textItems.find(item => item.type === 'location');
      const descriptionItem = textItems.find(item => item.type === 'description');
      const tagItems = textItems.filter(item => item.type === 'tag');
      const filterItems = textItems.filter(item => item.type === 'text');
  ```
  Change to:
  ```ts
      const dateItem = textItems.find(item => item.type === 'date');
      const locationItem = textItems.find(item => item.type === 'location');
      const descriptionItem = textItems.find(item => item.type === 'description');
      const tagItems = textItems.filter(item => item.type === 'tag');
      const filterItems = textItems.filter(item => item.type === 'text');
      const collectionItems = textItems.filter(item => item.type === 'collection');
  ```
  Then add the render block after the tags container and before the client-gallery block. Current (lines 236-254):
  ```tsx
              {!collectionFilter && tagItems.length > 0 && (
                <div className={cbStyles.metadataTagsContainer}>
                  <div className={cbStyles.metadataTagsRow}>
                    {tagItems.map(item => (
                      <button
                        key={`tag-${contentId}-${item.value}`}
                        type="button"
                        className={cbStyles.metadataTag}
                        onClick={() => handleTagClick(item.value, item.slug)}
                      >
                        {item.value}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {isClientGallery && collectionSlug && (
                <ClientGalleryDownload collectionSlug={collectionSlug} />
              )}
  ```
  Change to (insert the siblings block between the tags container and the client-gallery block):
  ```tsx
              {!collectionFilter && tagItems.length > 0 && (
                <div className={cbStyles.metadataTagsContainer}>
                  <div className={cbStyles.metadataTagsRow}>
                    {tagItems.map(item => (
                      <button
                        key={`tag-${contentId}-${item.value}`}
                        type="button"
                        className={cbStyles.metadataTag}
                        onClick={() => handleTagClick(item.value, item.slug)}
                      >
                        {item.value}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              {collectionItems.length > 0 && (
                <div className={cbStyles.metadataSiblingsContainer}>
                  <span className={cbStyles.metadataSiblingLabel}>Related:</span>
                  <div className={cbStyles.metadataSiblingsRow}>
                    {collectionItems.map(item => (
                      <Link
                        key={`sibling-${contentId}-${item.value}`}
                        href={item.slug!}
                        className={cbStyles.metadataSiblingCollection}
                      >
                        {item.value}
                      </Link>
                    ))}
                  </div>
                </div>
              )}
              {isClientGallery && collectionSlug && (
                <ClientGalleryDownload collectionSlug={collectionSlug} />
              )}
  ```
  > `Link` is already imported (`import Link from 'next/link';`, line 4) and `cbStyles` is already in scope (line 33). No new imports.

- [ ] Add the SCSS to `app/components/Content/ContentComponent.module.scss`. Insert after the `.metadataTag` rule block closes (line 514) — `.metadataSiblingCollection` copies `.metadataLocation`'s link treatment (lines 422-434):
  ```scss
  /* Siblings (Related:) — anchored below tags */
  .metadataSiblingsContainer {
    display: flex;
    align-items: baseline;
    flex-wrap: wrap;
    gap: var(--space-2);
    padding-top: var(--space-2);
  }

  .metadataSiblingLabel {
    font-weight: 600;
    font-size: var(--text-xs);
    color: var(--color-black);
    letter-spacing: 0.02em;
  }

  .metadataSiblingsRow {
    display: flex;
    flex-wrap: wrap;
    gap: var(--space-2);
  }

  .metadataSiblingCollection {
    font-weight: 600;
    color: var(--color-black);
    font-size: var(--text-sm);
    letter-spacing: 0.02em;
    text-decoration: none;
    cursor: pointer;

    &:hover {
      text-decoration: underline;
    }
  }
  ```

- [ ] Run the renderer test — both cases must pass:
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/jest tests/components/Content/CollectionContentRenderer.test.tsx
  ```
  Expected output: `Tests: 2 passed`.

- [ ] Format, lint, SCSS-lint, type-check:
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/prettier --write app/components/Content/CollectionContentRenderer.tsx app/components/Content/ContentComponent.module.scss tests/components/Content/CollectionContentRenderer.test.tsx
  /opt/homebrew/bin/node node_modules/.bin/eslint --fix app/components/Content/CollectionContentRenderer.tsx tests/components/Content/CollectionContentRenderer.test.tsx
  /opt/homebrew/bin/node node_modules/.bin/stylelint --fix app/components/Content/ContentComponent.module.scss
  /opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
  ```
  Expected output: each exits 0, no remaining errors.

- [ ] Full-suite smoke (catch any cross-test regression from the type/SCSS changes):
  ```bash
  /opt/homebrew/bin/node node_modules/.bin/jest
  ```
  Expected output: all suites pass (`Tests: <all> passed`).

- [ ] Commit:
  ```bash
  git commit -m "feat(siblings): render Related: sibling links in CollectionContentRenderer"
  ```

---

### Frontend track notes

- **`CollectionListSelector` has TWO consumers, not one.** Grepping confirms it is imported in both `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx:14` (used at line 1602) **and** `app/components/ImageMetadata/ImageMetadataModal.tsx:6` (used at line 1051). The spec's line 183 ("if `manage` is the only consumer, simplify to the two-column form") therefore does **not** apply — the two-column extension must be backward-compatible. FE-3 keeps every new prop optional and preserves the exact single-column `aria-label` (`Toggle ${name}`) so the modal and the existing 19 tests are untouched. This is the single biggest real-code surprise.

- **Exact current prop interface being extended** (`CollectionListSelectorProps`, lines 11-21):
  ```ts
  interface CollectionListSelectorProps {
    allCollections: CollectionListModel[];
    savedCollectionIds: Set<number>;
    pendingAddIds: Set<number>;
    pendingRemoveIds: Set<number>;
    onToggle: (collection: CollectionListModel) => void;
    onNavigate?: (collection: CollectionListModel) => void;
    onAddNewChild?: () => void;
    label?: string;
    excludeCollectionId?: number;
  }
  ```
  FE-3 adds four optional props: `siblingSavedIds?`, `siblingPendingAddIds?`, `siblingPendingRemoveIds?: Set<number>`, `onToggleSibling?: (c) => void`. The existing `savedCollectionIds`/`onToggle` become the **Child** column.

- **React test library / pattern.** The project uses **React Testing Library** (`@testing-library/react` + `@testing-library/jest-dom`) with Jest in `jsdom` (`jest.config.mjs`: `testEnvironment: 'jsdom'`, setup `jest.setup.ts`). Tests live in `tests/**` mirroring `app/**`, matched by `testMatch: ['<rootDir>/tests/**/*.test.{ts,tsx}']`; `@/` maps to repo root so `@/app/...` and `@/tests/fixtures/...` both resolve. The selector test (`tests/components/CollectionListSelector.test.tsx`) is the closest reference: `render(<Component {...props}/>)`, `screen.getByText/getByLabelText/getByRole`, `fireEvent.click/keyDown`, `jest.fn()` spies. FE-6 additionally mocks `next/navigation`, `useParallax`, and `useCollectionFilter` because `CollectionContentRenderer` is a `'use client'` component that calls those hooks.

- **`buildMetadataItems` is private** — not exported from `contentLayout.ts`. FE-5 tests it the same way the existing suite does: through `createHeaderRow(...).items[1].content.items` (the metadata `ContentTextModel`). The default `createCollectionModel(1)` fixture (`tests/fixtures/contentFixtures.ts:150`) yields **exactly 3** metadata items (date + 1 location + description, **no tags, no siblings**), which an existing test asserts (`contentLayout.test.ts:976`). Sibling tests must pass an explicit `siblings:` override and the "no siblings" guard re-asserts the 3-item baseline.

- **`TextBlockItem.type` has no exhaustive `switch`.** The only consumers are five `find`/`filter` calls in `CollectionContentRenderer.tsx:169-173`. Adding `'collection'` to the union (FE-1) is non-breaking; no other file needs a new branch.

- **Dead-code carry-alongs in touched files** (spec §"Dead code surfaced", lines 233-241). All four sit in files this track edits. Recommendation: leave them as-is for this feature to keep diffs minimal, and let the plan's dead-code task own them. Specifically:
  - `_chunkSize` in `createHeaderRow` (`contentLayout.ts:544`) and `_chunkSize` is still threaded from `processContentForDisplay` (line 100). FE-5 edits `buildMetadataItems` (a different function), so removal is out of scope here — defer.
  - `_hasSlug` in `CollectionContentRenderer` (line 55) shadows the `hasSlug` prop and is referenced in `hasClickHandler`/`handleClick` (lines 100-152). FE-6 only adds a TEXT-branch block; renaming `_hasSlug` touches click logic unrelated to siblings — **defer** to avoid scope creep.
  - `_currentState` in `mergeNewMetadata` (`manageUtils.ts:302`) and `_deletedIds` in `handleDeleteSuccess` (`ManageClient.tsx:769-770`) are in files FE-2/FE-4 edit but in unrelated functions — defer.

- **`onNavigate` removal in FE-4 is the one behavioral decision needing reviewer sign-off.** Two independent toggle columns are incompatible with the existing "click row → navigate to that collection's manage page" affordance. FE-4 drops `onNavigate` from the manage-page selector instance (the `ImageMetadataModal` instance never set it). This is spec-aligned (the grid spec specifies name-left + two toggle columns, not row navigation) but removes a convenience shortcut — call it out at review. If navigation must be retained, the fallback is a dedicated name-cell `<Link>`, which would be a small follow-up to FE-3's JSX.

- **API layer needs zero changes** (spec §API). `getCollectionBySlug`, `getCollectionUpdateMetadata`, and `updateCollection` in `app/lib/api/collections.ts` are typed to `CollectionModel` / `CollectionUpdateResponseDTO` / `CollectionUpdateRequest`, so `siblings` flows through automatically once FE-1 lands and the backend populates it. No FE task touches that file.

---

## Self-review (plan vs spec)

**Spec coverage — every section maps to a task:**

| Spec section | Task(s) |
|---|---|
| Data model — `V26` migration | BE-1 |
| Backend DAO (`addSibling`/`removeSibling`/`findSiblings`) | BE-2 |
| DTO (`CollectionModel.siblings`, `Update.siblings`) | BE-3 |
| Service write (`handleSiblingUpdates`) | BE-4 |
| Read-path population + visibility filter (`populateSiblings`, LISTED-only public) | BE-5 |
| Controller contract (PUT accepts, GET returns) | BE-6 |
| FE types (`CollectionModel`, `CollectionUpdateRequest`, `TextBlockItem`) | FE-1 |
| `buildUpdatePayload` passthrough | FE-2 |
| Manage UI — two-column `Sibling \| Child` grid | FE-3 |
| Manage state wiring | FE-4 |
| Public render — metadata items | FE-5 |
| Public render — `Related:` links + SCSS | FE-6 |

No spec section is left unimplemented.

**Type consistency (cross-task):** `findSiblings(id, listedOnly)`, `addSibling`, `removeSibling` (BE-2) are the exact names called in BE-4/BE-5; `populateSiblings(model, listedOnly)` (BE-5) matches its call sites; `Records.CollectionList(id, name, slug, type)` is used identically in the DAO RowMapper and the BE-6 controller test. Frontend: `siblings?: CollectionListModel[]` (FE-1) is read in FE-4/FE-5; `siblings?: CollectionUpdate` (FE-1) is written in FE-2/FE-4; the four new selector props in FE-3 (`siblingSavedIds`, `siblingPendingAddIds`, `siblingPendingRemoveIds`, `onToggleSibling`) match exactly what FE-4 passes; the `'collection'` `TextBlockItem` (FE-1) is produced in FE-5 and consumed in FE-6.

**Placeholder scan:** no TBD/TODO/"handle edge cases" steps; every code step shows real code; every run step has expected output. Conscious deferrals (not gaps): BE-1 has no automated test (no DB/Spring-boot harness exists — verified via `psql \d`), and FE-4 leans on FE-2/FE-3 unit coverage plus a manual check (the existing ManageClient test mocks the selector).

**Carry-along dead code (spec §):** `_chunkSize`, `_hasSlug`, `_currentState`, `_deletedIds` all sit in touched files but in functions unrelated to this feature → deferred to keep diffs minimal (flagged, not silently left).

## Execution caveats

- **Backend `./mvnw`** may need network to fetch Maven 3.8.7 on first run; in a sandbox that download is blocked, so run backend builds **unsandboxed** (or with the Maven distro pre-cached in `~/.m2/wrapper`).
- **FE-6 SCSS** reuses the `.metadataLocation` token treatment; confirm `--color-black` / `--text-sm` / `--space-2` match that rule during the visual check (stylelint won't validate custom-property existence).
- **Preview server:** use port 3001 for manual verification (the user keeps 3000).

## Execution handoff

Two options:
1. **Subagent-Driven (recommended)** — a fresh subagent per task with two-stage review between tasks. Sub-skill: `superpowers:subagent-driven-development`. Pairs naturally with running the two tracks as an Agent Team.
2. **Inline Execution** — execute tasks in-session with batch checkpoints. Sub-skill: `superpowers:executing-plans`.
