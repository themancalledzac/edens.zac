# Row composition V2 rollout — A/B toggle implementation plan

**Date:** 2026-05-26
**Status:** Ready for subagent dispatch
**Spec:** `docs/superpowers/specs/2026-05-26-row-composition-redesign.md`
**Flowcharts:** `docs/superpowers/specs/2026-05-26-row-composition-flowcharts.md`
**Retrospective:** `docs/spikes/2026-05-26-row-composition-retrospective.md`

This plan covers ONLY the wrapping that lets us run the new bottom-up merge alongside the existing top-down composition with a URL query param. The algorithm itself is fully specified in the redesign spec — this document does not relitigate it.

---

## 1. Goal

Land the bottom-up merge composition (spec §3) in a way that is:

1. **Opt-in via URL.** `?layout=v2` runs the new algorithm; absence runs current behavior (no visible change for visitors).
2. **Side-by-side reachable.** Open two tabs of the same collection — one with `?layout=v2`, one without — and compare in real time.
3. **Reversible.** Existing tests stay green. Cleanup PR flips the default and deletes old code in one commit.
4. **A discovery tool, not just a verification gate.** Treat the A/B period as a way to surface intentional vs unintentional layout differences and missing test coverage.

---

## 2. A/B toggle wiring

### URL flow

```
User → /collection/<slug>?layout=v2
   → app/components/Content/Component.tsx (client)
       reads ?layout via useSearchParams() (next/navigation)
       passes useV2: boolean into processContentForDisplay options
   → app/utils/contentLayout.ts
       processContentForDisplay() threads useV2 to row-building
   → app/utils/rowCombination.ts
       lookupComposition(images, …, useV2)
       if useV2: return composeV2(images, targetAR, rowWidth) from rowCombinationV2.ts
       else:    fall through to existing compose() path (unchanged)
```

### Default behavior

`useV2` defaults to **false**. Visitors hitting a collection without `?layout=v2` see the current (top-down) behavior. Cleanup PR flips this default to true, then deletes the false branch.

### Why URL param (not localStorage / dev-only)

- Zero UI code.
- Trivially shareable ("open these two URLs and compare").
- Stateless — doesn't persist across browser refreshes accidentally.
- Deletes in one line during cleanup.

---

## 3. File map

| Action | File | Responsibility |
|--------|------|----------------|
| Add | `app/utils/rowCombinationV2.ts` | New `composeV2()` implementing bottom-up adjacent merge per spec §3. Imports `BoxTree`, `AtomicComponent`, `ImageType`, `single`, `hPair`, `vStack`, `acToBoxTree`, `toImageType` from `rowCombination.ts`. Self-contained otherwise. |
| Modify | `app/constants/index.ts` | Add `ORIENTATION_PENALTY = 1.0`, `SWAP_PENALTY = 0.6`, `AR_WEIGHT = 0.3`. |
| Modify | `app/utils/rowCombination.ts` | Add `useV2?: boolean` param to `lookupComposition()`. When true, return `{ composition: composeV2(images, targetAR, rowWidth) }` (with templateKey passthrough). Otherwise unchanged. |
| Modify | `app/utils/contentLayout.ts` | Add `useV2?: boolean` to `ProcessContentOptions`. Thread it into `buildRows`/`lookupComposition` call site. |
| Modify | `app/components/Content/Component.tsx` | Read `useSearchParams().get('layout') === 'v2'` and pass `useV2` into `processContentForDisplay` options. |
| Modify | `app/utils/rowCombination.ts` (`buildRows` only) | `buildRows` calls `lookupComposition` internally — add `useV2` param + pass through. No other changes. |
| Add | `tests/utils/rowCombinationV2.test.ts` | Unit tests for the new algorithm. Fixtures: spec §6 walked example `[5v, 1h, 4v, 3v, 2h]`, Issue #1 panorama row, Issue #2 item-1-on-right row, edge cases (n=1, n=2, all-V row, all-H row). |

**Not touched in this PR:**
- `app/utils/rowOptimizer.ts` (reorderWithinRows audit is a separate PR)
- `app/utils/contentRatingUtils.ts` (arFactor cap lift is a separate PR)
- `app/utils/rowStructureAlgorithm.ts` (size calc downstream of BoxTree)
- `app/components/Content/BoxRenderer.tsx` (renderer agnostic to which compose ran)
- Existing `tests/utils/rowCombination.test.ts` and `tests/utils/rowCombination.characterization.test.ts` (stay green by hitting the default-OFF path)

---

## 4. Subagent dispatch

Two implementer subagents run in parallel. They have independent file boundaries.

### Subagent A — "algorithm"

**Files written/modified:**
- `app/utils/rowCombinationV2.ts` (new)
- `app/constants/index.ts` (add 3 constants)
- `tests/utils/rowCombinationV2.test.ts` (new)

**Brief:**

Implement `composeV2(images: ImageType[], targetAR: number, rowWidth: number): AtomicComponent` exporting from `app/utils/rowCombinationV2.ts`. Follow spec §3 algorithm exactly:

1. Initialize `atoms` as input-ordered leaves, each carrying `cv`, `orient` (`'H' | 'V' | 'M'`), and `ar`.
2. Initialize `swapBudget: Map<id, 1>` — one swap per leaf.
3. While `atoms.length > 1`:
   - For each adjacent pair `(i, i+1)`, for each swap option (none / swap with `i-1` / swap with `i+2`), for each direction (`hPair` / `vStack`):
     - Skip if swap exceeds budget for either involved leaf.
     - Compute `score = sum_cv_cost + orientation_cost + swap_cost + AR_WEIGHT × |running_ar - target|` per spec §4.
   - Pick lowest score. Tiebreakers (spec §5): leftmost wins, then hPair over vStack, then no-swap over swap.
   - Apply: decrement swap budgets used, replace `atoms[i..i+1]` with merged atom (`cv = left.cv + right.cv`, `orient = 'M'`, `ar = calculateBoxTreeAspectRatio(acToBoxTree(merged))`).
4. Return `atoms[0]`.

Constants in `app/constants/index.ts`:
```ts
export const ORIENTATION_PENALTY = 1.0;
export const SWAP_PENALTY = 0.6;
export const AR_WEIGHT = 0.3;
```

Reference commit `402f07c` for ~70% of the implementation (it had the bottom-up loop minus orientation_cost, swap_cost, and the ±1 swap budget).

**Test fixtures (write to `tests/utils/rowCombinationV2.test.ts`):**

1. **Spec §6 walked example**: `[5v, 1h, 4v, 3v, 2h]` → final tree `hPair(hPair(5v, vStack(1h, 4v)), vStack(3v, 2h))`. Zero swaps. Order preserved.
2. **Issue #1 panorama**: a panorama (AR ~2.67, rating 4) in a row with three normals — assert panorama appears as one of 2-3 top-level cluster atoms (not nested into a sub-cell).
3. **Issue #2 item-1-on-right**: a row where the highest-rated item is item 0 — assert item 0 stays leftmost in the rendered tree.
4. **Edge cases**:
   - `n=1`: returns `single(items[0])`.
   - `n=2`: picks hPair vs vStack by score; for H+H pick hPair (no orientation penalty); for V+V pick hPair (vStack penalty avoids it).
   - **All-V row** (4 verticals): no V+V vStacks should appear (orientation penalty pushes toward hPair chains).
   - **All-H row** (4 horizontals): no H+H vStacks.

**Verification:**
- `/opt/homebrew/bin/node node_modules/.bin/jest tests/utils/rowCombinationV2.test.ts`
- `/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit`

**Boundary contract:** DO NOT touch `app/utils/rowCombination.ts`, `app/utils/contentLayout.ts`, `app/components/Content/Component.tsx`, or any other test file. Those belong to Subagent B.

### Subagent B — "wiring"

**Files modified:**
- `app/utils/rowCombination.ts` (add `useV2?: boolean` param to `lookupComposition` + `buildRows`; dispatcher stub)
- `app/utils/contentLayout.ts` (add `useV2?: boolean` to `ProcessContentOptions`, thread through)
- `app/components/Content/Component.tsx` (read URL param, pass through)

**Brief:**

Wire the `useV2` boolean through the call chain so that when `useSearchParams().get('layout') === 'v2'`, the user sees a different code path. The destination function `composeV2` is being written by Subagent A — for now, stub the dispatcher so it throws a clear error when `useV2` is true:

```ts
// in rowCombination.ts lookupComposition (or buildRows where it calls compose)
if (useV2) {
  // Subagent A will replace this with: import { composeV2 } from './rowCombinationV2';
  // return { templateKey, composition: composeV2(images, targetAR, rowWidth), label: 'v2-merge' };
  throw new Error('composeV2 dispatcher reached; algorithm not yet integrated');
}
```

The integration step (main agent) will replace the stub with the real `composeV2` import.

**Component.tsx changes:**

Add at the top of the component:
```ts
import { useSearchParams } from 'next/navigation';
// ...
const searchParams = useSearchParams();
const useV2 = searchParams?.get('layout') === 'v2';
```

Pass `useV2` in the `processContentForDisplay` options object. If `useSearchParams` introduces a Next.js Suspense bailout warning, that's acceptable for this dev toggle — note it but don't restructure to fix.

**ProcessContentOptions update:**
```ts
export interface ProcessContentOptions {
  // ... existing fields
  /** Use bottom-up merge composition (V2) instead of top-down template lookup */
  useV2?: boolean;
}
```

**lookupComposition + buildRows signatures:**

Both should accept an optional `useV2?: boolean` parameter (default false). Thread it through:
- `processContentForDisplay` → `buildRows(content, rowWidth, targetAR, useV2)`
- `buildRows` → `lookupComposition(images, targetAR, rowWidth, useV2)`
- `lookupComposition` checks the flag at the dispatch point.

**Verification:**
- `/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit` passes
- `/opt/homebrew/bin/node node_modules/.bin/jest tests/utils/rowCombination.test.ts` still passes (default-OFF path is unchanged)
- A unit test confirms `useV2=true` throws the dispatcher stub error (until main agent integrates)

**Boundary contract:** DO NOT touch `app/utils/rowCombinationV2.ts`, `app/constants/index.ts` (Subagent A owns those), or `tests/utils/rowCombinationV2.test.ts`.

---

## 5. Integration step (main agent, after both subagents finish)

1. Replace the dispatcher stub in `rowCombination.ts` with a real import:
   ```ts
   import { composeV2 } from './rowCombinationV2';
   // ...
   if (useV2) {
     return {
       templateKey: { h: 0, v: 0 }, // templateKey is documentation-only when useV2
       composition: composeV2(images, targetAR, rowWidth),
       label: 'v2-merge',
     };
   }
   ```
2. Decide what to do with `templateKey` when `useV2` — for now, return `{ h: 0, v: 0 }` (templates don't exist in V2). The rendered `data-pattern` attribute in `Component.tsx` will show `0h-0v` — acceptable for dev; cleanup PR removes templateKey entirely.
3. Remove the test that asserted the stub throws.
4. Run full test suite + type-check.

---

## 6. Verification checklist (post-integration)

- [ ] `/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit` → 0 errors
- [ ] `/opt/homebrew/bin/node node_modules/.bin/jest` → all pre-existing tests green (default-OFF path unchanged)
- [ ] `/opt/homebrew/bin/node node_modules/.bin/jest tests/utils/rowCombinationV2.test.ts` → all V2 tests pass
- [ ] Dev server runs; `/tylerabby?layout=v2` renders without errors
- [ ] Browser visual: Issue #2 — item 1 renders leftmost on `?layout=v2` (currently renders right on default)
- [ ] Browser visual: a panorama-row collection — panorama gets meaningful cluster area on `?layout=v2` (currently squashed on default)
- [ ] Side-by-side: open same collection in two tabs (`?layout=v1` vs `?layout=v2`), confirm both render

---

## 7. Cleanup PR outline (NOT this PR — follow-up)

After visual review confirms V2 is right:

1. Flip `useV2` default to `true` in `Component.tsx` (or invert: `?layout=v1` for opt-out).
2. Manual soak period (1-2 days).
3. Delete:
   - `findDominant`, `buildAtomic`, `generateCandidates`, `generatePartitionCandidates`, `compose` partition branch, `TEMPLATE_MAP` body, `lookupComposition` template logic from `rowCombination.ts`
   - `tests/utils/rowCombination.characterization.test.ts` (V1 characterization — obsoleted by V2 tests)
   - `templateKey` field from `RowResult` and `RowWithPatternAndSizes` if nothing else uses it
4. Rename `rowCombinationV2.ts` → merge contents back into `rowCombination.ts` (or keep V2 name — preference).
5. Remove `useV2` plumbing from `Component.tsx`, `contentLayout.ts`, `rowCombination.ts`.

Net: ~250 lines deleted, ~80 lines added (per spec §7).

---

## 8. Known issues this PR does NOT address

Per spec §8, the row-packing stage-1 bugs remain:
- `arFactor` cap in `getComponentValue` (panorama underweight)
- Standalone-skip dead code on desktop (threshold unreachable)
- Moderate-overfill ceiling at 1.35 (item cramming)

And the stage-2 bug:
- `reorderWithinRows` swap logic (`/tylerabby` 2026-05-13 bug)

These are tracked as separate follow-up PRs in the handoff. The bottom-up merge alone will visibly improve panorama and item-1-on-right rows even without those fixes.
