# GIF/MP4 Web Variant Pipeline (Frontend) Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Consume the backend's new 1080px "web" MP4 variant in the row layout while keeping the 2000px "full" master for the fullscreen viewer, and add `preload="auto"` so mobile keeps the loop buffered.

**Architecture:** The in-row `<video>` is fed by the normalized `imageUrl` produced in `contentRendererUtils.ts`; switching that single mapping to `gifUrlWeb ?? gifUrl` routes the row layout to the small variant with a fallback for pre-existing gifs. The fullscreen viewer already reads `currentImage.gifUrl` (the full master) directly off the raw `ContentGifModel`, so it needs no change. A new optional `gifUrlWeb` field on `ContentGifModel` mirrors the backend API.

**Tech Stack:** Next.js App Router, React (named imports), TypeScript (strict, no `any`), Jest.

**Test runner (npm/npx are NOT on PATH — use the Homebrew node binary):**
- All: `/opt/homebrew/bin/node node_modules/.bin/jest`
- Single file: `/opt/homebrew/bin/node node_modules/.bin/jest tests/utils/contentRendererUtils.test.ts`
- Type check: `/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit`
- Lint fix: `/opt/homebrew/bin/node node_modules/.bin/eslint --fix <files>`

**Dependency:** the backend plan (`edens.zac.backend/docs/superpowers/plans/2026-05-26-gif-mp4-variant-pipeline.md`) must ship for `gifUrlWeb` to be populated in API responses. This frontend work is safe to ship first or in parallel: when `gifUrlWeb` is absent (pre-existing gifs, or before the backend lands), every site falls back to `gifUrl`, so behavior is unchanged until the backend starts returning the field.

## File Structure

| File | Responsibility | Change |
|------|----------------|--------|
| `app/types/Content.ts:148-171` | `ContentGifModel` — add `gifUrlWeb` | Modify |
| `app/utils/contentRendererUtils.ts:225-241` | In-row normalize: `imageUrl` → `gifUrlWeb ?? gifUrl` | Modify |
| `tests/utils/contentRendererUtils.test.ts:231-267` | Tests for web-variant + fallback mapping | Modify |
| `app/components/Content/CollectionContentRenderer.tsx:290` | In-row `<video>` — add `preload="auto"` | Modify |
| `app/components/FullScreenModal/FullScreenModal.tsx:98` | Fullscreen `<video>` — add `preload="auto"` (still uses `gifUrl`) | Modify |
| `app/components/ImageMetadata/ImageMetadataModal.tsx:75` | Admin preview `<video>` — add `preload="auto"` | Modify |

No change needed to `tests/fixtures/contentFixtures.ts`: `createGifContent` already spreads `...overrides`, so once `gifUrlWeb` exists on the type, tests set it via `createGifContent(id, { gifUrlWeb: '...' })`. Leaving the default without `gifUrlWeb` keeps the existing GIF test valid as the fallback case.

---

## Task 1: Add `gifUrlWeb` to `ContentGifModel`

**Files:**
- Modify: `app/types/Content.ts:148-171`

- [ ] **Step 1: Add the field after `gifUrl`**

In the `ContentGifModel` interface, insert the new field immediately after the `gifUrl` line (150):

```typescript
export interface ContentGifModel extends Content {
  contentType: 'GIF';
  gifUrl: string; // 2000px "full" master — used by the fullscreen viewer
  /**
   * 1080px "web" display variant — used in the row layout. Optional: pre-existing gifs and actual
   * image/gif uploads have no web variant, so consumers fall back to `gifUrl` (`gifUrlWeb ?? gifUrl`).
   * Mirrors backend ContentModels.Gif.gifUrlWeb.
   */
  gifUrlWeb?: string | null;
  thumbnailUrl?: string | null; // Backend field name (was imageUrlRaw)
```

- [ ] **Step 2: Verify the type compiles and existing tests are unaffected**

Run: `/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit`
Then: `/opt/homebrew/bin/node node_modules/.bin/jest tests/utils/contentRendererUtils.test.ts`
Expected: tsc clean; all existing GIF tests still PASS (the field is optional and unused so far).

- [ ] **Step 3: Commit**

```bash
git add app/types/Content.ts
git commit -m "feat(content): add optional gifUrlWeb to ContentGifModel"
```

---

## Task 2: Route the in-row video to `gifUrlWeb` with fallback (TDD)

**Files:**
- Modify: `tests/utils/contentRendererUtils.test.ts` (inside `describe('GIF content', ...)`, ~231-267)
- Modify: `app/utils/contentRendererUtils.ts:230`

- [ ] **Step 1: Write the failing tests**

Inside the existing `describe('GIF content', () => { ... })` block in `tests/utils/contentRendererUtils.test.ts`, add these two cases (after the existing `'should normalize GIF content'` test):

```typescript
      it('should use gifUrlWeb for the in-row imageUrl when present', () => {
        const gif = createGifContent(1, {
          gifUrl: 'https://example.com/gif-1-full.mp4',
          gifUrlWeb: 'https://example.com/gif-1-web.mp4',
        });
        const result = normalizeContentToRendererProps(gif, 500, 300, 'imageLeft', false);

        // Row layout must load the small 1080px variant, not the 2000px master.
        expect(result.imageUrl).toBe('https://example.com/gif-1-web.mp4');
      });

      it('should fall back to gifUrl when gifUrlWeb is absent', () => {
        const gif = createGifContent(1, {
          gifUrl: 'https://example.com/gif-1-full.mp4',
          // gifUrlWeb intentionally omitted (pre-existing gif / backend not yet deployed)
        });
        const result = normalizeContentToRendererProps(gif, 500, 300, 'imageLeft', false);

        expect(result.imageUrl).toBe('https://example.com/gif-1-full.mp4');
      });
```

- [ ] **Step 2: Run the tests to verify the first one fails**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest tests/utils/contentRendererUtils.test.ts -t "gifUrlWeb"`
Expected: `should use gifUrlWeb for the in-row imageUrl when present` FAILS (received `gif-1-full.mp4`, the current `content.gifUrl` mapping); the fallback test PASSES.

- [ ] **Step 3: Make the mapping use the web variant with fallback**

In `app/utils/contentRendererUtils.ts`, in the `if (isGifContent(content))` branch, change the `imageUrl` line (currently line 230):

```typescript
  if (isGifContent(content)) {
    const dimensions = extractImageDimensions(undefined, content.width, undefined, content.height);

    return {
      ...baseProps,
      imageUrl: content.gifUrlWeb ?? content.gifUrl,
      imageWidth: dimensions.imageWidth,
      imageHeight: dimensions.imageHeight,
      alt: extractAltText(content.alt, content.title, content.caption, undefined, 'GIF'),
      overlayText: content.overlayText,
      enableParallax: false,
      isCollection: false,
      contentType: 'GIF',
      isGif: true,
      thumbnailUrl: content.thumbnailUrl,
    };
  }
```

- [ ] **Step 4: Run the tests to verify they pass**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest tests/utils/contentRendererUtils.test.ts`
Expected: PASS — both new cases green AND the pre-existing `'should normalize GIF content'` test (which uses `createGifContent(1)` with no `gifUrlWeb`) still green via fallback.

- [ ] **Step 5: Commit**

```bash
git add app/utils/contentRendererUtils.ts tests/utils/contentRendererUtils.test.ts
git commit -m "feat(content): render 1080px gifUrlWeb in row layout, fall back to gifUrl"
```

---

## Task 3: Add `preload="auto"` to the three `<video>` sites

**Files:**
- Modify: `app/components/Content/CollectionContentRenderer.tsx:290`
- Modify: `app/components/FullScreenModal/FullScreenModal.tsx:98`
- Modify: `app/components/ImageMetadata/ImageMetadataModal.tsx:75`

Presentational attribute change (no unit test — `preload` is a buffering hint not observable in jsdom). Verified by build + grep.

- [ ] **Step 1: In-row video (`CollectionContentRenderer.tsx`)**

Change the opening `<video` tag (line 290) so it reads:

```tsx
          <video
            autoPlay
            loop
            muted
            playsInline
            preload="auto"
            poster={thumbnailUrl || undefined}
            width={imageWidth || undefined}
            height={imageHeight || undefined}
            className={cbStyles.nonParallaxImage}
            style={{ cursor: hasClickHandler ? 'pointer' : 'default' }}
          >
            <source src={imageUrl} type="video/mp4" />
          </video>
```

(`imageUrl` here is the normalized prop, now `gifUrlWeb ?? gifUrl` from Task 2.)

- [ ] **Step 2: Fullscreen video (`FullScreenModal.tsx`)**

Change the gif `<video>` (line 98) so it reads — note the source stays `currentImage.gifUrl`, the **full** master, deliberately:

```tsx
            <video
              key={currentImage.id}
              autoPlay
              loop
              muted
              playsInline
              controls={false}
              preload="auto"
              poster={currentImage.thumbnailUrl ?? undefined}
              width={currentImage.width || IMAGE.defaultWidth}
              height={currentImage.height || IMAGE.defaultHeight}
              className={`${styles.fullScreenImage} ${currentImageLoaded ? styles.fullScreenImageLoaded : ''}`}
            >
              <source src={currentImage.gifUrl} type="video/mp4" />
            </video>
```

- [ ] **Step 3: Admin preview video (`ImageMetadataModal.tsx`)**

Add `preload="auto"` to the `<video>` opening tag (line 75), after `playsInline`/`controls={false}`:

```tsx
      <video
        key={previewImageAsGif.gifUrl}
        autoPlay
        loop
        muted
        playsInline
        controls={false}
        preload="auto"
        poster={previewImageAsGif.thumbnailUrl ?? undefined}
        width={previewImageAsGif.width || IMAGE.defaultWidth}
        height={previewImageAsGif.height || IMAGE.defaultHeight}
        style={{
          maxWidth: '100%',
          maxHeight: '100%',
          width: 'auto',
          height: 'auto',
          objectFit: 'contain',
        }}
      >
        <source src={previewImageAsGif.gifUrl} type="video/mp4" />
      </video>
```

(The admin preview keeps `gifUrl` — admins edit against the master.)

- [ ] **Step 4: Verify all three changed and the app type-checks**

Run: `grep -rn 'preload="auto"' app/components/Content/CollectionContentRenderer.tsx app/components/FullScreenModal/FullScreenModal.tsx app/components/ImageMetadata/ImageMetadataModal.tsx`
Expected: one match in each file.
Run: `/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit`
Expected: clean.

- [ ] **Step 5: Commit**

```bash
git add app/components/Content/CollectionContentRenderer.tsx app/components/FullScreenModal/FullScreenModal.tsx app/components/ImageMetadata/ImageMetadataModal.tsx
git commit -m "feat(content): preload=auto on gif/mp4 video elements to smooth mobile loops"
```

---

## Task 4: Full verification

**Files:** none (verification only)

- [ ] **Step 1: Format, lint, type-check the touched files**

```bash
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/types/Content.ts app/utils/contentRendererUtils.ts app/components/Content/CollectionContentRenderer.tsx app/components/FullScreenModal/FullScreenModal.tsx app/components/ImageMetadata/ImageMetadataModal.tsx tests/utils/contentRendererUtils.test.ts
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/types/Content.ts app/utils/contentRendererUtils.ts app/components/Content/CollectionContentRenderer.tsx app/components/FullScreenModal/FullScreenModal.tsx app/components/ImageMetadata/ImageMetadataModal.tsx tests/utils/contentRendererUtils.test.ts
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
```
Expected: prettier writes, eslint clean (no errors), tsc clean.

- [ ] **Step 2: Run the whole jest suite**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest`
Expected: all tests pass (the 2 new GIF cases included; no regressions).

- [ ] **Step 3: Manual check against a backend that returns `gifUrlWeb`**

With the backend variant pipeline deployed (preview server on port 3001), open a collection containing an MP4:
- In-row: DevTools → Network → the `.mp4` requested in the grid is the `Gif/Web/...` URL (small), not `Gif/Full/...`.
- Click to fullscreen: the requested `.mp4` is the `Gif/Full/...` URL.
- On mobile (or device emulation), confirm the in-row loop has no visible pause at the seam.

- [ ] **Step 4: Commit (if lint/format produced changes)**

```bash
git add -A
git commit -m "chore(content): format + lint gif web-variant changes"
```

---

## Spec Coverage Checklist

| Spec requirement (from design discussion) | Task |
|-------------------------------------------|------|
| In-row layout uses the 1080px web variant | Task 2 |
| Fullscreen uses the 2000px full master | Task 3 Step 2 (source kept as `currentImage.gifUrl`) — pre-existing, verified |
| Fallback to `gifUrl` for pre-existing gifs / pre-deploy | Task 1 (optional field) + Task 2 (`gifUrlWeb ?? gifUrl`) |
| `gifUrlWeb` mirrors backend API field | Task 1 |
| `preload="auto"` to keep mobile buffer warm | Task 3 (all 3 sites) |
| No regressions to existing gif rendering/tests | Task 1 Step 2, Task 2 Step 4, Task 4 Step 2 |

**Spec sections not covered (intentional):** the dual-`<video>` crossfade seamless-loop technique (deferred — the small web variant + `preload="auto"` is expected to resolve the mobile pause without it; revisit only if a pause persists after the backend ships); admin preview deliberately keeps `gifUrl` (master) rather than the web variant.

## Pre-existing observations (not in scope, do not fix here)
- `normalizeContentType` in `contentRendererUtils.ts` is a passthrough cast kept "for consistency" — unrelated to this change, leave as-is.
- `ContentRendererProps.imageUrl` is a single normalized URL field reused across IMAGE/GIF; this plan routes the gif's in-row URL through it. The fullscreen path does NOT use this normalized field (it reads the raw `ContentGifModel.gifUrl`), which is why full vs web split cleanly without a new prop.
