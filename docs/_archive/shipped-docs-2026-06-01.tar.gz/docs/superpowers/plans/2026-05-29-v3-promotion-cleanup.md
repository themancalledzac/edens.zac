# V3 Promotion & Cleanup Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Promote layout V3 to be the one and only layout algorithm — delete V1, V2, the row optimizer, the `?layout` A/B plumbing, and the layout trace; rename `composeV3` → `compose`; keep the density slider as a permanent control.

**Architecture:** The layout pipeline stays `processContentForDisplay → buildRows (Stage 1, greedy fill) → compose (Stage 2, the former composeV3) → calculateSizesFromBoxTree → BoxRenderer`. Stage 1 (`buildRows`, density remap, `MAX_ROW_IMAGES`, `targetAR`) is unchanged and shared. Everything that existed only to support V1/V2 A/B (template map, `findDominant`, `rowCombinationV2`, `rowOptimizer`, `layoutTrace`, `?layout` reader, `layoutVersion` threading) is deleted. The composition becomes a single `compose()` in `rowCombination.ts`.

**Tech Stack:** Next.js 16 App Router, TypeScript (strict, no `any`), Jest. Node/jest invoked via `/opt/homebrew/bin/node node_modules/.bin/...` (npm/npx not on PATH).

---

## Spec / Source of Truth

This plan implements:
- **User directive (2026-05-29):** "move to our latest 'v3' version, which requires REMOVING all previous logic, as well as renaming our 'v3' version code as just the 'normal' code. Remove any tests or code that was only used in the previous versions' logic. Cleanup should be a major part."
- **Review findings (this session):** D1 (global targetAR/density now permanent — inherent once V3 is default), T1 (Option-A regression test — moot once optimizeRows is deleted), C1–C4 (stale "AR-propagation" comments, `.claude/agent-memory/` untracked).
- **Fork decisions (confirmed with user):** layoutTrace → **delete**; density slider → **keep as permanent control** (un-gate); composition → **fold `composeV3` into `rowCombination.ts` as `compose`**.
- **Removal map** from two exploration passes (line-accurate, captured below).

**Behavioral risk to surface during execution (Task 3):** `estimateRowAR` (the Stage-1 row-breaking heuristic) currently calls V1 `compose` *even on today's `?layout=v3` path*. Repointing it to V3 makes the Stage-1 AR estimate match what V3 actually renders (an accuracy improvement) but **shifts some row breaks vs the visually-approved `?layout=v3` view**. A `:3000` visual re-verify after Task 3 is mandatory.

---

## Scope Check

Single subsystem (the frontend layout engine + its filter-bar UI). One plan is appropriate. **Out of scope (separate follow-up):** backend `rowsWide` 1–10 validation in `edens-zac-backend` (cross-repo; the admin slider range must be accepted server-side on save). Tracked at the end, not executed here.

---

## File Structure (end state)

**Deleted files:**
- `app/utils/rowCombinationV2.ts`
- `app/utils/rowCombinationV3.ts` (folded into `rowCombination.ts`)
- `app/utils/rowOptimizer.ts`
- `app/utils/layoutTrace.ts`
- `tests/utils/rowCombinationV2.test.ts`
- `tests/utils/rowOptimizer.test.ts`
- `tests/utils/layoutTrace.test.ts`

**Modified files:**
- `app/utils/rowCombination.ts` — V1 cluster deleted (~350 lines); `composeV3` body folded in as `compose`; `lookupComposition` simplified; `LayoutVersion` type removed; `RowResult.label`/`.direction` + `deriveDirection` removed.
- `app/utils/contentLayout.ts` — `layoutVersion`, `optimizeRows`, and trace plumbing removed.
- `app/components/Content/Component.tsx` — `?layout` reader removed; `targetAR` clamp kept.
- `app/components/ContentCollection/CollectionPageClient.tsx`, `CollectionFilterBar.tsx`, `CollectionFilterContext.tsx`, `app/components/Content/CollectionContentRenderer.tsx`, `ContentComponent.module.scss` — density slider **un-gated** (permanent), `?layout`/`showDensitySlider` removed, styling polished.
- `app/constants/index.ts` — V2 scoring constants removed.
- `tests/utils/rowCombination.test.ts`, `tests/utils/rowCombination.characterization.test.ts` — V1 blocks removed, shape/label assertions re-baselined.
- `tests/utils/rowCombination.composition.test.ts` — renamed from `rowCombinationV3.test.ts` (canonical composition test).
- `tests/components/ContentCollection/CollectionFilterBar.test.tsx` — updated for the now-permanent slider.

**Net:** ~1,500 lines removed; one composition file; zero version flags.

---

## Verify commands (used throughout)

```bash
# Type check (ignore the 2 pre-existing .next/types/validator.ts route-stub errors)
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
# Full suite
/opt/homebrew/bin/node node_modules/.bin/jest --no-coverage
# Single file
/opt/homebrew/bin/node node_modules/.bin/jest tests/utils/rowCombination.test.ts --no-coverage
# Format + lint a touched file set
/opt/homebrew/bin/node node_modules/.bin/prettier --write <files>
/opt/homebrew/bin/node node_modules/.bin/eslint --fix <files>
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix <scss files>
```

**Invariant: the suite must be green at every commit.** Each task ends with a green run + commit.

---

## Task 0: Baseline

- [ ] **Step 1: Confirm green baseline**

Run:
```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest --no-coverage
```
Expected: tsc clean except the 2 known `.next/types/validator.ts` errors; jest `1445 passed, 49 suites`.

- [ ] **Step 2: Confirm on the MR branch**

Run: `git branch --show-current` → expect `0141-gif-updates`. Work proceeds on this branch (the user's `:3000` server renders it). Optional: `git worktree` isolation if you prefer, but the user verifies on `:3000` against this checkout.

---

## Task 1: Make V3 the only composition path (remove `?layout` + `layoutVersion` + trace)

After this task, the default (and only) runtime path is V3. `estimateRowAR` is **deliberately left calling V1 `compose`** so behavior exactly equals today's approved `?layout=v3` (the estimateRowAR change is isolated to Task 3). V1 code remains present but dead.

**Files:**
- Modify: `app/utils/rowCombination.ts` (`lookupComposition` 579–618; `buildRows` signature 687–692 + its two `lookupComposition` calls ~802–807 and ~879–883; remove `LayoutVersion` type 22–26; remove `composeV2` import line 18)
- Modify: `app/utils/contentLayout.ts` (imports 12,18,22; `ProcessContentOptions.layoutVersion` 58–64; lines 125–162)
- Modify: `app/components/Content/Component.tsx` (import line 17; `?layout` reader 129–138; option line 165; dep line 173)
- Delete: `app/utils/layoutTrace.ts`, `tests/utils/layoutTrace.test.ts`
- Modify tests: `tests/utils/rowCombination.test.ts`, `tests/utils/contentLayout.test.ts`

- [ ] **Step 1: Simplify `lookupComposition` to call composeV3 unconditionally**

In `app/utils/rowCombination.ts`, replace the whole `lookupComposition` function (lines 579–618) with:

```ts
export function lookupComposition(
  images: ImageType[],
  targetAR: number = 1.5,
  rowWidth: number = 5
): CompositionResult {
  return {
    composition: composeV3(images, targetAR, rowWidth),
    templateKey: parseTemplateKey(images),
    label: 'standard',
  };
}
```

Also delete the now-unused import on line 18: `import { composeV2 } from '@/app/utils/rowCombinationV2';`. (The `compose` and `TEMPLATE_MAP` symbols are now dead but still compile; they're deleted in Task 3. They are `export`ed so no unused-var lint error.)

- [ ] **Step 2: Drop `layoutVersion` from `buildRows`**

In `buildRows` (signature ~687–692), remove the `layoutVersion?: LayoutVersion` parameter. In its two `lookupComposition(...)` calls (~802–807 and ~879–883), remove the trailing `layoutVersion` argument so they read `lookupComposition(rowImgs, targetAR, rowWidth)` and `lookupComposition(bfImgs, targetAR, rowWidth)`.

- [ ] **Step 3: Remove the `LayoutVersion` type**

Delete the `LayoutVersion` type and its doc comment (`app/utils/rowCombination.ts` lines 22–26).

- [ ] **Step 4: Simplify `contentLayout.ts`**

In `app/utils/contentLayout.ts`:
- Delete import line 12 (`buildLayoutTrace, logLayoutTrace`), line 22 (`optimizeRows`), and `type LayoutVersion` from the import on lines 13–21.
- Delete `ProcessContentOptions.layoutVersion` (lines 58–64, the whole JSDoc + field).
- Replace lines 129–135 (the comment block + `built`/`optimizeRows` ternary) with:

```ts
  const rows = buildRows(content, rowWidth, targetAR);
```

- Delete the trace block (lines 148–162, `if (options?.layoutVersion) { ... logLayoutTrace(trace); }`).

- [ ] **Step 5: Remove the `?layout` reader from `Component.tsx`**

In `app/components/Content/Component.tsx`:
- Line 17: change to `import { type BoxTree } from '@/app/utils/rowCombination';` (drop `type LayoutVersion`).
- Delete lines 129–138 (the `?layout` comment, `const [layoutVersion, setLayoutVersion] = useState<...>()`, and the `useEffect`).
- Line 165: remove `layoutVersion,` from the `processContentForDisplay` options object.
- Line 173: remove `layoutVersion` from the `useMemo` dependency array.
- Keep the `targetAR` clamp (lines 150–157) exactly as-is.

- [ ] **Step 6: Delete layoutTrace + its test**

```bash
git rm app/utils/layoutTrace.ts tests/utils/layoutTrace.test.ts
```

- [ ] **Step 7: Update tests for the flip**

In `tests/utils/rowCombination.test.ts`: delete the `lookupComposition layoutVersion dispatcher` describe block (~1645–1672) and remove now-unused imports it added. Run `tests/utils/rowCombination.test.ts` and `tests/utils/contentLayout.test.ts`; for any assertion that pinned a V1-specific label (e.g. `'compose-fallback'`, `'hero'`, `'dom-stacked-…'`) or a V1 tree shape, re-baseline to the actual V3 output (these tests now exercise V3 by default — that's the approved behavior). Confirm `contentLayout.test.ts:~1200` (4 H images → 1 row) still holds.

- [ ] **Step 8: Verify green + format + commit**

```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest --no-coverage
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/utils/rowCombination.ts app/utils/contentLayout.ts app/components/Content/Component.tsx tests/utils/rowCombination.test.ts
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/utils/rowCombination.ts app/utils/contentLayout.ts app/components/Content/Component.tsx
```
Expected: tsc clean (known 2 errors only); jest green.
```bash
git add -A && git commit -m "refactor(layout): make V3 the sole composition path; remove ?layout + layoutTrace

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>"
```

---

## Task 2: Delete the row optimizer (now dead)

`optimizeRows` only ran on the non-V3 path; after Task 1 nothing imports it. The whole file is dead (confirmed: only callers were `contentLayout.ts` and its own test).

**Files:**
- Delete: `app/utils/rowOptimizer.ts`, `tests/utils/rowOptimizer.test.ts`

- [ ] **Step 1: Confirm no remaining importers**

Run: `grep -rn "rowOptimizer\|optimizeRows\|optimizeBoundaries\|reorderWithinRows\|rebuildRow" app/`
Expected: no hits in `app/` (only the file itself, which we're deleting).

- [ ] **Step 2: Delete the files**

```bash
git rm app/utils/rowOptimizer.ts tests/utils/rowOptimizer.test.ts
```

- [ ] **Step 3: Verify green + commit**

```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest --no-coverage
git add -A && git commit -m "refactor(layout): delete rowOptimizer — dead once V3 skips the post-pass

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>"
```

---

## Task 3: Repoint `estimateRowAR` to V3 and delete the V1 cluster ⚠️ behavioral shift

This is the one task that changes Stage-1 behavior (see Spec note). Repoint `estimateRowAR` to `composeV3`, then delete every V1-only symbol (now caller-free).

**Files:**
- Modify: `app/utils/rowCombination.ts` (`estimateRowAR` 453–456; delete V1 cluster)
- Modify tests: `tests/utils/rowCombination.test.ts`, `tests/utils/rowCombination.characterization.test.ts`

- [ ] **Step 1: Repoint `estimateRowAR`**

Replace `app/utils/rowCombination.ts` lines 449–456 with:

```ts
/**
 * Estimate the combined aspect ratio of a set of images when composed together.
 * Uses the V3 composer (composeV3) so the estimate matches what actually renders.
 */
export function estimateRowAR(images: ImageType[], targetAR: number, rowWidth: number): number {
  const composition = composeV3(images, targetAR, rowWidth);
  return calculateBoxTreeAspectRatio(acToBoxTree(composition), rowWidth);
}
```

- [ ] **Step 2: Delete the V1 cluster**

In `app/utils/rowCombination.ts`, delete these symbols entirely (now caller-free):
- `findDominant` (189–202)
- `getTemplateKey` string version (205–213)
- `generateCandidates` (225–251) and the `buildAtomic` doc section header
- `buildAtomic` (264–291)
- `PARTITION_THRESHOLD` (298), `scoreCandidate` (304–307), `pickBest` (312–329), `generatePartitionCandidates` (340–377), `MAX_COMPOSE_DEPTH` (380)
- `compose` (396–434)
- `LayoutTemplate` interface (463–466), `buildDominantStacked` (473–483), `buildNestedQuad` (490–512), `TEMPLATE_MAP` (515–554)
- The now-orphaned `// TEMPLATE MAP` / `buildAtomic` section header comments

Keep: `single`, `hPair`, `vStack`, `hChain`, `acToBoxTree`, `toImageType`, `parseTemplateKey`, `estimateRowAR`, `AR_FLOOR_MULTIPLIER`, `MAX_ROW_IMAGES`, `collectRowItems`, `buildRows`, `isRowComplete`, `getTotalCV`, all types.

- [ ] **Step 3: Update V1 tests**

In `tests/utils/rowCombination.test.ts`, delete the describe blocks: `findDominant` (~966–987), `TEMPLATE_MAP` (~989–1030), `lookupComposition` V1-label block (~1032–1095), `buildAtomic` (~1101–end). Remove the now-dead imports `buildAtomic`, `compose`, `findDominant`, `TEMPLATE_MAP`. Keep `isRowComplete`, `buildRows`, `row density packing`, `toImageType`, `acToBoxTree`, builder tests.

In `tests/utils/rowCombination.characterization.test.ts`, delete the V1-shape blocks: `findDominant` (~735–766), `TEMPLATE_MAP` (~798–845), `TEMPLATE_MAP build functions` (~847–995), `lookupComposition` (~997–end). In the `buildRows characterization` block (~62–495): keep item-count / all-consumed / boxTree-id assertions; **re-baseline every `templateKey`/label expectation** (`'dom-stacked-1h2v'`, `'triple-h'`, `'nested-quad'`, `'compose-3h1v'`, etc.) to the V3 output by running the test and reading the actual values. Keep `architecture types` (`toImageType`, builders, `acToBoxTree`, object `getTemplateKey`) (~498–733).

- [ ] **Step 4: Verify green + commit**

```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/utils/rowCombination.test.ts tests/utils/rowCombination.characterization.test.ts --no-coverage
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest --no-coverage
git add -A && git commit -m "refactor(layout): repoint estimateRowAR to V3, delete V1 template engine

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>"
```

- [ ] **Step 5: ⚠️ Visual re-verify on :3000 (REQUIRED before continuing)**

Ask the user to reload `/chamonix`, `/2020-protests`, `/enchantments-2020`, `/a-mariners-game` on `:3000` (no `?layout` flag now — V3 is default). Confirm row composition still looks correct after the `estimateRowAR` repoint. If row breaks look wrong, STOP and re-plan estimateRowAR before proceeding.

---

## Task 4: Delete V2

**Files:**
- Delete: `app/utils/rowCombinationV2.ts`, `tests/utils/rowCombinationV2.test.ts`
- Modify: `app/constants/index.ts` (remove V2 scoring block, lines 66–80)

- [ ] **Step 1: Confirm no importers of composeV2 / V2 constants**

Run: `grep -rn "composeV2\|rowCombinationV2\|ORIENTATION_PENALTY\|SWAP_PENALTY\|AR_WEIGHT" app/`
Expected: only `app/constants/index.ts` (the defs) — no consumers (the import was removed in Task 1).

- [ ] **Step 2: Delete V2 file + test + constants**

```bash
git rm app/utils/rowCombinationV2.ts tests/utils/rowCombinationV2.test.ts
```
In `app/constants/index.ts`, delete lines 66–80 (the `ROW COMPOSITION V2` section header + `ORIENTATION_PENALTY`, `SWAP_PENALTY`, `AR_WEIGHT`).

- [ ] **Step 3: Verify green + commit**

```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest --no-coverage
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/constants/index.ts
git add -A && git commit -m "refactor(layout): delete composeV2 and its scoring constants

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>"
```

---

## Task 5: Fold `composeV3` into `rowCombination.ts` as `compose`; delete `rowCombinationV3.ts`

The V1 `compose` name is now free (deleted in Task 3). Move composeV3's body in and rename it.

**Files:**
- Modify: `app/utils/rowCombination.ts` (add folded composition; update `lookupComposition` + `estimateRowAR` to call `compose`; remove `composeV3` import)
- Delete: `app/utils/rowCombinationV3.ts`
- Rename: `tests/utils/rowCombinationV3.test.ts` → `tests/utils/rowCombination.composition.test.ts`

- [ ] **Step 1: Move the composition code**

Copy the body of `app/utils/rowCombinationV3.ts` (the private helpers `splitByPointBalance`, `enumerateAssignments`, `rowAR_Cost`, `leafShares`, `equitySpread`, `pickRootAssignment`, the `Candidate`/`AbstractNode` types, the `ROW_AR_FLOOR`/`AR_EQUITY_BAND` consts) into a new `// ROW COMPOSITION` section of `app/utils/rowCombination.ts`. Its imports (`single`, `hPair`, `vStack`, `ImageType`, `AtomicComponent`) are now local — drop the import statement. Rename the exported `composeV3` to `compose`:

```ts
export function compose(items: ImageType[], targetAR: number, rowWidth: number): AtomicComponent {
  if (items.length === 0) throw new Error('compose requires at least 1 image');
  if (items.length === 1) return single(items[0]!);
  void rowWidth; // AR is intrinsic to the tree; kept for call-site symmetry
  const tree = splitByPointBalance(items);
  return pickRootAssignment(tree, targetAR);
}
```

- [ ] **Step 2: Repoint callers to `compose`**

In `rowCombination.ts`: remove `import { composeV3 } from '@/app/utils/rowCombinationV3';` (line 19). Change `estimateRowAR` and `lookupComposition` to call `compose(...)` instead of `composeV3(...)`.

- [ ] **Step 3: Delete the V3 file, rename its test**

```bash
git rm app/utils/rowCombinationV3.ts
git mv tests/utils/rowCombinationV3.test.ts tests/utils/rowCombination.composition.test.ts
```
In the renamed test, update the import to `import { compose } from '@/app/utils/rowCombination';` and replace all `composeV3(` calls with `compose(`. Update the file's top comment to describe the canonical composer (drop "V3" framing).

- [ ] **Step 4: Verify green + commit**

```bash
/opt/homebrew/bin/node node_modules/.bin/jest tests/utils/rowCombination.composition.test.ts --no-coverage
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest --no-coverage
/opt/homebrew/bin/node node_modules/.bin/prettier --write app/utils/rowCombination.ts tests/utils/rowCombination.composition.test.ts
/opt/homebrew/bin/node node_modules/.bin/eslint --fix app/utils/rowCombination.ts
git add -A && git commit -m "refactor(layout): fold composeV3 into rowCombination as compose()

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>"
```

---

## Task 6: Drop write-only `RowResult.label` + `.direction`

`label` and `direction` are never read downstream (`contentLayout` keeps only `{templateKey, items, boxTree}`). `templateKey` IS read (`Component.tsx` data-pattern attr) → keep.

**Files:**
- Modify: `app/utils/rowCombination.ts` (`RowResult` 96–102; `CompositionResult` 561–565; `lookupComposition`; `deriveDirection` 653–656; `buildRows` row-push sites; hero push ~727)
- Modify tests: any asserting `RowResult.label`/`.direction`

- [ ] **Step 1: Write failing test for the trimmed shape**

In `tests/utils/rowCombination.test.ts`, add to the `buildRows` describe:

```ts
it('row results expose only templateKey, components, and boxTree (no label/direction)', () => {
  const rows = buildRows([createHorizontalImage(1, 3), createHorizontalImage(2, 3)], 8, 1.5);
  expect(rows[0]).toHaveProperty('templateKey');
  expect(rows[0]).toHaveProperty('boxTree');
  expect(rows[0]).toHaveProperty('components');
  expect(rows[0]).not.toHaveProperty('label');
  expect(rows[0]).not.toHaveProperty('direction');
});
```

- [ ] **Step 2: Run it — expect FAIL** (`label`/`direction` still present)

Run: `/opt/homebrew/bin/node node_modules/.bin/jest tests/utils/rowCombination.test.ts -t "no label/direction" --no-coverage`

- [ ] **Step 3: Remove the fields**

In `rowCombination.ts`:
- `RowResult` (96–102): remove `direction` and `label` fields → `{ components, templateKey, boxTree }`.
- `CompositionResult` (561–565): remove `label` → `{ composition, templateKey }`.
- `lookupComposition`: drop the `label: 'standard'` line.
- Delete `deriveDirection` (653–656).
- In `buildRows`, at the three `rows.push({...})` sites (hero ~727, main ~810, best-fit ~886), remove the `direction:` and `label:` keys; keep `components`, `templateKey`, `boxTree`. Remove the destructure of `label`/`templateKey` where now unused (keep `templateKey`).

- [ ] **Step 4: Run tests — expect PASS; fix any test asserting the removed fields**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest tests/utils/rowCombination.test.ts tests/utils/rowCombination.characterization.test.ts --no-coverage`. Remove/adjust any remaining `expect(...).toBe('hero')`-style label assertions.

- [ ] **Step 5: Verify green + commit**

```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest --no-coverage
git add -A && git commit -m "refactor(layout): drop write-only RowResult.label/direction + deriveDirection

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>"
```

---

## Task 7: Un-gate the density slider (make it permanent)

The slider stays as a permanent control; remove only the `?layout`/`showDensitySlider` gate. Keep the `density → chunkSize` wiring.

**Files:**
- Modify: `app/components/ContentCollection/CollectionPageClient.tsx` (remove `showDensitySlider` state + the `?layout` `useEffect` ~78–82; keep `density` state, `handleDensityChange`, `chunkSize={density}`; remove `showDensitySlider` from context value ~238–240 + deps ~247–249)
- Modify: `app/components/ContentCollection/CollectionFilterContext.tsx` (remove `showDensitySlider` field ~45; keep `density`, `onDensityChange`)
- Modify: `app/components/ContentCollection/CollectionFilterBar.tsx` (remove `showDensitySlider` prop + the `{showDensitySlider && ...}` gate ~325; render the slider unconditionally; keep `density`/`onDensityChange`)
- Modify: `app/components/Content/CollectionContentRenderer.tsx` (remove the `showDensitySlider` prop passed to `<CollectionFilterBar>` ~262–264)
- Modify tests: `tests/components/ContentCollection/CollectionFilterBar.test.tsx`

- [ ] **Step 1: Update the slider test for always-on rendering**

In `tests/components/ContentCollection/CollectionFilterBar.test.tsx`: remove any `showDensitySlider`/gating assertions; keep/adapt: (a) the slider renders without any flag, (b) moving it calls `onDensityChange` with the new value, (c) it shows the current `density`. Run it — expect FAIL (slider currently gated).

- [ ] **Step 2: Remove the gate across the wiring**

Apply the removals listed under **Files** above. Net effect: `CollectionFilterBar` always renders the density `<label><input type="range">`; `CollectionPageClient` no longer reads `?layout`; `showDensitySlider` is gone from the context type, value, and all props. Drop now-unused imports (`useEffect`/`LAYOUT` in `CollectionPageClient` if nothing else uses them — verify with grep before removing).

- [ ] **Step 3: Run tests — expect PASS**

Run: `/opt/homebrew/bin/node node_modules/.bin/jest tests/components/ContentCollection/CollectionFilterBar.test.tsx --no-coverage`

- [ ] **Step 4: Verify green + commit**

```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest --no-coverage
git add -A && git commit -m "feat(layout): make the row-density slider a permanent filter-bar control

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>"
```

---

## Task 8: Polish the now-permanent density slider

The slider was dev-quality. Make it production-quality.

**Files:**
- Modify: `app/components/ContentCollection/ContentComponent.module.scss` (`.filterBarSlider`, `.filterBarSliderLabel` ~586–611)
- Modify: `app/components/ContentCollection/CollectionFilterBar.tsx` (a11y attributes)

- [ ] **Step 1: Accessibility + label**

On the range input add `aria-label="Row density"`, `min={1}`, `max={10}`, `step={1}`, and a visible current-value readout. Ensure it is keyboard-operable and the label is associated (`htmlFor`/wrapping `<label>`).

- [ ] **Step 2: Production styling**

In the SCSS module, align the slider track/thumb with the existing filter-bar design tokens (CSS custom props, not hardcoded colors); verify it sits correctly in the fl/responsive bar (follow `scss-conventions`: container queries, gap rule). Run Stylelint:
```bash
/opt/homebrew/bin/node node_modules/.bin/stylelint --fix app/components/ContentCollection/ContentComponent.module.scss
```

- [ ] **Step 3: Verify + commit**

```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest --no-coverage
git add -A && git commit -m "style(layout): production styling + a11y for the density slider

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>"
```

- [ ] **Step 4: Visual approval on :3000** — ask the user to confirm the slider looks/behaves right on a collection page.

---

## Task 9: Stale-comment + housekeeping cleanup; final verification

**Files:**
- Modify: `app/utils/rowCombination.ts` (575, 682 comments), `app/utils/contentLayout.ts` (60 comment if any remains), `app/components/Content/Component.tsx` (130 comment)
- Modify: `.gitignore`

- [ ] **Step 1: Remove stale "AR-propagation" wording**

Grep and fix: `grep -rn "AR-propagation\|two-phase AR-propagation\|composeV2\|composeV3\|useV2\|layoutVersion\|?layout" app/`. Every remaining hit should be gone or rewritten to describe the single `compose()` enumeration algorithm. Expected after fixes: zero hits for `composeV2`/`composeV3`/`useV2`/`layoutVersion`/`AR-propagation`.

- [ ] **Step 2: Gitignore agent-memory**

Add to `.gitignore`:
```
.claude/agent-memory/
```
Run: `git status --short` → confirm `.claude/agent-memory/` no longer shows as untracked.

- [ ] **Step 3: Full final verification**

```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit
/opt/homebrew/bin/node node_modules/.bin/jest --no-coverage
/opt/homebrew/bin/node node_modules/.bin/eslint app/ tests/
/opt/homebrew/bin/node node_modules/.bin/stylelint "app/**/*.scss"
```
Expected: tsc clean (2 known errors), jest green, eslint/stylelint clean.

- [ ] **Step 4: Commit**

```bash
git add -A && git commit -m "chore(layout): remove stale A/B comments, gitignore agent-memory

Co-Authored-By: Claude Opus 4.8 (1M context) <noreply@anthropic.com>"
```

---

## Follow-up (separate, cross-repo — NOT executed here)

- [ ] **Backend `rowsWide` validation** (`edens-zac-backend`): confirm the save endpoint accepts `rowsWide` 1–10 (the admin density range). Verify with a save round-trip. Use `mempalace_find_tunnels` to link layout density context across repos before touching the backend.

---

## Self-Review

**1. Spec coverage**

| Spec item | Task |
|---|---|
| Remove all V1 logic | Task 1 (dispatch), Task 3 (delete cluster) |
| Remove V2 logic | Task 1 (import), Task 4 (file + constants) |
| Remove previous-version-only tests | Tasks 1,3,4 (delete/trim test blocks + files) |
| Rename V3 → "normal" code | Task 5 (`composeV3`→`compose`, file fold, test rename) |
| layoutTrace → delete | Task 1 |
| Density slider → keep permanent | Tasks 7 (un-gate) + 8 (polish) |
| Composition → fold into rowCombination.ts | Task 5 |
| Dead code: optimizeRows | Task 2 |
| Dead code: RowResult.label/direction | Task 6 |
| Review C1 (AR-propagation comments) | Task 9 |
| Review C4 (.claude/agent-memory gitignore) | Task 9 |
| Review T1 (Option-A test) | Moot — optimizeRows deleted (Task 2) |
| Review D1 (global targetAR/density) | Inherent — V3 is now the default; targetAR clamp kept (Task 1 Step 5) |
| Backend rowsWide | Follow-up (out of scope) |

No spec item is unmapped.

**2. Placeholder scan:** No "TBD"/"handle edge cases"/"similar to Task N". Modify steps show full code; delete steps name exact symbols + line ranges. The one explicit re-baseline (Task 3 Step 3) is unavoidable (V3 output values must be read from a run, not guessed) and is called out as such.

**3. Type consistency:** `compose(items, targetAR, rowWidth)` signature is identical to the old `composeV3`. `CompositionResult` loses `label` consistently in Task 6 (def + producer + consumers). `RowResult` → `{components, templateKey, boxTree}` consistently. `LayoutVersion` removed in Task 1 before any task references it.

---

## Agent Teams Evaluation

**Not recommended for execution.** Although this is a large refactor, the changes are concentrated in 2–3 hot files (`rowCombination.ts`, `contentLayout.ts`, plus the slider cluster) with **tight sequential dependencies** (the `compose`-name collision forces V1-delete → fold ordering; green-per-commit forces test updates in lockstep). Parallel agents would collide on the same files and the same test files. The correct execution model is **sequential, single-session, one subagent per task** (subagent-driven-development), with the Task 3 `:3000` checkpoint.

---

## Execution Handoff

Plan complete and saved to `docs/superpowers/plans/2026-05-29-v3-promotion-cleanup.md`. Two execution options:

1. **Subagent-Driven (recommended)** — I dispatch a fresh subagent per task, review between tasks, fast iteration. Hard stop for your visual approval at Task 3 Step 5 and Task 8 Step 4.
2. **Inline Execution** — I execute tasks in this session with checkpoints for review.

Which approach?
