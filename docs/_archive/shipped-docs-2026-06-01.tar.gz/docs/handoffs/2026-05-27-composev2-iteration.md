# Handoff — composeV2 layout iteration (2026-05-27)

## Branch state

- **Branch:** `0141-gif-updates` (frontend repo `edens.zac`)
- **Origin:** 12 commits ahead, ready for review/push
- **Tests:** 1405 / 1405 passing across 46 suites
- **Type-check:** clean (modulo pre-existing `.next/types/validator.ts` noise)
- **Lint:** clean on touched files. Pre-existing `imagesToEdit` unused-var error in `app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx:340` — not from this work, confirmed via `git stash`

## Read first (in order)

1. `docs/superpowers/specs/2026-05-26-row-composition-redesign.md` — composeV2 spec (locked algorithm)
2. `docs/superpowers/specs/2026-05-26-row-composition-flowcharts.md` — pipeline diagrams
3. `docs/superpowers/plans/2026-05-26-row-composition-v2-rollout.md` — original rollout plan
4. `docs/spikes/2026-05-26-row-composition-retrospective.md` — why we're rewriting at all
5. **This file** — current state + known issues

## What this session accomplished (chronological by commit)

Each line below maps 1:1 to a commit on `0141-gif-updates`.

| Commit | What | Status |
|---|---|---|
| `291c170` | Created `app/utils/rowCombinationV2.ts` with bottom-up merge per spec §3–§5; added 3 constants; new test file | landed |
| `fd5552e` | Wired `?layout=v2` URL toggle through `Component.tsx` → `processContentForDisplay` → `lookupComposition` dispatcher | landed |
| `1a95376` | Same-orientation vStack hard-skip in composeV2 (first iteration of vStack-cluster bug fix) | landed |
| `aa08b1a` | Asymmetric V+V penalty + top-level unconditional hPair (restored dom-stacked variety) | landed |
| `15a5ed1` | Wired Row Density admin control (was completely dead) — admin 1-10 → `rowWidth = chunkSize + 4` | landed |
| `628e3bf` | Scaled `targetAR` with rowWidth (attempt at contact-sheet at high density) | landed but superseded |
| `24bed8a` | Reverted targetAR scaling; added `vTier` cap at 2 (forces 2×N grids instead of N-tier strips) | landed |
| `73363e2` | Density-scaled MIN_FILL in `buildRows` so high-density rows pack more items | landed |
| `68b776f` | Prominence rule: `maxEffRating ≥ 4` blocks vStack (no shrinking of 4★+ items into narrow columns) | landed (user pushed back on framing, agreed to keep) |
| `76083c9` | Singleton-only swaps to bound leaf displacement to ±1 (spec P6) | landed |
| `4257ce9` | Threaded `useV2` through `optimizeRows` → `rebuildRow` | **REVERTED — made layouts worse** |
| `87a5a21` | Revert of `4257ce9` | landed |

## Current composeV2 algorithm (post-revert state)

Per-merge candidate skip rules in order (all in the merge-loop of `composeV2`):

1. **Top-level constraint:** when `atoms.length === 2` (this is the row root), `direction === 'V'` is always skipped. Rows are horizontal — root must be hPair.
2. **vTier cap:** `vStack` skipped if `leftAtom.vTier + rightAtom.vTier > 2`. Caps vertical depth to 2 tiers. Prevents 3-tier vertical strips.
3. **Prominence rule:** `vStack` skipped if either atom's subtree contains a leaf with `maxEffRating ≥ 4`. Prevents 4★/5★ items from being shrunk into a vStack subordinate-column.
4. **Singleton-only swaps:** swap-with-prev and swap-with-next each require BOTH swapped atoms be singletons (`ids.length === 1`). Bounds leaf displacement to ±1 per spec P6.

Scoring (in `scoreMerge`):
- `sumCvCost = left.cv + right.cv` — drives "small pairs first"
- `orientationCost = ORIENTATION_PENALTY (1.0)` IFF `direction === 'V' AND both atoms have orient === 'V'` (asymmetric — V+V only, NOT H+H)
- `swapCost = SWAP_PENALTY (0.6)` if any swap applied
- `arCost = AR_WEIGHT (0.3) × |simulated_row_ar - targetAR|`

`MergeAtom` carries `{ ac, cv, orient, ar, ids, vTier, maxEffRating }`. Orient propagates as `matched-or-M`. `vTier` propagates as `left+right` for vStack, `max` for hPair. `maxEffRating` propagates as `max`.

## Density control (admin → algorithm)

`ManageClient.tsx` UI: **"Row Density"** stepper input, range 1–10, default 4. Maps to `collection.rowsWide` backend field.

`CollectionPageWrapper.tsx`: `chunkSize = collection.rowsWide ?? LAYOUT.defaultChunkSize (4)`.

`processContentForDisplay` (contentLayout.ts:121): `rowWidth = isMobile ? mobileSlotWidth : chunkSize + 4`. Mobile pins.

`buildRows`: `effectiveMinFill = MIN_FILL_RATIO + max(0, (rowWidth - 8) × 0.02)`. Forces denser packing at higher rowWidth.

| Admin density | rowWidth | effectiveMinFill | Typical items/row (H r3) |
|---|---|---|---|
| 1 | 5 | 0.90 | 1-2 |
| 4 (default) | 8 | 0.90 | 3 |
| 6 | 10 | 0.94 | 4 |
| 8 | 12 | 0.98 | 5 |
| 10 | 14 | 1.02 | 6 |

## Known issues (priority order)

### 1. **CRITICAL** — `rowOptimizer.rebuildRow` doesn't honor `useV2`

When `optimizeBoundaries` decides to shift an item across a row boundary (because it improves combined fill score), it calls `rebuildRow(components, rowWidth)` which internally calls `lookupComposition(images)` without passing `useV2`. The default is `false`, so the rebuilt row uses V1's `buildAtomic` — including its known "dominant always right" bug.

**Visible symptom (user report):** a 4-item row `[H4★, H4★, H3★, V5★]` on `?layout=v2` rendered as leaf order `[3, 2, 4, 1]` — exactly V1's `hPair(vStack(hPair(item3, item2), item4), single(item1))` candidate winning.

**Why the naive fix failed:** commit `4257ce9` threaded `useV2` through `optimizeRows → optimizeBoundaries → rebuildRow`. User reported "made EVERYTHING WORSE" across the page. Hypothesis: `optimizeBoundaries` + `reorderWithinRows` were implicitly tuned against V1's tree shapes (rowScore + boundary-shift heuristics). Feeding composeV2 trees through the same pipeline scored differently → triggered more boundary shifts → cascading layout damage.

**Options for next session (DO NOT just re-attempt the naive thread):**
- **A.** When `useV2` is true, skip `optimizeRows` entirely. Trust composeV2's output as-is.
- **B.** Audit `rowScore` / `optimizeBoundaries` / `reorderWithinRows` for V1-assumption coupling. Re-tune for V2 output shape.
- **C.** Remove `reorderWithinRows` entirely per the [2026-05-13 audit Option B](../spikes/2026-05-13-image-reorder-audit.md). Test whether `optimizeBoundaries` alone is acceptable for both V1 and V2.

### 2. Stage-1 (`buildRows`) bugs — deferred per the original rollout plan

Per the 2026-05-26 retrospective and mempalace `layout-stage-1-bugs-deferred-2026-05-26`:
- **arFactor cap** in `contentRatingUtils.ts:102` — `Math.min(imageAR, REFERENCE_AR=1.5)` caps max cv at 5.0. Panoramas at AR 2.67+ get same cv as AR 1.5 horizontals. Loses panorama prominence signal.
- **Standalone-skip threshold unreachable on desktop** — `cv / rowWidth >= 0.95` with `desktopSlotWidth=8` gives threshold 7.6; max cv = 5.0 (capped). Dead code on desktop, still works on mobile.
- **Moderate-overfill at 1.35** in `buildRows` — accepts up to 135% fill when row under MIN_FILL. May cram items inappropriately. Spec recommends tightening to 1.20.

These were intentionally deferred to a separate PR after composeV2 lands.

### 3. Verbose comments in layout pipeline (task #15)

User feedback (2026-05-27): code comments in `rowCombinationV2.ts` and `contentLayout.ts` are too long, include diagnosis dates, multi-paragraph histories. Should be tightened to single-line WHAT/WHY explanations. Detail belongs in commit messages.

### 4. Last-row filler atom — deferred (spec §13)

Locked per mempalace `last-row-filler-spec-locked-2026-05-26`. Not for current PR cycle. Re-evaluate visually after stage-1 tuning and reorderWithinRows removal land.

## What you should NOT do

These are architectural reset signals from the user, captured in mempalace:

- **DO NOT** propose Knuth-Plass / optimal-fill DP row balancing (user explicitly rejected, 2026-05-26).
- **DO NOT** bring back TEMPLATE_MAP / named pattern registry. Three attempts have failed (Jan 24 `patternRegistry`, Feb 5 `CombinationPattern`, Mar 13 `TEMPLATE_MAP`). Combinatorial treadmill.
- **DO NOT** propose keeping `findDominant` or the "dominant always right" rule from V1.
- **DO NOT** add brittle "skip rule" bandaids without grounding them in a clear principle from the spec (P1–P8). User pushback on `68b776f` framing taught: state the principle FIRST, then the rule that encodes it.
- **DO NOT** rewrite verbose code comments mid-implementation — task #15 tracks that cleanup separately.
- **DO NOT** thread `useV2` through `optimizeRows` naively (commit `4257ce9` was the failed attempt — see Known Issue #1 for what to do instead).

## Mempalace user-wing references (source-wing `edens-zac`)

Load these via `mempalace_user_search` at session start:

- `april-1-2026-revert-cost-2-months` — frustration / lesson: when architecture is right but missing one ingredient, ADD the ingredient. Don't revert.
- `layout-design-thesis-consistent-since-2025` — goals: 7-point design thesis. "Images appear in input order, important images render larger, layout emerges from item properties not registries."
- `user-architectural-instincts-pattern-2026` — observation: when user says "too much logic", that's an architectural reset signal, not a tuning request.
- `row-composition-bottom-up-merge-architecture-2026-05-26` — decision: the algorithm and its origin (402f07c was 70% correct).
- `in-row-quality-over-last-row-balance-2026-05-26` — decision: explicit rejection of optimal-fill DP.
- `last-row-filler-spec-locked-2026-05-26` — decision: deferred to a future PR.
- `last-row-filler-atom-concept-2026-05-26` — design context for filler atom.
- `layout-stage-1-bugs-deferred-2026-05-26` — decision: arFactor + standalone-skip + overfill ceiling deferred.
- `panorama-standalone-skip-dead-code-2026-05-26` — discovery: dead code analysis.
- `reorder-pipeline-bug-tylerabby` — discovery: `reorderWithinRows` swap bug, audit doc location.
- `layout-rewrite-session-resume-2026-05-26-manual-ab-toggle` — goal: this session's intent.
- `composev2-vstack-cluster-bug-2026-05-27` — discovery: orient='M' propagation + soft penalty overwhelmed.
- `composev2-asymmetric-orient-penalty-and-top-level-rule-2026-05-27` — discovery: fix split into asymmetric soft cost + top-level hard rule.
- `rowsWide-admin-control-was-dead-wiring-2026-05-27` — discovery: chunkSize was reaching `createHeaderRow` only, never `buildRows`.
- `verbose-code-comments-2026-05-27` — frustration: comment-style preferences for future code.
- `composev2-optimizer-rebuildRow-usev2-attempt-reverted-2026-05-27` — decision: optimizer wiring needs deeper rework, not a thread-through.

Cross-repo: no `edens-zac-backend` tunnels relevant to this work. Backend may need `rowsWide` validation update to accept range 1–10 (was 1–6 previously); user can verify on first save past 6.

## Files modified on this branch (since main)

```
app/(admin)/collection/manage/[[...slug]]/ManageClient.tsx   (admin UI: Row Density)
app/components/Content/Component.tsx                          (useV2 URL reader)
app/constants/index.ts                                        (ORIENTATION_PENALTY, SWAP_PENALTY, AR_WEIGHT)
app/utils/contentLayout.ts                                    (rowWidth from chunkSize, useV2 plumbing)
app/utils/rowCombination.ts                                   (lookupComposition useV2 dispatcher, density-scaled MIN_FILL)
app/utils/rowCombinationV2.ts                                 (composeV2 algorithm — new file)
tests/utils/rowCombination.test.ts                            (dispatcher tests + density-scaled MIN_FILL tests)
tests/utils/rowCombinationV2.test.ts                          (16 algorithm tests — new file)
```

Untouched by this session:
- `app/utils/rowOptimizer.ts` — `rebuildRow` still calls `lookupComposition(images)` with no `useV2`. **This is Known Issue #1.**
- `app/utils/rowStructureAlgorithm.ts`
- `app/utils/contentRatingUtils.ts` (arFactor cap unchanged — stage-1 deferred)

## Verification commands

```bash
/opt/homebrew/bin/node node_modules/.bin/tsc --noEmit                 # type-check
/opt/homebrew/bin/node node_modules/.bin/jest                          # full test suite
/opt/homebrew/bin/node node_modules/.bin/jest tests/utils/rowCombinationV2.test.ts  # V2 only (16 tests)
/opt/homebrew/bin/node node_modules/.bin/prettier --write <files>
/opt/homebrew/bin/node node_modules/.bin/eslint --fix <files>
```

Browser smoke test: `http://localhost:3000/2020-protests` (V1 default) vs `?layout=v2`. Diagnostic logs were removed (commit `aa08b1a` mentioned them); re-add via `processContentForDisplay` if needed for next-session diagnosis.

## Next session recommended order

1. **Fix Known Issue #1** (rowOptimizer + useV2). Try Option A (skip optimizeRows when useV2) FIRST — it's the smallest change. If layouts regress, fall back to Option C (remove reorderWithinRows) per the 2026-05-13 audit.
2. **Re-add `[ROW-TRACE]` diagnostic logs** to `buildRows` and `processContentForDisplay` to verify any fix. Pattern: `console.log` gated by `process.env.NODE_ENV === 'development'`, dumps row count, item IDs, eff ratings, AR string, label, fill ratio, and `tree=...` shape using single-char `h`/`v`/`L<id>` form.
3. **Stage-1 tuning PR** (separate). Lower arFactor cap removal, lower standalone-skip threshold, tighten moderate-overfill ceiling.
4. **Comment cleanup pass** (task #15). One sweep through `rowCombinationV2.ts` and `contentLayout.ts` to tighten verbose blocks.
5. **Cleanup PR** (eventual): flip `useV2` default to true, delete V1 path (`compose`, `buildAtomic`, `findDominant`, `generateCandidates`, `TEMPLATE_MAP`), remove the `useV2` toggle plumbing.

## Recent visible bugs surfaced via A/B that this session iterated on

These came up during user smoke tests at progressively higher densities — each drove one or more commits above.

1. **"1+2 everywhere" on /2020-protests `?layout=v2`** — composeV2 produced `vStack(hPair(H,H), single(H))` at row root. Fixed by `1a95376` + `aa08b1a` (orient propagation + asymmetric V+V + top-level hard rule).
2. **Uniform 3-wide at density 4 after fix** — my full hard-skip blocked dom-stacked emergence too aggressively. Fixed by `aa08b1a` (asymmetric: H+H allowed, V+V blocked).
3. **Row Density slider had no effect** — dead wiring. Fixed by `15a5ed1`.
4. **`1×4` strip at density 8** — `targetAR` scaling pushed hPair preference too far. Fixed by `24bed8a` (revert + vTier cap).
5. **4-item row capped at 4 items even with capacity for 5** — fixed-MIN_FILL bar didn't scale with rowWidth. Fixed by `73363e2`.
6. **2×2 grid for `[4★,4★,3★,3★]` (all images same size)** — 4★s deserve prominence over 3★s but algorithm pair-matched them. Fixed by `68b776f` (prominence rule).
7. **Item moved 3 positions back in row** — spec P6 violation. Cluster swaps were moving N leaves by 1 swap operation. Fixed by `76083c9` (singleton-only swaps).
8. **V1's `[3, 2, 4, 1]` layout still appearing on V2 page** — `rowOptimizer.rebuildRow` not honoring `useV2`. **NOT FIXED** — see Known Issue #1.

## End

Branch is in a stable state — all tests pass, type-check clean, lint clean. Issue #1 is the most visible remaining V2 bug. Don't re-attempt the naive `useV2` thread-through; explore Options A/C from the Known Issue #1 section instead.
