# HANDOFF — Mobile Full-Screen Viewer "white strip at bottom" (landscape)

_Updated 2026-05-31 (late). Read this fully before touching anything — there is a long trail of
dead ends below; do not repeat them._

## CURRENT STATUS

A fix is **applied but uncommitted** on branch `0144-fullscreen-debug`, **awaiting on-device
verification** by the user (Brave on iOS, over LAN). The root cause is finally pinned down (proven,
not guessed). If the user confirms the bottom is dark/clean, the remaining work is: **strip the
temporary diagnostic, decide frame-removal scope, commit, push, PR.**

> ⚠️ This bug is **iOS-mobile-specific and does NOT reproduce in the headless preview / desktop
> Chrome** (there the browser toolbar doesn't exist, so `lvh == dvh == innerHeight` and the gap never
> appears). **Verification is device-only.** Do not claim it fixed from the preview.

---

## THE BUG (Issue B)

Full-screen image viewer (the modal that opens when you tap an image), **mobile + landscape only**:
a strip of **white at the bottom of the screen**. Reported on **Brave iOS**. It is NOT on the
scrollable pages — only the full-screen modal.

(There was an earlier **Issue A** — landscape phones got the *desktop* 40px padding/border. That was
fixed by height-gating the desktop media queries and is **merged** (branch `0142`). Don't touch it.)

## ROOT CAUSE (proven)

The modal overlay (`.imageFullScreenWrapper`, `position: fixed; inset: 0`) only reaches
`window.innerHeight`. On iOS Brave, when the browser toolbar is retracted, the **actual visible
screen is taller than `innerHeight`** (`vh`/`lvh` = 333 vs `innerHeight`/`dvh` = 313 in landscape —
a ~20px difference). The overlay stops at 313; the **20px gap exposes the white page canvas**
(`color-scheme: light` makes the canvas white). That white strip is the bug.

**Proof:** a diagnostic that tinted the page canvas lime made the bottom strip turn lime → it's the
page showing through, not any element in the modal.

## THE FIX (currently applied, uncommitted, in `app/styles/fullscreen-image.module.scss`)

- `.imageFullScreenWrapper`: `position: fixed; inset: 0; min-height: 100lvh;` — the dark backdrop now
  extends to the **large** viewport (333), covering the toolbar gap. (Confirmed on device: after this,
  `wrapBottom` reads `333` and `gapBelowWrap` reads `-20`, i.e. it covers ~20px past `innerHeight`.)
- `.overlayContainer`: `padding: 0; max-height: 100dvh;` — keeps the image centered in the **visible**
  viewport (dvh), not the taller lvh backdrop, so the image isn't shifted/cropped.

These two ride on top of several earlier changes also in the working tree (see below). Desktop is
unaffected because there `lvh == dvh == vh == innerHeight`.

---

## FULL TIMELINE OF ATTEMPTS (so you don't redo them)

| # | Attempt | Result |
|---|---------|--------|
| A | Height-gate desktop media queries `@media (width>=768px) and (height>=600px)` so landscape phones keep mobile styling | ✅ Fixed Issue A. **Merged** (0142 / PR #146). |
| 1 | `100vh` → `100dvh` on the overlay/image | ❌ Did not fix B. (Merged as the *only* commit of PR #147 — see Git Pitfall below.) |
| 2 | Remove vestigial `<body> { perspective: 1px }` (parallax is JS-driven; perspective only broke `position:fixed`) | ❌ Not the cause of B. (Valid cleanup though. iOS-engine-level theory was wrong — Safari & Brave share WebKit.) |
| 3 | `inset: 0` instead of `width/height` viewport units on the wrapper | ❌ Did not fix B. `inset:0` reaches `innerHeight`, **not** the large viewport — same gap. |
| 4 | Symmetric axes: `.overlayContainer { padding: 0 }` + image `max-height: 100dvh - 16px` mirroring `max-width: 100vw - 16px` | Image now fills the height symmetric to portrait, but the white = the **8px white frame**, which this kept. |
| 5 | Remove the white photo-matte (`.imageWrapperLoaded` white bg/padding) on mobile; desktop keeps 40px matte | Frame gone (img reaches the edge) — but **white STILL there** → proved the white was NOT the frame. |
| 6 | **`min-height: 100lvh` backdrop + overlayContainer `max-height: 100dvh`** | ⏳ CURRENT — structurally covers the gap (`wrapBottom 313→333`). Awaiting device confirm. |

Key realizations along the way:
- The white was **constant** through every frame change → it was never the frame; it was the page
  canvas in the toolbar gap.
- The lime diagnostic, after the lvh fix, showed **green** at the bottom which spooked the user — but
  that's the lime canvas bleeding through the **90%-opaque** overlay (`rgba(0,0,0,0.9)`), i.e. it's
  tinting a now-**covered** area. On a real white canvas that strip is `overlay×white` ≈ near-black
  (invisible). The lime tint has since been **removed** from the diagnostic to avoid this confusion.

## DIAGNOSTIC HARNESS (temporary — MUST be deleted before PR)

- `app/components/FullScreenModal/FsDebug.tsx` — renders only when URL has `?fsdebug=1`. Prints a
  green readout (innerHeight, visualViewport, `vh/dvh/svh/lvh`, safe-area, `wrapBottom`,
  `gapBelowWrap`, `FRAME top/bot`, `gapBelowFrame`, `IMG bottom`), outlines layers (cyan=overlay,
  red=imageWrapper, yellow=image), and a magenta line at the overlay's fixed bottom edge.
- Wired in `FullScreenModal.tsx`: a `const fsdebug = ...URLSearchParams...get('fsdebug')==='1'` and
  `{fsdebug && <FsDebug />}`, plus `import { FsDebug } from './FsDebug'`.
- The Next dev overlay's **"1 Issue"** badge is from this component reading `window` during render —
  it disappears when the diagnostic is removed. Ignore it.

**To remove before PR:** delete `FsDebug.tsx`, and remove the import + the `fsdebug` const + the
`{fsdebug && <FsDebug />}` line from `FullScreenModal.tsx`.

---

## HOW TO TEST (LAN, no deploy — this is the only real test)

1. Preview server: `.claude/launch.json` → "Next.js Dev Server", port **3001**, `.next-preview` build
   dir, binds all interfaces. Start via the Claude Preview tool (`preview_start`) or
   `node node_modules/.bin/next dev -H 0.0.0.0 -p 3001` (npm/npx are NOT on PATH; use
   `/opt/homebrew/bin/node`).
2. Mac LAN IP = **192.168.68.59** (the **wired** en7; Wi-Fi en0 is `.55` but the Mac is dual-homed and
   `.59` is the routable one). Phone on same Wi-Fi → Brave → `http://192.168.68.59:3001/chamonix`
   (add `?fsdebug=1` for the readout).
3. **`allowedDevOrigins: ['192.168.68.55','192.168.68.59']` was added to `next.config.js`** — Next 16
   blocks LAN-origin client navigation/HMR without it (symptom: landing page works, links/menu don't).
4. macOS firewall is OFF; if a page won't load at all it's Wi-Fi client-isolation → use a tunnel
   (cloudflared/ngrok), none installed yet.

### Backend caveat
Spring backend in Docker on `localhost:8080`. In `next dev`, `getApiBaseUrl()` returns
`http://localhost:8080` for **both** server and client (`isLocalEnvironment()` true). So
server-rendered collection pages + the modal work on the phone, but client-side refetches
(pagination/filters) point at the phone's own localhost and fail — irrelevant for the modal test.
**Currently `/api/collections` (the LIST endpoint) 500s, but individual collections work** — and the
headless preview's data loading has been flaky (sometimes redirects `/chamonix` → `/location/...` or
`/admin`). Just use a collection that loads.

---

## GIT STATE

- `origin/main` @ `e41c906` = has Issue A (0142) + the **dvh-only** Issue-B attempt (0143).
- **GIT PITFALL:** PR #147 (branch 0143) was merged at commit `bd6dfd9` (the dvh fix). Later commits
  `73b9e7b` (perspective) and `f0107ea` (inset:0) were pushed to the branch **after** the merge, so
  **they never reached `main`.** They were recovered onto `0144`.
- Current branch **`0144-fullscreen-debug`**: committed `be7e236` (WIP: recovered inset:0 + perspective
  + initial FsDebug) on top of `e41c906`. **NOT pushed.**
- **Uncommitted** working-tree changes on top of `be7e236`:
  - `app/styles/fullscreen-image.module.scss` — symmetric axes + frame removal + `min-height:100lvh` +
    `overlayContainer max-height:100dvh` (the real fix).
  - `app/components/FullScreenModal/FsDebug.tsx` — diagnostic refinements (lime added then removed).
  - `next.config.js` — `allowedDevOrigins`.
  - `app/components/Content/CollectionContentRenderer.tsx` — **the user's pre-existing 2-line change,
    NOT part of this work. Do NOT stage/commit it.**
  - `docs/` — this handoff (gitignored).

## FILES INVOLVED

| File | Role |
|------|------|
| `app/styles/fullscreen-image.module.scss` | The modal styles — **the fix surface.** |
| `app/components/FullScreenModal/FullScreenModal.tsx` | The modal (portaled to `document.body`); has the `?fsdebug` wiring to remove. |
| `app/components/FullScreenModal/FsDebug.tsx` | **TEMP diagnostic — delete before PR.** |
| `app/hooks/useFullScreenImage.tsx` | Modal open/close state. (Perspective toggle was removed here on 0144.) |
| `app/hooks/useBodyScrollLock.ts` | Scroll lock (`body.scroll-locked`, `position:fixed; top:-scrollY`). |
| `app/styles/globals.css` | `<body>` styles; the vestigial `perspective:1px` lived here (removed on 0144 in commit `73b9e7b`, which is in the working tree via recovery). |
| `next.config.js` | `allowedDevOrigins` for LAN dev. |

## NEXT STEPS

1. **User verifies the lvh fix on Brave landscape.** Expected: bottom strip dark, no white. (`?fsdebug=1`
   readout should show `wrapBottom ≈ lvh`, negative `gapBelowWrap`, and with lime removed the strip is dark.)
2. **If clean:**
   - Delete the FsDebug diagnostic (file + wiring) and the `allowedDevOrigins`? (keep it — harmless,
     useful for future LAN testing; or strip if undesired).
   - Confirm scope of the white-frame removal (currently removed on mobile, kept 40px on desktop — the
     user may want it back, or want it gone — ASK).
   - Squash/clean the working-tree + `be7e236` into one coherent commit on a fresh branch off
     `origin/main`, push, open PR to `main`. (The perspective removal + symmetric axes + frame removal +
     lvh are all part of the final fix — decide which to keep; lvh + overlayContainer dvh is the core
     white-strip fix.)
3. **If a thin white sliver still shows below the dark:** Brave is under-reporting even `lvh` →
   over-scan the backdrop, e.g. `min-height: calc(100lvh + 40px)` or extend with `bottom: -40px`.

## ENVIRONMENT GOTCHAS

- **mempalace MCP is disconnected** this session — can't search/write it.
- npm/npx not on PATH — use `/opt/homebrew/bin/node node_modules/.bin/<tool>`.
- Lint/verify after edits: `prettier --write`, `stylelint` (scss/css), `eslint --fix` (ts/tsx),
  `tsc --noEmit`. (Note: `tsc` shows 2 pre-existing stale errors in `.next/types/validator.ts` about
  removed `collectionType`/`search` routes — environmental, not from this work.)
- The user values: minimal/concise comments, investigation before changing, evidence over assertion.
