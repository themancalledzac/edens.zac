# Backend Spike: Camera → Film Metadata

**Date:** 2026-05-13
**Repo:** `~/Code/edens.zac.backend` (Spring Boot)
**Companion frontend work:** see commit on `0139-minor-fixes` in `~/Code/edens.zac` — `ContentCameraModel` already carries optional `isFilm` + `defaultFilmFormat` fields, and `ImageMetadataModal` will auto-toggle Film Photography + Film Format when a film camera is picked. The frontend changes are harmless until this backend work lands.

## 1. Motivation

When a user picks a film camera (e.g. `Hasselblad 500cm`) in the image metadata editor, the modal should auto-flip the `Film Photography` checkbox to `true` and set `Film Format` to the camera's default (`120` for the Hasselblad, `35mm` for a Nikon FM3a). Today `Records.Camera` carries only `id` and `name`, so the frontend has nothing to key on.

This work adds two columns on `content_cameras` — `is_film` and `default_film_format` — and surfaces them through every existing camera-read path. The migration also backfills known film cameras, which replaces the need for a separate "edit camera" admin endpoint.

## 2. Schema migration

Highest existing migration is `V22__collection_people.sql`. Add `V23` at:

`src/main/resources/db/migration/V23__add_film_metadata_to_cameras.sql`

```sql
-- V23: Add film-photography defaults to content_cameras so that
-- selecting a known film body in the metadata editor can auto-toggle
-- isFilm + filmFormat on the frontend.
--
-- is_film defaults to FALSE for back-compat (all existing cameras).
-- default_film_format is nullable and holds FilmFormat enum names
-- (currently MM_35 or MM_120).

ALTER TABLE content_cameras
    ADD COLUMN IF NOT EXISTS is_film             BOOLEAN     NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS default_film_format VARCHAR(20);

-- Backfill known film bodies. Case-insensitive match; safe no-op if the
-- camera doesn't yet exist in this environment.
UPDATE content_cameras
   SET is_film = TRUE,
       default_film_format = 'MM_120'
 WHERE LOWER(camera_name) IN ('hasselblad 500cm', 'hasselblad 500c/m', 'hasselblad 500 c/m');

UPDATE content_cameras
   SET is_film = TRUE,
       default_film_format = 'MM_35'
 WHERE LOWER(camera_name) IN ('nikon fm3a', 'nikon fm-3a');
```

**CRITICAL:** `FilmFormat` enum values are `MM_35` and `MM_120` (see `types/FilmFormat.java:14-16`), NOT `_35MM` / `_120`. Use the canonical enum names everywhere.

Adding more film cameras after this ships is a follow-up `V24__...` migration of the same shape — no new admin endpoint required.

## 3. Entity — `entity/ContentCameraEntity.java`

Add two fields after `bodySerialNumber` (line 44), before `createdAt`:

```java
/** Column: is_film (BOOLEAN, NOT NULL, DEFAULT FALSE) - Whether this camera shoots film */
private Boolean isFilm;

/** Column: default_film_format (VARCHAR(20), nullable) - FilmFormat enum name, e.g. "MM_120" */
private FilmFormat defaultFilmFormat;
```

Add import: `import edens.zac.portfolio.backend.types.FilmFormat;`. No JPA annotations — this project uses Spring `JdbcTemplate` + `RowMapper`, not JPA. Lombok `@Data` + `@Builder` already declared at the class level cover getters/setters/construction.

## 4. Record DTO — `model/Records.java:18`

Change:

```java
public record Camera(Long id, String name) {}
```

to:

```java
public record Camera(Long id, String name, Boolean isFilm, FilmFormat defaultFilmFormat) {}
```

Add import at the top of the file: `import edens.zac.portfolio.backend.types.FilmFormat;`.

### Caller impact

All 11 sites identified by grep. Most are type-only (recompile with no value change). Two are value-sites:

**Value-site (must update constructor args):**
- `services/ContentModelConverter.java:179-180` — production mapper.
- `src/test/java/edens/zac/portfolio/backend/controller/prod/ContentControllerProdTest.java:149-150` — test fixtures (the two cameras passed today: `Canon EOS R5` and `Sony A7 IV`).

**Type-only (recompiles after the enum import is added at the call site if it doesn't reference the new fields):**
- `model/ContentModels.java:44`
- `model/ContentImageUpdateResponse.java:47`
- `controller/prod/ContentControllerProd.java:107-108`
- `services/MetadataService.java:169-171`
- `services/CollectionService.java:674`
- `services/ContentService.java:810`
- `model/GeneralMetadataDTO.java:20`
- `src/test/java/edens/zac/portfolio/backend/services/CollectionServiceTest.java:71`

### Converter update

`ContentModelConverter.cameraEntityToCameraModel`:

```java
public static Records.Camera cameraEntityToCameraModel(ContentCameraEntity entity) {
  return new Records.Camera(
      entity.getId(),
      entity.getCameraName(),
      entity.getIsFilm() != null ? entity.getIsFilm() : Boolean.FALSE,
      entity.getDefaultFilmFormat());
}
```

`MetadataService.getAllCameras()` needs no change — it delegates entirely to this converter.

## 5. Repository — `dao/EquipmentRepository.java`

### Row mappers

Both `CAMERA_ROW_MAPPER` (lines 31-37) and `CAMERA_ROW_MAPPER_WITH_SERIAL` (lines 39-46) must read the new columns:

```java
.isFilm(rs.getBoolean("is_film"))
.defaultFilmFormat(
    getString(rs, "default_film_format") != null
        ? FilmFormat.valueOf(rs.getString("default_film_format"))
        : null)
```

Add `import edens.zac.portfolio.backend.types.FilmFormat;` to the file.

### SELECTs

Every SELECT using these mappers needs `is_film, default_film_format` added to the column list (and to the GROUP BY where applicable):

- Line 93 — `findCameraByBodySerialNumber`
- Line 102 — `findCameraByName`
- Line 110 — `findCameraByNameIgnoreCase`
- Line 118 — `findCamerasByNameContainingIgnoreCase`
- Line 126 — `findAllCamerasOrderByName` ← this is what powers `GET /api/read/content/cameras`
- Line 151 — `findCamerasOrderByUsageCount` (also update GROUP BY)
- Line 192 — `findCameraById`

### `saveCamera()` — INSERT + UPDATE (lines 161-188)

INSERT SQL (line ~164): add `is_film, default_film_format` to the column list and `:isFilm, :defaultFilmFormat` to the named params.

UPDATE SQL (line ~179): add `is_film = :isFilm, default_film_format = :defaultFilmFormat` to the SET clause.

The MapSqlParameterSource builder must also bind both new params from the entity.

## 6. Tests

`src/test/java/edens/zac/portfolio/backend/controller/prod/ContentControllerProdTest.java:149-150` — update existing fixtures to the 4-arg constructor (digital cameras pass `false, null`):

```java
new Records.Camera(1L, "Canon EOS R5", false, null),
new Records.Camera(2L, "Sony A7 IV", false, null),
```

Add a new film-camera fixture and assert it round-trips through `GET /api/read/content/cameras` with both new fields in the JSON:

```java
new Records.Camera(3L, "Hasselblad 500cm", true, FilmFormat.MM_120)
```

```java
.andExpect(jsonPath("$[2].isFilm").value(true))
.andExpect(jsonPath("$[2].defaultFilmFormat").value("MM_120"))
```

`ContentModelConverterTest.java` (if it covers `cameraEntityToCameraModel`) — extend a case to assert the two new fields propagate from entity to record.

## 7. Verification

```bash
# From ~/Code/edens.zac.backend
./mvnw test -Dtest=ContentControllerProdTest,ContentModelConverterTest
./mvnw verify

# After local backend restart:
curl -s http://localhost:8080/api/read/content/cameras \
  | jq '.[] | {id, name, isFilm, defaultFilmFormat}'
```

Expected: every entry has both new fields; Hasselblad 500cm shows `isFilm: true, defaultFilmFormat: "MM_120"`.

## 8. Deploy gate / frontend coordination

The frontend's auto-toggle handler (`ImageMetadataModal.tsx` `computeCameraSelectionUpdate`) is already in place on branch `0139-minor-fixes` in the `edens.zac` repo. Pre-backend, `camera.isFilm` is `undefined` and the handler falls through to today's behavior (just sets `camera`). The moment this backend ships and the API returns the new fields, the auto-toggle activates with no frontend redeploy needed.

There is therefore no coordinated cutover. Ship the backend at any time.
